# SSIAP Pro — version de démonstration

Application créée par Rochdi Mecheti.

Copie complète de SSIAP Pro destinée aux présentations. **Toutes les données sont fictives** : site (Parc Expo Valmont / Valmont Arena, Valmont-sur-Mer), client (Valmont Événements — VEV), agents, encadrement, prestataires, numéros de téléphone (plages réservées à la fiction) et adresses (domaine `.test`).

## Ce qui est automatique
- Au premier lancement : 7 comptes de test (mot de passe `demo2026`) et un jeu d'exemples (main courante, rapports, ronde, check-list, clés, bâtiment, alerte levée).
- Planning fictif recalculé autour de la date du jour (3 semaines avant, 6 semaines après) : équipe PC jour/nuit, SSIAP 1, salons au Parc une semaine sur deux, soirées à l'Arena le vendredi et le samedi.
- Aucun mail n'est envoyé.

## Comptes
| Compte | Rôle |
|---|---|
| pc@valmont.test | PC sécurité (administrateur) |
| t.garnier@valmont.test | Responsable PCS journée (administrateur) |
| l.fontaine@valmont.test | Responsable PC, rédacteur planning |
| j.moreau@valmont.test | SSIAP 3, planificateur (valide et publie) |
| agent.ssiap1@valmont.test | Agent SSIAP 1 |
| agent.ads@valmont.test | Agent ADS |
| client@valmont.test | Client, lecture seule |

Le propriétaire se connecte avec son e-mail et le mot de passe défini dans Netlify (`ADMIN_PASSWORD`).

## Mise en ligne (site Netlify séparé de l'appli réelle)
1. Créer un dépôt GitHub privé (ex. `Ssiap_pro_demo`) et y téléverser le contenu du zip.
2. Sur Netlify : Add new site → Import from GitHub → choisir ce dépôt (build automatique).
3. Variables d'environnement : `ADMIN_PASSWORD` (ton mot de passe propriétaire) et `APP_SECRET` (une longue phrase au hasard). Ne pas mettre de clé Brevo.
4. Redéployer. Les comptes et les exemples se créent à la première ouverture.
