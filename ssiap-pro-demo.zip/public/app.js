// SSIAP Pro — Application créée par Rochdi Mecheti
(() => {
const $ = (s, el = document) => el.querySelector(s);
const view = $("#view");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const ROLE_LBL = { ads: "ADS", ssiap1: "SSIAP 1", ssiap2: "SSIAP 2", ssiap3: "SSIAP 3", pc: "PC Sécurité", responsable: "Lecture 24h/24", admin: "Admin" };
const fmt = (t) => new Date(t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

let CUSTOM = {};
try { CUSTOM = JSON.parse(localStorage.getItem("ssiap-textes") || "{}"); } catch {}
const T = (k) => esc(CUSTOM[k] ?? window.TEXTES_DEFAUT[k] ?? k);
function applyChrome() {
  $("#t-titre").textContent = CUSTOM["app.titre"] ?? TEXTES_DEFAUT["app.titre"];
  $("#t-titre2").textContent = CUSTOM["app.titre2"] ?? TEXTES_DEFAUT["app.titre2"];
  $("#t-sign").textContent = CUSTOM["app.signature"] ?? TEXTES_DEFAUT["app.signature"];
  $("#t-slogan").textContent = CUSTOM["app.slogan"] ?? TEXTES_DEFAUT["app.slogan"];
  document.querySelectorAll("nav.tab a").forEach((a) => { a.lastChild.textContent = CUSTOM["nav." + (a.dataset.r || "accueil")] ?? TEXTES_DEFAUT["nav." + (a.dataset.r || "accueil")]; });
}
async function loadTextes() {
  try {
    const r = await fetch("/api/textes"); if (!r.ok) return;
    const d = await r.json(); const changed = JSON.stringify(d) !== JSON.stringify(CUSTOM);
    CUSTOM = d; try { localStorage.setItem("ssiap-textes", JSON.stringify(d)); } catch {}
    if (changed) render();
  } catch {}
}
let S = { token: null, user: null };
try { S = JSON.parse(localStorage.getItem("ssiap-pro") || "null") || S; } catch {}
const persist = () => { try { localStorage.setItem("ssiap-pro", JSON.stringify(S)); } catch {} sauverJeton(); };
// le jeton est aussi rangé pour le service worker (il vient chercher le message d'une notification push)
function sauverJeton() { try { if ("caches" in window) caches.open("ssiap-auth").then((c) => (S && S.token ? c.put("/jeton", new Response(S.token)) : c.delete("/jeton"))).catch(() => {}); } catch {} }
/* ---------- Sons : alerte (sirène deux tons) et notification (carillon) ---------- */
let AUDIO = null;
const audioOk = () => { try { AUDIO ||= new (window.AudioContext || window.webkitAudioContext)(); if (AUDIO.state === "suspended") AUDIO.resume(); } catch {} };
["pointerdown", "keydown", "touchstart"].forEach((ev) => window.addEventListener(ev, audioOk, { passive: true }));
function bip(freqs, dur, vol = 0.35, type = "square") {
  if (!AUDIO) return; const t0 = AUDIO.currentTime;
  freqs.forEach((f, i) => { const o = AUDIO.createOscillator(), g = AUDIO.createGain(); o.type = type; o.frequency.value = f;
    g.gain.setValueAtTime(0.0001, t0 + i * dur); g.gain.exponentialRampToValueAtTime(vol, t0 + i * dur + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, t0 + (i + 1) * dur - 0.02);
    o.connect(g).connect(AUDIO.destination); o.start(t0 + i * dur); o.stop(t0 + (i + 1) * dur); });
}
const sonAlerte = () => { audioOk(); bip([960, 640, 960, 640, 960, 640, 960, 640], 0.32, 0.4, "sawtooth"); if (navigator.vibrate) navigator.vibrate([400, 150, 400, 150, 800]); };
const sonNotif = () => { audioOk(); bip([880, 1320], 0.18, 0.25, "sine"); if (navigator.vibrate) navigator.vibrate([150, 80, 150]); };
async function notifSysteme(titre, texte, url) {
  try { if (!("Notification" in window) || Notification.permission !== "granted" || !document.hidden) return; const r = await navigator.serviceWorker?.ready;
    r?.showNotification(titre, { body: texte, icon: "/img/icon-192.png", badge: "/img/favicon-64.png", tag: "ssiap-loc", renotify: true, vibrate: [400, 150, 400], data: { url } }); } catch {}
}
/* ---------- Abonnement aux notifications push ---------- */
const b64ToU8 = (s) => { const p = "=".repeat((4 - (s.length % 4)) % 4), b = atob((s + p).replace(/-/g, "+").replace(/_/g, "/")); return Uint8Array.from([...b].map((c) => c.charCodeAt(0))); };
async function etatPush() {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || !("Notification" in window)) return "nonsupporte";
  if (Notification.permission === "denied") return "refuse";
  const r = await navigator.serviceWorker.ready, sub = await r.pushManager.getSubscription();
  return sub && Notification.permission === "granted" ? "actif" : "inactif";
}
async function activerPush() {
  audioOk();
  if (!("serviceWorker" in navigator) || !("PushManager" in window)) { toast(/iPhone|iPad/.test(navigator.userAgent) ? "Sur iPhone : installe d'abord l'appli sur l'écran d'accueil (Partager ➜ Sur l'écran d'accueil), puis ouvre-la depuis l'icône." : "Ce navigateur ne gère pas les notifications.", 7000); return false; }
  const perm = await Notification.requestPermission(); if (perm !== "granted") { toast("Notifications refusées : autorise-les dans les réglages du téléphone.", 6000); return false; }
  const r = await navigator.serviceWorker.ready, { cle } = await api("push/cle");
  let sub = await r.pushManager.getSubscription(); if (!sub) sub = await r.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(cle) });
  await api("push/abonner", { method: "POST", body: { subscription: sub.toJSON() } }); sauverJeton(); sonNotif(); toast("Notifications sonores activées sur ce téléphone");
  return true;
}
async function blocPush(box) {
  if (!box) return; const e = await etatPush().catch(() => "inactif");
  if (e === "actif") { box.innerHTML = ""; return; }
  box.innerHTML = `<div class="card" style="border-color:var(--g-moy,#f08a00)"><h2 style="margin-bottom:6px">Notifications sonores</h2>
    <p class="mut" style="margin:0 0 10px">${e === "refuse" ? "Les notifications sont bloquées sur ce téléphone : autorise-les dans les réglages (Notifications ➜ SSIAP Pro), puis reviens ici." : e === "nonsupporte" ? (/iPhone|iPad/.test(navigator.userAgent) ? "Sur iPhone, installe l'appli sur l'écran d'accueil (Partager ➜ Sur l'écran d'accueil) et ouvre-la depuis l'icône pour recevoir les alertes avec le son." : "Ce navigateur ne reçoit pas les notifications : utilise Chrome ou l'appli installée.") : "Active-les pour entendre les alertes (enfant perdu, faits urgents…) même quand l'appli est fermée ou le téléphone en veille."}</p>
    ${e === "inactif" ? `<button class="btn red" id="pushon">Activer les notifications sonores</button>` : ""}</div>`;
  if ($("#pushon")) $("#pushon").onclick = async () => { try { if (await activerPush()) box.innerHTML = ""; } catch (err) { toast(err.message); } };
}
const staff = () => S.user && ["pc", "responsable", "admin"].includes(S.user.role);
const admin = () => S.user && (S.user.role === "admin" || S.user.role === "responsable"); // vue administrateur (lecture de tout)
const lecture = () => !!(S.user && S.user.role === "responsable"); // accès 24h/24 en lecture seule
const proprio = () => !!(S.user && S.user.proprio);
const peutDPAE = () => !!(S.user && (S.user.proprio || S.user.role === "admin" || S.user.role === "ssiap3" || S.user.roleAgent === "ssiap3" || S.user.profilMC === "ssiap3"));
const coord = () => !!(S.user && (S.user.proprio || S.user.coord)); // coordinateur PC : numéros, adresses mail, planning // seul compte autorisé à modifier l'application

/* ================= Thème professionnel : icônes au trait et nettoyage des émojis ================= */
const ICO_P = {
  home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/><path d="M10 21v-6h4v6"/>',
  mc: '<path d="M5 3h11a2 2 0 0 1 2 2v16H7a2 2 0 0 1-2-2z"/><path d="M9 8h6M9 12h6M9 16h3"/>',
  rap: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M8 13h8M8 17h5"/>',
  alertes: '<path d="M12 3 2 20h20z"/><path d="M12 10v4"/><path d="M12 17h.01"/>',
  site: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
  rondes: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>',
  memo: '<path d="M2 5h6a4 4 0 0 1 4 4v11a3 3 0 0 0-3-3H2z"/><path d="M22 5h-6a4 4 0 0 0-4 4v11a3 3 0 0 1 3-3h7z"/>',
  plus: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  chat: '<path d="M21 12a8 8 0 0 1-11.6 7.1L4 20.5l1.4-4.6A8 8 0 1 1 21 12z"/><path d="M8.5 10.5h7M8.5 13.5h4.5"/>',
  camera: '<path d="M4 8h3l2-3h6l2 3h3a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"/><circle cx="12" cy="13.5" r="3.5"/>',
  send: '<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4z"/>',
  bell: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  sms: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  fiches: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="12" r="2"/><path d="M14 10h4M14 14h4"/>',
  planning: '<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
  notifs: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/>',
  admin: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  malaise: '<path d="M3 12h4l2-5 4 10 2-5h6"/>',
  incident: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5"/><path d="M12 16h.01"/>',
  di: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
  rixe: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14.5a5 5 0 0 1 5 5.5"/>',
  intrusion: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="M12 9v4"/><path d="M12 16h.01"/>',
  forcing: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>',
  phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.8.7 2.7a2 2 0 0 1-.5 2.1L8 9.8a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.5c.9.3 1.8.6 2.7.7a2 2 0 0 1 1.7 2z"/>',
};
const ico = (n) => `<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICO_P[n] || ICO_P.mc}</svg>`;
// Icônes des types de rapport (couleur = gravité par défaut : vert info, orange moyenne, rouge urgente)
const P_ = {
  pouls: '<path d="M3 12h4l2-5 4 10 2-5h6"/>', coeur: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/><path d="M8 12h2l1-2 2 4 1-2h2"/>',
  croix: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 8v8M8 12h8"/>', camion: '<path d="M1 6h13v10H1z"/><path d="M14 9h4l3 3v4h-7"/><circle cx="5.5" cy="18" r="2"/><circle cx="17.5" cy="18" r="2"/>',
  verre: '<path d="M7 3h10l-1 8a4 4 0 0 1-8 0z"/><path d="M12 15v6M8 21h8"/>', enfant: '<circle cx="12" cy="5" r="2.5"/><path d="M12 8v7M8 11h8M10 21l2-6 2 6"/>',
  cloche: '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10 21a2 2 0 0 0 4 0"/>', flamme: '<path d="M12 2s5 4.5 5 10a5 5 0 0 1-10 0c0-2.5 1.5-4 1.5-4S9 10 10.5 10C10.5 6 12 2 12 2z"/>',
  vent: '<path d="M3 8h11a3 3 0 1 0-3-3"/><path d="M3 12h16a3 3 0 1 1-3 3"/><path d="M3 16h7"/>', ecran: '<rect x="3" y="4" width="18" height="12" rx="2"/><path d="M8 20h8M12 16v4"/><path d="M7 8h4M7 11h6"/>',
  power: '<path d="M12 2v10"/><path d="M18.4 6.6a9 9 0 1 1-12.8 0"/>', extinct: '<path d="M9 7h6v14H9z"/><path d="M12 7V4h4"/><path d="M9 11h6"/><path d="M16 4l3 2"/>',
  porte: '<path d="M5 21V3h11v18"/><path d="M3 21h18"/><path d="M13 12h.01"/>', ascenseur: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M9 9l3-3 3 3M9 15l3 3 3-3"/>',
  check: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 12l2 2 4-4"/>', sortie: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
  groupe: '<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0 1 12 0"/><circle cx="17" cy="9" r="2.5"/><path d="M16 14.5a5 5 0 0 1 5 5.5"/>', main: '<path d="M8 13V5a1.5 1.5 0 0 1 3 0v6"/><path d="M11 10V4a1.5 1.5 0 0 1 3 0v6"/><path d="M14 10V6a1.5 1.5 0 0 1 3 0v8a6 6 0 0 1-6 6h-1a6 6 0 0 1-5-3l-2-4a1.5 1.5 0 0 1 2.6-1.5L8 13"/>',
  bulle: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M9 8l6 5M15 8l-6 5"/>', userx: '<circle cx="9" cy="8" r="4"/><path d="M2 21a7 7 0 0 1 14 0"/><path d="M17 8l5 5M22 8l-5 5"/>',
  bouclier: '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="M12 9v4M12 16h.01"/>', cadenas: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 7.5-2"/>',
  sac: '<path d="M6 7h12l1 14H5z"/><path d="M9 7a3 3 0 0 1 6 0"/>', marteau: '<path d="M15 12l-8.5 8.5a2.1 2.1 0 0 1-3-3L12 9"/><path d="M17.6 15 22 10.6 13.4 2 9 6.4z"/>',
  menottes: '<circle cx="7" cy="15" r="4"/><circle cx="17" cy="15" r="4"/><path d="M10 12l4 0M7 11V7M17 11V7"/>', oeil: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
  colis: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="M3 8l9 5 9-5M12 13v8"/>', octo: '<path d="M7.9 2h8.2L22 7.9v8.2L16.1 22H7.9L2 16.1V7.9z"/><path d="M12 8v4M12 16h.01"/>',
  voiture: '<path d="M5 17h14v-5l-2-5H7l-2 5z"/><circle cx="7.5" cy="17" r="2"/><circle cx="16.5" cy="17" r="2"/><path d="M5 12h14"/>', drone: '<circle cx="5" cy="5" r="2.5"/><circle cx="19" cy="5" r="2.5"/><circle cx="5" cy="19" r="2.5"/><circle cx="19" cy="19" r="2.5"/><path d="M7 7l3 3M17 7l-3 3M7 17l3-3M17 17l-3-3"/><rect x="10" y="10" width="4" height="4"/>',
  etiquette: '<path d="M20.6 13.4 12 22l-9-9V3h10z"/><circle cx="7.5" cy="7.5" r="1.5"/>', patte: '<circle cx="6" cy="10" r="2"/><circle cx="10" cy="6" r="2"/><circle cx="14" cy="6" r="2"/><circle cx="18" cy="10" r="2"/><path d="M8 17c0-3 2-5 4-5s4 2 4 5a2 2 0 0 1-2 2h-4a2 2 0 0 1-2-2z"/>',
  interdit: '<circle cx="12" cy="12" r="9"/><path d="M5.6 5.6l12.8 12.8"/>', archive: '<rect x="3" y="4" width="18" height="5" rx="1"/><path d="M5 9v11h14V9M10 13h4"/>',
  ticket: '<path d="M3 7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v3a2 2 0 0 0 0 4v3a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-3a2 2 0 0 0 0-4z"/><path d="M10 9l4 6M14 9l-4 6"/>',
  cle: '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3 21 2M16 7l3 3M19 4l2 2"/>', jauge: '<path d="M12 14l4-4"/><path d="M3.3 19a10 10 0 1 1 17.4 0z"/>',
  ouverte: '<path d="M13 4h3a2 2 0 0 1 2 2v14M2 20h20M13 20V4l-6 2v14"/><path d="M10 12h.01"/>', cle_molette: '<path d="M14.7 6.3a4 4 0 0 0-5.4 5.4L3 18l3 3 6.3-6.3a4 4 0 0 0 5.4-5.4l-2.6 2.6-2.4-.6-.6-2.4z"/>',
  eclair: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>', goutte: '<path d="M12 2.7s7 7.3 7 12.3a7 7 0 0 1-14 0c0-5 7-12.3 7-12.3z"/>', radio: '<rect x="6" y="7" width="12" height="15" rx="2"/><path d="M9 7l6-5M10 12h4M10 16h4"/>',
  ronde: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3"/>', releve: '<path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5M3 21v-5h5"/>',
  presse: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 3v3h6V3M9 11h6M9 15h4"/>', casque: '<path d="M4 15a8 8 0 0 1 16 0"/><path d="M2 15h20v3H2zM10 7V4h4v3"/>',
  malette: '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>', nuage: '<path d="M17.5 19H8a5 5 0 1 1 1.2-9.9A6 6 0 0 1 20 11.5a3.8 3.8 0 0 1-2.5 7.5z"/>',
  loupe: '<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>', alerte: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>', doc: '<path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/>',
};
const RAP_ICO = { malaise: "pouls", blessure: "croix", arret: "coeur", secours: "camion", ivresse: "verre", perdu: "enfant",
  alarme: "cloche", feu: "flamme", odeur: "vent", ssi: "ecran", isolement: "power", permisfeu: "flamme", extincteur: "extinct", issue: "porte", desenfumage: "vent", ascenseur: "ascenseur", exercice: "check", evacuation: "sortie",
  rixe: "groupe", agression: "main", incivilite: "bulle", harcelement: "userx", intrusion: "bouclier", forcing: "cadenas", vol: "sac", degradation: "marteau", interpellation: "menottes", suspect: "oeil", objet: "colis", menace: "octo", vehicule: "voiture", drone: "drone", rassemblement: "groupe", sauvette: "etiquette", animal: "patte",
  refus: "interdit", saisie: "archive", fraude: "ticket", livraison: "camion", cles: "cle", jauge: "jauge", ouverture: "ouverte",
  di: "cle_molette", coupure: "eclair", eau: "goutte", porte: "porte", intrusionalarme: "cloche", radio: "radio",
  ronde: "ronde", releve: "releve", consigne: "presse", travaux: "casque", prestataire: "malette", meteo: "nuage", accident: "voiture", reclamation: "bulle", trouve: "loupe", incident: "alerte", autre: "doc" };
let RAP_GRAV = null;
const icoRap = (k) => { if (!RAP_GRAV) { RAP_GRAV = {}; (window.RAP_CATS || []).forEach((c) => c.types.forEach((t) => (RAP_GRAV[t.k] = t.grav || "info"))); }
  return `<svg class="ric g-${RAP_GRAV[k] || "info"}" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P_[RAP_ICO[k]] || P_.doc}</svg>`; };
const DOTS = { "🟢": "ok", "🔴": "rouge", "🟠": "orange", "🟡": "jaune", "🟨": "jaune", "🟥": "rouge", "⚪": "vide", "⚫": "gris", "🔵": "bleu" };
const GARDER = new Set(["✕", "✔", "✖", "➜", "☰", "⟲", "➕", "➖", "❤", "↩", "↳", "•", "→"]);
const RE_EMO = /(?:[\u{1F1E6}-\u{1F1FF}]{2}|\p{Extended_Pictographic})(?:️|︎|‍\p{Extended_Pictographic}️?)*[  ]?/gu;
function proTexte(node) {
  const t = node.nodeValue; if (!t || !RE_EMO.test(t)) return; RE_EMO.lastIndex = 0;
  const p = node.parentNode; if (!p || p.closest?.("svg,textarea,script,style,[data-brut]")) return;
  const simple = p.tagName === "OPTION" || p.tagName === "TITLE";
  let html = "", plain = "", dots = false, last = 0, mm;
  const esc2 = (s) => s.replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  while ((mm = RE_EMO.exec(t))) {
    const seg = t.slice(last, mm.index); html += esc2(seg); plain += seg; last = mm.index + mm[0].length;
    const e = mm[0].replace(/[️︎  ]/g, "");
    if (GARDER.has(e[0]) && e.length <= 2) { html += esc2(mm[0]); plain += mm[0]; }
    else if (DOTS[e] && !simple) { html += `<i class="dot dot-${DOTS[e]}"></i>`; dots = true; }
  }
  html += esc2(t.slice(last)); plain += t.slice(last);
  if (dots) { const s = document.createElement("span"); s.className = "txt"; s.innerHTML = html; p.replaceChild(s, node); }
  else if (plain !== t) node.nodeValue = plain.replace(/^\s+(?=\S)/, (x) => (node.previousSibling ? x : ""));
}
function proNoeud(root) {
  if (!root) return;
  if (root.nodeType === 3) return proTexte(root);
  if (root.nodeType !== 1 || root.closest("svg")) return;
  root.querySelectorAll?.("[data-ico]").forEach((s) => { if (!s.firstChild || s.firstChild.nodeType !== 1) s.innerHTML = ico(s.dataset.ico); });
  root.querySelectorAll?.("a.tile[data-k] > span:first-child, a.tile[data-rk] > span:first-child").forEach((s) => { if (!s.querySelector("svg")) s.innerHTML = icoRap(s.parentNode.dataset.k || s.parentNode.dataset.rk); });
  root.querySelectorAll?.("a.tile > span:first-child").forEach((s) => { if (!s.querySelector("svg")) { const t = s.parentNode, r = t.dataset.rk || (t.getAttribute("href") || "").replace("#/", "").split(/[?/]/)[0] || "home"; s.innerHTML = ico(r); } });
  root.querySelectorAll?.(".call .ic").forEach((s) => { if (!s.querySelector("svg")) s.innerHTML = ico("phone"); });
  const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT); const l = []; while (w.nextNode()) l.push(w.currentNode); l.forEach(proTexte);
}
new MutationObserver((ms) => { for (const m of ms) { if (m.type === "characterData") proTexte(m.target); else m.addedNodes.forEach(proNoeud); } })
  .observe(document.body, { childList: true, subtree: true, characterData: true });
proNoeud(document.body);

function toast(msg, ms = 2600) {
  const t = document.createElement("div"); t.className = "toast"; t.textContent = msg;
  document.body.appendChild(t); setTimeout(() => t.remove(), ms);
}
async function api(path, opts = {}) {
  const r = await fetch("/api/" + path, {
    method: opts.method || "GET",
    headers: { "content-type": "application/json", ...(S.token ? { authorization: "Bearer " + S.token } : {}), ...(CONTACTS && CONTACTS.exp > Date.now() ? { "x-contacts": CONTACTS.token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const d = await r.json().catch(() => ({}));
  if (r.status === 401 && path !== "login") { logout(); throw new Error(d.error || "Session expirée"); }
  if (r.status === 403 && d.hors && path !== "login" && path !== "inscription") { MSG_HORS = d.error; if (S.user && !S.user.hors) { S.user.hors = true; persist(); setTimeout(render, 0); } throw new Error(d.error); }
  if (r.status === 423 && d.verrou) { CONTACTS = null; const e = new Error(d.error); e.verrou = true; throw e; }
  if (!r.ok) { const e = new Error(d.error || "Erreur " + r.status); e.data = d; throw e; }
  return d;
}
let CONTACTS = null;
let MES_VACS = null; // planning personnel affiché sur l'écran de connexion hors vacation
let MSG_HORS = ""; // message affiché sur l'écran de connexion quand l'agent est hors vacation
window.__lock = () => { CONTACTS = null; toast("🔒 Contacts verrouillés"); location.hash = "#/"; }; // déverrouillage des contacts, gardé en mémoire seulement (se reverrouille à la fermeture)
function logout() { try { navigator.serviceWorker?.ready.then((r) => r.pushManager.getSubscription()).then((sub) => { if (sub && S.token) api("push/abonner", { method: "DELETE", body: { subscription: sub.toJSON() } }).catch(() => {}); }); } catch {}
  clearInterval(notifTimer); notifTimer = null; $("#bell").classList.add("hidden"); S = { token: null, user: null }; CONTACTS = null; persist(); location.hash = "#/"; render(); }
// Écran « code d'accès » devant les pages qui contiennent des numéros
async function withCode(fn) {
  try { return await fn(); }
  catch (e) {
    if (!e.verrou) throw e;
    view.innerHTML = `<div class="card login"><h2>🔐 Accès protégé</h2>
      <p class="mut">Les contacts des agents sont réservés aux personnes habilitées. Entre le code d'accès.</p>
      <form id="fc"><input name="code" type="password" autocomplete="off" required placeholder="Code d'accès">
      <button class="btn red" style="margin-top:12px">Déverrouiller</button></form>
      <p class="mut">Déverrouillé pour 4 h sur ce téléphone, ou jusqu'à la fermeture de l'appli.</p></div>`;
    $("#fc").onsubmit = async (ev) => {
      ev.preventDefault();
      try { CONTACTS = await api("deverrouiller", { method: "POST", body: { code: ev.target.code.value } }); render(); }
      catch (err) { toast(err.message); ev.target.code.value = ""; }
    };
  }
}
$("#logout").onclick = logout;

/* ================= Connexion ================= */
function vLogin() {
  view.innerHTML = `<div class="login card">
    <h2>${T("login.titre")}</h2>
    <p class="mut">${T("login.texte")}</p>
    ${MSG_HORS ? `<div class="alerte orange" style="margin-bottom:10px">🕑 ${esc(MSG_HORS)}</div>` : ""}
    ${MES_VACS ? `<div style="margin-bottom:12px"><h3 style="margin:6px 0">📅 Mon planning</h3>${htmlMonPlanning(MES_VACS)}</div>` : ""}
    <form id="f">
      <label>Adresse e-mail</label><input name="email" type="text" inputmode="email" autocomplete="username" autocapitalize="none" required>
      <label>Mot de passe</label><input name="mdp" type="password" autocomplete="current-password" required>
      <div style="height:14px"></div><button class="btn red">${T("login.bouton")}</button>
    </form>
    <button class="btn sm" id="oubli" style="margin-top:12px;width:100%;background:none;border:0;color:var(--mut)">Mot de passe oublié ?</button></div>
    <div class="card login" style="text-align:center"><p style="margin:0 0 10px">Agent de sécurité, pas encore de compte ?</p>
      <button class="btn" id="inscr">🆕 Créer mon compte</button>
      <p class="mut" style="margin:8px 0 0">Accès complet pendant tes vacations. En dehors : ton planning et tes disponibilités.</p></div>
    <div class="foot">${T("pied")}</div>`;
  view.insertAdjacentHTML("afterbegin", `<div class="card demo-card"><div class="psur">Version de démonstration</div><h2 style="margin:2px 0 6px">Comptes de test</h2>
    <p class="mut" style="margin-top:0">Toutes les données sont fictives : site, client, agents, prestataires et numéros. Mot de passe pour tous : <b style="color:var(--txt)">demo2026</b>. Touche un compte pour le remplir.</p>
    <div class="demo-cpt">${[["pc@valmont.test", "PC sécurité", "administrateur"], ["t.garnier@valmont.test", "Thomas Garnier", "responsable PCS · admin"], ["l.fontaine@valmont.test", "Lucas Fontaine", "responsable PC · planification"],
      ["j.moreau@valmont.test", "Julien Moreau", "SSIAP 3 · planificateur"], ["agent.ssiap1@valmont.test", "Camille Leroy", "agent SSIAP 1"], ["agent.ads@valmont.test", "Yanis Morel", "agent ADS"], ["client@valmont.test", "Client VEV", "lecture seule"]]
      .map(([e, n, r]) => `<button type="button" data-demo="${e}"><b>${n}</b><span>${r}</span></button>`).join("")}</div></div>`);
  view.querySelector(".demo-cpt").onclick = (e) => { const b = e.target.closest("[data-demo]"); if (!b) return; const f = $("#f"); f.elements.email.value = b.dataset.demo; f.elements.mdp.value = "demo2026"; f.scrollIntoView({ behavior: "smooth" }); };
  $("#f").onsubmit = async (e) => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(e.target));
    try { const d = await api("login", { method: "POST", body: fd }); MSG_HORS = d.message || ""; MES_VACS = null; S = { token: d.token, user: d.user }; persist(); location.hash = "#/"; render(); }
    catch (err) { if (err.data?.hors || /vacation|planning/i.test(err.message)) { MSG_HORS = err.message; MES_VACS = err.data?.planning || null; vLogin(); } else toast(err.message); }
  };
  $("#inscr").onclick = vInscription;
  $("#oubli").onclick = () => {
    view.innerHTML = `<div class="login card"><h2>🔑 Mot de passe oublié</h2>
      <form id="r1"><label>Ton adresse e-mail</label><input name="email" type="email" required autocapitalize="none">
      <button class="btn red" style="margin-top:12px">Recevoir un code par mail</button></form>
      <form id="r2" class="hidden"><p class="mut">Si un compte existe, un code à 6 chiffres vient d'être envoyé (pense à regarder dans les spams).</p>
      <label>Code reçu</label><input name="code" inputmode="numeric" required>
      <label>Nouveau mot de passe (6 caractères min.)</label><input name="mdp" type="password" minlength="6" required autocomplete="new-password">
      <button class="btn red" style="margin-top:12px">Valider</button></form>
      <button class="btn sm" id="back" style="margin-top:12px;width:100%;background:none;border:0;color:var(--mut)">← Retour</button></div>`;
    let email = "";
    $("#back").onclick = vLogin;
    $("#r1").onsubmit = async (e) => { e.preventDefault(); email = e.target.email.value;
      try { await api("reset", { method: "POST", body: { email } }); $("#r1").classList.add("hidden"); $("#r2").classList.remove("hidden"); } catch (err) { toast(err.message); } };
    $("#r2").onsubmit = async (e) => { e.preventDefault();
      try { await api("reset", { method: "POST", body: { email, code: e.target.code.value, mdp: e.target.mdp.value } }); toast("✅ Mot de passe changé, connecte-toi"); vLogin(); } catch (err) { toast(err.message); } };
  };
}

/* ================= Inscription agent (code d'accès obligatoire) ================= */
function vInscription() {
  view.innerHTML = `<div class="login card"><h2>🆕 Créer mon compte agent</h2>
    <p class="mut">Tout le monde peut créer son compte. L'accès à l'appli n'est possible <b>que pendant tes vacations</b> au planning (1 h avant à 1 h après).</p>
    <form id="fi">
      <div class="row"><div><label>Prénom</label><input name="prenom" required autocomplete="given-name"></div>
        <div><label>Nom</label><input name="nom" required autocomplete="family-name"></div></div>
      <label>Adresse e-mail (ton identifiant)</label><input name="email" type="email" required autocapitalize="none" autocomplete="email">
      <label>Téléphone portable</label><input name="tel" type="tel" required autocomplete="tel">
      <label>Qualification</label><select name="role"><option value="ads">Agent de sécurité (ADS)</option><option value="ssiap1">SSIAP 1</option><option value="ssiap2">SSIAP 2</option><option value="ssiap3">SSIAP 3</option></select>
      <label>Choisis un mot de passe (6 caractères min.)</label><input name="mdp" type="password" minlength="6" required autocomplete="new-password">
      <label>Code PIN responsable (laisse vide si tu es agent)</label><input name="code" type="text" inputmode="numeric" autocomplete="off" autocorrect="off" spellcheck="false">
      <button class="btn red" style="margin-top:14px">Créer mon compte</button>
    </form>
    <button class="btn sm" id="back" style="margin-top:12px;width:100%;background:none;border:0;color:var(--mut)">← Retour à la connexion</button></div>`;
  $("#back").onclick = vLogin;
  $("#fi").onsubmit = async (e) => {
    e.preventDefault(); const btn = e.submitter; btn.disabled = true;
    try {
      const d = await api("inscription", { method: "POST", body: Object.fromEntries(new FormData(e.target)) });
      MSG_HORS = d.message || ""; S = { token: d.token, user: d.user }; persist(); toast("✅ Compte créé, bienvenue !"); location.hash = "#/"; render();
    }
    catch (err) { toast(err.message, 4000); btn.disabled = false; }
  };
}

/* ================= Accueil ================= */
const WICON = (c) => c >= 95 ? "⛈️" : c >= 71 && c <= 86 ? "🌨️" : c >= 51 ? "🌧️" : c >= 45 ? "🌫️" : c >= 3 ? "☁️" : c >= 1 ? "⛅" : "☀️";
async function vHome() {
  setTimeout(() => blocPush($("#pushbox")), 0);
  view.innerHTML = `<div id="pushbox"></div>${S.user.planif || S.user.voitPlanif ? `<a class="btn${S.user.planif ? " red" : ""}" href="#/planif" style="margin-top:14px">Planification · planning, devis, tarifs</a>` : ""}
  ${proprio() ? `<a class="btn" href="#/docs" style="margin-top:14px">✍️ Rédaction : téléverser un document</a>` : ""}
  ${staff() ? `<div class="grid2" style="margin-top:14px"><a class="btn" href="#/monplanning">📅 Mon planning</a><a class="btn" href="#/plangen">🗓️ Planning général</a><a class="btn" href="#/dispos-admin">🙋 Disponibilités</a><a class="btn" href="#/cles">🔑 Clés</a><a class="btn" href="#/materiel">📦 Matériel</a><a class="btn" href="#/batiments">🏢 Bâtiments</a></div>` : ""}
  ${S.user.coordArena ? `<a class="btn red" href="#/equipe" style="display:block;text-align:center;text-decoration:none;margin-top:14px">🏟️ Mon équipe ADS Arena par groupe</a>` : ""}
  ${staff() ? `<a class="btn red" href="#/direct" style="display:block;text-align:center;text-decoration:none;margin-top:14px">🔴 Voir en direct ce qui se passe</a>` : ""}
  ${staff() ? `<a class="btn" href="#/fil" style="margin-top:10px">📜 Fil de l'eau Parc / Arena</a>` : ""}
  ${lecture() ? `<div class="alerte" style="margin-top:12px;border-color:var(--ok)">👁️ Accès en <b>lecture seule</b>, 24 h / 24 : tu vois tout ce qui se passe, sans rien modifier${S.user.redac ? ", sauf téléverser les documents du PC sécurité" : ""}.</div>
    ${S.user.redac ? `<a class="btn red" href="#/docs" style="margin-top:10px">✍️ Rédaction : téléverser un document</a>` : ""}
    ${S.user.coord ? `<a class="btn" href="#/coord" style="margin-top:10px">🗂️ Coordination PC : numéros, mails, planning</a>` : ""}
    <div class="grid2" style="margin-top:10px"><a class="btn" href="#/docs">📂 Documents</a><a class="btn" href="#/rap">📋 Rapports</a></div>` : blocRapide()}
  <div class="card"><h2>${T("accueil.appels")}</h2><div id="calls" class="grid2" style="grid-template-columns:1fr"></div>
    <p class="mut" style="margin:10px 0 0">Les numéros ne sont jamais affichés dans l'appli.</p></div>
  <div class="card" id="meteo"><h2>${T("accueil.meteo")}</h2><p class="mut">Chargement…</p></div>
  <div class="card"><h2>${T("accueil.urgence")}</h2><div class="urg">
    <a class="f" href="tel:18">18<small>Pompiers</small></a><a class="f" href="tel:15">15<small>SAMU</small></a>
    <a class="f" href="tel:17">17<small>Police</small></a><a class="f" href="tel:112">112<small>Europe</small></a>
    <a href="sms:114">114<small>SMS sourds</small></a></div></div>
  <div class="tiles">
    <a class="tile" href="#/mc"><span>📝</span>${T("tuile.incidents")}</a>
    <a class="tile" href="#/rondes"><span>🔦</span>${T("tuile.rondes")}</a>
    <a class="tile" href="#/site"><span>🏟️</span>${T("tuile.site")}</a>
    <a class="tile" href="#/memo"><span>📘</span>${T("tuile.memo")}</a>
    ${staff() ? `<a class="tile" href="#/sms"><span>💬</span>${T("tuile.sms")}</a><a class="tile" href="#/fiches"><span>🪪</span>${T("tuile.fiches")}</a><a class="tile" href="#/planning"><span>🗓️</span>${T("tuile.planning")}</a>` : ""}
    ${admin() ? `<a class="tile" href="#/notifs"><span>🔔</span>${T("tuile.notifs")}</a>${proprio() ? `<a class="tile" href="#/admin"><span>⚙️</span>${T("tuile.admin")}</a>` : ""}` : ""}
  </div>
  <div class="foot">${T("pied")}</div>`;
  loadCalls(); loadMeteo(); brancherRapide();
}
async function loadCalls() {
  try {
    const list = await api("contacts");
    $("#calls").innerHTML = list.map((c) => `<button class="btn call" data-id="${esc(c.id)}" ${c.dispo ? "" : "disabled"}>
      <span class="ic">📞</span><span><span class="nm">${T("accueil.appeler")} ${esc(c.nom)}</span><span class="fn">${esc(c.fonction)}${c.dispo ? "" : " — numéro à configurer"}</span></span></button>`).join("");
    $("#calls").onclick = async (e) => {
      const b = e.target.closest("[data-id]"); if (!b) return;
      b.disabled = true;
      try { const d = await api("appel", { method: "POST", body: { id: b.dataset.id } }); location.href = d.href; }
      catch (err) { toast(err.message); } finally { setTimeout(() => (b.disabled = false), 1500); }
    };
  } catch (e) { $("#calls").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}
async function loadMeteo() {
  const box = $("#meteo");
  try {
    const m = await api("meteo"), h0 = m.heures[0];
    box.innerHTML = `<h2>${T("accueil.meteo")}</h2>
      <div class="meteo-now"><div><div class="temp">${WICON(h0.code)} ${Math.round(h0.temp)}°</div>
        <div class="mut">Ressenti ${Math.round(h0.ress)}° · vent ${Math.round(h0.vent)} km/h · rafales ${Math.round(h0.rafales)} km/h</div></div></div>
      ${m.alertes.length ? m.alertes.map((a) => `<div class="alerte ${a.niveau}"><span class="badge ${a.niveau}">${a.niveau}</span>
        <b> ${esc(a.titre)}</b>${a.heure ? ` · vers ${a.heure}` : ""}<div class="mut">${esc(a.detail)}</div></div>`).join("")
        : `<div class="alerte" style="border-color:var(--ok)">✅ Aucune alerte sur les 12 prochaines heures</div>`}
      <div class="hours">${m.heures.map((x) => `<div>${x.h}<b>${WICON(x.code)} ${Math.round(x.temp)}°</b>💨${Math.round(x.rafales)}${x.pluie ? `<br>💧${x.pluie}` : ""}</div>`).join("")}</div>
      <p class="mut" style="margin:6px 0 0">Mise à jour ${fmt(m.at)} · alertes envoyées par mail à la liste de diffusion</p>`;
  } catch (e) { box.innerHTML = `<h2>🌦️ Météo</h2><p class="mut">Indisponible : ${esc(e.message)}</p>`; }
}

/* ================= Main courante ================= */
const CATS = ["Prise de service", "Fin de service", "Incident", "Malaise", "DI – défaut technique / anomalie", "Événement", "Information / consigne", "Ouverture / fermeture site", "Accès / contrôle entrée", "Refus d'entrée", "Objet interdit / saisie",
  "Mouvement de foule", "Personne en état d'ivresse", "Enfant / personne perdue", "Évacuation", "Visite organisateur / commission", "Alarme incendie / levée de doute", "Départ de feu", "Secours à personne", "Intrusion", "Vol / dégradation",
  "Colis suspect", "Altercation / rixe", "Problème technique", "Ascenseur", "Météo", "Ronde — anomalie", "Accès / contrôle", "Autre"];
function compress(file) {
  return new Promise((res, rej) => {
    const img = new Image(), url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, 1280 / Math.max(img.width, img.height));
      const c = document.createElement("canvas"); c.width = img.width * k; c.height = img.height * k;
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      res(c.toDataURL("image/jpeg", 0.7));
    };
    img.onerror = rej; img.src = url;
  });
}
/* ================= Main courante électronique — événementiel ================= */
const SITES_EV = ["Parc Expo Valmont", "Valmont Arena", "Parc Expo Valmont + Arena"];
const TYPES_EV = ["T — Salon / exposition", "L — Spectacle / concert", "L — Congrès / réunion", "X — Sportif", "CTS / plein air", "Mixte", "Autre"];
const nowLocal = () => { const d = new Date(); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };
let MC = { ev: null, mois: "", evs: [], list: [], filtre: { q: "", statut: "", grav: "" } };
try { MC.ev = localStorage.getItem("ssiap-ev") || null; } catch {}

let PRESTA = null;
const prestaSeuls = () => Object.fromEntries(Object.entries(PRESTA || {}).filter(([g]) => !/^clients?$/i.test(g.trim()))); // le client (VEV) n'est pas un prestataire
async function chargerPresta() { if (!PRESTA) PRESTA = await api("prestataires").catch(() => ({})); return PRESTA; }
async function vMC() {
  await chargerZones(); await chargerPresta();
  MC.evs = await api("evenements").catch(() => []);
  const actifs = MC.evs.filter((e) => e.statut !== "clos");
  if (MC.ev && !MC.evs.some((e) => e.id === MC.ev)) MC.ev = null;
  view.innerHTML = `
  <div class="card">
    <div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2 style="margin:0">${T("mc.titre")}</h2>
      ${staff() && !lecture() ? `<button class="btn sm" id="evnew">＋ Événement</button>` : ""}</div>
    <label>Événement</label>
    <select id="evsel"><option value="">— Hors événement / exploitation courante —</option>
      ${(staff() ? MC.evs : actifs).map((e) => `<option value="${e.id}" ${e.id === MC.ev ? "selected" : ""}>${e.statut === "clos" ? "🔒 " : ""}${esc(e.nom)}${e.site ? " · " + esc(e.site) : ""}</option>`).join("")}
    </select>
    <div id="evinfo"></div>
    <div id="evform"></div>
  </div>

  <div class="card" data-action><h2>${T("incident.titre")}</h2><form id="f">
    <label>Main courante du poste</label><div class="seg" id="mcposte" style="flex-wrap:wrap">${[...window.MC_POSTES.map((p) => [p.k, p.lb]), ["general", "📝 Général"]].map(([k, l]) => `<button type="button" data-p="${k}" style="flex:1 1 45%">${l}</button>`).join("")}</div>
    <div class="row"><div><label>Heure du fait</label><input type="datetime-local" name="heure" value="${nowLocal()}"></div></div>
    <div id="mccat"></div>
    <div id="mcacces"></div>
    <label>Gravité</label><div class="seg" id="grav"><button type="button" data-g="info" class="on">Info</button><button type="button" data-g="moyenne">Moyenne</button><button type="button" data-g="urgente">🚨 Urgente</button></div>
    ${htmlLieu("mcl")}<datalist id="lieux"></datalist>
    <label>Faits constatés</label><textarea name="description" required placeholder="Qui, quoi, où, comment : uniquement des faits."></textarea>
    <label>Prestataire concerné (facultatif)</label><select name="prestataire"><option value="">— Aucun —</option>
      ${Object.entries(prestaSeuls()).map(([g, l]) => `<optgroup label="${esc(g)}">${l.map((x) => `<option>${esc(x)}</option>`).join("")}</optgroup>`).join("")}</select>
    <label>Intervenants (agents, secours, police, organisateur…)</label><input name="intervenants">
    <label>Actions menées</label><textarea name="actions" style="min-height:70px"></textarea>
    <div class="row" style="margin-top:12px">
      <label class="btn" style="margin:0;text-align:center;color:var(--txt)">📷 Ajouter une photo<input type="file" accept="image/*" capture="environment" id="ph" hidden></label>
      <button type="button" class="btn" id="geo">📍 Position</button></div>
    <div id="prev" style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px"></div><p class="mut" style="margin:4px 0 0">4 photos maximum, envoyées au PC avec la saisie.</p><p id="gpsinfo" class="mut"></p>
    <label style="display:flex;gap:10px;align-items:center;color:var(--txt)"><input type="checkbox" name="clos" style="width:22px;height:22px;flex:none"> Fait réglé (clos à la saisie)</label>
    <button class="btn red" style="margin-top:10px">${T("incident.bouton")}</button>
    <p class="mut">Numéro, date et heure de saisie sont ajoutés automatiquement. Une gravité « urgente » envoie aussi un mail à la liste de diffusion.</p>
  </form></div>

  <div class="card">
    <div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2 style="margin:0">${staff() ? "📋 Main courante" : { arena: "📋 Main courante PCS Arena", p3: "📋 Main courante P3", portail: "📋 Main courante portail" }[S.user.perimetre] || "📋 Mes saisies"}</h2>
      ${staff() ? `<span style="display:flex;gap:6px"><a class="btn sm" href="#/mc-archives" style="text-decoration:none">📦 Archives</a><button class="btn sm red" id="rapport">📄 Rapport</button></span>` : ""}</div>
    ${staff() ? `<select id="fm" style="margin-top:10px"><option value="">Mois en cours et précédent</option></select>` : ""}
    <div class="row" style="margin-top:10px"><input id="fq" placeholder="Rechercher…" value="${esc(MC.filtre.q)}">
      <select id="fs" style="flex:0 0 110px"><option value="">Statut</option><option>ouvert</option><option>en cours</option><option>clos</option></select>
      <select id="fg" style="flex:0 0 110px"><option value="">Gravité</option><option>info</option><option>moyenne</option><option>urgente</option></select></div>
    <div id="stats" class="mut" style="margin-top:8px"></div>
    <div id="list"><p class="mut">Chargement…</p></div></div>`;

  brancherLieu("mcl");
  try { const L = JSON.parse(sessionStorage.getItem("ssiap-lieu") || "null"); if (L) { sessionStorage.removeItem("ssiap-lieu"); $("#mcl-site").value = L.site; $("#mcl-site").onchange(); if (L.zone) $("#mcl-zone").value = L.zone; } } catch {}
  $("#fs").value = MC.filtre.statut; $("#fg").value = MC.filtre.grav;
  $("#evsel").onchange = (e) => { MC.ev = e.target.value || null; try { MC.ev ? localStorage.setItem("ssiap-ev", MC.ev) : localStorage.removeItem("ssiap-ev"); } catch {} drawEvInfo(); loadMC(); };
  if ($("#evnew")) $("#evnew").onclick = () => evForm(null);
  drawEvInfo();

  let photos = [], gps = null, grav = "info";
  $("#grav").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; grav = b.dataset.g; [...$("#grav").children].forEach((x) => x.classList.toggle("on", x === b)); };
  const setGrav = (g) => { grav = g; [...$("#grav").children].forEach((x) => x.classList.toggle("on", x.dataset.g === g)); };
  // Main courante imposée par le poste du planning (l'administrateur, le PC et le SSIAP 2 du PC Parc gardent toutes les mains courantes)
  const IMPOSE = staff() ? "" : S.user.profilMC || { arena: "pcsarena", p3: "p3", portail: "portail" }[S.user.perimetre || ""] || "";
  let posteMC = null; try { posteMC = localStorage.getItem("ssiap-mcposte"); } catch {}
  if (IMPOSE) posteMC = IMPOSE; else if (!posteMC) posteMC = S.user.perimetre === "pcparc" ? "ssiap2" : "general";
  if (IMPOSE) [...$("#mcposte").children].forEach((b) => (b.style.display = b.dataset.p === IMPOSE ? "" : "none"));
  const PERIM_TXT = { arena: "🏟️ Tu es au <b>PCS Arena</b> : tu vois et gères les événements de l'Arena.", p3: "🚧 Tu es au <b>poste P3</b> : tu vois et gères les saisies du P3.", portail: "🚪 Tu es au <b>portail prestataires</b> : tu vois et gères les saisies du portail.", pcparc: "🖥️ Tu es <b>SSIAP 2 au PC Parc</b> : tu vois et gères l'intégralité des événements." }[S.user.perimetre || ""];
  const PMC = window.MC_POSTES.find((x) => x.k === IMPOSE);
  if (IMPOSE && PMC && !PERIM_TXT) $("#mcposte").insertAdjacentHTML("beforebegin", `<div class="alerte" style="border-color:var(--ok);margin-bottom:6px">📅 Main courante de ton poste au planning : <b>${esc(PMC.lb)}</b>${S.user.postePlanning ? ` (${esc(S.user.postePlanning)})` : ""}.</div>`);
  if (PERIM_TXT) $("#mcposte").insertAdjacentHTML("beforebegin", `<div class="alerte" style="border-color:var(--ok);margin-bottom:6px">${PERIM_TXT}</div>`);
  const PRIO_COL = { 1: "#22b573", 2: "#e83e8c", 3: "#f39c12", 4: "#e3002b" };
  const dessinerPoste = () => {
    [...$("#mcposte").children].forEach((x) => x.classList.toggle("on", x.dataset.p === posteMC));
    const P = window.MC_POSTES.find((x) => x.k === posteMC);
    if (!P) { $("#mccat").innerHTML = `<label>Catégorie</label><select name="categorie">${CATS.map((c) => `<option>${c}</option>`).join("")}</select>`; $("#mcacces").innerHTML = ""; return; }
    const fams = Object.keys(P.familles);
    $("#mccat").innerHTML = `<div class="row"><div><label>Famille</label><select name="famille" id="mcfam">${fams.map((f) => `<option>${esc(f)}</option>`).join("")}</select></div></div>
      <label>Type</label><select name="categorie" id="mctype"></select><div id="mcprio" class="mut" style="margin-top:4px"></div>`;
    const typer = () => { const l = P.familles[$("#mcfam").value] || [];
      $("#mctype").innerHTML = l.map(([t, p]) => `<option value="${esc(t)}" data-p="${p}">${p} · ${esc(t)}</option>`).join(""); prio(); };
    const prio = () => { const o = $("#mctype").selectedOptions[0]; if (!o) return; const p = +o.dataset.p;
      $("#mcprio").innerHTML = `<b style="display:inline-block;width:22px;height:22px;border-radius:50%;background:${PRIO_COL[p]};color:#fff;text-align:center;line-height:22px">${p}</b> priorité ${p} sur 4`; setGrav(window.MC_PRIO_GRAV(p)); };
    $("#mcfam").onchange = typer; $("#mctype").onchange = prio; typer();
    $("#mcacces").innerHTML = P.acces ? `<div class="row"><div><label>Société / prestataire</label><input name="societe" list="mcpresta" placeholder="facultatif"></div><div><label>Immatriculation</label><input name="immat" placeholder="facultatif" autocapitalize="characters"></div></div>
      <datalist id="mcpresta">${Object.values(prestaSeuls()).flat().map((x) => `<option>${esc(x)}</option>`).join("")}</datalist>` : "";
  };
  $("#mcposte").onclick = (e) => { const b = e.target.closest("[data-p]"); if (!b) return; posteMC = b.dataset.p; try { localStorage.setItem("ssiap-mcposte", posteMC); } catch {} dessinerPoste(); };
  dessinerPoste();
  try { const c = sessionStorage.getItem("ssiap-cat"); if (c) { sessionStorage.removeItem("ssiap-cat"); if (![...$("#f [name=categorie]").options].some((x) => x.value === c)) { posteMC = "general"; dessinerPoste(); } $("#f [name=categorie]").value = c;
    if (c === "Malaise") $("#grav [data-g=moyenne]").click(); $("#mcl-zone").focus(); } } catch {}
  const prevPh = () => ($("#prev").innerHTML = photos.map((p, i) => `<div style="position:relative"><img src="${p}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px"><button type="button" data-rm="${i}" style="position:absolute;top:2px;right:2px;border:0;border-radius:50%;width:22px;height:22px">✕</button></div>`).join(""));
  $("#ph").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; if (photos.length >= 4) return toast("4 photos maximum"); photos.push(await compress(f)); e.target.value = ""; prevPh(); };
  $("#prev").onclick = (e) => { const b = e.target.closest("[data-rm]"); if (b) { photos.splice(+b.dataset.rm, 1); prevPh(); } };
  $("#geo").onclick = () => navigator.geolocation?.getCurrentPosition(
    (p) => { gps = { lat: p.coords.latitude, lon: p.coords.longitude }; $("#gpsinfo").textContent = `📍 Position ajoutée (±${Math.round(p.coords.accuracy)} m)`; },
    () => toast("Position refusée ou indisponible"), { enableHighAccuracy: true, timeout: 10000 });
  $("#f").onsubmit = async (e) => {
    e.preventDefault(); const btn = e.submitter; btn.disabled = true;
    const fd = Object.fromEntries(new FormData(e.target));
    try {
      const L = lireLieu("mcl"); if (!L.lieu) { btn.disabled = false; return toast("Choisis la zone"); }
      const inc = await api("incidents", { method: "POST", body: { ...fd, ...L, clos: !!fd.clos, gravite: grav, photos, gps, evenementId: MC.ev, poste: posteMC } });
      toast(`✅ ${inc.numero} enregistré`); vMC();
    } catch (err) { toast(err.message); btn.disabled = false; }
  };
  const refilter = () => { MC.filtre = { q: $("#fq").value, statut: $("#fs").value, grav: $("#fg").value }; drawMC(); };
  $("#fq").oninput = refilter; $("#fs").onchange = refilter; $("#fg").onchange = refilter;
  if ($("#rapport")) $("#rapport").onclick = rapportMC;
  if ($("#fm")) { api("incidents/mois").then((d) => { $("#fm").innerHTML += d.mois.map((x) => `<option value="${x.mois}" ${x.mois === MC.mois ? "selected" : ""}>📦 ${esc(nomMoisC(x.mois))} (${x.nb})</option>`).join(""); }).catch(() => {});
    $("#fm").onchange = (e) => { MC.mois = e.target.value; loadMC(); }; }
  loadMC();
}
function drawEvInfo() {
  const e = MC.evs.find((x) => x.id === MC.ev), box = $("#evinfo");
  if (!e) { box.innerHTML = ""; return; }
  box.innerHTML = `<div class="alerte" style="border-color:${e.statut === "clos" ? "var(--mut)" : "var(--red)"};margin-top:10px">
    <b>${esc(e.nom)}</b> ${e.statut === "clos" ? `<span class="badge clos">clôturé</span>` : `<span class="badge ouvert">en cours</span>`}
    <div class="mut">${[e.site, e.lieux, e.type, e.organisateur && "Orga : " + e.organisateur, e.effectif && "Effectif : " + e.effectif, e.debut && "Du " + fmt(e.debut), e.fin && "au " + fmt(e.fin)].filter(Boolean).map(esc).join(" · ")}</div>
    ${staff() && !lecture() ? `<div class="row" style="margin-top:8px"><button class="btn sm" id="evedit">✏️ Modifier</button>
      <button class="btn sm" id="evtoggle">${e.statut === "clos" ? "Rouvrir" : "🔒 Clôturer"}</button></div>` : ""}</div>`;
  if (staff() && !lecture()) {
    $("#evedit").onclick = () => evForm(e);
    $("#evtoggle").onclick = async () => {
      if (e.statut !== "clos" && !confirm("Clôturer l'événement ? Plus aucune saisie possible dessus.")) return;
      try { await api("evenements/" + e.id, { method: "PUT", body: { statut: e.statut === "clos" ? "ouvert" : "clos" } }); vMC(); } catch (err) { toast(err.message); }
    };
  }
}
function evForm(e) {
  const v = e || {};
  $("#evform").innerHTML = `<form id="fev" style="margin-top:12px;border-top:1px solid var(--line);padding-top:8px">
    <h3>${e ? "Modifier l'événement" : "Nouvel événement"}</h3>
    <label>Nom</label><input name="nom" required value="${esc(v.nom || "")}">
    <div class="row"><div><label>Site</label><select name="site">${SITES_EV.map((x) => `<option ${x === v.site ? "selected" : ""}>${x}</option>`).join("")}</select></div>
      <div><label>Type</label><select name="type">${TYPES_EV.map((x) => `<option ${x === v.type ? "selected" : ""}>${x}</option>`).join("")}</select></div></div>
    <label>Halls / zones utilisés</label><input name="lieux" value="${esc(v.lieux || "")}">
    <div class="row"><div><label>Organisateur</label><input name="organisateur" value="${esc(v.organisateur || "")}"></div>
      <div><label>Effectif attendu</label><input name="effectif" type="number" inputmode="numeric" value="${esc(v.effectif || "")}"></div></div>
    <div class="row"><div><label>Début</label><input name="debut" type="datetime-local" value="${esc(v.debut || "")}"></div>
      <div><label>Fin</label><input name="fin" type="datetime-local" value="${esc(v.fin || "")}"></div></div>
    <label>Responsable sécurité</label><input name="responsable" value="${esc(v.responsable || "")}">
    <div class="row" style="margin-top:12px"><button class="btn red">Enregistrer</button><button type="button" class="btn" id="evcancel">Annuler</button></div></form>`;
  $("#evcancel").onclick = () => ($("#evform").innerHTML = "");
  $("#fev").onsubmit = async (ev) => {
    ev.preventDefault();
    try {
      const r = await api("evenements" + (e ? "/" + e.id : ""), { method: e ? "PUT" : "POST", body: Object.fromEntries(new FormData(ev.target)) });
      MC.ev = r.id; try { localStorage.setItem("ssiap-ev", r.id); } catch {} toast("Événement enregistré"); vMC();
    } catch (err) { toast(err.message); }
  };
}
async function loadMC() {
  try {
    MC.list = await api("incidents" + (MC.ev ? "?evenement=" + MC.ev : MC.mois ? "?mois=" + MC.mois : ""));
    if (!MC.ev && !MC.mois) MC.list = MC.list.filter((i) => !i.evenementId || !staff());
    const lieux = [...new Set(MC.list.map((i) => i.lieu).filter(Boolean))].slice(0, 60);
    $("#lieux").innerHTML = lieux.map((l) => `<option value="${esc(l)}">`).join("");
    drawMC();
  } catch (e) { $("#list").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}
function drawMC() {
  const f = MC.filtre, n = (s) => String(s || "").toLowerCase();
  const list = MC.list.filter((i) => (!f.statut || i.statut === f.statut) && (!f.grav || i.gravite === f.grav)
    && (!f.q || n([i.numero, i.categorie, i.lieu, i.description, i.auteur, i.intervenants, i.actions, i.prestataire, i.famille, i.societe, i.immat].join(" ")).includes(n(f.q))));
  const ouverts = MC.list.filter((i) => i.statut !== "clos").length, urg = MC.list.filter((i) => i.gravite === "urgente").length;
  $("#stats").textContent = `${MC.list.length} saisie(s) · ${ouverts} non close(s) · ${urg} urgente(s)`;
  const box = $("#list");
  if (!list.length) { box.innerHTML = `<p class="mut">Aucune saisie.</p>`; return; }
  box.innerHTML = list.map((i) => `<div class="item" data-id="${i.id}">
    <div class="h"><b>${esc(i.numero || "")} · ${esc(i.categorie)}</b><span><span class="badge ${i.gravite}">${i.gravite}</span> <span class="badge ${i.statut.replace(" ", "")}">${i.statut}</span></span></div>
    <div class="mut">${fmt(i.heure || i.t)} · ${esc(i.lieu)}${i.site ? " (" + esc(siteCourt(i.site)) + ")" : ""}${staff() ? " · " + esc(i.auteur) : ""}${i.gps ? ` · <a target="_blank" rel="noopener" href="https://maps.google.com/?q=${i.gps.lat},${i.gps.lon}">carte</a>` : ""}</div>
    <div style="white-space:pre-wrap;margin-top:4px">${esc(i.description)}</div>
    ${i.famille ? `<div class="mut">📂 ${esc(i.famille)}</div>` : ""}${i.societe || i.immat ? `<div class="mut">🚚 ${[i.societe, i.immat].filter(Boolean).map(esc).join(" · ")}</div>` : ""}
    ${i.prestataire ? `<div class="mut">🏢 Prestataire : <b>${esc(i.prestataire)}</b></div>` : ""}${i.intervenants ? `<div class="mut">👥 ${esc(i.intervenants)}</div>` : ""}${i.actions ? `<div style="white-space:pre-wrap;font-size:.92rem">➜ ${esc(i.actions)}</div>` : ""}
    ${i.photos ? `<button class="btn sm" data-photo="${i.id}" data-n="${i.photos}" style="margin-top:6px">📷 Voir ${i.photos} photo(s)</button>` : i.photo ? `<button class="btn sm" data-photo="${i.id}" style="margin-top:6px">📷 Voir la photo</button>` : ""}
    ${(i.suivi || []).map((s) => `<div class="mut" style="margin-top:4px">↳ ${fmt(s.t)} ${esc(s.qui)} : ${esc(s.note)}</div>`).join("")}
    ${(staff() && !lecture()) || S.user.perimetre ? `<div class="row" style="margin-top:8px">
      <select data-st="${i.id}" style="flex:0 0 110px">${["ouvert", "en cours", "clos"].map((s) => `<option ${s === i.statut ? "selected" : ""}>${s}</option>`).join("")}</select>
      <input data-note="${i.id}" placeholder="Suivi / complément"><button class="btn sm red" data-save="${i.id}" style="flex:0 0 auto">OK</button></div>` : ""}
  </div>`).join("");
  box.onclick = async (e) => {
    const p = e.target.closest("[data-photo]"), s = e.target.closest("[data-save]");
    if (p) { const ids = p.dataset.n ? [...Array(+p.dataset.n).keys()].map((k) => p.dataset.photo + "-" + k) : [p.dataset.photo], box = document.createElement("div");
      for (const id of ids) { try { const d = await api("photo/" + id); const img = new Image(); img.src = d.d; img.className = "thumb"; box.appendChild(img); } catch (err) { toast(err.message); } } p.replaceWith(box); }
    if (s) {
      const id = s.dataset.save;
      try { await api("incidents/" + id, { method: "PATCH", body: { statut: $(`[data-st="${id}"]`).value, note: $(`[data-note="${id}"]`).value } }); toast("Mis à jour"); loadMC(); }
      catch (err) { toast(err.message); }
    }
  };
}
// Rapport imprimable (Imprimer ➜ Enregistrer en PDF sur le téléphone)
function rapportMC() {
  const e = MC.evs.find((x) => x.id === MC.ev);
  const list = [...MC.list].sort((a, b) => (a.heure || a.t.slice(0, 16)).localeCompare(b.heure || b.t.slice(0, 16)) || a.t.localeCompare(b.t));
  const parCat = {}; list.forEach((i) => (parCat[i.categorie] = (parCat[i.categorie] || 0) + 1));
  const w = document.createElement("div"); w.id = "print";
  w.innerHTML = `<div class="ph"><div><b style="font-size:20px">${esc(CUSTOM["app.titre"] ?? TEXTES_DEFAUT["app.titre"])} ${esc(CUSTOM["app.titre2"] ?? TEXTES_DEFAUT["app.titre2"])}</b> — Main courante électronique</div>
    <div>Édité le ${new Date().toLocaleString("fr-FR")} par ${esc(S.user.nom)}</div></div>
    <h1>${e ? esc(e.nom) : "Exploitation courante (hors événement)"}</h1>
    ${e ? `<p>${[e.site, e.lieux, e.type, e.organisateur && "Organisateur : " + e.organisateur, e.effectif && "Effectif attendu : " + e.effectif,
      e.debut && "Début : " + fmt(e.debut), e.fin && "Fin : " + fmt(e.fin), e.responsable && "Responsable sécurité : " + e.responsable].filter(Boolean).map(esc).join(" · ")}</p>` : ""}
    <p><b>${list.length}</b> saisie(s) · ${list.filter((i) => i.gravite === "urgente").length} urgente(s) · ${list.filter((i) => i.statut !== "clos").length} non close(s)<br>
      ${Object.entries(parCat).map(([k, v]) => `${esc(k)} : ${v}`).join(" · ")}</p>
    <table><thead><tr><th>N°</th><th>Heure</th><th>Catégorie / lieu</th><th>Faits, intervenants, actions</th><th>Statut</th></tr></thead><tbody>
    ${list.map((i) => `<tr><td>${esc(i.numero || "")}</td><td>${fmt(i.heure || i.t)}</td><td><b>${esc(i.categorie)}</b><br>${esc(i.lieu)}<br><i>${esc(i.gravite)}</i></td>
      <td>${esc(i.description)}${i.prestataire ? `<br><i>Prestataire :</i> ${esc(i.prestataire)}` : ""}${i.intervenants ? `<br><i>Intervenants :</i> ${esc(i.intervenants)}` : ""}${i.actions ? `<br><i>Actions :</i> ${esc(i.actions)}` : ""}
      ${(i.suivi || []).map((s) => `<br>↳ ${fmt(s.t)} ${esc(s.qui)} : ${esc(s.note)}`).join("")}<br><small>Saisi par ${esc(i.auteur)} le ${fmt(i.t)}</small></td>
      <td>${esc(i.statut)}</td></tr>`).join("")}</tbody></table>
    <div class="sig"><div>Le responsable sécurité<br><br><br>Signature</div><div>Visa organisateur / exploitant<br><br><br>Signature</div></div>
    <p class="foot">${T("pied")}</p>
    <div class="noprint" style="text-align:center;margin:20px"><button class="btn red" data-pr="1">🖨️ Imprimer / PDF</button> <button class="btn" data-pr="0">Fermer</button></div>`;
  document.body.appendChild(w); window.scrollTo(0, 0);
}

/* ================= Planning des vacations + rappels SMS (protégé par code PIN) ================= */
const normNom = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z ]/g, " ").split(/\s+/).filter(Boolean).sort().join(" ");
const isoDate = (v) => {
  if (v instanceof Date) return v.toISOString().slice(0, 10);
  const s = String(v || "").trim(); let m;
  if ((m = s.match(/^(\d{4})-(\d{2})-(\d{2})/))) return `${m[1]}-${m[2]}-${m[3]}`;
  if ((m = s.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})$/))) return `${m[3].length === 2 ? "20" + m[3] : m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}`;
  if (/^\d{5}$/.test(s)) return new Date(Math.round((+s - 25569) * 864e5)).toISOString().slice(0, 10); // date Excel
  return "";
};
const hhmm = (v) => {
  const s = String(v ?? "").trim().toLowerCase(); let m;
  if (/^0?\.\d+$/.test(s)) { const mn = Math.round(+s * 1440); return `${String(Math.floor(mn / 60)).padStart(2, "0")}:${String(mn % 60).padStart(2, "0")}`; }
  if ((m = s.match(/^(\d{1,2})\s*[h:]\s*(\d{2})?/))) return `${m[1].padStart(2, "0")}:${m[2] || "00"}`;
  return "";
};
// Lit un tableau (lignes de cellules) : 1re ligne = en-têtes, reconnus par leur nom
function lirePlanning(rows) {
  const head = rows[0].map((h) => String(h || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, ""));
  const col = (...k) => head.findIndex((h) => k.some((x) => h.includes(x)));
  const nomCol = head.findIndex((h) => (h.includes("nom") && !h.includes("prenom")) || h.includes("agent") || h.includes("salarie"));
  const c = { date: col("date", "jour"), nom: nomCol, prenom: col("prenom"), debut: col("debut", "prise", "entree"),
    fin: col("fin", "sortie"), poste: col("poste", "affectation", "zone", "mission"), ev: col("evenement", "manif", "event", "salon", "client"), tel: col("tel", "portable", "mobile") };
  if (c.prenom === c.nom) c.prenom = -1;
  if (c.date < 0 || c.nom < 0) throw new Error("Colonnes « Date » et « Nom » introuvables dans la 1re ligne");
  return rows.slice(1).map((r) => ({
    date: isoDate(r[c.date]), nom: [c.prenom >= 0 ? r[c.prenom] : "", r[c.nom]].filter(Boolean).join(" ").trim(),
    debut: c.debut >= 0 ? hhmm(r[c.debut]) : "", fin: c.fin >= 0 ? hhmm(r[c.fin]) : "",
    poste: c.poste >= 0 ? String(r[c.poste] || "") : "", evenement: c.ev >= 0 ? String(r[c.ev] || "") : "", tel: c.tel >= 0 ? String(r[c.tel] || "") : "",
  })).filter((l) => l.date && l.nom);
}
async function fichierEnLignes(file) {
  if (/\.(xlsx|xls|ods)$/i.test(file.name)) {
    if (!window.XLSX) await new Promise((ok, ko) => { const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"; s.onload = ok; s.onerror = () => ko(new Error("Lecture Excel indisponible hors connexion")); document.head.appendChild(s); });
    const wb = XLSX.read(await file.arrayBuffer(), { cellDates: true });
    return XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, raw: true, defval: "" });
  }
  const txt = await file.text(); return texteEnLignes(txt);
}
const texteEnLignes = (txt) => { const sep = txt.includes("\t") ? "\t" : txt.split("\n")[0].includes(";") ? ";" : ","; return txt.split(/\r?\n/).filter((l) => l.trim()).map((l) => l.split(sep).map((x) => x.trim().replace(/^"|"$/g, ""))); };

// Recherche du numéro d'un agent dans l'annuaire à partir de son nom (exact, puis approchant)
const toksNom = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z ]/g, " ").split(/\s+/).filter(Boolean);
const lev = (a, b) => { const m = [...Array(b.length + 1).keys()]; for (let i = 1; i <= a.length; i++) { let p = m[0]; m[0] = i; for (let j = 1; j <= b.length; j++) { const t = m[j]; m[j] = Math.min(m[j] + 1, m[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t; } } return m[b.length]; };
function creerChercheur(annuaire) {
  const exact = new Map(), liste = [];
  annuaire.forEach((a) => { if (!a.tel) return; const t = toksNom(a.nom); exact.set([...t].sort().join(" "), cleanTel(a.tel)); liste.push({ t, tel: cleanTel(a.tel), nom: a.nom }); });
  return (nom) => {
    const t = toksNom(nom), k = [...t].sort().join(" ");
    if (exact.has(k)) return { tel: exact.get(k), sur: true };
    const joint = t.join("");
    let best = null, nb = 0;
    for (const a of liste) {
      const ok = t.filter((x) => a.t.some((y) => x === y || (x.length >= 5 && lev(x, y) <= (x.length >= 8 ? 2 : 1)))).length;
      const colle = a.t.join("").length >= 8 && (joint.includes(a.t.join("")) || a.t.join("").includes(joint));
      const score = colle ? 2 : ok;
      if (score >= Math.min(2, t.length) && score >= Math.min(2, a.t.length)) { if (!best || score > best.score) { best = { score, a }; nb = 1; } else if (score === best.score) nb++; }
    }
    return best && nb === 1 ? { tel: best.a.tel, sur: false, nomAnnuaire: best.a.nom } : null;
  };
}
// Missions prédéfinies selon l'intitulé du poste (remplacées par la consigne personnalisée si elle existe)
const MISSIONS = [
  [/(^|\W)PC(\W|$)|PC ARENA|COORDINATEUR/, "Tenue du PC sécurité : SSI, radio, main courante, coordination des équipes."],
  [/SSIAP ?3/, "Chef de service sécurité incendie : coordination SSIAP, lien organisateur et secours."],
  [/SSIAP ?2|CHEF/, "Chef d'équipe : encadrement des agents, levées de doute, relais avec le PC."],
  [/SSIAP/, "Sécurité incendie : rondes, levées de doute, dégagements libres, moyens de secours accessibles."],
  [/FOUILLE|PALPATION/, "Inspection visuelle des sacs et palpation de sécurité avec consentement, refus d'accès en cas de refus."],
  [/ACCRED|BACKSTAGE|LOGES|VIP|MEDIA|ARTISTE|BENEVOLE/, "Contrôle des accréditations : accès réservé aux seules personnes autorisées."],
  [/DEVANT (DE )?SCENE|CRASH|FOSSE|PARTERRE|GRADIN|PHOTO/, "Surveillance du public en salle, mouvements de foule, alerte du PC en cas de malaise."],
  [/PKG|PARKING|ROND POINT|PATTE|PORTAIL|FRIGO|(^|\W)P\d/, "Régulation de la circulation et du stationnement, accès des seuls véhicules autorisés."],
  [/CONTROLE|CTRL|ACCUEIL|ENTREE|BILLET/, "Contrôle d'accès : billets et badges, accueil et orientation du public, filtrage."],
  [/CYNO/, "Surveillance cynophile : rondes et dissuasion sur la zone indiquée par le PC."],
  [/NUIT|FERMETURE/, "Rondes de surveillance, fermeture des accès, signalement de toute anomalie au PC."],
  [/PORTE/, "Tenue de la porte : contrôle des flux, issues dégagées, filtrage du public."],
  [/VOLANT|REGUL|REDEP|REDLP|REPLAC/, "Agent volant : renforts, relèves et régulation selon les consignes du PC."],
  [/REGIE|TERRAIN|FOP/, "Protection de la zone technique / terrain : accès réservé, surveillance du matériel et des personnes."],
  [/SALLE|CONFERENCE/, "Surveillance de la salle : contrôle des accès, issues dégagées, assistance au public."],
  [/MAIL|PARVIS|HALL|ZONE|JARDIN|COUR/, "Surveillance de la zone, orientation du public, signalement des anomalies au PC."],
];
const missionAuto = (poste) => { const p = String(poste || "").toUpperCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); const m = MISSIONS.find(([r]) => r.test(p)); return m ? m[1] : "Selon les consignes du chef d'équipe et du PC."; };
const SIGNATURE = "Le PC Sécurité Parc Expo Valmont / Arena\n04 65 71 00 00";

function chargerScript(src) { return new Promise((ok, ko) => { if (document.querySelector(`script[src="${src}"]`)) return ok(); const s = document.createElement("script"); s.src = src; s.onload = ok; s.onerror = () => ko(new Error("Chargement impossible : " + src)); document.head.appendChild(s); }); }

async function vPlanning() {
  if (!staff()) return (location.hash = "#/");
  const sms = await withCode(() => api("sms")); if (!sms) return;
  const chercher = creerChercheur([...sms.agents, ...sms.annuaire]);
  let CONS = await api("postes").catch(() => ({}));
  const cleP = (p) => String(p || "").toUpperCase().trim();
  const telDe = (v) => { if (v.tel) return { tel: v.tel, sur: !v.telApproche }; const r = chercher(v.nom); return r || { tel: "", sur: false }; };
  let auto = null; try { auto = sessionStorage.getItem("ssiap-rafale"); sessionStorage.removeItem("ssiap-rafale"); } catch {}
  const demain = auto || new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  let siteF = ""; try { siteF = localStorage.getItem("ssiap-plsite") || ""; } catch {}
  view.innerHTML = `
  <div class="card"><h2>${T("planning.titre")}</h2>
    <div class="row"><div><label>Jour</label><input type="date" id="pd" value="${demain}"></div>
      <div style="flex:0 0 auto;align-self:flex-end"><button class="btn sm" id="pprev">◀</button> <button class="btn sm" id="pnext">▶</button></div></div>
    <div class="seg" id="psite" style="margin-top:10px"><button data-s="">Tous</button><button data-s="Parc Expo Valmont">Parc Expo</button><button data-s="Valmont Arena">Arena</button></div>
    <input id="pq" placeholder="Rechercher un agent, un poste…" style="margin-top:10px">
    <div id="pjour" style="margin-top:10px"><p class="mut">Chargement…</p></div></div>

  <div class="card"><h2>📨 Rappel de vacation par SMS</h2>
    <label>Modèle ({prenom} {nom} {date} {heure} {fin} {site} {poste} {evenement} {mission} {signature})</label>
    <textarea id="pmod">${esc(sms.modeleVacation || "Bonjour {prenom}, rappel de ta vacation le {date} de {heure} à {fin} — {site}.\nPoste : {poste}\nMission : {mission}\nMerci de confirmer par retour de SMS.\n{signature}")}</textarea>
    <button class="btn sm" data-proprio id="psavemod" style="margin-top:8px">💾 Enregistrer le modèle</button>
    <p class="mut">« Envoyer les rappels du jour » enchaîne les agents un par un : tu valides chaque SMS dans ta messagerie, puis « Suivant ». ≈ = numéro trouvé avec un nom écrit un peu différemment, à vérifier.</p></div>

  <div class="card"><h2>📍 Postes et missions</h2>
    <p class="mut">Chaque poste a une <b>mission prédéfinie</b> (en gris), ajoutée automatiquement au SMS. Tape un texte pour la remplacer (rendez-vous, tenue, consignes du jour…). Les postes affichés sont ceux du jour choisi.</p>
    <input id="cq" placeholder="Filtrer les postes…">
    <div id="cons" style="margin-top:8px;max-height:420px;overflow:auto"></div>
    <button class="btn sm red" data-proprio id="csave" style="margin-top:10px">💾 Enregistrer les missions</button></div>

  <div class="card" data-proprio="coord"><h2>📥 Importer un planning</h2>
    <p class="mut"><b>PDF Comète</b> (Planning site par Agents et par Activités, Parc Expo ou Arena) : il est lu directement, avec la légende des vacations. Aussi possible : Excel / CSV ou copier-coller avec les colonnes Date, Nom, Début, Fin, Poste, Événement.</p>
    <input type="file" id="pfile" accept=".pdf,.xlsx,.xls,.ods,.csv,.txt" multiple>
    <label>…ou colle un tableau ici</label><textarea id="ptxt" style="min-height:90px"></textarea>
    <label>Mode</label><select id="pmode"><option value="remplacer">Remplacer les jours importés (même site)</option><option value="ajouter">Ajouter au planning existant</option></select>
    <div id="papercu" class="mut" style="margin-top:8px"></div>
    <button class="btn red" id="pimport" style="margin-top:10px" disabled>Importer</button></div>`;

  const segSite = () => [...$("#psite").children].forEach((b) => b.classList.toggle("on", b.dataset.s === siteF));
  segSite();
  $("#psite").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; siteF = b.dataset.s; try { localStorage.setItem("ssiap-plsite", siteF); } catch {} segSite(); dessiner(); };

  let lignes = [];
  const apercu = (ls, info = "") => {
    lignes = ls.map((l) => { const r = l.tel ? { tel: cleanTel(l.tel), sur: true } : chercher(l.nom); return { ...l, tel: r?.tel || "", telApproche: !!(r && !r.sur) }; });
    const agents = [...new Set(lignes.map((l) => l.nom))], sans = [...new Set(lignes.filter((l) => !l.tel).map((l) => l.nom))];
    const jours = new Set(lignes.map((l) => l.date)).size;
    $("#papercu").innerHTML = lignes.length ? `✅ ${info}${lignes.length} vacation(s) · ${agents.length} agent(s) · ${jours} jour(s)` +
      (sans.length ? `<br>⚠️ ${sans.length} agent(s) sans numéro : ${sans.map(esc).join(", ")}` : "<br>📱 Tous les agents ont un numéro") : "❌ Aucune vacation trouvée";
    $("#pimport").disabled = !lignes.length;
  };
  $("#pfile").onchange = async (e) => {
    const files = [...e.target.files]; if (!files.length) return;
    $("#papercu").textContent = "Lecture en cours…";
    try {
      let tout = [], infos = [];
      for (const f of files) {
        if (/\.pdf$/i.test(f.name)) {
          await chargerScript("comete.js");
          const r = await window.lireComete(f);
          tout.push(...r.lignes);
          infos.push(`${r.site} ${r.mois} : ${r.lignes.length} vac. (${r.stats.nonAffectees} non affectées ignorées${Object.keys(r.stats.indispo).length ? ", " + Object.entries(r.stats.indispo).map(([k, v]) => `${v} ${k.toLowerCase()}`).join(", ") : ""})`);
        } else tout.push(...lirePlanning(await fichierEnLignes(f)));
      }
      apercu(tout, infos.length ? infos.map(esc).join("<br>") + "<br>" : "");
    } catch (err) { $("#papercu").textContent = "❌ " + err.message; }
  };
  $("#ptxt").oninput = (e) => { if (!e.target.value.trim()) return; try { apercu(lirePlanning(texteEnLignes(e.target.value))); } catch (err) { $("#papercu").textContent = "❌ " + err.message; } };
  $("#pimport").onclick = async () => {
    $("#pimport").disabled = true;
    try { const r = await api("planning", { method: "PUT", body: { lignes, mode: $("#pmode").value } }); toast(`✅ ${r.importees} vacation(s) importée(s)`); $("#pd").value = lignes.map((l) => l.date).sort()[0]; jour(); }
    catch (e) { toast(e.message); $("#pimport").disabled = false; }
  };
  $("#psavemod").onclick = async () => { try { await api("sms", { method: "PUT", body: { modeleVacation: $("#pmod").value } }); toast("Modèle enregistré"); } catch (e) { toast(e.message); } };
  const shift = (n) => { const d = new Date($("#pd").value); d.setDate(d.getDate() + n); $("#pd").value = d.toISOString().slice(0, 10); jour(); };
  $("#pprev").onclick = () => shift(-1); $("#pnext").onclick = () => shift(1); $("#pd").onchange = jour; $("#pq").oninput = () => dessiner();

  let liste = [];
  const fill = (v) => {
    const [prenom, ...rest] = prenomNom(v.nom);
    return $("#pmod").value.replaceAll("{prenom}", prenom).replaceAll("{nom}", rest.join(" "))
      .replaceAll("{date}", new Date(v.date).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" }))
      .replaceAll("{heure}", (v.debut || "").replace(":", "h")).replaceAll("{fin}", (v.fin || "").replace(":", "h"))
      .replaceAll("{site}", v.site || "").replaceAll("{poste}", v.poste || "").replaceAll("{evenement}", v.evenement || "")
      .replaceAll("{consigne}", "{mission}")
      .replaceAll("{mission}", ((c) => /[.!?]$/.test(c) ? c : c + ".")((CONS[cleP(v.poste)] || "").trim() || missionAuto(v.poste)))
      .replaceAll("{signature}", SIGNATURE)
      .replace(/[ \t]{2,}/g, " ").replace(/ ,/g, ",");
  };
  async function jour() {
    try {
      liste = await api(`planning?du=${$("#pd").value}&au=${$("#pd").value}`); dessiner(); dessinerCons();
      if (auto) { auto = null; const r = $("#rafale"); if (r && !r.disabled) r.click(); }
    }
    catch (e) { $("#pjour").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
  }
  function dessiner() {
    const q = $("#pq").value.toLowerCase();
    const vis = liste.filter((v) => (!siteF || v.site === siteF) && (!q || [v.nom, v.poste, v.evenement, v.qualif].join(" ").toLowerCase().includes(q)));
    const box = $("#pjour");
    if (!vis.length) { box.innerHTML = `<p class="mut">Aucune vacation ce jour${siteF ? " sur ce site" : ""}.</p>`; return; }
    const parSite = {}; vis.forEach((v) => (parSite[v.site || "—"] ||= []).push(v));
    const aEnvoyer = vis.filter((v) => !v.rappel && telDe(v).tel);
    box.innerHTML = `<p class="mut">${vis.length} vacation(s) · ${vis.filter((v) => v.rappel).length} rappel(s) déjà envoyé(s)</p>
      <button class="btn red" data-action id="rafale" ${aEnvoyer.length && !lecture() ? "" : "disabled"}>📨 Envoyer les rappels du jour (${aEnvoyer.length})</button>` + Object.entries(parSite).map(([s, vs]) =>
      `<h3 style="margin:14px 0 4px">${esc(s)} <span class="mut">(${vs.length})</span></h3>` + vs.map((v) => {
        const t = telDe(v), i = liste.indexOf(v);
        return `<div class="item" style="display:flex;gap:8px;align-items:center"><span style="flex:1"><b>${esc(v.nom)}</b> <span class="mut">${esc(v.qualif || "")}</span><br>
          <span style="font-size:.9rem">🕑 ${v.debut || "?"} → ${v.fin || "?"} · ${esc(v.poste)}${v.evenement ? " · " + esc(v.evenement) : ""}</span>
          ${t.tel ? (t.sur ? "" : ` <span class="badge moyenne" title="Nom approchant dans l'annuaire">≈ à vérifier</span>`) : ` <span class="badge urgente">pas de numéro</span>`}
          ${v.rappel ? `<br><span class="mut" style="color:var(--ok)">✓ rappel envoyé par ${esc(v.rappel.qui)} · ${fmt(v.rappel.t)}</span>` : ""}</span>
          ${t.tel && !lecture() ? `<button class="btn sm ${v.rappel ? "" : "red"}" data-i="${i}" data-tel="${esc(t.tel)}" style="flex:none">${v.rappel ? "Renvoyer" : "Rappel"}</button>` : ""}
          ${proprio() ? `<button class="btn sm" data-del="${v.id}" style="flex:none">✕</button>` : ""}</div>`;
      }).join("")).join("");
    box.onclick = async (e) => {
      const b = e.target.closest("[data-tel]"), x = e.target.closest("[data-del]");
      if (b) {
        const v = liste[+b.dataset.i];
        envoyerSMS(b.dataset.tel, fill(v)); marquer(v);
        b.textContent = "✓"; b.classList.remove("red");
      }
      if (e.target.closest("#rafale")) rafale(aEnvoyer);
      if (x && confirm("Retirer cette vacation ?")) { await api("planning/" + x.dataset.del, { method: "DELETE" }); jour(); }
    };
  }
  const envoyerSMS = (tel, msg) => { const ios = /iPhone|iPad/.test(navigator.userAgent); location.href = `sms:${tel}${ios ? "&" : "?"}body=${encodeURIComponent(msg)}`; };
  const marquer = (v) => api("planning/" + v.id, { method: "PATCH", body: { rappel: true } })
    .then((r) => { v.rappel = r.rappel; }).catch((e) => toast(e.message));

  // Rafale : un agent après l'autre, tu valides chaque SMS puis « Suivant »
  function rafale(file) {
    let k = 0;
    const ov = document.createElement("div"); ov.id = "rafaleBox";
    ov.style.cssText = "position:fixed;inset:0;z-index:150;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:16px";
    document.body.appendChild(ov);
    const fermer = () => { ov.remove(); dessiner(); };
    const montrer = () => {
      if (k >= file.length) {
        ov.innerHTML = `<div class="card" style="max-width:480px;width:100%;text-align:center"><h2>✅ Terminé</h2><p>${file.length} rappel(s) traité(s).</p><button class="btn red" id="rf-ok">Fermer</button></div>`;
        $("#rf-ok").onclick = fermer; return;
      }
      const v = file[k], t = telDe(v);
      ov.innerHTML = `<div class="card" style="max-width:480px;width:100%">
        <div class="mut">${k + 1} / ${file.length} · ${esc(v.site || "")}</div>
        <h2 style="margin:6px 0">${esc(v.nom)} ${t.sur ? "" : `<span class="badge moyenne">≈ à vérifier</span>`}</h2>
        <div class="mut">🕑 ${v.debut} → ${v.fin} · ${esc(v.poste)}</div>
        <label>Message (modifiable)</label><textarea id="rf-msg" style="min-height:130px">${esc(fill(v))}</textarea>
        <button class="btn red" id="rf-send" style="margin-top:10px">📤 Envoyer à ${esc(t.tel)}</button>
        <div class="row" style="margin-top:10px"><button class="btn" id="rf-skip">⏭ Passer</button><button class="btn" id="rf-stop">✕ Arrêter</button></div></div>`;
      $("#rf-send").onclick = () => {
        envoyerSMS(t.tel, $("#rf-msg").value); marquer(v);
        $("#rf-send").textContent = "Suivant ➜"; $("#rf-send").classList.replace("red", "ok");
        $("#rf-send").onclick = () => { k++; montrer(); };
      };
      $("#rf-skip").onclick = () => { k++; montrer(); };
      $("#rf-stop").onclick = fermer;
    };
    montrer();
  }

  // Consignes par poste
  function dessinerCons() {
    const q = ($("#cq").value || "").toLowerCase();
    const postes = [...new Set([...liste.filter((v) => !siteF || v.site === siteF).map((v) => cleP(v.poste)), ...Object.keys(CONS)])].filter(Boolean)
      .filter((p) => !q || p.toLowerCase().includes(q)).sort((a, b) => (CONS[a] ? 1 : 0) - (CONS[b] ? 1 : 0) || a.localeCompare(b));
    $("#cons").innerHTML = postes.map((p) => `<div class="item"><label style="margin:0 0 4px;color:var(--txt)">${esc(p)}</label>
      <input data-cp="${esc(p)}" value="${esc(CONS[p] || "")}" placeholder="${esc(missionAuto(p))}"></div>`).join("") || `<p class="mut">Aucun poste ce jour.</p>`;
    $("#cons").oninput = (e) => { const i = e.target.closest("[data-cp]"); if (i) { if (i.value.trim()) CONS[i.dataset.cp] = i.value; else delete CONS[i.dataset.cp]; } };
  }
  $("#cq").oninput = dessinerCons;
  $("#csave").onclick = async () => { try { const r = await api("postes", { method: "PUT", body: { consignes: CONS } }); toast(`✅ ${r.nb} mission(s) personnalisée(s) enregistrée(s)`); } catch (e) { toast(e.message); } };
  jour();
}
// « MOREL Yanis » (NOM Prénom, format Comète) → ["Yanis", "MOREL"]
function prenomNom(n) {
  const w = n.split(" "), maj = w.filter((x) => x.length > 1 && x === x.toUpperCase() && /[A-Z]/.test(x));
  if (!maj.length || maj.length === w.length) return w;
  return [w.filter((x) => !maj.includes(x)).join(" "), ...maj];
}

/* ================= Notifications / historique (administrateurs) ================= */
let notifTimer = null, notifVu = 0;
async function pollNotifs() {
  if (!admin() || !S.token) return;
  try {
    const n = await api("notifs?compte=1");
    const b = $("#bell"); b.classList.toggle("hidden", false); if (n.nonLues > (window.__nl ?? n.nonLues)) sonNotif(); window.__nl = n.nonLues; b.innerHTML = ico("bell") + (n.nonLues ? `<span>${n.nonLues > 99 ? "99+" : n.nonLues}</span>` : ""); b.classList.toggle("on", !!n.nonLues);
    b.classList.toggle("on", n.nonLues > 0);
    if (n.nonLues > notifVu && notifVu >= 0 && "Notification" in window && Notification.permission === "granted" && document.hidden)
      new Notification("SSIAP Pro", { body: `${n.nonLues} nouvelle(s) notification(s)`, icon: "img/icon-192.png" });
    notifVu = n.nonLues;
  } catch {}
}
function startNotifs() {
  clearInterval(notifTimer);
  if (!admin()) { $("#bell").classList.add("hidden"); return; }
  pollNotifs(); notifTimer = setInterval(pollNotifs, 30000);
}
async function viderNotifs() { if (!confirm("Effacer toutes les notifications de la cloche ?")) return;
  try { await api("historique/notifications", { method: "POST" }); window.__nl = 0; const b = $("#bell"); if (b) { b.innerHTML = ico("bell"); b.classList.remove("on"); } toast("Notifications effacées"); if (location.hash === "#/notifs") vNotifs(); } catch (e) { toast(e.message); } }
async function vNotifs() {
  if (!admin()) return (location.hash = "#/");
  const d = await api("notifs");
  const types = [...new Set(d.items.map((x) => x.type))].sort();
  view.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">${T("notifs.titre")}</h2>
      <div style="display:flex;gap:6px">${proprio() || S.user.role === "admin" ? `<button class="btn sm" id="nvider">Tout effacer</button>` : ""}${"Notification" in window && Notification.permission !== "granted" ? `<button class="btn sm" id="nperm">Activer les alertes</button>` : ""}</div></div>
    <div class="row" style="margin-top:10px"><input id="nq" placeholder="Rechercher…">
      <select id="nt" style="flex:0 0 140px"><option value="">Tout</option>${types.map((t) => `<option>${esc(t)}</option>`).join("")}</select></div>
    <div id="nl" style="margin-top:6px"></div></div>`;
  if ($("#nvider")) $("#nvider").onclick = viderNotifs;
  const NIV = { urgent: "🔴", attention: "🟠", info: "⚪" };
  const draw = () => {
    const q = $("#nq").value.toLowerCase(), t = $("#nt").value;
    const list = d.items.filter((x) => (!t || x.type === t) && (!q || (x.qui + x.detail + x.type).toLowerCase().includes(q)));
    $("#nl").innerHTML = list.slice(0, 400).map((x) => `<div class="item" ${x.lien ? `data-l="${x.lien}" style="cursor:pointer"` : ""}>
      <div class="h"><span>${NIV[x.niveau] || "⚪"} <b>${esc(x.type)}</b> · ${esc(x.qui)}</span><span class="mut">${fmt(x.t)}${x.t > d.lu ? ` <span class="badge urgente">nouveau</span>` : ""}</span></div>
      <div style="font-size:.92rem">${esc(x.detail)}</div></div>`).join("") || `<p class="mut">Rien pour l'instant.</p>`;
  };
  $("#nq").oninput = draw; $("#nt").onchange = draw; draw();
  $("#nl").onclick = (e) => { const r = e.target.closest("[data-l]"); if (r) location.hash = r.dataset.l; };
  if ($("#nperm")) $("#nperm").onclick = () => Notification.requestPermission().then(() => vNotifs());
  api("notifs", { method: "POST" }).then(pollNotifs).catch(() => {});
}

/* ================= Sites et zones : sélecteur réutilisable ================= */
let ZONES = null;
async function chargerZones() { if (!ZONES) ZONES = await api("zones").catch(() => ({})); return ZONES; }
const siteCourt = (s) => (/arena/i.test(s || "") ? "Arena" : /parc/i.test(s || "") ? "Parc" : s || "");
function htmlLieu(pfx, requis = true) {
  let site = ""; try { site = localStorage.getItem("ssiap-site") || ""; } catch {}
  const sites = Object.keys(ZONES || {});
  if (!sites.includes(site)) site = sites[0] || "";
  return `<div class="row"><div><label>Site</label><select id="${pfx}-site">${sites.map((x) => `<option ${x === site ? "selected" : ""}>${esc(x)}</option>`).join("")}</select></div>
    <div><label>Zone</label><select id="${pfx}-zone" ${requis ? "required" : ""}></select></div></div>
    <input id="${pfx}-autre" class="hidden" placeholder="Précise le lieu" style="margin-top:8px">`;
}
function brancherLieu(pfx) {
  const s = $(`#${pfx}-site`), z = $(`#${pfx}-zone`), a = $(`#${pfx}-autre`);
  if (!s) return;
  const remplir = () => {
    const secs = (ZONES || {})[s.value] || {};
    z.innerHTML = `<option value="">— choisir —</option>` + Object.entries(secs).map(([sec, zs]) => `<optgroup label="${esc(sec)}">${zs.map((x) => `<option>${esc(x)}</option>`).join("")}</optgroup>`).join("") + `<option value="__autre">Autre (préciser)</option>`;
    try { localStorage.setItem("ssiap-site", s.value); } catch {}
  };
  s.onchange = remplir; z.onchange = () => a.classList.toggle("hidden", z.value !== "__autre"); remplir();
}
function lireLieu(pfx) {
  const s = $(`#${pfx}-site`), z = $(`#${pfx}-zone`), a = $(`#${pfx}-autre`);
  if (!s) return { site: "", lieu: "" };
  return { site: s.value, lieu: z.value === "__autre" ? a.value.trim() : z.value };
}

/* ================= Actions rapides agent (accueil) ================= */
const RAPIDES = ["malaise", "incident", "di", "rixe", "intrusion", "forcing"];
function blocRapide() {
  return `<div class="card" style="border-color:var(--red)"><h2>👮 Mon service</h2>
    <div class="grid2"><button class="btn ok" data-svc="prise">🟢 Prise de service</button><button class="btn red" data-svc="fin">🔴 Fin de service</button></div>
    <div class="tiles" style="margin-top:12px;grid-template-columns:repeat(3,1fr)">
      ${RAPIDES.map((k) => { const [, ic, lb] = RT(k); return `<a class="tile" role="button" tabindex="0" data-rk="${k}" style="font-size:.8rem;padding:10px 4px"><span>${ic}</span>${lb.split(" / ")[0].replace("DI – défaut technique", "DI technique")}</a>`; }).join("")}
    </div>
    <div class="grid2" style="margin-top:10px"><a class="btn" href="#/rap">📋 Tous les rapports</a><a class="btn" href="#/mc">📝 Main courante</a>
      <a class="btn" href="#/docs">📂 Documents</a>${staff() ? `<a class="btn" href="#/risques">⚠️ Risques</a>` : `<a class="btn" href="#/monplanning">📅 Mon planning</a>`}
      <a class="btn" href="#/cles">🔑 Clés</a><a class="btn" href="#/materiel">📦 Matériel</a><a class="btn" href="#/batiments" style="grid-column:1/-1">🏢 Ouverture / fermeture · éclairage</a>${staff() ? "" : `<a class="btn" href="#/dispos" style="grid-column:1/-1">🙋 Mes disponibilités</a>`}</div>
    <p class="mut" style="margin:10px 0 0">Tout ce que tu envoies part directement au PC sécurité, avec ton nom et ton poste.</p></div>`;
}
function brancherRapide() {
  view.querySelectorAll("[data-rk]").forEach((a) => (a.onclick = () => ouvrirRapport(a.dataset.rk)));
  view.querySelectorAll("[data-svc]").forEach((b) => (b.onclick = async () => {
    const prise = b.dataset.svc === "prise";
    await chargerZones();
    const ov = document.createElement("div");
    ov.style.cssText = "position:fixed;inset:0;z-index:150;background:rgba(0,0,0,.85);display:flex;align-items:center;justify-content:center;padding:16px";
    ov.innerHTML = `<form class="card" id="svcf" style="max-width:460px;width:100%"><h2>${prise ? "🟢 Prise de service" : "🔴 Fin de service"}</h2>
      ${htmlLieu("svc")}
      <label>${prise ? "Observation (facultatif)" : "Observations de fin de service"}</label><input id="svc-obs" value="${prise ? "" : "RAS"}">
      <button class="btn ${prise ? "ok" : "red"}" style="margin-top:12px">Valider</button>
      <button type="button" class="btn" id="svc-x" style="margin-top:8px">Annuler</button></form>`;
    document.body.appendChild(ov); brancherLieu("svc");
    $("#svc-x").onclick = () => ov.remove();
    $("#svcf").onsubmit = async (e) => {
      e.preventDefault(); const L = lireLieu("svc"); if (!L.lieu) return toast("Choisis ta zone");
      const h = new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), obs = $("#svc-obs").value.trim();
      try {
        await api("incidents", { method: "POST", body: { categorie: prise ? "Prise de service" : "Fin de service", gravite: "info", site: L.site, lieu: L.lieu,
          description: `${prise ? "Prise" : "Fin"} de service à ${h} — ${L.lieu} (${siteCourt(L.site)})${obs ? " — " + obs : ""}`, clos: true, evenementId: MC.ev } });
        ov.remove(); toast(prise ? "🟢 Prise de service enregistrée" : "🔴 Fin de service enregistrée");
      } catch (err) { toast(err.message); }
    };
  }));
}

/* ================= Rapports libres avec photos ================= */
async function vRapports() {
  await chargerZones();
  let photos = [], gps = null;
  view.innerHTML = `<div class="card" data-action><h2>📷 Nouveau rapport</h2><form id="fr">
    <label>Titre</label><input name="titre" placeholder="ex. Porte de secours endommagée hall B" required>
    ${htmlLieu("rpl", false)}
    <label>Rapport</label><textarea name="texte" style="min-height:140px" placeholder="Décris ce que tu as constaté, ce que tu as fait, qui est prévenu."></textarea>
    <div class="row" style="margin-top:12px">
      <label class="btn" style="margin:0;text-align:center;color:var(--txt)">📷 Ajouter une photo<input type="file" accept="image/*" capture="environment" id="rph" hidden></label>
      <button type="button" class="btn" id="rgeo">📍 Position</button></div>
    <div id="rprev" style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:8px"></div><p id="rgpsi" class="mut"></p>
    <button class="btn red" style="margin-top:10px">📤 Envoyer au PC sécurité</button>
    <p class="mut">4 photos maximum. Le rapport est envoyé par mail au PC sécurité, avec les photos en pièce jointe.</p></form></div>
  <div class="card"><h2>${staff() ? "🗂️ Tous les rapports" : "🗂️ Mes rapports"}</h2><div id="rl"><p class="mut">Chargement…</p></div></div>`;
  brancherLieu("rpl");
  const prev = () => ($("#rprev").innerHTML = photos.map((p, i) => `<div style="position:relative"><img src="${p}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px"><button type="button" data-rm="${i}" style="position:absolute;top:2px;right:2px;border:0;border-radius:50%;width:22px;height:22px">✕</button></div>`).join(""));
  $("#rph").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; if (photos.length >= 4) return toast("4 photos maximum"); photos.push(await compress(f)); e.target.value = ""; prev(); };
  $("#rprev").onclick = (e) => { const b = e.target.closest("[data-rm]"); if (b) { photos.splice(+b.dataset.rm, 1); prev(); } };
  $("#rgeo").onclick = () => navigator.geolocation?.getCurrentPosition((p) => { gps = { lat: p.coords.latitude, lon: p.coords.longitude }; $("#rgpsi").textContent = "📍 Position ajoutée"; }, () => toast("Position indisponible"), { enableHighAccuracy: true, timeout: 10000 });
  $("#fr").onsubmit = async (e) => {
    e.preventDefault(); const btn = e.submitter; btn.disabled = true;
    try { await api("rapports", { method: "POST", body: { ...Object.fromEntries(new FormData(e.target)), ...lireLieu("rpl"), photos, gps } }); toast("✅ Rapport envoyé au PC"); vRapports(); }
    catch (err) { toast(err.message); btn.disabled = false; }
  };
  try {
    const list = await api("rapports");
    $("#rl").innerHTML = list.length ? list.map((r) => `<div class="item"><div class="h"><b>${esc(r.titre)}</b><span class="mut">${fmt(r.t)}</span></div>
      <div class="mut">${staff() ? esc(r.auteur) + " · " : ""}${esc(r.lieu)}${r.gps ? ` · <a target="_blank" rel="noopener" href="https://maps.google.com/?q=${r.gps.lat},${r.gps.lon}">carte</a>` : ""}</div>
      <div style="white-space:pre-wrap;margin-top:4px">${esc(r.texte)}</div>
      ${r.photos ? `<button class="btn sm" data-rp="${r.id}" data-n="${r.photos}" style="margin-top:6px">📷 Voir ${r.photos} photo(s)</button>` : ""}</div>`).join("") : `<p class="mut">Aucun rapport.</p>`;
    $("#rl").onclick = async (e) => {
      const b = e.target.closest("[data-rp]"); if (!b) return;
      const box = document.createElement("div"); box.style.cssText = "display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-top:6px";
      for (let i = 0; i < +b.dataset.n; i++) { try { const d = await api(`photo/${b.dataset.rp}-${i}`); const im = new Image(); im.src = d.d; im.className = "thumb"; box.appendChild(im); } catch {} }
      b.replaceWith(box);
    };
  } catch (e) { $("#rl").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}

/* ================= En direct (responsables, PC, admin) ================= */
let directTimer = null;
async function vDirect() {
  if (!staff()) return (location.hash = "#/");
  view.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">🔴 En direct</h2><span class="mut" id="dmaj"></span></div>
    <div class="grid2" style="margin-top:12px"><div class="alerte" style="border-color:var(--ok)"><div class="temp" id="dsvc">–</div><div class="mut">agent(s) en service</div></div>
      <div class="alerte orange"><div class="temp" id="dopen">–</div><div class="mut">fait(s) non clos</div></div></div></div>
  <div class="seg" id="dsite" style="margin-top:12px"><button data-s="" class="on">Tous</button><button data-s="Parc">Parc Expo</button><button data-s="Arena">Arena</button></div>
  <div class="card"><h2>👮 Agents en service</h2><div id="dlist"></div></div>
  <div class="card"><h2>📡 Fil des dernières 24 h</h2><div id="dfil"></div></div>`;
  const ICON = { "Prise de service": "🟢", "Fin de service": "🔴", "Malaise": "🚑", "Incident": "⚠️", "DI – défaut technique / anomalie": "🛠️", "Événement": "📌" };
  let fSite = "", last = null;
  $("#dsite").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; fSite = b.dataset.s; [...$("#dsite").children].forEach((x) => x.classList.toggle("on", x === b)); if (last) dessinerD(last); };
  const dessinerD = (d0) => {
    const ok = (x) => !fSite || siteCourt(x.site) === fSite;
    const d = { ...d0, enService: d0.enService.filter(ok), fil: d0.fil.filter(ok) };
    $("#dsvc").textContent = d.enService.length;
    $("#dlist").innerHTML = d.enService.map((a) => `<div class="item"><b>🟢 ${esc(a.nom)}</b> <span class="mut">depuis ${fmt(a.depuis)}${a.lieu ? " · " + esc(a.lieu) : ""}${a.site ? " (" + esc(siteCourt(a.site)) + ")" : ""}${a.evenement ? " · " + esc(a.evenement) : ""}</span></div>`).join("") || `<p class="mut">Aucun agent n'a pris son service.</p>`;
    $("#dfil").innerHTML = d.fil.map((x) => x.type === "rap"
        ? `<a class="item" href="#/rap" style="display:block;color:inherit;text-decoration:none;border-left:3px solid ${x.urgence === "urgente" ? "var(--red)" : "orange"}"><div class="h"><b>${RT(x.kind)[1]} ${esc(x.numero)} · ${esc(x.label || "")}</b><span class="mut">${fmt(x.t)}</span></div><div class="mut">${esc(x.auteur)}${x.poste ? " (" + esc(x.poste) + ")" : ""} · ${esc(x.lieu)}${x.photos ? ` · 📷 ${x.photos}` : ""} · <b>${esc(x.statut)}</b>${x.urgence === "urgente" ? " · 🚨 urgente" : ""}</div><div style="white-space:pre-wrap">${esc(x.texte).slice(0, 300)}</div></a>`
        : x.type === "rapport"
      ? `<div class="item"><div class="h"><b>📷 Rapport · ${esc(x.titre)}</b><span class="mut">${fmt(x.t)}</span></div><div class="mut">${esc(x.auteur)}${x.lieu ? " · " + esc(x.lieu) : ""}${x.site ? " (" + esc(siteCourt(x.site)) + ")" : ""}${x.photos ? ` · ${x.photos} photo(s)` : ""}</div><div style="white-space:pre-wrap">${esc(x.texte).slice(0, 300)}</div></div>`
      : `<div class="item"><div class="h"><b>${ICON[x.categorie] || "📝"} ${esc(x.numero || "")} · ${esc(x.categorie)}</b><span><span class="badge ${x.gravite}">${x.gravite}</span></span></div>
         <div class="mut">${fmt(x.heure || x.t)} · ${esc(x.auteur)}${x.lieu ? " · " + esc(x.lieu) : ""}${x.site ? " (" + esc(siteCourt(x.site)) + ")" : ""}${x.evenement ? " · " + esc(x.evenement) : ""}</div><div style="white-space:pre-wrap">${esc(x.description).slice(0, 300)}</div></div>`).join("") || `<p class="mut">Rien dans les dernières 24 h.</p>`;
  };
  const charger = async () => {
    if (location.hash !== "#/direct") return clearInterval(directTimer);
    try {
      const d = await api("direct"); last = d;
      $("#dmaj").textContent = "maj " + new Date(d.maj).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
      $("#dopen").textContent = d.ouverts; dessinerD(d);
    } catch (e) { $("#dfil").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
  };
  clearInterval(directTimer); charger(); directTimer = setInterval(charger, 15000);
}

/* ================= Rondes ================= */
let stream = null;
let nfcCtl = null, NFC_EN_ATTENTE = null, geoWatch = null, POS = null, POS_ERR = ""; // lecteur NFC actif + pointeau lu via un lien (iPhone)
function stopScan() { if (stream) { stream.getTracks().forEach((t) => t.stop()); stream = null; } if (nfcCtl) { nfcCtl.abort(); nfcCtl = null; } if (geoWatch !== null) { navigator.geolocation.clearWatch(geoWatch); geoWatch = null; } }
const normUID = (x) => String(x || "").toUpperCase().replace(/[^0-9A-F]/g, "");
const dureeDepuis = (t) => { const m = Math.floor((Date.now() - Date.parse(t)) / 60000); return m >= 60 ? `${Math.floor(m / 60)} h ${String(m % 60).padStart(2, "0")}` : `${m} min`; };
let rondeTimer = null;
async function vRondes() {
  clearInterval(rondeTimer);
  const [parcours, actuelle] = await Promise.all([api("parcours").catch(() => []), lecture() ? null : api("ronde/actuelle").catch(() => null)]);
  let R = actuelle;
  const histo = async () => {
    try { const l = await api("ronde");
      $("#rhist").innerHTML = l.length ? l.slice(0, 60).map((r) => { const fait = new Set(r.passages.map((x) => x.uid)).size;
        return `<details class="item" style="border-left:4px solid ${r.statut === "en cours" ? "var(--orange)" : r.oublies || r.anomalies ? "var(--red)" : "var(--ok)"}"><summary><b>${esc(r.nom)}</b>
          <span class="mut"> · ${fmt(r.debut)}${staff() ? " · " + esc(r.agent) : ""} · ${fait}/${r.points.length}${r.statut === "en cours" ? " · en cours" : ` · ${r.duree} min`}${r.oublies ? ` · ${r.oublies} oublié(s)` : ""}${r.anomalies ? ` · ⚠️ ${r.anomalies}` : ""}${r.ordreOk === false ? " · ordre non respecté" : ""}</span></summary>
          ${r.points.map((p) => { const pa = r.passages.find((x) => x.uid === p.uid);
            return `<div class="mut" style="margin:3px 0">${pa ? (pa.ras ? "✔" : "⚠️") : "✖"} ${pa ? fmt(pa.t).slice(-5) : "--:--"} · ${esc(p.nom)}${pa && pa.mode !== "nfc" ? ` <i>(${pa.mode})</i>` : ""}${pa && pa.obs ? ` — <b>${esc(pa.obs)}</b>` : ""}
              ${pa && pa.gps ? ` · <a target="_blank" rel="noopener" href="https://maps.google.com/?q=${pa.gps.lat},${pa.gps.lon}">📍 carte</a>` : ""}${pa && pa.photos ? ` · <a role="button" style="cursor:pointer;text-decoration:underline" data-vp="${esc(r.id)}-${esc(p.uid)}" data-n="${pa.photos}">📷 ${pa.photos}</a>` : ""}</div>`; }).join("")}
          ${r.obs ? `<p>${esc(r.obs)}</p>` : ""}</details>`; }).join("") : `<p class="mut">Aucune ronde pour le moment.</p>`;
    } catch (e) { $("#rhist").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
  };
  const pointer = async (uid, mode, extra = {}) => {
    if (!R) return toast("Démarre d'abord une ronde");
    try { R = await api(`ronde/${R.id}/pointage`, { method: "POST", body: { uid, mode, gps: POS && Date.now() - POS.t < 120000 ? POS : null, ...extra } });
      const pa = R.passages.find((x) => x.uid === normUID(uid)); if (navigator.vibrate) navigator.vibrate(extra.ras === false ? [80, 60, 80] : 60);
      toast(`${extra.photoSeule ? "📷 Photo ajoutée" : extra.ras === false ? "⚠️ Anomalie" : "✅"} ${pa ? pa.nom : ""}`); dessiner(); }
    catch (e) { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); toast(e.message, 4000); }
  };
  const dessiner = () => {
    if (!R) {
      $("#rzone").innerHTML = lecture() ? `<p class="mut">Consultation seulement.</p>` : `<p class="mut" style="margin-top:0">Choisis ta ronde, puis passe ton téléphone sur chaque pointeau NFC.</p>
        ${parcours.map((p) => `<div class="item"><div class="h"><b>${esc(p.nom)}</b><span class="mut">${p.points.length} pts</span></div><div class="mut">${esc(p.site || "")}${p.dureeMax ? ` · ${p.dureeMax} min max` : ""}</div>
          <button class="btn ok sm" data-go="${esc(p.id)}" style="margin-top:6px">▶ Démarrer cette ronde</button></div>`).join("") || `<p class="mut">Aucun parcours défini.</p>`}
        <div class="item" style="border-left:4px solid var(--red)"><div class="h"><b>🧯 Ronde moyens de secours et d'extinction</b><span class="mut">SSIAP 1</span></div>
          <div class="mut">Check-list guidée de 18 points (extincteurs, RIA, DAE, DM, BAES, issues…), avec l'explication de chaque contrôle pour les nouveaux agents.</div>
          <button class="btn sm" id="rmds" style="margin-top:6px">▶ Ouvrir la ronde guidée</button></div>`;
      if ($("#rmds")) $("#rmds").onclick = () => { try { sessionStorage.setItem("ssiap-check", "SSIAP 1 — Ronde moyens de secours et d'extinction"); } catch {} location.hash = "#/site"; };
      return;
    }
    const fait = new Set(R.passages.map((x) => x.uid)), nfc = "NDEFReader" in window;
    if (geoWatch === null && navigator.geolocation) geoWatch = navigator.geolocation.watchPosition((p) => { POS = { lat: p.coords.latitude, lon: p.coords.longitude, acc: p.coords.accuracy, t: Date.now() }; POS_ERR = ""; const g = $("#rgeo"); if (g) g.textContent = `📍 Position active (±${Math.round(POS.acc)} m)`; },
      () => { POS_ERR = "📍 Position refusée : autorise la localisation pour SSIAP Pro"; const g = $("#rgeo"); if (g) g.textContent = POS_ERR; }, { enableHighAccuracy: true, maximumAge: 20000, timeout: 20000 });
    $("#rzone").innerHTML = `<div class="alerte" style="border-color:var(--orange)"><b>${esc(R.nom)}</b><br><span class="mut">Démarrée à ${fmt(R.debut).slice(-5)} · <span id="rchrono">${dureeDepuis(R.debut)}</span>${R.dureeMax ? ` / ${R.dureeMax} min` : ""} · <b>${fait.size}/${R.points.length}</b> points</span><br><span class="mut" id="rgeo" style="font-size:.8rem">${POS ? `📍 Position active (±${Math.round(POS.acc)} m)` : POS_ERR || "📍 Recherche de la position…"}</span>
        <div style="height:8px;background:var(--card2);border-radius:9px;margin-top:6px;overflow:hidden"><div style="height:100%;width:${Math.round((fait.size / R.points.length) * 100)}%;background:var(--ok)"></div></div></div>
      ${nfc ? `<button class="btn red" id="rnfc" style="margin-top:10px">${nfcCtl ? "📶 NFC actif : passe le téléphone sur le pointeau" : "📶 Activer le NFC"}</button>`
        : `<div class="alerte" style="margin-top:10px">📱 iPhone : approche le haut du téléphone du pointeau (pointeaux programmés avec le lien), ou scanne le QR de secours.</div>`}
      <div class="row" style="margin-top:8px">${"BarcodeDetector" in window ? `<button class="btn sm" id="rqr">📷 QR de secours</button>` : ""}<button class="btn sm" id="rano">⚠️ Signaler une anomalie</button></div>
      <video id="rvid" class="hidden" playsinline muted style="width:100%;border-radius:10px;margin-top:8px"></video>
      <div style="margin-top:10px">${R.points.map((p, i) => { const pa = R.passages.find((x) => x.uid === p.uid);
        return `<div class="item" style="display:flex;gap:8px;align-items:center;opacity:${pa ? 0.75 : 1}"><span style="font-size:1.3rem;flex:none">${pa ? (pa.ras ? "✅" : "⚠️") : "⬜"}</span>
          <span style="flex:1"><b style="font-size:.92rem">${esc(p.nom)}</b>${p.consigne ? `<br><span style="color:var(--orange);font-size:.82rem">📌 ${esc(p.consigne)}</span>` : ""}
          ${pa ? `<br><span class="mut" style="font-size:.8rem">${fmt(pa.t).slice(-5)}${pa.mode !== "nfc" ? " · " + pa.mode : ""}${pa.gps ? " · 📍" : ""}${pa.photos ? ` · 📷 ${pa.photos}` : ""}${pa.obs ? " · " + esc(pa.obs) : ""}</span>` : ""}</span>
          ${pa ? `<button class="btn sm" data-ph="${esc(p.uid)}" style="flex:none" title="Ajouter une photo">📷</button>` : `<button class="btn sm" data-man="${esc(p.uid)}" style="flex:none" title="Pointeau abîmé ou illisible">✋</button>`}</div>`; }).join("")}</div>
      <label>Observations de fin de ronde</label><input id="robs" placeholder="RAS, ou ce qu'il faut savoir…">
      <button class="btn ok" id="rfin" style="margin-top:10px">🏁 Terminer la ronde</button>
      <p class="mut">✋ = pointer à la main si le pointeau est abîmé : c'est signalé au PC.</p>`;
    if ($("#rnfc")) $("#rnfc").onclick = async () => {
      if (nfcCtl) return;
      try { const r = new NDEFReader(); nfcCtl = new AbortController(); await r.scan({ signal: nfcCtl.signal });
        r.onreading = (e) => { let u = e.serialNumber; // UID du pointeau, ou lien écrit dedans
          try { for (const rec of e.message.records) if (rec.recordType === "url") { const m = new TextDecoder().decode(rec.data).match(/nfc\/([0-9A-Fa-f:]+)/); if (m) u = m[1]; } } catch {}
          pointer(u, "nfc"); };
        r.onreadingerror = () => toast("Pointeau illisible, réessaie");
        toast("📶 NFC actif"); dessiner();
      } catch (e) { nfcCtl = null; toast(e.name === "NotAllowedError" ? "Autorise le NFC pour SSIAP Pro" : "NFC indisponible : active-le dans les réglages du téléphone", 4000); }
    };
    if ($("#rqr")) $("#rqr").onclick = async () => {
      if (stream) { stopScan(); $("#rvid").classList.add("hidden"); return; }
      try { stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } }); const v = $("#rvid"); v.srcObject = stream; v.classList.remove("hidden"); await v.play();
        const det = new BarcodeDetector({ formats: ["qr_code"] });
        const tick = async () => { if (!stream) return; const r = await det.detect(v).catch(() => []);
          if (r[0]) { const m = r[0].rawValue.match(/nfc\/([0-9A-Fa-f:]+)/); if (stream) { stream.getTracks().forEach((t) => t.stop()); stream = null; } v.classList.add("hidden"); return m ? pointer(m[1], "qr") : toast("QR inconnu"); }
          requestAnimationFrame(tick); }; tick();
      } catch { toast("Caméra indisponible"); }
    };
    $("#rano").onclick = async () => {
      const choix = R.points.map((p, i) => `${i + 1}. ${p.nom}`).join("\n");
      const n = parseInt(prompt("Numéro du point concerné :\n" + choix, String(Math.min(R.points.length, (R.passages.at(-1)?.ordre || 0) || 1))));
      if (!n || !R.points[n - 1]) return; const obs = prompt("Décris l'anomalie :"); if (!obs) return;
      let photo = null;
      if (confirm("Ajouter une photo ?")) photo = await new Promise((ok) => { const f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.capture = "environment"; f.onchange = async () => ok(f.files[0] ? await compress(f.files[0]) : null); f.click(); });
      pointer(R.points[n - 1].uid, R.passages.find((x) => x.uid === R.points[n - 1].uid)?.mode || "manuel", { ras: false, obs, photo });
    };
    $("#rzone").querySelectorAll("[data-ph]").forEach((b) => (b.onclick = () => { const f = document.createElement("input"); f.type = "file"; f.accept = "image/*"; f.capture = "environment";
      f.onchange = async () => { if (f.files[0]) pointer(b.dataset.ph, "nfc", { photoSeule: true, photo: await compress(f.files[0]) }); }; f.click(); }));
    $("#rzone").querySelectorAll("[data-man]").forEach((b) => (b.onclick = () => { if (confirm("Pointer ce point à la main ? (pointeau abîmé ou illisible — signalé au PC)")) pointer(b.dataset.man, "manuel"); }));
    $("#rfin").onclick = async () => {
      const reste = R.points.length - new Set(R.passages.map((x) => x.uid)).size;
      if (reste && !confirm(`${reste} point(s) non pointé(s). Terminer quand même ?`)) return;
      try { const r = await api(`ronde/${R.id}/fin`, { method: "POST", body: { obs: $("#robs").value } }); stopScan(); R = null; clearInterval(rondeTimer);
        toast(`🏁 Ronde terminée : ${r.points.length - r.oublies}/${r.points.length} points`, 4000); dessiner(); histo(); } catch (e) { toast(e.message); }
    };
  };
  view.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2 style="margin:0">🔦 Rondes NFC</h2>
      ${coord() ? `<div class="row" style="flex:0 0 auto;gap:6px"><button class="btn sm" id="rlearn">🎓 Apprendre</button><button class="btn sm" id="rpar">✏️ Parcours</button><button class="btn sm" id="rprint">🖨️ Pointeaux</button></div>` : ""}</div>
    <div id="rzone"></div></div><div id="redit"></div>
    <div class="card"><h2>${staff() ? "🕑 Rondes de tous les agents" : "🕑 Mes rondes"}</h2><div id="rhist"><p class="mut">Chargement…</p></div></div>`;
  $("#rhist").onclick = async (e) => { const a = e.target.closest("[data-vp]"); if (!a) return; e.preventDefault();
    const box = document.createElement("div"); box.style.cssText = "display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:6px 0";
    for (let k = 0; k < +a.dataset.n; k++) { try { const p = await api(`photo/${a.dataset.vp}-${k}`); const im = new Image(); im.src = p.d; im.className = "thumb"; box.appendChild(im); } catch {} }
    a.replaceWith(box); };
  $("#rzone").onclick = async (e) => { const b = e.target.closest("[data-go]"); if (!b) return;
    try { R = await api("ronde", { method: "POST", body: { parcoursId: b.dataset.go } }); toast("▶ Ronde démarrée"); dessiner(); histo(); if ($("#rnfc")) $("#rnfc").click(); } catch (err) { toast(err.message); } };
  if (coord()) {
    $("#rlearn").onclick = () => {
      const nfc = "NDEFReader" in window; let pc = null, ctl = null;
      const sauver = async () => { const all = parcours.filter((p) => p !== pc && p.points.length); if (pc.points.length) all.push(pc);
        await api("parcours", { method: "PUT", body: { parcours: all.map((p) => ({ ...p })) } }); };
      const dessinerL = () => {
        $("#redit").innerHTML = `<div class="card" style="border-color:var(--red)"><h2>🎓 Apprendre les pointeaux sur le terrain</h2>
          <p class="mut">Tu fais la ronde une fois avec un téléphone <b>Android</b> : à chaque pointeau, tu le scannes et tu lui donnes un nom. L'appli enregistre son numéro toute seule, dans l'ordre de passage.</p>
          ${!nfc ? `<div class="alerte orange">Ce téléphone ne permet pas de lire les pointeaux depuis l'appli. Utilise un Android avec Chrome et le NFC activé.</div>` : ""}
          <label>Parcours</label><select id="lpc"><option value="">— Nouveau parcours —</option>${parcours.map((p) => `<option value="${esc(p.id)}" ${pc && pc.id === p.id ? "selected" : ""}>${esc(p.nom)} (${p.points.length} pts)</option>`).join("")}</select>
          ${!pc || !pc.id ? `<div class="row"><div><label>Nom du nouveau parcours</label><input id="lnom" value="${esc(pc?.nom || "")}" placeholder="Ronde de nuit Hall A"></div><div><label>Site</label><select id="lsite"><option>Parc Expo Valmont</option><option>Valmont Arena</option></select></div></div>` : ""}
          ${nfc ? `<button class="btn red" id="lgo" style="margin-top:10px">${ctl ? "📶 À l'écoute : approche le téléphone du pointeau suivant" : "📶 Démarrer l'apprentissage"}</button>` : ""}
          <div style="margin-top:10px">${(pc?.points || []).map((x, i) => `<div class="item" style="display:flex;gap:8px;align-items:center"><b style="flex:none;color:var(--red2)">${i + 1}</b><span style="flex:1">${esc(x.nom)}<br><span class="mut" style="font-size:.75rem">${esc(x.uid)}</span></span><button class="btn sm" data-lrm="${i}" style="flex:none">✕</button></div>`).join("") || `<p class="mut">Aucun pointeau appris pour l'instant.</p>`}</div>
          <button class="btn sm" id="lstop" style="margin-top:8px">✔ Terminer</button></div>`;
        $("#lpc").onchange = (e) => { pc = parcours.find((p) => p.id === e.target.value) || null; dessinerL(); };
        if ($("#lgo")) $("#lgo").onclick = async () => {
          if (!pc) { const nom = $("#lnom").value.trim(); if (!nom) return toast("Donne un nom au parcours"); pc = { id: "", nom, site: $("#lsite").value, dureeMax: 0, points: [] }; }
          else if (!pc.id && $("#lnom")) pc.nom = $("#lnom").value.trim() || pc.nom;
          if (ctl) return;
          try { const r = new NDEFReader(); ctl = new AbortController(); await r.scan({ signal: ctl.signal }); nfcCtl = ctl;
            r.onreading = async (e) => { const uid = normUID(e.serialNumber); if (!uid) return toast("Numéro illisible, réessaie");
              if (navigator.vibrate) navigator.vibrate(60);
              if (pc.points.some((x) => x.uid === uid)) return toast("Ce pointeau est déjà dans ce parcours");
              const ailleurs = parcours.flatMap((p) => p.points).find((x) => x.uid === uid);
              const nom = prompt(`Pointeau n° ${pc.points.length + 1} lu (${uid})${ailleurs ? `\nDéjà connu sous le nom « ${ailleurs.nom} »` : ""}\nNom de ce point :`, ailleurs ? ailleurs.nom : `${String(pc.points.length + 1).padStart(2, "0")} - `);
              if (!nom) return; pc.points.push({ uid, nom: nom.trim(), consigne: "" });
              try { await sauver(); const fr = await api("parcours"); parcours.length = 0; parcours.push(...fr); pc = fr.find((p) => p.nom === pc.nom) || pc; toast(`✅ ${nom.trim()} enregistré`); } catch (er) { toast(er.message); }
              dessinerL(); };
            toast("📶 Approche le téléphone du premier pointeau"); dessinerL();
          } catch { ctl = null; toast("NFC indisponible : active-le et autorise SSIAP Pro", 4000); }
        };
        $("#redit").querySelectorAll("[data-lrm]").forEach((b) => (b.onclick = async () => { if (!confirm("Retirer ce pointeau du parcours ?")) return; pc.points.splice(+b.dataset.lrm, 1); try { await sauver(); } catch (er) { toast(er.message); } dessinerL(); }));
        $("#lstop").onclick = () => { if (ctl) { ctl.abort(); ctl = null; nfcCtl = null; } vRondes(); };
      };
      dessinerL(); $("#redit").scrollIntoView({ behavior: "smooth" });
    };
    $("#rpar").onclick = () => {
      $("#redit").innerHTML = `<div class="card" style="border-color:var(--red)"><h2>✏️ Parcours de ronde</h2>
        <p class="mut">Format : <b>## Nom du parcours | Site | durée max en minutes (0 = libre)</b>, puis une ligne par pointeau dans l'ordre : <b>Référence du pointeau ; Nom du point ; Consigne</b>. La référence est le numéro de série NFC (ex. 0441826AA30F91).</p>
        <textarea id="pced" style="min-height:300px;font-family:monospace;font-size:.78rem">${esc(parcours.map((p) => `## ${p.nom} | ${p.site || ""} | ${p.dureeMax || 0}\n` + p.points.map((x) => `${x.uid} ; ${x.nom}${x.consigne ? " ; " + x.consigne : ""}`).join("\n")).join("\n\n"))}</textarea>
        <div class="row" style="margin-top:8px">${"NDEFReader" in window ? `<button class="btn sm" id="pcscan">📶 Scanner un pointeau</button>` : ""}<button class="btn red sm" id="pcsave">💾 Enregistrer les parcours</button></div>
        <p class="mut">${"NDEFReader" in window ? "📶 Scanner un pointeau : approche le téléphone du pointeau, donne-lui un nom, la ligne s'ajoute à la fin de la liste (place-la sous le bon parcours si besoin)." : "Pour scanner un pointeau directement, utilise un téléphone Android avec Chrome. Sinon, recopie la référence depuis Guardtek ou l'appli NFC Tools (« Numéro de série »)."}</p></div>`;
      if ($("#pcscan")) $("#pcscan").onclick = async () => {
        try { const r = new NDEFReader(), ctl = new AbortController(); await r.scan({ signal: ctl.signal }); toast("📶 Approche le téléphone du pointeau…", 6000);
          r.onreading = (e) => { ctl.abort(); const uid = normUID(e.serialNumber); if (!uid) return toast("Numéro illisible, réessaie");
            const deja = parcours.flatMap((p) => p.points).find((x) => x.uid === uid) || $("#pced").value.includes(uid);
            const nom = prompt(`Pointeau lu : ${uid}${deja ? "\n(déjà présent dans la liste)" : ""}\nNom du point :`, ""); if (!nom) return;
            $("#pced").value = $("#pced").value.replace(/\s*$/, "") + `\n${uid} ; ${nom.trim()}`; toast("✅ Pointeau ajouté : pense à enregistrer"); };
        } catch (e) { toast("NFC indisponible : active-le et autorise SSIAP Pro", 4000); }
      };
      $("#pcsave").onclick = async () => {
        const out = []; let cur = null;
        for (const l of $("#pced").value.split("\n")) { const t = l.trim(); if (!t) continue;
          if (t.startsWith("##")) { const [nom, site, d] = t.replace(/^#+/, "").split("|").map((x) => (x || "").trim()); const old = parcours.find((p) => p.nom === nom); cur = { id: old ? old.id : "", nom, site, dureeMax: parseInt(d) || 0, points: [] }; out.push(cur); continue; }
          if (!cur) continue; const [uid, nom, consigne] = t.split(";").map((x) => (x || "").trim()); if (uid && nom) cur.points.push({ uid, nom, consigne: consigne || "" }); }
        try { const r = await api("parcours", { method: "PUT", body: { parcours: out } }); toast(`✅ ${r.nb} parcours enregistré(s)`); vRondes(); } catch (e) { toast(e.message); }
      };
      $("#redit").scrollIntoView({ behavior: "smooth" });
    };
    $("#rprint").onclick = async () => {
      if (!window.QRCode) await new Promise((ok, ko) => { const s = document.createElement("script"); s.src = "https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"; s.onload = ok; s.onerror = () => ko(); document.head.appendChild(s); }).catch(() => toast("Connexion nécessaire pour générer les QR"));
      const base = location.origin + "/#/nfc/", vus = new Set(), pts = parcours.flatMap((p) => p.points).filter((x) => !vus.has(x.uid) && vus.add(x.uid));
      const w = document.createElement("div"); w.id = "print";
      w.innerHTML = `<div class="ph"><div><b style="font-size:20px">SSIAP Pro</b> — Pointeaux de ronde</div><div>${pts.length} pointeau(x) · édité le ${new Date().toLocaleDateString("fr-FR")}</div></div>
        <p><b>iPhone :</b> avec l'appli gratuite « NFC Tools », écris dans chaque pointeau le lien indiqué (Écrire ➜ Ajouter un enregistrement ➜ URL). Android lit directement le numéro du pointeau. Le QR sert de secours.</p>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">${pts.map((x, i) => `<div style="border:1px solid #999;border-radius:8px;padding:8px;text-align:center;break-inside:avoid"><div id="q${i}" style="display:flex;justify-content:center"></div>
          <b style="font-size:11px">${esc(x.nom)}</b><div style="font-size:9px;word-break:break-all">${base + x.uid}</div></div>`).join("")}</div>
        <div class="noprint" style="text-align:center;margin:20px"><button class="btn red" data-pr="1">🖨️ Imprimer / PDF</button> <button class="btn" data-pr="0">Fermer</button></div>`;
      document.body.appendChild(w);
      if (window.QRCode) pts.forEach((x, i) => new QRCode(w.querySelector("#q" + i), { text: base + x.uid, width: 110, height: 110, correctLevel: QRCode.CorrectLevel.M }));
      window.scrollTo(0, 0);
    };
  }
  dessiner(); histo();
  rondeTimer = setInterval(() => { if (location.hash !== "#/rondes") return clearInterval(rondeTimer); const c = $("#rchrono"); if (c && R) c.textContent = dureeDepuis(R.debut); }, 20000);
  if (NFC_EN_ATTENTE && R) { const u = NFC_EN_ATTENTE; NFC_EN_ATTENTE = null; pointer(u, "lien"); }
  else if (NFC_EN_ATTENTE && !R) { NFC_EN_ATTENTE = null; toast("Démarre d'abord ta ronde, puis repasse sur le pointeau", 4000); }
}

/* ================= Mémo ================= */
async function vMemo() {
  view.innerHTML = `<div class="card"><h2>${T("memo.titre")}</h2><input class="memo-search" id="q" placeholder="Rechercher : extincteur, palpation, DAE…"></div><div id="fiches"></div>`;
  const P = await chargerPresta();
  const fPresta = { cat: "Site", titre: "🏢 Client et prestataires du Parc Expo Valmont",
    html: Object.entries(P || {}).map(([g, l]) => `<p><b>${esc(g)}</b></p><ul>${l.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`).join("") || "<p>Aucun prestataire.</p>" };
  const draw = (q = "") => {
    const n = (s) => s.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
    const list = [fPresta, ...window.MEMO].filter((f) => !q || n(f.titre + f.html + f.cat).includes(n(q)));
    $("#fiches").innerHTML = list.map((f) => `<details ${q ? "open" : ""}><summary>${f.titre}</summary><div class="c">${f.html}</div></details>`).join("") || `<p class="mut">Aucune fiche.</p>`;
  };
  $("#q").oninput = (e) => draw(e.target.value); draw();
}

/* ================= Site T / L — événementiel ================= */
let jaugeTimer = null;
function catERP(n) { return n > 1500 ? "1re" : n > 700 ? "2e" : n > 300 ? "3e" : "4e ou 5e (selon seuil)"; }
async function vSite() {
  view.innerHTML = `
  <a class="btn red" href="#/plan" style="margin-top:14px">🗺️ Plan du site interactif</a>
  <a class="btn" href="#/risques" style="margin-top:10px">⚠️ Évaluation des risques</a>
  <div class="card"><h2>${T("site.checklists")}</h2>
    <label>Check-list</label><select id="cm">${window.CHECKLISTS_GROUPES.map((g) => `<optgroup label="${esc(g.groupe)}">${Object.keys(g.listes).map((m) => `<option>${esc(m)}</option>`).join("")}</optgroup>`).join("")}</select>
    <div class="row"><div><label>Événement</label><input id="cev" placeholder="Salon, concert…"></div><div><label>Lieu</label><input id="clieu" placeholder="Hall B, Arena…"></div></div>
    <div id="citems" style="margin-top:10px"></div>
    <label>Observations</label><textarea id="cobs" placeholder="Non-conformités, actions demandées…"></textarea>
    <button class="btn red" id="csend" style="margin-top:10px">${T("site.envoyer")}</button>
    <p class="mut">Pour chaque point : ✔ conforme, ✖ non conforme. Les points sans réponse restent non vérifiés.</p>
  </div>

  <div class="card"><h2>🧮 Calcul d'effectif (type T)</h2>
    <div class="row"><div><label>Surface accessible au public (m²)</label><input id="surf" type="number" inputmode="numeric"></div>
    <div><label>Salle</label><select id="stype"><option value="1">Temporaire (salon) — 1 pers./m²</option><option value="9">Permanente — 1 pers./9 m²</option></select></div></div>
    <div id="eff" class="alerte" style="border-color:var(--line)">Saisis une surface.</div></div>

  <h2 style="margin:20px 0 4px">📚 Réglementation du site</h2>
  ${window.SITE_FICHES.map((f) => `<details><summary>${f.titre}</summary><div class="c">${f.html}</div></details>`).join("")}

  <div class="card"><h2>${staff() ? "🗂️ Check-lists envoyées (toutes)" : "🗂️ Mes check-lists"}</h2><div id="clist"><p class="mut">Chargement…</p></div></div>`;

  // Check-lists
  let state = [];
  const drawC = () => {
    state = window.CHECKLISTS[$("#cm").value].map((it) => (Array.isArray(it) ? { label: it[0], aide: it[1], ok: false, nc: false } : { label: it, ok: false, nc: false }));
    const guide = state.some((x) => x.aide);
    $("#citems").innerHTML = (guide ? `<div class="alerte" style="margin-bottom:6px">🎓 Ronde guidée : touche <b>ⓘ</b> pour savoir quoi vérifier et que faire en cas de problème.</div>` : "") + state.map((x, i) => `<div class="item" style="padding:8px 0">
      <div style="display:flex;gap:8px;align-items:center"><span style="flex:1;font-size:.92rem">${esc(x.label)}</span>
      ${x.aide ? `<button class="btn sm" data-aide="${i}" style="flex:none">ⓘ</button>` : ""}<button class="btn sm" data-ok="${i}" style="flex:none">✔</button><button class="btn sm" data-nc="${i}" style="flex:none">✖</button></div>
      ${x.aide ? `<div class="mut hidden" id="aide${i}" style="font-size:.85rem;margin-top:6px;padding:8px;border-radius:8px;background:var(--card2)">${esc(x.aide)}</div>` : ""}</div>`).join("");
  };
  const g0 = window.CHECKLISTS_GROUPES.find((g) => g.roles.includes(S.user.role)); if (g0) $("#cm").value = Object.keys(g0.listes)[0];
  try { const pre = sessionStorage.getItem("ssiap-check"); if (pre && window.CHECKLISTS[pre]) { $("#cm").value = pre; sessionStorage.removeItem("ssiap-check"); } } catch {}
  $("#cm").onchange = drawC; drawC();
  $("#citems").onclick = (e) => {
    const ai = e.target.closest("[data-aide]"); if (ai) { $("#aide" + ai.dataset.aide).classList.toggle("hidden"); return; }
    const o = e.target.closest("[data-ok]"), n = e.target.closest("[data-nc]"); if (!o && !n) return;
    const i = +(o ? o.dataset.ok : n.dataset.nc), x = state[i];
    if (o) { x.ok = !x.ok; x.nc = false; } else { x.nc = !x.nc; x.ok = false; }
    const row = e.target.closest(".item");
    row.querySelector("[data-ok]").classList.toggle("ok", x.ok); row.querySelector("[data-nc]").classList.toggle("red", x.nc);
  };
  $("#csend").onclick = async () => {
    const reste = state.filter((x) => !x.ok && !x.nc).length;
    if (reste && !confirm(`${reste} point(s) non vérifié(s). Envoyer quand même ?`)) return;
    try {
      await api("checklists", { method: "POST", body: { modele: $("#cm").value, evenement: $("#cev").value, lieu: $("#clieu").value, obs: $("#cobs").value, items: state } });
      toast("✅ Check-list envoyée"); $("#cobs").value = ""; drawC(); loadCL();
    } catch (e) { toast(e.message); }
  };

  // Calcul effectif
  $("#surf").oninput = $("#stype").onchange = () => {
    const s = +$("#surf").value, k = +$("#stype").value;
    if (!s) return ($("#eff").textContent = "Saisis une surface.");
    const n = Math.floor(s / k);
    $("#eff").innerHTML = `Effectif public : <b>${n.toLocaleString("fr-FR")} personnes</b> · catégorie <b>${catERP(n)}</b> (hors personnel)<br>
      <span class="mut">${n <= 1500 ? "✅ Chargé de sécurité SSIAP 3 possible (≤ 1 500 personnes)" : "⚠️ Plus de 1 500 personnes : chargé de sécurité PRV 2 ou AP 2 requis"}</span>`;
  };
  loadCL();
}
async function loadCL() {
  try {
    const list = await api("checklists");
    $("#clist").innerHTML = list.length ? list.slice(0, 100).map((c) => {
      const nc = c.items.filter((x) => x.nc), nv = c.items.filter((x) => !x.ok && !x.nc);
      return `<div class="item"><div class="h"><b>${esc(c.modele)}</b><span class="badge ${c.conforme && !nv.length ? "clos" : nc.length ? "urgente" : "ouvert"}">${nc.length ? nc.length + " NC" : nv.length ? nv.length + " non vérifié" : "conforme"}</span></div>
        <div class="mut">${fmt(c.t)} · ${esc(c.evenement)} ${c.lieu ? "· " + esc(c.lieu) : ""}${staff() ? " · " + esc(c.agent) : ""}</div>
        ${nc.map((x) => `<div style="color:var(--red2);font-size:.9rem">✖ ${esc(x.label)}</div>`).join("")}${c.obs ? `<div style="white-space:pre-wrap">${esc(c.obs)}</div>` : ""}</div>`;
    }).join("") : `<p class="mut">Aucune check-list.</p>`;
  } catch (e) { $("#clist").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}

/* ================= Plus ================= */
function vPlus() {
  view.innerHTML = `<div class="card"><h2>☰ Plus</h2>
    <p>Connecté : <b>${esc(S.user.nom)}</b> — ${ROLE_LBL[S.user.role] || S.user.role}</p>
    <div style="display:grid;gap:10px">
      ${S.user.planif || S.user.voitPlanif ? `<a class="btn${S.user.planif ? " red" : ""}" href="#/planif">Planification · planning, devis, tarifs</a>` : ""}
      <a class="btn" href="#/plan">🗺️ Plan du site</a><a class="btn" href="#/docs">📂 Documents PC sécurité</a><a class="btn" href="#/risques">⚠️ Évaluation des risques</a>${staff() ? `<a class="btn" href="#/fil">📜 Fil de l'eau</a>` : ""}<a class="btn" href="#/cles">🔑 Gestion des clés</a><a class="btn" href="#/materiel">📦 Prêt de matériel</a><a class="btn" href="#/batiments">🏢 Ouverture / fermeture · éclairage</a>
      ${peutDPAE() || coord() || lecture() ? `<a class="btn${peutDPAE() ? " red" : ""}" href="#/dpae">📝 Demandes de DPAE</a>` : ""}
      ${S.user.coordArena || staff() || coord() ? `<a class="btn${S.user.coordArena ? " red" : ""}" href="#/equipe">🏟️ Équipe ADS Arena par groupe</a>` : ""}
      <a class="btn" href="#/monplanning">📅 Mon planning</a>${staff() ? `<a class="btn" href="#/plangen">🗓️ Planning général</a><a class="btn" href="#/dispos-admin">🙋 Disponibilités des agents</a>` : `<a class="btn" href="#/dispos">🙋 Mes disponibilités</a>`}
      ${S.user.id !== "__admin" ? `<a class="btn" href="#/fiche" style="text-align:center;text-decoration:none">🪪 Ma fiche de renseignement</a><a class="btn" href="#/dossier" style="text-align:center;text-decoration:none">📁 Mon dossier : diplômes, carte pro, recyclages</a>` : ""}
      ${staff() || coord() || proprio() ? `<a class="btn" href="#/dossiers" style="text-align:center;text-decoration:none">🗂️ Dossiers des agents</a>` : ""}
      ${staff() ? `<a class="btn" href="#/sms" style="text-align:center;text-decoration:none">💬 Prise de poste SMS</a><a class="btn" href="#/fiches" style="text-align:center;text-decoration:none">🪪 Fiches agents</a><a class="btn" href="#/planning" style="text-align:center;text-decoration:none">🗓️ Planning & rappels</a>` : ""}
      ${proprio() ? `<a class="btn" href="#/admin" style="text-align:center;text-decoration:none">⚙️ Administration</a>` : ""}
      ${coord() && !proprio() ? `<a class="btn red" href="#/coord">🗂️ Coordination PC : numéros, mails, planning</a>` : ""}
      <button class="btn" id="pushplus">Notifications sonores : activer / tester</button>
      <button class="btn" id="inst">📲 Installer l'application</button>
      ${S.user.id !== "__admin" ? `<button class="btn" id="chmdp">🔑 Changer mon mot de passe</button>` : ""}
      <button class="btn red" id="out">Déconnexion</button></div></div>
    <div class="foot">${T("pied")} · v1.3</div>`;
  $("#out").onclick = logout;
  if ($("#pushplus")) $("#pushplus").onclick = () => (location.hash = "#/notifdiag");
  if ($("#chmdp")) $("#chmdp").onclick = async () => {
    const ancien = prompt("Mot de passe actuel"); if (!ancien) return;
    const mdp = prompt("Nouveau mot de passe (6 caractères minimum)"); if (!mdp) return;
    try { await api("mdp", { method: "POST", body: { ancien, mdp } }); toast("✅ Mot de passe changé"); } catch (e) { toast(e.message); }
  };
  $("#inst").onclick = () => deferredPrompt ? deferredPrompt.prompt()
    : toast("iPhone : Partager ➜ Sur l'écran d'accueil. Android : menu ⋮ ➜ Installer l'application", 5000);
}

/* ================= Planification (type Comète) : planning, contrôles réglementaires, devis, tarifs ================= */
const PL = { lundi: null, mois: null, vue: "mois", onglet: "semaine", site: "", q: "", sel: null, devis: null };
const QUALIFS_DEF = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "ADS cynophile", "Coordinateur"];
const JOURS_C = ["Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"], JOURS_L = ["D", "L", "M", "M", "J", "V", "S"];
const frDate = (s) => s.split("-").reverse().join("/");
const euros = (n) => (Number(n) || 0).toLocaleString("fr-FR", { style: "currency", currency: "EUR" });
const hFmt = (h) => (Math.round(h * 100) / 100).toLocaleString("fr-FR") + " h";
// couleur d'un événement (même événement = même couleur)
const EV_COUL = ["#2dd4bf", "#f472b6", "#a78bfa", "#fb923c", "#4ade80", "#38bdf8", "#facc15", "#f87171", "#c084fc", "#34d399", "#fbbf24", "#60a5fa"];
const couleurEv = (ev) => { if (!ev) return ""; let h = 0; for (const c of ev.toLowerCase()) h = (h * 31 + c.charCodeAt(0)) >>> 0; return EV_COUL[h % EV_COUL.length]; };
async function vPlanif() {
  if (!S.user.voitPlanif && !S.user.planif && !proprio()) return (location.hash = "#/");
  if (!PL.lundi) PL.lundi = window.PLANIF.lundi(Date.now());
  if (!PL.mois) PL.mois = new Date().toISOString().slice(0, 7);
  const mois = PL.vue === "mois";
  const du = mois ? PL.mois + "-01" : PL.lundi;
  const fin = mois ? window.PLANIF.iso(new Date(Date.UTC(+PL.mois.slice(0, 4), +PL.mois.slice(5, 7), 0))) : window.PLANIF.iso(new Date(Date.parse(PL.lundi) + 6 * 864e5));
  const [D, tarifs] = await Promise.all([api(`planif?du=${du}&au=${fin}`), api("planif/tarifs").catch(() => ({ taux: {} }))]);
  const modif = D.peutModif, valideur = D.niveau === "valideur", attente = (D.brouillons || []).filter((b) => b.statut === "en attente"), rouges = D.controles.filter((c) => c.niveau === "rouge"), oranges = D.controles.filter((c) => c.niveau === "orange");
  const idsRouges = new Set(rouges.flatMap((c) => c.ids)), idsOranges = new Set(oranges.flatMap((c) => c.ids));
  const nbJ = Math.round((Date.parse(fin) - Date.parse(du)) / 864e5) + 1, jours = [...Array(nbJ).keys()].map((i) => window.PLANIF.iso(new Date(Date.parse(du) + i * 864e5)));
  const titrePer = mois ? (() => { const t = new Date(du + "T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" }); return t[0].toUpperCase() + t.slice(1); })() : `Semaine du ${frDate(du)} au ${frDate(fin)}`;
  const decaler = (n) => { if (mois) { const d = new Date(Date.UTC(+PL.mois.slice(0, 4), +PL.mois.slice(5, 7) - 1 + n, 1)); PL.mois = d.toISOString().slice(0, 7); } else PL.lundi = window.PLANIF.iso(new Date(Date.parse(PL.lundi) + n * 7 * 864e5)); vPlanif(); };
  const navHTML = `<div class="plnav"><button class="btn sm" id="plp">‹</button><b>${titrePer}</b><button class="btn sm" id="pln">›</button><button class="btn sm" id="plt">Aujourd'hui</button><div class="seg" id="plv" style="flex:0 0 auto">${[["mois", "Mois"], ["semaine", "Semaine"]].map(([k, l]) => `<button type="button" data-vu="${k}" class="${PL.vue === k ? "on" : ""}">${l}</button>`).join("")}</div></div>`;
  const brancherNav = () => { $("#plp").onclick = () => decaler(-1); $("#pln").onclick = () => decaler(1); $("#plt").onclick = () => { PL.lundi = window.PLANIF.lundi(Date.now()); PL.mois = new Date().toISOString().slice(0, 7); vPlanif(); };
    $("#plv").onclick = (e) => { const b = e.target.closest("[data-vu]"); if (!b) return; PL.vue = b.dataset.vu; if (PL.vue === "semaine" && mois) PL.lundi = window.PLANIF.lundi(Date.parse(du)); if (PL.vue === "mois" && !mois) PL.mois = PL.lundi.slice(0, 7); vPlanif(); }; };
  view.innerHTML = `<div class="card plan-h"><div class="h" style="display:flex;justify-content:space-between;align-items:flex-end;gap:8px;flex-wrap:wrap">
      <div><div class="psur">Planification · ${D.niveau === "valideur" ? "planificateur" : D.niveau === "redacteur" ? "rédacteur (validation Julien Moreau)" : "lecture seule"}</div><h2 style="margin:2px 0 0">Planning des agents</h2></div>
      <div class="seg" id="plo" style="flex:0 1 auto">${[["semaine", "Planning"], ["postes", "Postes"], ["valider", `À valider${attente.length ? ` <b class="cnt" style="background:var(--g-moy)">${attente.length}</b>` : ""}`], ["agents", "Agents"], ["controles", `Contrôles${rouges.length ? ` <b class="cnt">${rouges.length}</b>` : ""}`], ["devis", "Devis"], ["tarifs", "Tarifs"]].map(([k, l]) => `<button type="button" data-o="${k}" class="${PL.onglet === k ? "on" : ""}">${l}</button>`).join("")}</div></div>
    ${modif ? (valideur ? "" : `<p class="mut" style="margin:8px 0 0">Tes saisies sont <b>enregistrées</b> mais <b>ne sont publiées</b> qu'après validation de Julien Moreau.</p>`) : `<p class="mut" style="margin:8px 0 0">Planning en lecture : seuls les planificateurs (Julien Moreau, Antoine Rivière) le modifient.</p>`}</div>
  <div id="plz"></div>`;
  $("#plo").onclick = (e) => { const b = e.target.closest("[data-o]"); if (!b) return; PL.onglet = b.dataset.o; PL.sel = null; vPlanif(); };
  const box = $("#plz");
  // ---------------- planning (mois ou semaine)
  if (PL.onglet === "semaine") {
    const lignes = D.lignes.filter((v) => (!PL.site || (PL.site === "arena" ? /arena/i.test(v.site + " " + v.poste) : !/arena/i.test(v.site + " " + v.poste))) && (!PL.q || (v.nom + " " + v.poste + " " + (v.evenement || "")).toLowerCase().includes(PL.q.toLowerCase())));
    const brs = (D.brouillons || []).filter((b) => b.statut === "en attente"), aSupp = new Set(brs.filter((b) => b.action !== "ajouter").map((b) => b.ref));
    const bv = brs.filter((b) => b.action !== "supprimer").map((b) => ({ ...b.vac, id: b.id, brouillon: b }));
    const parAgent = {}; for (const v of [...lignes, ...bv].filter((x) => jours.includes(x.date))) (parAgent[window.PLANIF.cleAgent(v.nom)] ||= { nom: v.nom, vs: [] }).vs.push(v);
    const agents = Object.values(parAgent).sort((a, b) => a.nom.localeCompare(b.nom, "fr"));
    const semRouge = new Set(rouges.filter((c) => c.type === "hebdo48").map((c) => window.PLANIF.cleAgent(c.nom)));
    const evs = [...new Set([...lignes, ...bv].filter((v) => jours.includes(v.date) && v.evenement).map((v) => v.evenement))].sort();
    const typeJour = (j) => (window.PLANIF.estFerie(j) ? "fer" : [0, 6].includes(new Date(j + "T12:00:00Z").getUTCDay()) ? "we" : "");
    const chip = (v) => { const h = window.PLANIF.vacation(v), nuit = h.hNuit >= h.heures / 2, tj = typeJour(v.date), ce = couleurEv(v.evenement);
      return `<div class="pv ${nuit ? "nuit" : tj ? "wk" : "jour"} ${v.brouillon ? "brouillon" : v.source === "planif" ? "saisi" : "imp"} ${aSupp.has(v.id) ? "asupp" : ""} ${idsRouges.has(v.id) ? "err" : idsOranges.has(v.id) ? "warn" : ""} ${PL.sel === v.id ? "sel" : ""}" data-v="${esc(v.id || "")}" ${ce ? `style="--ev:${ce}"` : ""} title="${esc([v.nom, v.debut + "-" + v.fin, v.poste, v.evenement].filter(Boolean).join(" · "))}">
        <b>${mois ? esc(v.debut.replace(":00", "h").replace(":", "h")) + "–" + esc(v.fin.replace(":00", "h").replace(":", "h")) : esc(v.debut) + "–" + esc(v.fin)}</b>${mois ? "" : `<small>${esc((v.poste || v.qualif || "").slice(0, 26))}</small>`}</div>`; };
    box.innerHTML = `<div class="card">${navHTML}
      <div class="row" style="margin-top:10px"><input id="plq" placeholder="Rechercher un agent, un poste, un événement…" value="${esc(PL.q)}"><div class="seg" id="pls" style="flex:0 0 auto">${[["", "Tous"], ["parc", "Parc"], ["arena", "Arena"]].map(([k, l]) => `<button type="button" data-s="${k}" class="${PL.site === k ? "on" : ""}">${l}</button>`).join("")}</div></div>
      <p class="mut" style="margin:8px 0 0">${agents.length} agent(s) · ${lignes.filter((v) => jours.includes(v.date)).length} vacation(s) · <span style="color:var(--g-urg)">${rouges.length} alerte(s)</span>${oranges.length ? ` · <span style="color:var(--g-moy)">${oranges.length} à vérifier</span>` : ""}</p>
      ${modif ? `<div class="row" style="margin-top:10px"><button class="btn red" id="pladd">Ajouter une vacation</button>${valideur ? `<button class="btn" id="plup">Téléverser un planning</button>` : ""}</div>` : ""}</div>
      <div id="plform"></div>
      <div class="card plgrid-card"><div class="plgrid-wrap"><table class="plgrid ${mois ? "mois" : ""}"><thead><tr><th class="ag">Agent</th>${jours.map((j) => { const d = new Date(j + "T12:00:00Z").getUTCDay(), tj = typeJour(j);
        return `<th class="${tj}">${mois ? `${JOURS_L[d]}<br>${+j.slice(8)}` : `${JOURS_C[(d + 6) % 7]} ${j.slice(8)}`}${tj === "fer" ? `<br><small>férié</small>` : ""}</th>`; }).join("")}<th>Total</th></tr></thead><tbody>
      ${agents.length ? agents.map((a) => { const tot = a.vs.filter((v) => !v.brouillon).reduce((s, v) => s + window.PLANIF.vacation(v).heures, 0), k = window.PLANIF.cleAgent(a.nom);
        return `<tr><td class="ag">${esc(a.nom)}</td>${jours.map((j) => `<td class="${typeJour(j)}">${a.vs.filter((v) => v.date === j).sort((x, y) => x.debut.localeCompare(y.debut)).map(chip).join("")}</td>`).join("")}
          <td class="tot ${(!mois && tot > 48) || semRouge.has(k) ? "err" : ""}">${hFmt(tot)}</td></tr>`; }).join("") : `<tr><td colspan="${nbJ + 2}" class="mut" style="padding:16px">Aucune vacation sur la période.</td></tr>`}
      </tbody></table></div>
      <div class="plleg"><span><i class="pv jour"></i>Jour</span><span><i class="pv nuit"></i>Nuit (21 h – 6 h)</span><span><i class="pv wk"></i>Samedi, dimanche, férié</span><span><i class="pv jour err"></i>Règle dépassée</span><span><i class="pv jour warn"></i>À vérifier</span><span><i class="pv jour brouillon"></i>En attente de validation</span><span><i class="pv jour imp"></i>Téléversé (pointillé)</span></div>
      ${evs.length ? `<div class="plleg" style="border-top:0;padding-top:0">${evs.map((e) => `<span><i class="evp" style="background:${couleurEv(e)}"></i>${esc(e)}</span>`).join("")}</div>` : ""}</div>
      <div id="pldet"></div>`;
    brancherNav();
    $("#plq").onchange = (e) => { PL.q = e.target.value; vPlanif(); };
    $("#pls").onclick = (e) => { const b = e.target.closest("[data-s]"); if (!b) return; PL.site = b.dataset.s; vPlanif(); };
    view.querySelector(".plgrid").onclick = (e) => { const c = e.target.closest("[data-v]"); if (!c) return; PL.sel = c.dataset.v; view.querySelectorAll(".pv.sel").forEach((x) => x.classList.remove("sel")); c.classList.add("sel");
      const b = (D.brouillons || []).find((x) => x.id === PL.sel); b ? detailBrouillon(b) : detail(D.lignes.find((v) => v.id === PL.sel)); };
    if ($("#pladd")) $("#pladd").onclick = () => formVac(null);
    if ($("#plup")) $("#plup").onclick = televerser;
    if (PL.sel) { const v = D.lignes.find((x) => x.id === PL.sel); if (v) detail(v); }
  }
  function detail(v) {
    if (!v) return; const c = D.controles.filter((x) => x.ids.includes(v.id)), h = window.PLANIF.vacation(v);
    $("#pldet").innerHTML = `<div class="card pfiche" style="--zc:${c.some((x) => x.niveau === "rouge") ? "var(--g-urg)" : "#3a4250"}"><div class="pfh"><div><div class="psur">${v.source === "planif" ? "Saisi par " + esc(v.par || "la planification") : "Téléversé · verrouillé"}</div><h2 style="margin:2px 0 0">${esc(v.nom)}</h2></div><span class="pcarreau">${frDate(v.date)}</span></div>
      <div class="pkvs" style="margin-top:10px"><div class="pkv"><span>Horaires</span><b>${esc(v.debut)} – ${esc(v.fin)} (${hFmt(h.heures)})</b></div>${v.poste ? `<div class="pkv"><span>Poste</span><b>${esc(v.poste)}</b></div>` : ""}${v.site ? `<div class="pkv"><span>Site</span><b>${esc(v.site)}</b></div>` : ""}${v.evenement ? `<div class="pkv"><span>Événement</span><b>${esc(v.evenement)}</b></div>` : ""}${v.qualif ? `<div class="pkv"><span>Qualification</span><b>${esc(v.qualif)}</b></div>` : ""}
        <div class="pkv"><span>Dont nuit / dimanche / férié</span><b>${hFmt(h.hNuit)} · ${hFmt(h.hDim)} · ${hFmt(h.hFer)}</b></div></div>
      ${c.length ? `<div class="psec">Contrôles</div>${c.map((x) => `<div class="pfait ${x.niveau === "rouge" ? "g-urgente" : "g-moyenne"}">${esc(x.texte)}</div>`).join("")}` : `<p class="mut" style="margin:10px 0 0">Aucune alerte sur cette vacation.</p>`}
      ${(D.brouillons || []).some((b) => b.ref === v.id && b.statut === "en attente") ? `<p style="color:var(--g-moy);margin:10px 0 0">Une ${(D.brouillons.find((b) => b.ref === v.id && b.statut === "en attente") || {}).action === "supprimer" ? "suppression" : "modification"} est en attente de validation.</p>` : ""}
      ${modif && v.source === "planif" ? `<div class="pactions"><button class="btn" id="pledit">Modifier</button><button class="btn" id="pldel">Supprimer</button></div>` : v.source !== "planif" ? `<p class="mut" style="font-size:.78rem;margin:10px 0 0">Vacation téléversée : elle n'est jamais modifiée par l'appli, les écarts sont seulement signalés.</p>` : ""}</div>`;
    if ($("#pledit")) $("#pledit").onclick = () => formVac(v);
    if ($("#pldel")) $("#pldel").onclick = async () => { if (!confirm(valideur ? "Supprimer cette vacation ?" : "Demander la suppression de cette vacation ? (validation de Julien Moreau)")) return; try { const r = await api("planif/vacation/" + v.id, { method: "DELETE" }); PL.sel = null; toast(r.brouillon ? "Suppression en attente de validation" : "Vacation supprimée"); vPlanif(); } catch (e) { toast(e.message); } };
    $("#pldet").scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
  function formVac(v) {
    const f = v || { date: jours[0], debut: "08:00", fin: "20:00", site: "Parc Expo Valmont" };
    $("#plform").innerHTML = `<div class="card"><h2>${v ? "Modifier la vacation" : "Nouvelle vacation"}</h2><form id="pvf">
      <label>Agent</label><input name="nom" list="plag" value="${esc(f.nom || "")}" required autocomplete="off"><datalist id="plag">${D.agents.map((n) => `<option value="${esc(n)}">`).join("")}</datalist>
      <div class="row"><div><label>Date</label><input type="date" name="date" value="${f.date}" required></div><div><label>Début</label><input type="time" name="debut" value="${f.debut}" required></div><div><label>Fin</label><input type="time" name="fin" value="${f.fin}" required></div></div>
      <div class="row"><div><label>Poste</label><input name="poste" value="${esc(f.poste || "")}" placeholder="ex. SSIAP 1 TOUS HALLS"></div><div><label>Qualification</label><select name="qualif"><option value="">—</option>${QUALIFS_DEF.map((q) => `<option ${q === f.qualif ? "selected" : ""}>${q}</option>`).join("")}</select></div></div>
      <div class="row"><div><label>Site</label><select name="site">${["Parc Expo Valmont", "Valmont Arena"].map((s) => `<option ${s === f.site ? "selected" : ""}>${s}</option>`).join("")}</select></div><div><label>Événement</label><input name="evenement" value="${esc(f.evenement || "")}"></div></div>
      <div class="row" style="margin-top:12px"><button class="btn red">${v ? "Enregistrer" : "Ajouter"}</button><button class="btn" type="button" id="pvx">Annuler</button></div></form></div>`;
    $("#pvx").onclick = () => ($("#plform").innerHTML = "");
    $("#pvf").onsubmit = async (e) => { e.preventDefault();
      try { const r = await api("planif/vacation" + (v ? "/" + v.id : ""), { method: v ? "PATCH" : "POST", body: Object.fromEntries(new FormData(e.target)) });
        if (r.brouillon) { PL.sel = r.brouillon.id; PL.lundi = window.PLANIF.lundi(Date.parse(r.brouillon.vac.date)); PL.mois = r.brouillon.vac.date.slice(0, 7); toast("Enregistré — en attente de validation de Julien Moreau : pas encore publié", 6000); vPlanif(); return; }
        PL.sel = r.vacation.id; PL.lundi = window.PLANIF.lundi(Date.parse(r.vacation.date)); PL.mois = r.vacation.date.slice(0, 7); toast(r.controles.some((c) => c.niveau === "rouge") ? `Enregistré — ${r.controles.filter((c) => c.niveau === "rouge").length} règle(s) dépassée(s), en rouge` : "Vacation enregistrée", 5000); vPlanif(); } catch (err) { toast(err.message); } };
    $("#plform").scrollIntoView({ behavior: "smooth" });
  }
  function televerser() {
    $("#plform").innerHTML = `<div class="card"><h2>Téléverser un planning</h2><p class="mut" style="margin-top:0">PDF Comète (« Planning site par agents »), Excel ou CSV. Les vacations téléversées ne sont <b>jamais modifiées</b> : l'appli signale seulement les écarts en rouge.</p>
      <input type="file" id="ufile" accept=".pdf,.xlsx,.xls,.ods,.csv,.txt" multiple><label>Mode</label><select id="umode"><option value="remplacer">Remplacer les jours importés (même site) — les vacations saisies sont conservées</option><option value="ajouter">Ajouter au planning existant</option></select>
      <div id="uap" class="mut" style="margin-top:8px"></div><button class="btn red" id="ugo" style="margin-top:10px" disabled>Importer</button></div>`;
    let lignes = [];
    $("#ufile").onchange = async (e) => { const fs = [...e.target.files]; if (!fs.length) return; $("#uap").textContent = "Lecture en cours…";
      try { lignes = []; const infos = [];
        for (const f of fs) { if (/\.pdf$/i.test(f.name)) { await chargerScript("comete.js"); const r = await window.lireComete(f); lignes.push(...r.lignes); infos.push(`${r.site} ${r.mois} : ${r.lignes.length} vacation(s)`); } else lignes.push(...lirePlanning(await fichierEnLignes(f))); }
        const nb = new Set(lignes.map((l) => l.nom)).size, ctl = window.PLANIF.controles(lignes).filter((c) => c.niveau === "rouge");
        $("#uap").innerHTML = lignes.length ? `${infos.map(esc).join("<br>")}${infos.length ? "<br>" : ""}${lignes.length} vacation(s) · ${nb} agent(s)${ctl.length ? `<br><span style="color:var(--g-urg)">${ctl.length} écart(s) réglementaire(s) détecté(s) dans ce fichier</span>` : ""}` : "Aucune vacation trouvée"; $("#ugo").disabled = !lignes.length;
      } catch (err) { $("#uap").textContent = err.message; } };
    $("#ugo").onclick = async () => { $("#ugo").disabled = true; try { const r = await api("planning", { method: "PUT", body: { lignes, mode: $("#umode").value } }); toast(`${r.importees} vacation(s) téléversée(s)`); PL.lundi = window.PLANIF.lundi(Date.parse(lignes.map((l) => l.date).sort()[0])); PL.mois = lignes.map((l) => l.date).sort()[0].slice(0, 7); vPlanif(); } catch (err) { toast(err.message); $("#ugo").disabled = false; } };
    $("#plform").scrollIntoView({ behavior: "smooth" });
  }
  function detailBrouillon(b) {
    const v = b.vac, h = window.PLANIF.vacation(v), lib = { ajouter: "Ajout", modifier: "Modification", supprimer: "Suppression" }[b.action];
    $("#pldet").innerHTML = `<div class="card pfiche" style="--zc:var(--g-moy)"><div class="pfh"><div><div class="psur">${lib} en attente de validation · saisi par ${esc(b.par)}</div><h2 style="margin:2px 0 0">${esc(v.nom)}</h2></div><span class="pcarreau">${frDate(v.date)}</span></div>
      <div class="pkvs" style="margin-top:10px"><div class="pkv"><span>Horaires</span><b>${esc(v.debut)} – ${esc(v.fin)} (${hFmt(h.heures)})</b></div>${v.poste ? `<div class="pkv"><span>Poste</span><b>${esc(v.poste)}</b></div>` : ""}${v.site ? `<div class="pkv"><span>Site</span><b>${esc(v.site)}</b></div>` : ""}<div class="pkv"><span>Saisi le</span><b>${fmt(b.t)}</b></div></div>
      <p class="mut" style="margin:10px 0 0">Enregistré, mais pas publié : les agents ne le voient pas tant que Julien Moreau n'a pas validé.</p>
      <div class="pactions">${valideur ? `<button class="btn ok" data-bv="${b.id}">Valider et publier</button><button class="btn" data-br="${b.id}">Refuser</button>` : ""}${b.parId === S.user.id || valideur ? `<button class="btn" data-bx="${b.id}">Retirer</button>` : ""}</div></div>`;
    $("#pldet").scrollIntoView({ behavior: "smooth", block: "nearest" });
  }
  const actionsBrouillon = async (e) => {
    const v = e.target.closest("[data-bv]"), r = e.target.closest("[data-br]"), x = e.target.closest("[data-bx]");
    try {
      if (v) { await api(`planif/brouillon/${v.dataset.bv}/valider`, { method: "POST" }); toast("Validé et publié"); PL.sel = null; vPlanif(); }
      if (r) { const motif = prompt("Motif du refus (facultatif)") ?? null; if (motif === null) return; await api(`planif/brouillon/${r.dataset.br}/refuser`, { method: "POST", body: { motif } }); toast("Refusé"); PL.sel = null; vPlanif(); }
      if (x) { if (!confirm("Retirer cette saisie ?")) return; await api(`planif/brouillon/${x.dataset.bx}`, { method: "DELETE" }); toast("Retiré"); PL.sel = null; vPlanif(); }
    } catch (err) { toast(err.message); }
  };
  box.addEventListener("click", actionsBrouillon);
  // ---------------- à valider
  if (PL.onglet === "valider") {
    const refus = (D.brouillons || []).filter((b) => b.statut === "refusé");
    const carte = (b) => { const v = b.vac, lib = { ajouter: "Ajout", modifier: "Modification", supprimer: "Suppression" }[b.action];
      return `<div class="pfait ${b.statut === "refusé" ? "g-urgente" : "g-moyenne"}"><b>${lib} · ${esc(v.nom)}</b> — ${frDate(v.date)} ${esc(v.debut)}–${esc(v.fin)}${v.poste ? " · " + esc(v.poste) : ""}<br><span class="mut">par ${esc(b.par)} le ${fmt(b.t)}${b.statut === "refusé" ? ` · refusé par ${esc(b.par2 || "")}${b.motif ? " : " + esc(b.motif) : ""}` : ""}</span>
        <div class="row" style="margin-top:6px">${valideur && b.statut === "en attente" ? `<button class="btn sm ok" data-bv="${b.id}">Valider et publier</button><button class="btn sm" data-br="${b.id}">Refuser</button>` : ""}${b.parId === S.user.id || valideur ? `<button class="btn sm" data-bx="${b.id}">Retirer</button>` : ""}</div></div>`; };
    box.innerHTML = `<div class="card"><h2>À valider</h2><p class="mut" style="margin-top:0">Les saisies de Thomas Garnier et Lucas Fontaine sont enregistrées ici. Elles ne sont publiées dans le planning des agents qu'après la validation de Julien Moreau.</p>
      ${valideur && attente.length > 1 ? `<button class="btn ok" id="bvall" style="margin-bottom:8px">Tout valider (${attente.length})</button>` : ""}
      <div class="psec">En attente <b>${attente.length}</b></div>${attente.map(carte).join("") || `<p class="mut">Rien en attente.</p>`}
      ${refus.length ? `<div class="psec">Refusées <b>${refus.length}</b></div>${refus.map(carte).join("")}` : ""}</div>`;
    if ($("#bvall")) $("#bvall").onclick = async () => { if (!confirm(`Valider et publier ${attente.length} saisie(s) ?`)) return; for (const b of attente) { try { await api(`planif/brouillon/${b.id}/valider`, { method: "POST" }); } catch (err) { toast(err.message); } } toast("Saisies validées et publiées"); vPlanif(); };
  }
  // ---------------- postes à pourvoir : créer les postes, glisser les agents, publication par Julien Moreau
  if (PL.onglet === "postes") {
    const R = await api(`planif/postes?du=${du}&au=${fin}`), ed = R.peutEditer;
    const postes = R.postes.filter((p) => !p.supprime).sort((a, b) => (a.date + a.debut + a.poste).localeCompare(b.date + b.debut + b.poste));
    const pourvus = postes.filter((p) => p.agents.length >= p.nb), aPourvoir = postes.filter((p) => p.agents.length < p.nb), manque = aPourvoir.reduce((s, p) => s + p.nb - p.agents.length, 0);
    const f = PL.fpostes || "", vis = f === "ok" ? pourvus : f === "ko" ? aPourvoir : postes;
    const telDe = (n) => (D.tels || {})[window.PLANIF.cleAgent(n)] || "";
    // heures déjà prévues sur la période (publié + postes en brouillon) pour aider au choix
    const heures = {}; D.lignes.filter((v) => jours.includes(v.date) && !v.posteId).forEach((v) => { const k = window.PLANIF.cleAgent(v.nom); heures[k] = (heures[k] || 0) + window.PLANIF.vacation(v).heures; });
    postes.forEach((p) => p.agents.forEach((a) => { const k = window.PLANIF.cleAgent(a.nom); heures[k] = (heures[k] || 0) + window.PLANIF.vacation(p).heures; }));
    const tousAg = [...new Map([...D.agents, ...D.lignes.map((v) => v.nom)].map((n) => [window.PLANIF.cleAgent(n), n])).values()].sort((x, y) => x.localeCompare(y, "fr"));
    const parJour = {}; vis.forEach((p) => (parJour[p.date] ||= []).push(p));
    const tj = (j) => (window.PLANIF.estFerie(j) ? "fer" : [0, 6].includes(new Date(j + "T12:00:00Z").getUTCDay()) ? "we" : "");
    const carte = (p) => { const h = window.PLANIF.vacation(p), nuit = h.hNuit >= h.heures / 2, plein = p.agents.length >= p.nb;
      return `<div class="pst ${plein ? "plein" : "manque"} ${nuit ? "nuit" : tj(p.date) ? "wk" : ""}" data-p="${p.id}" style="--ev:${couleurEv(p.evenement) || "transparent"}">
        <div class="psth"><span><b>${esc(p.debut)}–${esc(p.fin)}</b> · ${esc(p.poste)}</span><span class="pchip ${plein ? "ok" : "dno"}">${p.agents.length}/${p.nb}</span></div>
        <div class="mut" style="font-size:.74rem">${[p.qualif, p.site, p.evenement].filter(Boolean).map(esc).join(" · ")}${p.modifie ? ` · <span style="color:var(--g-moy)">brouillon</span>` : ` · <span style="color:#4ade80">publié</span>`}</div>
        <div class="pslots">${p.agents.map((a, i) => `<span class="pag">${esc(a.nom)}${ed ? `<button type="button" data-rm="${p.id}|${i}" title="Retirer">✕</button>` : ""}</span>`).join("")}${[...Array(Math.max(0, p.nb - p.agents.length))].map(() => `<span class="pvide" data-drop="${p.id}">${ed ? "Glisser un agent ici" : "à pourvoir"}</span>`).join("")}</div>
        ${ed ? `<div class="row" style="margin-top:6px"><button type="button" class="btn sm" data-edp="${p.id}">Modifier</button><button type="button" class="btn sm" data-dlp="${p.id}">Supprimer</button></div>` : ""}</div>`; };
    box.innerHTML = `<div class="card">${navHTML}
      <div class="pstat"><button type="button" data-fp="" class="${!f ? "on" : ""}"><b>${postes.length}</b>postes</button><button type="button" data-fp="ok" class="${f === "ok" ? "on" : ""}"><b style="color:#4ade80">${pourvus.length}</b>fait (pourvus)</button><button type="button" data-fp="ko" class="${f === "ko" ? "on" : ""}"><b style="color:#ff6b7d">${aPourvoir.length}</b>pas fait · ${manque} agent(s)</button><button type="button" data-fp="np" class="${f === "np" ? "on" : ""}"><b style="color:var(--g-moy)">${R.nonPlanifiees.length}</b>prestations non planifiées</button></div>
      ${R.aPublier ? `<div class="pubbar"><span><b>${R.aPublier}</b> poste(s) en brouillon : les agents ne voient rien tant que ce n'est pas publié.</span>${R.peutPublier ? `<button class="btn ok" id="pspub">Publier le planning</button>` : `<span class="mut">Publication par Julien Moreau</span>`}</div>` : `<p class="mut" style="margin:8px 0 0">Tout est publié.</p>`}
      ${ed ? `<button class="btn red" id="psnew" style="margin-top:10px">Créer un poste</button>` : ""}</div>
      <div id="psform"></div>
      <div class="pboard"><div class="pcol">
        ${f === "np" ? `<div class="card"><h2>Prestations non planifiées</h2><p class="mut" style="margin-top:0">Lignes des devis acceptés sans poste créé.</p>${ed && R.nonPlanifiees.length ? `<div class="row" style="margin-bottom:8px">${[...new Map(R.nonPlanifiees.map((l) => [l.devisId, l.numero])).entries()].map(([id, n]) => `<button class="btn sm red" data-npall="${id}">Créer tous les postes du ${esc(n)}</button>`).join("")}</div>` : ""}${R.nonPlanifiees.map((l) => `<div class="prow"><span><b>${frDate(l.date)} ${esc(l.debut)}–${esc(l.fin)} · ${esc(l.libelle || l.qualif)}</b> × ${l.nb}<br><span class="mut" style="font-size:.78rem">${esc(l.numero)} · ${esc(l.client || "")} · ${esc(l.evenement || "")}</span></span>${ed ? `<button class="btn sm" data-np="${l.devisId}|${l.ligne}|${l.date}">Créer le poste</button>` : ""}</div>`).join("") || `<p class="mut">Aucune.</p>`}</div>`
        : Object.keys(parJour).sort().map((j) => `<div class="card pjour"><div class="psur ${tj(j)}">${new Date(j + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}${tj(j) === "fer" ? " · férié" : ""}</div>${parJour[j].map(carte).join("")}</div>`).join("") || `<div class="card"><p class="mut">Aucun poste sur la période${ed ? " : crée-les avec « Créer un poste » ou depuis un devis accepté." : "."}</p></div>`}
      </div>
      ${ed ? `<div class="pcol pagents card"><h2 style="margin-bottom:6px">Agents</h2><p class="mut" style="margin:0 0 6px;font-size:.78rem">Glisse un agent sur un poste, ou touche l'agent puis la case « à pourvoir ».</p><input id="psq" placeholder="Rechercher…" value="${esc(PL.qa || "")}">
        <div id="psl">${tousAg.filter((n) => !PL.qa || n.toLowerCase().includes(PL.qa.toLowerCase())).slice(0, 300).map((n) => { const h = heures[window.PLANIF.cleAgent(n)] || 0;
          return `<div class="pagd ${PL.agSel === n ? "sel" : ""}" draggable="true" data-ag="${esc(n)}"><span>${esc(n)}</span><small>${h ? hFmt(h) : ""}</small></div>`; }).join("")}</div></div>` : ""}</div>`;
    brancherNav();
    box.querySelector(".pstat").onclick = (e) => { const b = e.target.closest("[data-fp]"); if (!b) return; PL.fpostes = b.dataset.fp; vPlanif(); };
    const trouve = (id) => R.postes.find((p) => p.id === id);
    const enregistrer = async (p) => { const r = await api("planif/postes", { method: "POST", body: p }); return r; };
    const affecter = async (pid, nom) => { const p = trouve(pid); if (!p || !nom) return;
      if (p.agents.some((a) => window.PLANIF.cleAgent(a.nom) === window.PLANIF.cleAgent(nom))) return toast("Déjà sur ce poste");
      if (p.agents.length >= p.nb) return toast("Poste complet");
      // contrôle avant affectation : planning publié + postes en brouillon de cet agent
      const k = window.PLANIF.cleAgent(nom), test = { date: p.date, debut: p.debut, fin: p.fin, nom, id: "test" };
      const autres = [...D.lignes.filter((v) => window.PLANIF.cleAgent(v.nom) === k && !v.posteId), ...R.postes.filter((x) => !x.supprime && x.agents.some((a) => window.PLANIF.cleAgent(a.nom) === k)).map((x) => ({ date: x.date, debut: x.debut, fin: x.fin, nom, id: x.id }))];
      const ctl = window.PLANIF.controles([...autres, test]).filter((c) => c.niveau === "rouge" && c.ids.includes("test"));
      if (ctl.length && !confirm(`${nom} :\n${ctl.map((c) => "• " + c.texte).join("\n")}\n\nAffecter quand même ? (sera signalé en rouge)`)) return;
      try { await enregistrer({ ...p, agents: [...p.agents, { nom, tel: telDe(nom) }] }); PL.agSel = null; vPlanif(); } catch (err) { toast(err.message); } };
    box.addEventListener("dragstart", (e) => { const a = e.target.closest("[data-ag]"); if (a) e.dataTransfer.setData("text/plain", a.dataset.ag); });
    box.addEventListener("dragover", (e) => { const z = e.target.closest("[data-drop]"); if (z) { e.preventDefault(); z.classList.add("over"); } });
    box.addEventListener("dragleave", (e) => { const z = e.target.closest("[data-drop]"); if (z) z.classList.remove("over"); });
    box.addEventListener("drop", (e) => { const z = e.target.closest("[data-drop]"); if (!z) return; e.preventDefault(); affecter(z.dataset.drop, e.dataTransfer.getData("text/plain")); });
    box.addEventListener("click", async (e) => {
      const ag = e.target.closest("[data-ag]"), dz = e.target.closest("[data-drop]"), rm = e.target.closest("[data-rm]"), edp = e.target.closest("[data-edp]"), dlp = e.target.closest("[data-dlp]"), np = e.target.closest("[data-np]");
      if (ag) { PL.agSel = PL.agSel === ag.dataset.ag ? null : ag.dataset.ag; box.querySelectorAll("[data-ag]").forEach((x) => x.classList.toggle("sel", x.dataset.ag === PL.agSel)); if (PL.agSel) toast("Touche une case « à pourvoir »", 2500); }
      if (dz && ed) { if (PL.agSel) affecter(dz.dataset.drop, PL.agSel); else toast("Choisis d'abord un agent dans la liste"); }
      if (rm) { const [pid, i] = rm.dataset.rm.split("|"), p = trouve(pid); try { await enregistrer({ ...p, agents: p.agents.filter((_, k) => k !== +i) }); vPlanif(); } catch (err) { toast(err.message); } }
      if (edp) formPoste(trouve(edp.dataset.edp));
      if (dlp && confirm("Supprimer ce poste ?")) { try { await api("planif/postes/" + dlp.dataset.dlp, { method: "DELETE" }); vPlanif(); } catch (err) { toast(err.message); } }
      if (np) { const [id, l, date] = np.dataset.np.split("|"); try { const r = await api("planif/postes/devis/" + id, { method: "POST", body: { ligne: +l, date } }); toast(`${r.crees} poste créé`); vPlanif(); } catch (err) { toast(err.message); } }
      const npa = e.target.closest("[data-npall]"); if (npa && confirm("Créer tous les postes de ce devis ?")) { try { const r = await api("planif/postes/devis/" + npa.dataset.npall, { method: "POST", body: {} }); toast(`${r.crees} poste(s) créé(s)`); vPlanif(); } catch (err) { toast(err.message); } }
    });
    if ($("#psq")) $("#psq").oninput = (e) => { PL.qa = e.target.value; const q = PL.qa.toLowerCase(); box.querySelectorAll("[data-ag]").forEach((x) => (x.style.display = x.dataset.ag.toLowerCase().includes(q) ? "" : "none")); };
    if ($("#pspub")) $("#pspub").onclick = async () => { if (!confirm(`Publier ${R.aPublier} poste(s) ? Les agents verront leur planning.`)) return; try { const r = await api("planif/postes/publier", { method: "POST" }); toast(`Publié : ${r.vacations} vacation(s) visibles par les agents`, 5000); vPlanif(); } catch (err) { toast(err.message); } };
    if ($("#psnew")) $("#psnew").onclick = () => formPoste(null);
    function formPoste(p) {
      const v = p || { date: jours[0], debut: "08:00", fin: "20:00", nb: 1, site: "Parc Expo Valmont" };
      $("#psform").innerHTML = `<div class="card"><h2>${p ? "Modifier le poste" : "Nouveau poste"}</h2><form id="psf">
        <div class="row"><div><label>Date</label><input type="date" name="date" value="${v.date}" required></div><div><label>Début</label><input type="time" name="debut" value="${v.debut}" required></div><div><label>Fin</label><input type="time" name="fin" value="${v.fin}" required></div><div style="flex:0 0 90px"><label>Agents</label><input name="nb" inputmode="numeric" value="${v.nb}"></div></div>
        <div class="row"><div><label>Poste</label><input name="poste" value="${esc(v.poste || "")}" placeholder="ex. ADS PORTE 1 FOUILLE" required></div><div><label>Qualification</label><select name="qualif"><option value="">—</option>${QUALIFS_DEF.map((q) => `<option ${q === v.qualif ? "selected" : ""}>${q}</option>`).join("")}</select></div></div>
        <div class="row"><div><label>Site</label><select name="site">${["Parc Expo Valmont", "Valmont Arena"].map((x) => `<option ${x === v.site ? "selected" : ""}>${x}</option>`).join("")}</select></div><div><label>Événement</label><input name="evenement" value="${esc(v.evenement || "")}"></div></div>
        ${p ? "" : `<label style="display:flex;gap:8px;align-items:center;color:var(--txt);margin-top:10px"><input type="checkbox" id="psrep" style="width:20px;height:20px;flex:none"> Répéter chaque jour jusqu'au <input type="date" id="psjusq" value="${v.date}" style="flex:0 0 170px"></label>`}
        <div class="row" style="margin-top:12px"><button class="btn red">${p ? "Enregistrer" : "Créer"}</button><button class="btn" type="button" id="psx">Annuler</button></div></form></div>`;
      $("#psx").onclick = () => ($("#psform").innerHTML = "");
      $("#psf").onsubmit = async (e) => { e.preventDefault(); const fd = Object.fromEntries(new FormData(e.target));
        try { if (p) await api("planif/postes", { method: "POST", body: { ...p, ...fd } });
          else { const fin2 = $("#psrep")?.checked ? $("#psjusq").value : fd.date; for (let d = fd.date; d <= fin2; d = window.PLANIF.iso(new Date(Date.parse(d) + 864e5))) await api("planif/postes", { method: "POST", body: { ...fd, date: d, agents: [] } }); }
          toast("Poste enregistré (brouillon)"); vPlanif(); } catch (err) { toast(err.message); } };
      $("#psform").scrollIntoView({ behavior: "smooth" });
    }
  }
  // ---------------- liste de tous les agents (DPAE vert / rouge)
  if (PL.onglet === "agents") {
    const heures = {}; D.lignes.filter((v) => jours.includes(v.date)).forEach((v) => { const k = window.PLANIF.cleAgent(v.nom); heures[k] = (heures[k] || 0) + window.PLANIF.vacation(v).heures; });
    const tous = [...new Map([...D.agents, ...D.lignes.map((v) => v.nom)].map((n) => [window.PLANIF.cleAgent(n), n])).values()].sort((x, y) => x.localeCompare(y, "fr"));
    const st = (n) => (D.dpae || {})[window.PLANIF.cleAgent(n)], tel = (n) => (D.tels || {})[window.PLANIF.cleAgent(n)] || "";
    const telF = (t) => t.replace(/^\+33/, "0").replace(/(\d{2})(?=\d)/g, "$1 ");
    const f = PL.fdpae || "", liste = tous.filter((n) => (!PL.q || (n + " " + tel(n)).toLowerCase().includes(PL.q.toLowerCase())) && (!f || (f === "ok" ? st(n)?.statut === "faite" : st(n)?.statut !== "faite")));
    const nbOk = tous.filter((n) => st(n)?.statut === "faite").length;
    box.innerHTML = `<div class="card">${navHTML}<h2 style="margin-top:12px">Liste des agents</h2><p class="mut" style="margin-top:0"><i class="dot dot-ok"></i>${nbOk} avec DPAE · <i class="dot dot-rouge"></i>${tous.length - nbOk} sans DPAE · ${tous.filter(tel).length} numéro(s) · heures sur la période</p>
      <div class="row"><input id="agq" placeholder="Rechercher un agent ou un numéro…" value="${esc(PL.q)}"><div class="seg" id="agf" style="flex:0 0 auto">${[["", "Tous"], ["ok", "DPAE oui"], ["ko", "DPAE non"]].map(([k, l]) => `<button type="button" data-f="${k}" class="${f === k ? "on" : ""}">${l}</button>`).join("")}</div></div>
      <div id="agl" style="margin-top:8px">${liste.map((n) => { const s = st(n), h = heures[window.PLANIF.cleAgent(n)], t = tel(n), okD = s?.statut === "faite";
        return `<div class="prow agr"><span style="min-width:0"><b>${esc(n)}</b> <span class="pchip ${okD ? "ok" : "dno"}" style="font-size:.66rem;padding:1px 7px">DPAE ${okD ? "oui" : "non"}</span><br>
          <span class="mut" style="font-size:.78rem">${s ? `${esc(s.statut)}${s.numero ? " · " + esc(s.numero) : ""}${s.debut ? " · embauche " + frDate(s.debut) : ""}` : "aucune DPAE enregistrée"}${h ? " · " + hFmt(h) : ""}</span></span>
          ${t ? `<a class="btn sm" href="tel:${esc(t)}" style="flex:none;text-decoration:none;white-space:nowrap">${esc(telF(t))}</a>` : `<span class="mut" style="font-size:.76rem;flex:none">pas de numéro</span>`}</div>`; }).join("") || `<p class="mut">Aucun agent.</p>`}</div>
      <p class="mut" style="font-size:.76rem;margin-top:10px">DPAE oui : marquée « faite » dans Demandes de DPAE. DPAE non : aucune DPAE faite (demandée ou absente). Numéros : fiches des agents, annuaire et plannings.</p></div>`;
    brancherNav();
    $("#agq").onchange = (e) => { PL.q = e.target.value; vPlanif(); };
    $("#agf").onclick = (e) => { const b = e.target.closest("[data-f]"); if (!b) return; PL.fdpae = b.dataset.f; vPlanif(); };
  }
  // ---------------- contrôles
  if (PL.onglet === "controles") {
    const ligne = (c) => `<div class="pfait ${c.niveau === "rouge" ? "g-urgente" : "g-moyenne"}" data-d="${c.date || ""}" style="cursor:pointer"><b>${esc(c.nom)}</b><br>${esc(c.texte)}</div>`;
    box.innerHTML = `<div class="card">${navHTML}
      <p class="mut">Contrôle des plannings (téléversés et saisis) selon le Code du travail et la convention collective Prévention et sécurité (brochure 3196). <b>Rien n'est modifié</b> : les écarts sont seulement signalés.</p>
      <div class="pkvs"><div class="pkv"><span>Durée maximale</span><b>48 h par semaine</b></div><div class="pkv"><span>Repos quotidien</span><b>11 h minimum entre deux vacations</b></div><div class="pkv"><span>Dimanche</span><b>un dimanche sur deux libre</b></div><div class="pkv"><span>Vacation</span><b>12 h maximum (CCN 3196)</b></div><div class="pkv"><span>À vérifier</span><b>7 jours de suite · moyenne > 46 h sur 12 semaines</b></div></div>
      <div class="psec">Règles dépassées <b>${rouges.length}</b></div>${rouges.map(ligne).join("") || `<p class="mut">Aucune.</p>`}
      <div class="psec">À vérifier <b>${oranges.length}</b></div>${oranges.map(ligne).join("") || `<p class="mut">Aucun.</p>`}</div>`;
    brancherNav();
    box.onclick = (e) => { const r = e.target.closest("[data-d]"); if (!r || !r.dataset.d) return; PL.lundi = window.PLANIF.lundi(Date.parse(r.dataset.d)); PL.mois = r.dataset.d.slice(0, 7); PL.onglet = "semaine"; vPlanif(); };
  }
  // ---------------- tarifs
  if (PL.onglet === "tarifs") {
    const modif = D.peutDevis;
    const qs = [...new Set([...QUALIFS_DEF, ...Object.keys(tarifs.taux || {})])], dis = modif ? "" : "disabled";
    box.innerHTML = `<div class="card"><h2>Grille tarifaire</h2><p class="mut" style="margin-top:0">Taux horaires hors taxes par qualification, pour un agent et pour un chef d'équipe, et majorations : champs libres. Ils servent au calcul des devis (montants HT).</p>
      <form id="tff"><table class="pltab"><thead><tr><th>Qualification</th><th style="width:120px">Agent · € HT / h</th><th style="width:120px">Chef d'équipe · € HT / h</th></tr></thead><tbody id="tfb">${qs.map((q) => `<tr><td><input name="q" value="${esc(q)}" ${dis}></td><td><input name="t" inputmode="decimal" value="${esc((tarifs.taux || {})[q] || "")}" placeholder="à définir" ${dis}></td><td><input name="tc" inputmode="decimal" value="${esc((tarifs.tauxChef || {})[q] || "")}" placeholder="à définir" ${dis}></td></tr>`).join("")}</tbody></table>
      ${modif ? `<button type="button" class="btn sm" id="tfadd" style="margin-top:8px">Ajouter une qualification</button>` : ""}
      <div class="psec">Majorations</div>
      <div class="row"><div><label>Nuit (%)</label><input name="majNuit" inputmode="decimal" value="${esc(tarifs.majNuit || "")}" placeholder="ex. 10" ${dis}></div><div><label>Dimanche (%)</label><input name="majDimanche" inputmode="decimal" value="${esc(tarifs.majDimanche || "")}" placeholder="ex. 10" ${dis}></div><div><label>Jour férié (%)</label><input name="majFerie" inputmode="decimal" value="${esc(tarifs.majFerie || "")}" placeholder="ex. 100" ${dis}></div></div>
      <div class="row"><div><label>Nuit de</label><input type="time" name="nuitDebut" value="${esc(tarifs.nuitDebut || "21:00")}" ${dis}></div><div><label>à</label><input type="time" name="nuitFin" value="${esc(tarifs.nuitFin || "06:00")}" ${dis}></div></div>
      ${modif ? `<button class="btn red" style="margin-top:12px">Enregistrer la grille</button>` : ""}${tarifs.maj ? `<p class="mut" style="font-size:.76rem">Mise à jour ${fmt(tarifs.maj)} par ${esc(tarifs.par || "")}</p>` : ""}</form></div>`;
    if ($("#tfadd")) $("#tfadd").onclick = () => $("#tfb").insertAdjacentHTML("beforeend", `<tr><td><input name="q" placeholder="Qualification"></td><td><input name="t" inputmode="decimal" placeholder="à définir"></td><td><input name="tc" inputmode="decimal" placeholder="à définir"></td></tr>`);
    $("#tff").onsubmit = async (e) => { e.preventDefault(); const f = e.target, qn = [...f.querySelectorAll('[name="q"]')].map((x) => x.value.trim()), tn = [...f.querySelectorAll('[name="t"]')].map((x) => x.value.trim()), tcn = [...f.querySelectorAll('[name="tc"]')].map((x) => x.value.trim()), taux = {}, tauxChef = {};
      qn.forEach((q, i) => { if (q) { taux[q] = tn[i]; tauxChef[q] = tcn[i]; } }); const fd = Object.fromEntries(new FormData(f));
      try { await api("planif/tarifs", { method: "PUT", body: { taux, tauxChef, majNuit: fd.majNuit, majDimanche: fd.majDimanche, majFerie: fd.majFerie, nuitDebut: fd.nuitDebut, nuitFin: fd.nuitFin } }); toast("Grille enregistrée"); vPlanif(); } catch (err) { toast(err.message); } };
  }
  // ---------------- devis
  if (PL.onglet === "devis") {
    const modif = D.peutDevis;
    const list = await api("planif/devis");
    if (!PL.devis) {
      box.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">Devis</h2>${modif ? `<button class="btn sm red" id="dvnew">Nouveau devis</button>` : ""}</div>
        ${list.length ? list.map((d) => `<div class="item" data-dv="${d.id}" style="cursor:pointer"><div class="h"><b>${esc(d.numero)} · ${esc(d.client || "—")}</b><span class="badge ${d.statut === "accepté" ? "clos" : d.statut === "refusé" ? "urgente" : d.statut === "envoyé" ? "moyenne" : "ouvert"}">${esc(d.statut)}</span></div>
          <div class="mut">${d.mode === "mois" ? `<b>Au mois</b> ${d.mois ? new Date(d.mois + "-01T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" }) : ""} · ` : ""}${esc(d.evenement || "")}${d.site ? " · " + esc(d.site) : ""} · ${hFmt(d.calc.heures)} · <b style="color:var(--txt)">${euros(d.calc.ht)} HT</b>${d.calc.manquants ? ` · <span style="color:var(--g-urg)">tarif à renseigner</span>` : ""}</div></div>`).join("") : `<p class="mut">Aucun devis.</p>`}</div>`;
      if ($("#dvnew")) $("#dvnew").onclick = () => { PL.devis = { id: "", client: "Valmont Événements (VEV)", site: "Parc Expo Valmont", statut: "brouillon", mode: "evenement", lignes: [{ qualif: "ADS", nb: 1, date: window.PLANIF.iso(new Date()), au: "", debut: "08:00", fin: "20:00" }], frais: [], remise: "", validite: "30 jours" }; vPlanif(); };
      box.onclick = (e) => { const r = e.target.closest("[data-dv]"); if (!r) return; PL.devis = JSON.parse(JSON.stringify(list.find((x) => x.id === r.dataset.dv))); vPlanif(); };
    } else editeurDevis(PL.devis);
  }
  function editeurDevis(dv) {
    const modif = D.peutDevis, dis = modif ? "" : "disabled", qs = [...new Set([...QUALIFS_DEF, ...Object.keys(tarifs.taux || {})])];
    const mois = dv.mode === "mois", JL = [[1, "L"], [2, "M"], [3, "M"], [4, "J"], [5, "V"], [6, "S"], [0, "D"]];
    const moisLbl = (m) => (m ? new Date(m + "-01T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" }) : "");
    const joursTxt = (js) => { const a = Array.isArray(js) && js.length ? js.map(Number) : [0, 1, 2, 3, 4, 5, 6]; if (a.length === 7) return "tous les jours";
      const n = ["dim.", "lun.", "mar.", "mer.", "jeu.", "ven.", "sam."]; if (a.length === 5 && ![0, 6].some((x) => a.includes(x))) return "du lundi au vendredi"; if (a.length === 2 && a.includes(0) && a.includes(6)) return "week-ends";
      return [1, 2, 3, 4, 5, 6, 0].filter((x) => a.includes(x)).map((x) => n[x]).join(" "); };
    box.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><div><div class="psur">${esc(dv.numero || "Nouveau devis")}</div><h2 style="margin:2px 0 0">Devis de prestation de sécurité</h2></div><button class="btn sm" id="dvback">Retour</button></div>
      <form id="dvf"><div class="row"><div><label>Client</label><input name="client" value="${esc(dv.client || "")}" ${dis}></div><div><label>Contact</label><input name="contact" value="${esc(dv.contact || "")}" ${dis}></div></div>
      <div class="row"><div><label>Événement</label><input name="evenement" value="${esc(dv.evenement || "")}" ${dis}></div><div><label>Site</label><select name="site" ${dis}>${["Parc Expo Valmont", "Valmont Arena", "Parc + Arena", "Autre"].map((s) => `<option ${s === dv.site ? "selected" : ""}>${s}</option>`).join("")}</select></div></div>
      <div class="row"><div><label>Objet</label><input name="objet" value="${esc(dv.objet || "")}" placeholder="ex. Sécurité incendie et sûreté du salon" ${dis}></div><div style="flex:0 0 120px"><label>Validité</label><input name="validite" value="${esc(dv.validite || "")}" ${dis}></div><div style="flex:0 0 130px"><label>Statut</label><select name="statut" ${dis}>${["brouillon", "envoyé", "accepté", "refusé"].map((s) => `<option ${s === dv.statut ? "selected" : ""}>${s}</option>`).join("")}</select></div></div>
      <div class="psec">Postes à chiffrer</div>
      <div class="dvmode"><div class="seg" id="dvmode">${[["evenement", "À l'événement"], ["mois", "Au mois"]].map(([k, l]) => `<button type="button" data-m="${k}" class="${(dv.mode || "evenement") === k ? "on" : ""}" ${dis}>${l}</button>`).join("")}</div>
        ${mois ? `<div style="flex:0 0 190px"><input type="month" id="dvmois" value="${esc(dv.mois || "")}" ${dis}></div>` : ""}
        <p class="mut" style="margin:0;flex:1 1 260px;font-size:.82rem">${mois ? "Chaque poste est compté sur tous les jours cochés du mois (dimanches et jours fériés majorés automatiquement)." : "Chaque poste est compté du premier au dernier jour de l'événement (laisser « au » vide pour un seul jour)."}</p></div>
      <div class="plgrid-wrap"><table class="pltab" id="dvl"><thead><tr><th>Qualification</th><th>Poste / libellé</th><th style="width:54px">Nb</th>${mois ? `<th style="width:200px">Jours</th>` : `<th style="width:130px">Du</th><th style="width:130px">Au</th>`}<th style="width:90px">Début</th><th style="width:90px">Fin</th><th style="width:46px" title="Chef d'équipe">CE</th><th style="width:84px">Taux HT</th><th style="width:56px">Jours</th><th style="width:70px">Heures</th><th style="width:100px">Montant HT</th>${modif ? "<th></th>" : ""}</tr></thead><tbody></tbody></table></div>
      ${modif ? `<div class="row" style="margin-top:8px"><button type="button" class="btn sm" id="dvadd">Ajouter un poste</button><button type="button" class="btn sm" id="dvdup">Dupliquer le dernier</button></div>` : ""}
      <div class="psec">Récapitulatif par qualification</div><div id="dvrecap"></div>
      <div class="psec">Frais divers</div><div id="dvfr"></div>${modif ? `<button type="button" class="btn sm" id="dvfadd">Ajouter des frais</button>` : ""}
      <div class="row" style="margin-top:10px"><div><label>Remise (%)</label><input name="remise" inputmode="decimal" value="${esc(dv.remise || "")}" ${dis}></div></div>
      <label>Conditions / remarques</label><textarea name="notes" ${dis}>${esc(dv.notes || "")}</textarea>
      <div class="dvtot" id="dvtot"></div>
      <div class="pactions">${modif ? `<button class="btn red">Enregistrer le devis</button>` : ""}<button type="button" class="btn" id="dvpr">Imprimer / PDF</button>${modif && dv.id ? `<button type="button" class="btn" id="dvdel">Supprimer</button>` : ""}</div></form></div>`;
    const v = (r, k) => r.querySelector(`[data-k="${k}"]`);
    const lire = () => { const f = $("#dvf"), fd = Object.fromEntries(new FormData(f));
      dv = { ...dv, ...fd, mode: mois ? "mois" : "evenement", mois: mois ? $("#dvmois").value : dv.mois || "", lignes: [...$("#dvl tbody").rows].map((r) => ({ qualif: v(r, "qualif").value, libelle: v(r, "libelle").value, nb: v(r, "nb").value,
        ...(mois ? { date: "", au: "", jours: [...r.querySelectorAll("[data-j]")].filter((c) => c.checked).map((c) => +c.dataset.j) } : { date: v(r, "date").value, au: v(r, "au").value, jours: [] }),
        debut: v(r, "debut").value, fin: v(r, "fin").value, taux: v(r, "taux").value, chef: v(r, "chef").checked })),
        frais: [...$("#dvfr").querySelectorAll(".row")].map((r) => ({ libelle: r.querySelector('[data-k="fl"]').value, montant: r.querySelector('[data-k="fm"]').value })) }; PL.devis = dv; return dv; };
    const ligneHTML = (l) => { const js = Array.isArray(l.jours) && l.jours.length ? l.jours.map(Number) : [0, 1, 2, 3, 4, 5, 6];
      return `<tr><td><select data-k="qualif" ${dis}>${qs.map((q) => `<option ${q === l.qualif ? "selected" : ""}>${esc(q)}</option>`).join("")}</select></td><td><input data-k="libelle" value="${esc(l.libelle || "")}" placeholder="ex. PC sécurité, Hall B, accueil…" ${dis}></td><td><input data-k="nb" inputmode="numeric" value="${l.nb ?? 1}" ${dis}></td>
      ${mois ? `<td><div class="dvj">${JL.map(([d, n]) => `<label title="${["dimanche", "lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi"][d]}"><input type="checkbox" data-j="${d}" ${js.includes(d) ? "checked" : ""} ${dis}><span>${n}</span></label>`).join("")}</div></td>`
        : `<td><input type="date" data-k="date" value="${l.date || ""}" ${dis}></td><td><input type="date" data-k="au" value="${l.au || ""}" ${dis}></td>`}
      <td><input type="time" data-k="debut" value="${l.debut || ""}" ${dis}></td><td><input type="time" data-k="fin" value="${l.fin || ""}" ${dis}></td><td style="text-align:center"><input type="checkbox" data-k="chef" ${l.chef ? "checked" : ""} ${dis} style="width:20px;height:20px" title="Chef d'équipe"></td><td><input data-k="taux" inputmode="decimal" value="${esc(l.taux || "")}" placeholder="grille" ${dis}></td><td class="dvn"></td><td class="dvh"></td><td class="dvm"></td>${modif ? `<td><button type="button" class="btn sm" data-rm>✕</button></td>` : ""}</tr>`; };
    const fraisHTML = (f) => `<div class="row" style="margin:4px 0"><input data-k="fl" value="${esc(f.libelle || "")}" placeholder="ex. Frais de déplacement" ${dis}><input data-k="fm" inputmode="decimal" value="${esc(f.montant || "")}" placeholder="montant HT €" style="flex:0 0 130px" ${dis}>${modif ? `<button type="button" class="btn sm" data-rmf style="flex:none">✕</button>` : ""}</div>`;
    $("#dvl tbody").innerHTML = (dv.lignes || []).map(ligneHTML).join(""); $("#dvfr").innerHTML = (dv.frais || []).map(fraisHTML).join("");
    const recapHTML = (c) => c.parQualif.length ? `<table class="pltab dvrec"><thead><tr><th>Qualification</th><th>Agents</th><th>Vacations</th><th>Heures</th><th>Montant HT</th></tr></thead><tbody>${c.parQualif.map((q) => `<tr><td><b>${esc(q.qualif)}</b></td><td>${q.agents}</td><td>${q.vacations}</td><td>${hFmt(q.heures)}</td><td>${euros(q.montant)}</td></tr>`).join("")}</tbody></table>` : `<p class="mut">Ajoute des postes.</p>`;
    const recalc = () => { const c = window.PLANIF.calcDevis(lire(), tarifs);
      [...$("#dvl tbody").rows].forEach((r, i) => { const l = c.lignes[i]; if (!l) return; r.querySelector(".dvn").textContent = l.nbJours || "—"; r.querySelector(".dvh").textContent = hFmt(l.heures * l.nb); r.querySelector(".dvm").innerHTML = l.tarifManquant ? `<span style="color:var(--g-urg)">tarif ?</span>` : euros(l.montant); });
      $("#dvrecap").innerHTML = recapHTML(c);
      $("#dvtot").innerHTML = `${mois ? `<div><span>Période</span><b>${esc(moisLbl(dv.mois) || "mois à choisir")}</b></div>` : ""}<div><span>Heures</span><b>${hFmt(c.heures)}</b></div>${c.frais ? `<div><span>Frais</span><b>${euros(c.frais)}</b></div>` : ""}${c.remise ? `<div><span>Remise</span><b>− ${euros(c.remise)}</b></div>` : ""}<div class="ttc"><span>Total HT${mois ? " du mois" : ""}</span><b>${euros(c.ht)}</b></div>${c.manquants ? `<p style="color:var(--g-urg);margin:6px 0 0;font-size:.82rem">Des tarifs ne sont pas renseignés (onglet Tarifs ou colonne Taux).</p>` : ""}${mois && !dv.mois ? `<p style="color:var(--g-moy);margin:6px 0 0;font-size:.82rem">Choisis le mois à chiffrer.</p>` : ""}`; return c; };
    $("#dvf").oninput = recalc; $("#dvf").onchange = recalc; recalc();
    $("#dvmode").onclick = (e) => { const b = e.target.closest("[data-m]"); if (!b || !modif) return; const d = lire(); if ((d.mode || "evenement") === b.dataset.m) return;
      d.mode = b.dataset.m; if (d.mode === "mois" && !d.mois) d.mois = (d.lignes.find((l) => l.date)?.date || window.PLANIF.iso(new Date())).slice(0, 7);
      if (d.mode === "evenement") d.lignes = d.lignes.map((l) => ({ ...l, date: l.date || (d.mois ? d.mois + "-01" : window.PLANIF.iso(new Date())), jours: [] }));
      PL.devis = d; editeurDevis(d); };
    $("#dvback").onclick = () => { PL.devis = null; vPlanif(); };
    const nouvelle = () => ({ qualif: "ADS", nb: 1, date: mois ? "" : window.PLANIF.iso(new Date()), au: "", jours: [], debut: "08:00", fin: "20:00" });
    if ($("#dvadd")) $("#dvadd").onclick = () => { $("#dvl tbody").insertAdjacentHTML("beforeend", ligneHTML(nouvelle())); recalc(); };
    if ($("#dvdup")) $("#dvdup").onclick = () => { const d = lire(), l = d.lignes[d.lignes.length - 1]; if (!l) return; $("#dvl tbody").insertAdjacentHTML("beforeend", ligneHTML({ ...l })); recalc(); };
    if ($("#dvfadd")) $("#dvfadd").onclick = () => { $("#dvfr").insertAdjacentHTML("beforeend", fraisHTML({})); };
    $("#dvf").onclick = (e) => { if (e.target.closest("[data-rm]")) { e.target.closest("tr").remove(); recalc(); } if (e.target.closest("[data-rmf]")) { e.target.closest(".row").remove(); recalc(); } };
    $("#dvf").onsubmit = async (e) => { e.preventDefault(); const d = lire(); if (d.mode === "mois" && !d.mois) return toast("Choisis le mois");
      try { const r = await api("planif/devis", { method: "POST", body: d }); PL.devis = r; toast(`Devis ${r.numero} enregistré`); vPlanif(); } catch (err) { toast(err.message); } };
    if ($("#dvdel")) $("#dvdel").onclick = async () => { if (!confirm("Supprimer ce devis ?")) return; await api("planif/devis/" + dv.id, { method: "DELETE" }); PL.devis = null; vPlanif(); };
    $("#dvpr").onclick = () => { const c = recalc(), d = dv, w = document.createElement("div"); w.id = "print";
      const periode = (l) => mois ? joursTxt(l.jours) : l.du ? (l.nbJours > 1 ? `du ${frDate(l.du)} au ${frDate(l.auR)}` : frDate(l.du)) : "";
      w.innerHTML = `<div class="ph"><div><b style="font-size:20px">SSIAP Pro</b><br>Prestations de sécurité incendie et sûreté<br>Le PC Sécurité Parc Expo Valmont / Valmont Arena</div><div style="text-align:right"><b style="font-size:18px">DEVIS ${esc(d.numero || "(brouillon)")}</b><br>Établi le ${new Date().toLocaleDateString("fr-FR")}${d.validite ? "<br>Validité : " + esc(d.validite) : ""}</div></div>
        <p><b>Client :</b> ${esc(d.client || "")}${d.contact ? "<br><b>Contact :</b> " + esc(d.contact) : ""}<br><b>${mois ? "Prestation" : "Événement"} :</b> ${esc(d.evenement || "")} · ${esc(d.site || "")}${mois ? `<br><b>Période :</b> ${esc(moisLbl(d.mois))} (calcul au mois)` : ""}${d.objet ? "<br><b>Objet :</b> " + esc(d.objet) : ""}</p>
        <table><thead><tr><th>Qualification / poste</th><th>${mois ? "Jours" : "Dates"}</th><th>Horaires</th><th>Nb</th><th>Vac.</th><th>Heures</th><th>dont nuit / dim. / férié</th><th>Taux HT</th><th>Montant HT</th></tr></thead><tbody>
        ${c.lignes.map((l) => `<tr><td><b>${esc(l.qualif)}${l.chef ? " · chef d'équipe" : ""}</b>${l.libelle ? "<br>" + esc(l.libelle) : ""}</td><td>${periode(l)}</td><td>${esc(l.debut)}–${esc(l.fin)}</td><td>${l.nb}</td><td>${l.nb * l.nbJours}</td><td>${hFmt(l.nb * l.heures)}</td><td>${hFmt(l.nb * l.hNuit)} / ${hFmt(l.nb * l.hDim)} / ${hFmt(l.nb * l.hFer)}</td><td>${l.tarifManquant ? "—" : euros(l.taux)}</td><td>${euros(l.montant)}</td></tr>`).join("")}
        ${(d.frais || []).filter((f) => f.libelle).map((f) => `<tr><td colspan="8">${esc(f.libelle)}</td><td>${euros(parseFloat(String(f.montant).replace(",", ".")) || 0)}</td></tr>`).join("")}</tbody></table>
        <p style="margin:12px 0 4px"><b>Récapitulatif par qualification</b></p><table><thead><tr><th>Qualification</th><th>Agents</th><th>Vacations</th><th>Heures</th><th>Montant HT</th></tr></thead><tbody>${c.parQualif.map((q) => `<tr><td>${esc(q.qualif)}</td><td>${q.agents}</td><td>${q.vacations}</td><td>${hFmt(q.heures)}</td><td>${euros(q.montant)}</td></tr>`).join("")}</tbody></table>
        <table style="width:auto;margin:12px 0 0 auto"><tr><td>Total heures</td><td><b>${hFmt(c.heures)}</b></td></tr>${c.frais ? `<tr><td>Frais</td><td>${euros(c.frais)}</td></tr>` : ""}${c.remise ? `<tr><td>Remise</td><td>− ${euros(c.remise)}</td></tr>` : ""}<tr><td><b>Total HT${mois ? " du mois" : ""}</b></td><td><b>${euros(c.ht)}</b></td></tr></table><p style="font-size:12px;text-align:right;margin:4px 0 0">Montants exprimés hors taxes.</p>
        <p style="font-size:12px">Majorations appliquées : nuit (${esc(tarifs.nuitDebut || "21:00")}–${esc(tarifs.nuitFin || "06:00")}) ${esc(tarifs.majNuit || "0")} %, dimanche ${esc(tarifs.majDimanche || "0")} %, jour férié ${esc(tarifs.majFerie || "0")} %.</p>${d.notes ? `<p style="white-space:pre-wrap">${esc(d.notes)}</p>` : ""}
        <div class="sig"><div>Pour SSIAP Pro<br><br><br>Signature</div><div>Bon pour accord du client<br>(date, cachet, signature)<br><br>Signature</div></div>
        <div class="noprint" style="text-align:center;margin:20px"><button class="btn red" data-pr="1">Imprimer / PDF</button> <button class="btn" data-pr="0">Fermer</button></div>`;
      document.body.appendChild(w); window.scrollTo(0, 0); };
  }
}

/* ================= Plan du site interactif ================= */
let PLAN_SEL = null;
async function vPlan() {
  const P0 = window.PLAN_SITE, D = await api("plan");
  const P = { ...P0, dae: (P0.dae || []).map((d) => ({ ...d, ...((D.daePos || {})[d.id] || {}) })) }; let placeDAE = null;
  const ptsArr = (pts) => pts.split(" ").map((p) => p.split(",").map(Number));
  const centre = (pts) => { const a = ptsArr(pts), xs = a.map((p) => p[0]), ys = a.map((p) => p[1]); return [(Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2, Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys)]; };
  const reEsc = (x) => x.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const mcDe = (z) => D.mc.filter((i) => z.site ? /arena/i.test(i.site || "") : z.mc && new RegExp(`(^|[^A-Za-z0-9])${reEsc(z.mc)}($|[^0-9])`, "i").test(i.lieu || ""));
  const clesDe = () => []; // pas de clés sur le plan (halls, Arena)
  // ---- style « plan technique » (sobre, lisible de nuit)
  const TEINTE = { B: { f: "#4f4317", s: "#d9b43c" }, A: { f: "#521c25", s: "#d9404f" }, L: { f: "#46121d", s: "#e2283c" }, tech: { f: "#232c38", s: "#62748c" }, parking: { f: "url(#phach)", s: "#3b4452" } };
  const couleur = (z) => { const t = z.type === "parking" ? TEINTE.parking : z.type === "tech" ? TEINTE.tech : TEINTE[z.grp] || TEINTE.A; return [t.s, t.f]; };
  const G0 = { x: 265, y: 90, pas: 80 }, COLS = "ABCDEFGH";
  const carreau = (x, y) => `${COLS[Math.max(0, Math.min(7, Math.floor((x - G0.x) / G0.pas)))]}${Math.max(1, Math.floor((y - G0.y) / G0.pas) + 1)}`;
  let CAL = { grille: true, parkings: true, dae: true, voirie: true }; try { CAL = { ...CAL, ...JSON.parse(localStorage.getItem("ssiap-calques") || "{}") }; } catch {}
  const zonesSVG = P.zones.map((z) => { const [cx, cy, w, h] = centre(z.pts), t = z.type === "parking" ? TEINTE.parking : z.type === "tech" ? TEINTE.tech : TEINTE[z.grp] || TEINTE.A, e = D.etat[z.bat] || {}, nmc = mcDe(z).length, sel = PLAN_SEL === z.id;
    const nomC = z.id === "cc" ? "CENTRE DE CONF." : z.type === "hall" && z.id.length <= 2 ? "HALL " + z.id : z.type === "arena" ? "VALMONT ARENA" : z.type === "parking" ? z.nom.replace("Parking ", "P").replace(/ — .*/, "") : z.nom.toUpperCase();
    const fs = z.type === "parking" ? Math.min(9, w / 6) : Math.max(5, Math.min(z.type === "arena" ? 8 : 10.5, (w * 0.86) / (nomC.length * 0.64), h / 2.6));
    const sous = z.type === "parking" ? (z.places ? `${z.places.toLocaleString("fr-FR")} pl.` : "") : z.surface ? `${z.surface.toLocaleString("fr-FR")} m²` : "";
    const x0 = cx - w / 2, y0 = cy - h / 2;
    return `<g data-z="${z.id}" class="pz${z.type === "parking" ? " pzp" : ""}${sel ? " psel" : ""}" style="cursor:pointer">
      <polygon class="pf" points="${z.pts}" fill="${t.f}" stroke="${t.s}" stroke-width="${z.type === "parking" ? 0.8 : 1.1}" stroke-linejoin="round" ${z.type === "parking" ? 'stroke-dasharray="3 2"' : ""}/>
      ${z.type === "arena" ? `<ellipse cx="${cx}" cy="${cy + 6}" rx="${w * 0.27}" ry="${h * 0.26}" fill="none" stroke="${t.s}" stroke-opacity=".45" stroke-width=".8"/><ellipse cx="${cx}" cy="${cy + 6}" rx="${w * 0.17}" ry="${h * 0.15}" fill="none" stroke="${t.s}" stroke-opacity=".3" stroke-width=".6"/>` : ""}
      <text x="${cx}" y="${cy + (sous ? -1 : fs * 0.35)}" text-anchor="middle" font-size="${fs.toFixed(1)}" font-weight="700" letter-spacing=".06em" fill="${z.type === "parking" ? "#aab3c0" : "#f4f5f7"}" style="pointer-events:none">${esc(nomC)}</text>
      ${sous && h > 18 ? `<text x="${cx}" y="${cy + fs * 0.35 + 6.5}" text-anchor="middle" font-size="5.6" letter-spacing=".04em" fill="${z.type === "parking" ? "#7f8896" : "rgba(255,255,255,.62)"}" style="pointer-events:none">${sous}</text>` : ""}
      ${z.bat ? `<circle cx="${x0 + 5.5}" cy="${y0 + 5.5}" r="2.6" fill="${e.ouvert ? "#22c55e" : "#59606b"}" stroke="#0e1116" stroke-width=".8"/>${e.eclairage ? `<circle cx="${x0 + 12}" cy="${y0 + 5.5}" r="2.4" fill="#f5b301" stroke="#0e1116" stroke-width=".8"/><circle cx="${x0 + 12}" cy="${y0 + 5.5}" r="4.2" fill="none" stroke="#f5b301" stroke-opacity=".45" stroke-width=".6"/>` : ""}` : ""}
      ${nmc ? `<rect x="${x0 + w - 16}" y="${y0 + 2.5}" width="13" height="8" rx="4" fill="#e0182f"/><text x="${x0 + w - 9.5}" y="${y0 + 8.6}" text-anchor="middle" font-size="6" font-weight="700" fill="#fff" style="pointer-events:none">${nmc}</text>` : ""}</g>`; }).join("");
  const repSVG = P.reperes.map((r) => {
    if (r.c === "entree") return `<g style="pointer-events:none"><text x="${r.x}" y="${r.y}" text-anchor="middle" font-size="13" font-weight="700" letter-spacing=".22em" fill="#e43a51">${esc(r.t)}</text><path d="M${r.x - 5} ${r.y + 6} l5 6 l5 -6" fill="none" stroke="#e43a51" stroke-width="1.4"/></g>`;
    if (r.c === "portail") return `<g style="pointer-events:none"><rect x="${r.x - 5}" y="${r.y - 10}" width="10" height="10" transform="rotate(45 ${r.x} ${r.y - 5})" fill="#f5b301" stroke="#0e1116" stroke-width=".8"/><text x="${r.x + 9}" y="${r.y - 2}" font-size="6.5" font-weight="700" letter-spacing=".05em" fill="#f5b301">${esc(r.t.toUpperCase())}</text></g>`;
    return `<text class="cv" x="${r.x}" y="${r.y}" text-anchor="middle" font-size="${r.c === "voisin" ? 6.5 : 5.2}" letter-spacing=".04em" fill="#6f7987" ${r.r ? `transform="rotate(${r.r} ${r.x} ${r.y})"` : ""} style="pointer-events:none">${esc(r.t)}</text>`; }).join("");
  const grilleSVG = (() => { let g = ""; for (let i = 0; i <= 8; i++) { const x = G0.x + i * G0.pas; g += `<line x1="${x}" y1="${G0.y}" x2="${x}" y2="1560" />`; if (i < 8) g += `<text x="${x + G0.pas / 2}" y="${G0.y + 9}" text-anchor="middle">${COLS[i]}</text>`; }
    for (let j = 0; j <= 19; j++) { const y = G0.y + j * G0.pas; if (y > 1565) break; g += `<line x1="${G0.x}" y1="${y}" x2="${G0.x + 8 * G0.pas}" y2="${y}" />`; if (y + G0.pas <= 1600) g += `<text x="${G0.x + 5}" y="${y + G0.pas / 2 + 3}">${j + 1}</text>`; }
    return `<g id="pgrid" stroke="rgba(255,255,255,.07)" stroke-width=".6" fill="rgba(255,255,255,.28)" font-size="7" font-weight="600" style="pointer-events:none">${g}</g>`; })();
  const daeSVG = (P.dae || []).filter((d) => d.x != null).map((d) => `<g data-dae="${d.id}" class="pdae" style="cursor:pointer"><rect x="${d.x - 6}" y="${d.y - 6}" width="12" height="12" rx="2.5" fill="#0a9d4a" stroke="#fff" stroke-width="1"/><path d="M${d.x} ${d.y + 3.3} l-3.4 -3.3 a1.9 1.9 0 0 1 3.4 -2.3 a1.9 1.9 0 0 1 3.4 2.3 z" fill="#fff"/><path d="M${d.x + 0.6} ${d.y - 2.2} l-1.4 2.4 h1.6 l-1.2 2.2" fill="none" stroke="#0a9d4a" stroke-width=".7"/></g>`).join("");
  const M_PX = 0.84, ech = 100 / M_PX; // ≈ 0,84 m par unité de plan (déduit des surfaces des halls)
  view.innerHTML = `<div class="card pcarte" id="pcard"><div class="pentete"><div><div class="psur">PC Sécurité · plan de masse</div><h2 style="margin:0">Parc Expo Valmont · Valmont Arena</h2></div></div>
    <div id="pwrap" class="pwrap">
      <svg id="psvg" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" preserveAspectRatio="xMidYMid meet" viewBox="${P.vb.join(" ")}" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Arial,sans-serif">
        <defs><pattern id="phach" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="5" height="5" fill="#171c23"/><line x1="0" y1="0" x2="0" y2="5" stroke="#252c36" stroke-width="1.4"/></pattern></defs>
        <rect x="${P.vb[0] - 400}" y="${P.vb[1] - 400}" width="${P.vb[2] + 800}" height="${P.vb[3] + 800}" fill="#0b0e12"/>
        <polygon points="${P.contour}" fill="#11161c" stroke="#2a323d" stroke-width="1.2"/>
        ${(P.verts || []).map((v) => `<polygon points="${v}" fill="#13201a" stroke="#1b2c22" stroke-width=".6"/>`).join("")}
        ${(P.eau || [P.lac]).map((v) => `<polygon points="${v}" fill="#10303d" stroke="#1d5a73" stroke-width=".8"/>`).join("")}
        ${P.voies.map((d) => `<path d="${d}" fill="none" stroke="#252b34" stroke-width="11" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#3a424e" stroke-width=".7" stroke-dasharray="5 5"/>`).join("")}
        <g id="pzones">${zonesSVG}</g><g id="prep">${repSVG}</g>${grilleSVG}<g id="pdaes">${daeSVG}</g>
      </svg>
      <div class="poutils"><button id="pzp" title="Zoomer">+</button><button id="pzm" title="Dézoomer">−</button><button id="pz0" title="Recentrer">⟲</button><button id="pfs" title="Plein écran">⤢</button></div>
      <div class="pechelle"><div style="width:${(100 / P.vb[2]) * 100}%" id="pbar"></div><span id="pbarl">100 m</span></div>
    </div>
    <div class="pcalques">${[["grille", "Carroyage"], ["parkings", "Parkings"], ["dae", "DAE"], ["voirie", "Voirie"]].map(([k, l]) => `<button type="button" data-cal="${k}" class="${CAL[k] ? "on" : ""}">${l}</button>`).join("")}</div>
    <div class="plegende"><span><i style="background:#4f4317;border-color:#d9b43c"></i>Zone B</span><span><i style="background:#521c25;border-color:#d9404f"></i>Zone A</span><span><i style="background:#46121d;border-color:#e2283c"></i>Arena</span><span><i class="hach"></i>Parking</span>
      <span><b class="pt" style="background:#22c55e"></b>Ouvert</span><span><b class="pt" style="background:#59606b"></b>Fermé</span><span><b class="pt" style="background:#f5b301"></b>Éclairage</span><span><b class="pill">2</b>Faits ouverts</span><span><b class="dae">+</b>DAE</span></div>
    <details class="pdaeliste"><summary>Défibrillateurs (DAE) · ${(P.dae || []).length}</summary><div class="c">${(P.dae || []).map((d) => `<div class="prow"><span data-daef="${d.id}" style="cursor:pointer"><b>${esc(d.lieu)}</b>${d.gps ? ' <span class="pchip ok" style="font-size:.62rem;padding:1px 6px">GPS</span>' : ""}<br><span class="mut">${esc(d.detail)}${d.x == null ? " · à placer sur le plan" : " · carreau " + carreau(d.x, d.y)}</span></span>${D.peutModif ? `<button class="btn sm" data-place="${d.id}" type="button">${d.x == null ? "Placer" : "Déplacer"}</button>` : ""}</div>`).join("")}</div></details>
    <div class="pcartouche"><span>Échelle approximative · carroyage ${G0.pas * M_PX | 0} m</span><span>Document PC Sécurité — SSIAP Pro pour la VEV</span></div></div>
  <div id="pfiche"></div>`;
  const calques = () => { $("#pgrid").style.display = CAL.grille ? "" : "none"; $("#pdaes").style.display = CAL.dae ? "" : "none";
    view.querySelectorAll(".pzp").forEach((g) => (g.style.display = CAL.parkings ? "" : "none")); view.querySelectorAll(".cv").forEach((t) => (t.style.display = CAL.voirie ? "" : "none")); };
  calques();
  view.querySelector(".pcalques").onclick = (e) => { const b = e.target.closest("[data-cal]"); if (!b) return; CAL[b.dataset.cal] = !CAL[b.dataset.cal]; b.classList.toggle("on", CAL[b.dataset.cal]); try { localStorage.setItem("ssiap-calques", JSON.stringify(CAL)); } catch {} calques(); };
  $("#pfs").onclick = () => { $("#pcard").classList.toggle("plein"); document.body.classList.toggle("plan-plein", $("#pcard").classList.contains("plein")); };
  // ---- zoom / déplacement
  const svg = $("#psvg"), vb0 = [...P.vb]; let vb = PLAN_VB || [285, 270, 560, 900]; // vue de départ centrée sur les halls
  const appl = () => { svg.setAttribute("viewBox", vb.map((x) => x.toFixed(1)).join(" ")); PLAN_VB = vb;
    const r = svg.getBoundingClientRect(), s = Math.max(vb[2] / (r.width || 1), vb[3] / (r.height || 1)), m = [10, 20, 50, 100, 200, 500].find((v) => v / M_PX / s >= 60) || 500;
    if ($("#pbar")) { $("#pbar").style.width = (m / M_PX / s) + "px"; $("#pbarl").textContent = m + " m"; } };
  const zoom = (f, cx, cy) => { const [x, y, w, h] = vb, nw = Math.max(80, Math.min(vb0[2] * 1.4, w * f)), k = nw / w; cx ??= x + w / 2; cy ??= y + h / 2; vb = [cx - (cx - x) * k, cy - (cy - y) * k, nw, h * k]; appl(); };
  const versSVG = (cx, cy) => { const r = svg.getBoundingClientRect(), s = Math.max(vb[2] / r.width, vb[3] / r.height), ox = (r.width * s - vb[2]) / 2, oy = (r.height * s - vb[3]) / 2; return [vb[0] + (cx - r.left) * s - ox, vb[1] + (cy - r.top) * s - oy, s]; };
  appl();
  view.querySelectorAll("[data-daef]").forEach((s) => (s.onclick = () => ficheDAE(P.dae.find((x) => x.id === s.dataset.daef))));
  view.querySelectorAll("[data-place]").forEach((b) => (b.onclick = () => { placeDAE = b.dataset.place; $("#pwrap").scrollIntoView({ behavior: "smooth" }); toast("📍 Touche l'endroit du DAE sur le plan", 4000); }));
  $("#pzp").onclick = () => zoom(0.7); $("#pzm").onclick = () => zoom(1.4); $("#pz0").onclick = () => { vb = [...vb0]; appl(); };
  svg.addEventListener("wheel", (e) => { e.preventDefault(); const [px, py] = versSVG(e.clientX, e.clientY); zoom(e.deltaY > 0 ? 1.15 : 0.87, px, py); }, { passive: false });
  const ptrs = new Map(); let bouge = 0, pinch0 = null;
  svg.addEventListener("pointerdown", (e) => { svg.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, [e.clientX, e.clientY]); bouge = 0; if (ptrs.size === 2) { const [a, b] = [...ptrs.values()]; pinch0 = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), vb: [...vb], c: versSVG((a[0] + b[0]) / 2, (a[1] + b[1]) / 2) }; } });
  svg.addEventListener("pointermove", (e) => { if (!ptrs.has(e.pointerId)) return; const prev = ptrs.get(e.pointerId); ptrs.set(e.pointerId, [e.clientX, e.clientY]);
    if (ptrs.size === 2 && pinch0) { const [a, b] = [...ptrs.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]); vb = [...pinch0.vb]; zoom(pinch0.d / Math.max(d, 1), pinch0.c[0], pinch0.c[1]); bouge = 99; return; }
    const s = versSVG(0, 0)[2], dx = (e.clientX - prev[0]) * s, dy = (e.clientY - prev[1]) * s; bouge += Math.abs(e.clientX - prev[0]) + Math.abs(e.clientY - prev[1]); if (bouge > 6) { vb = [vb[0] - dx, vb[1] - dy, vb[2], vb[3]]; appl(); } });
  const fin = (e) => { const tap = ptrs.size === 1 && bouge <= 6; ptrs.delete(e.pointerId); if (ptrs.size < 2) pinch0 = null;
    if (tap && e.type === "pointerup" && placeDAE) { const [x, y] = versSVG(e.clientX, e.clientY), id = placeDAE; placeDAE = null;
      api("plan/dae/" + id, { method: "PUT", body: { x, y } }).then(() => { toast("✅ DAE placé"); vPlan(); }).catch((err) => toast(err.message)); return; }
    const dm = tap && e.type === "pointerup" ? document.elementFromPoint(e.clientX, e.clientY)?.closest("[data-dae]") : null;
    if (dm) { ficheDAE(P.dae.find((x) => x.id === dm.dataset.dae)); return; }
    if (tap && e.type === "pointerup") { const g = document.elementFromPoint(e.clientX, e.clientY)?.closest("[data-z]"); if (g) { PLAN_SEL = g.dataset.z; fiche(); svg.querySelectorAll("[data-z]").forEach((gg) => gg.classList.toggle("psel", gg.dataset.z === PLAN_SEL)); } } };
  svg.addEventListener("pointerup", fin); svg.addEventListener("pointercancel", fin);
  // ---- fiche d'un DAE : photo, position sur le plan, géolocalisation GPS, itinéraire
  const distCap = (a, b) => { const R = 6371e3, r = Math.PI / 180, dLa = (b.lat - a.lat) * r, dLo = (b.lon - a.lon) * r, la1 = a.lat * r, la2 = b.lat * r;
    const d = 2 * R * Math.asin(Math.sqrt(Math.sin(dLa / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLo / 2) ** 2));
    const y = Math.sin(dLo) * Math.cos(la2), x = Math.cos(la1) * Math.sin(la2) - Math.sin(la1) * Math.cos(la2) * Math.cos(dLo), c = ((Math.atan2(y, x) / r) + 360) % 360;
    return [d, ["N", "NE", "E", "SE", "S", "SO", "O", "NO"][Math.round(c / 45) % 8]]; };
  const ficheDAE = (d) => {
    if (!d) return; const g = d.gps;
    $("#pfiche").innerHTML = `<div class="card pfiche" style="--zc:#0a9d4a"><div class="pfh"><div><div class="psur">Défibrillateur automatisé externe</div><h2 style="margin:2px 0 0">DAE · ${esc(d.lieu)}</h2></div>${d.x != null ? `<span class="pcarreau">${carreau(d.x, d.y)}</span>` : ""}</div>
      <p style="margin:10px 0 0">${esc(d.detail)}</p>
      ${d.photo ? `<img src="${esc(d.photo)}" alt="DAE ${esc(d.lieu)}" style="width:100%;border-radius:8px;margin-top:10px;border:1px solid var(--line)">` : ""}
      <div class="psec">Géolocalisation</div>
      ${g ? `<div class="pkvs"><div class="pkv"><span>Coordonnées GPS</span><b>${g.lat.toFixed(6)}, ${g.lon.toFixed(6)}</b></div><div class="pkv"><span>Précision</span><b>${g.acc != null ? "± " + g.acc + " m" : "—"}</b></div><div class="pkv"><span>Relevé</span><b>${fmt(g.t)} · ${esc(g.par || "")}</b></div><div class="pkv"><span>Depuis ma position</span><b id="daedist">calcul…</b></div></div>
        <div class="pactions"><a class="btn red" href="https://www.google.com/maps/dir/?api=1&destination=${g.lat},${g.lon}&travelmode=walking" target="_blank" rel="noopener" style="text-align:center;text-decoration:none">Itinéraire à pied vers le DAE</a></div>`
        : `<p class="mut" style="margin:0">Position GPS pas encore relevée.${D.peutModif ? " Place-toi devant le DAE et appuie sur « Relever la position GPS ici »." : ""}</p>`}
      ${D.peutModif ? `<div class="pactions"><button class="btn" id="daegps">Relever la position GPS ici</button><button class="btn" id="daeplace">${d.x == null ? "Placer sur le plan" : "Déplacer sur le plan"}</button></div>` : ""}
      <p class="mut" style="font-size:.78rem;margin:10px 0 0">En cas d'arrêt cardiaque : alerter le PC (04 65 71 00 00) et les secours (15 / 18 / 112), masser, défibriller.</p></div>`;
    $("#pfiche").scrollIntoView({ behavior: "smooth" });
    if (g && navigator.geolocation) navigator.geolocation.getCurrentPosition((p) => { const [m, dir] = distCap({ lat: p.coords.latitude, lon: p.coords.longitude }, g); if ($("#daedist")) $("#daedist").textContent = `${m < 1000 ? Math.round(m) + " m" : (m / 1000).toFixed(1) + " km"} · direction ${dir} (± ${Math.round(p.coords.accuracy)} m)`; },
      () => { if ($("#daedist")) $("#daedist").textContent = "position du téléphone indisponible"; }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 15000 });
    if ($("#daeplace")) $("#daeplace").onclick = () => { placeDAE = d.id; $("#pwrap").scrollIntoView({ behavior: "smooth" }); toast("Touche l'endroit du DAE sur le plan", 4000); };
    if ($("#daegps")) $("#daegps").onclick = () => { if (!navigator.geolocation) return toast("GPS indisponible sur ce téléphone"); toast("Relevé GPS en cours… reste immobile devant le DAE", 6000);
      let best = null; const w = navigator.geolocation.watchPosition((p) => { if (!best || p.coords.accuracy < best.coords.accuracy) best = p; }, () => {}, { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 });
      setTimeout(async () => { navigator.geolocation.clearWatch(w); if (!best) return toast("Position introuvable : active la localisation et réessaie");
        try { await api("plan/dae/" + d.id, { method: "PUT", body: { gps: { lat: best.coords.latitude, lon: best.coords.longitude, acc: best.coords.accuracy } } }); toast(`Position enregistrée (± ${Math.round(best.coords.accuracy)} m)`); PLAN_DAE_OUVERT = d.id; vPlan(); } catch (err) { toast(err.message); } }, 8000); };
  };
  // ---- agents du jour (planning) : ADS de l'Arena par groupe, agents postés sur les halls
  const agentsHTML = (z) => {
    if (z.type === "arena" && D.arena) { const n = D.arena.groupes.reduce((k, g) => k + g.agents.length, 0);
      return `<div class="psec">ADS de l'Arena · ${D.arena.date.split("-").reverse().join("/")} <b>${n}</b></div>${D.arena.evenement ? `<p class="mut" style="margin:0 0 4px">🎫 ${esc(D.arena.evenement)}</p>` : ""}
        ${n ? D.arena.groupes.map((g) => `<div style="margin-top:6px"><b>${esc(g.lb)}</b> <span class="mut">${g.agents.length}${g.requis ? " / " + g.requis : ""}</span>${g.agents.map((a) => `<div class="mut" style="color:var(--txt);padding-left:10px">• ${esc(a.nom)} <span class="mut">${esc(a.debut || "")}${a.fin ? "-" + esc(a.fin) : ""}</span></div>`).join("")}</div>`).join("") : `<p class="mut" style="margin:0">Aucun ADS au planning Arena ce jour.</p>`}
        ${S.user.coordArena || staff() || coord() ? `<a class="btn sm" href="#/equipe" style="margin-top:8px;display:inline-block;text-decoration:none">🏟️ Répartir l'équipe</a>` : ""}`; }
    if (!D.postes || !D.postes.length || (z.type !== "hall" && z.type !== "accueil")) return "";
    const re = new RegExp(`(^|[^A-Za-z0-9])(${reEsc(z.mc || z.id)}|${reEsc(z.nom)})($|[^0-9])`, "i"), l = D.postes.filter((v) => !/arena/i.test(v.site + " " + v.poste) && re.test(v.poste));
    return l.length ? `<div class="psec">Agents prévus aujourd'hui <b>${l.length}</b></div>${l.map((a) => `<div class="mut" style="color:var(--txt)">• ${esc(a.nom)} <span class="mut">${esc(a.poste)} · ${esc(a.debut || "")}-${esc(a.fin || "")}</span></div>`).join("")}` : "";
  };
  // ---- fiche de la zone
  const fiche = () => {
    const z = P.zones.find((x) => x.id === PLAN_SEL), box = $("#pfiche"); if (!z) { box.innerHTML = ""; return; }
    const inf = D.infos[z.id] || {}, e = D.etat[z.bat] || {}, mc = mcDe(z), cl = clesDe(z), sorties = cl.filter((c) => c.sortie);
    const site = z.site || "Parc Expo Valmont", ligne = (ic, lb, v) => (v ? `<tr><td style="white-space:nowrap">${ic} ${lb}</td><td>${esc(v)}</td></tr>` : "");
    const [cx, cy] = centre(z.pts), chip = (t, c = "") => `<span class="pchip ${c}">${t}</span>`;
    const kv = (lb, v) => (v ? `<div class="pkv"><span>${lb}</span><b>${esc(v)}</b></div>` : "");
    box.innerHTML = `<div class="card pfiche" style="--zc:${couleur(z)[0]}"><div class="pfh"><div><div class="psur">${esc(P.infosType[z.type] || "")}</div><h2 style="margin:2px 0 0">${esc(z.nom)}</h2></div><span class="pcarreau">${carreau(cx, cy)}</span></div>
      <div class="pchips">${z.surface ? chip(z.surface.toLocaleString("fr-FR") + " m²") : ""}${z.places ? chip(z.places.toLocaleString("fr-FR") + " places") : ""}${z.bat ? chip(e.ouvert ? "Ouvert" : "Fermé", e.ouvert ? "ok" : "off") + chip(e.eclairage ? "Éclairage en fonction" : "Éclairage hors fonction", e.eclairage ? "lum" : "off") : ""}${z.extra ? chip(esc(z.extra)) : ""}</div>
      ${z.bat && e.maj ? `<p class="mut" style="margin:6px 0 0;font-size:.78rem">Dernière opération ${fmt(e.maj)} par ${esc(e.par || "")}</p>` : ""}
      ${D.voitMC ? `<div class="psec">Faits ouverts <b>${mc.length}</b></div>${mc.length ? mc.slice(0, 8).map((i) => `<div class="pfait g-${i.gravite}"><b>${esc(i.numero || "")}</b> ${esc(i.categorie)}<span class="mut"> · ${esc(i.lieu || "")} · ${fmt(i.heure || i.t)} · ${esc(i.statut)}</span></div>`).join("") : `<p class="mut" style="margin:0">Aucun fait ouvert.</p>`}` : ""}
      ${agentsHTML(z)}
      <div class="psec">Sécurité incendie et secours</div>
      ${[inf.effectif, inf.ssi, inf.dae, inf.ria, inf.coupures, inf.issues, inf.rassemblement, inf.notes].some(Boolean) ? `<div class="pkvs">${kv("Effectif maximum", inf.effectif)}${kv("SSI / CMSI", inf.ssi)}${kv("DAE", inf.dae)}${kv("RIA / extincteurs", inf.ria)}${kv("Coupures gaz / électricité", inf.coupures)}${kv("Issues / accès pompiers", inf.issues)}${kv("Point de rassemblement", inf.rassemblement)}${kv("Consignes", inf.notes)}</div>${inf.maj ? `<p class="mut" style="font-size:.74rem;margin:6px 0 0">Mise à jour ${fmt(inf.maj)} · ${esc(inf.par || "")}</p>` : ""}` : `<p class="mut" style="margin:0">Fiche à compléter${D.peutModif ? "." : " par le PC."}</p>`}
      <div class="pactions">
        ${!lecture() && (z.mc || z.site) ? `<button class="btn red" id="pmc">Saisir en main courante ici</button>` : ""}
        ${z.bat && (!lecture() || coord()) ? `<button class="btn" id="pbat">Ouverture / fermeture · éclairage</button>` : ""}
        ${D.peutModif ? `<button class="btn" id="pedit">Compléter la fiche sécurité</button>` : ""}</div>
      <div id="pform"></div></div>`;
    box.scrollIntoView({ behavior: "smooth", block: "start" });
    if ($("#pmc")) $("#pmc").onclick = () => { try { sessionStorage.setItem("ssiap-lieu", JSON.stringify({ site, zone: z.mc || "" })); } catch {} location.hash = "#/mc"; };
    if ($("#pbat")) $("#pbat").onclick = () => { try { sessionStorage.setItem("ssiap-bat", z.bat); } catch {} location.hash = "#/batiments"; };
    if ($("#pcle")) $("#pcle").onclick = () => { try { sessionStorage.setItem("ssiap-kq", z.type === "arena" ? "arena" : z.id.length <= 2 ? z.id : z.nom); } catch {} location.hash = "#/cles"; };
    if ($("#pedit")) $("#pedit").onclick = () => { const champ = (k, lb, ph) => `<label>${lb}</label><input name="${k}" value="${esc(inf[k] || "")}" placeholder="${ph}">`;
      $("#pform").innerHTML = `<form id="pf" style="margin-top:10px">${champ("effectif", "Effectif maximum", "ex. 5 000 personnes")}${champ("ssi", "SSI / CMSI (emplacement)", "ex. local SSI accueil B")}${champ("dae", "DAE (emplacement)", "ex. entrée nord du hall")}
        ${champ("ria", "RIA / extincteurs", "ex. 6 RIA, extincteurs à chaque issue")}${champ("coupures", "Coupures gaz / électricité", "ex. TGBT local technique B1")}${champ("issues", "Issues de secours / accès pompiers", "ex. 8 issues, accès pompiers allée Turgot")}${champ("rassemblement", "Point de rassemblement", "ex. parvis B")}
        <label>Consignes particulières</label><textarea name="notes">${esc(inf.notes || "")}</textarea><button class="btn red" style="margin-top:8px">💾 Enregistrer</button></form>`;
      $("#pf").onsubmit = async (ev) => { ev.preventDefault(); try { D.infos[z.id] = await api("plan/" + z.id, { method: "PUT", body: Object.fromEntries(new FormData(ev.target)) }); toast("✅ Fiche enregistrée"); fiche(); } catch (err) { toast(err.message); } }; };
  };
  if (PLAN_DAE_OUVERT) { const d = P.dae.find((x) => x.id === PLAN_DAE_OUVERT); PLAN_DAE_OUVERT = null; ficheDAE(d); } else fiche();
}
let PLAN_VB = null, PLAN_DAE_OUVERT = null;

/* ================= Archives mensuelles de la main courante ================= */
const nomMoisC = (m) => { const s = new Date(m + "-15T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" }); return s[0].toUpperCase() + s.slice(1); };
const csvMCc = (l) => "﻿" + [["N°", "Date saisie", "Heure du fait", "Poste", "Famille", "Type", "Gravité", "Statut", "Site", "Lieu", "Événement", "Faits", "Intervenants", "Actions", "Prestataire", "Société", "Immatriculation", "Auteur", "Photos", "Suivi"],
  ...[...l].reverse().map((i) => [i.numero, fmt(i.t), i.heure ? fmt(i.heure) : "", i.poste, i.famille, i.categorie, i.gravite, i.statut, i.site, i.lieu, i.evenement, i.description, i.intervenants, i.actions, i.prestataire, i.societe, i.immat, i.auteur, i.photos || (i.photo ? 1 : 0), (i.suivi || []).map((x) => `${fmt(x.t)} ${x.qui} : ${x.note}`).join(" | ")])]
  .map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""').replace(/\r?\n/g, " ")}"`).join(";")).join("\r\n");
async function vMCArchives() {
  if (!staff() && !coord()) return (location.hash = "#/");
  const d = await api("incidents/mois"), peutEnv = proprio() || coord() || S.user.role === "admin", c = d.conservation;
  view.innerHTML = `<div id="arw"><div class="card"><h2>📦 Archives de la main courante</h2>
    <p class="mut" style="margin-top:0">Chaque mois est rangé à part : rien n'est effacé. Le 1er de chaque mois, la main courante du mois écoulé part automatiquement au PC sécurité et à Lucas Fontaine (tableau Excel + version imprimable en PDF).</p>
    ${d.mois.length ? d.mois.map((x) => `<div class="item" style="display:flex;gap:8px;align-items:center;padding:8px"><span style="flex:1"><b>${esc(nomMoisC(x.mois))}</b><br><span class="mut" style="font-size:.82rem">${x.nb} saisie(s)${x.copie ? " · copie envoyée le " + fmt(x.copie) : ""}</span></span>
      <button class="btn sm" data-voir="${x.mois}" style="flex:none">👁️</button><button class="btn sm" data-csv="${x.mois}" style="flex:none">⬇️ Excel</button>${peutEnv ? `<button class="btn sm" data-env="${x.mois}" style="flex:none">📨</button>` : ""}</div>`).join("") : `<p class="mut">Aucune saisie pour l'instant.</p>`}
    ${peutEnv ? `<button class="btn sm red" id="aressai" style="margin-top:10px">📨 Essai : envoyer la copie du mois en cours</button>` : ""}</div>
    ${proprio() ? `<div class="card"><h2>🗄️ Durée de conservation</h2><p class="mut" style="margin-top:0">À valider avec la VEV avant de l'activer. Une fois activée, à chaque copie mensuelle : les mois plus anciens que la durée sont supprimés, et les photos plus anciennes que leur durée aussi (le texte reste).</p>
      <label style="display:flex;gap:10px;align-items:center;color:var(--txt)"><input type="checkbox" id="cact" ${c.actif ? "checked" : ""} style="width:22px;height:22px;flex:none"> Activer la suppression automatique</label>
      <div class="row"><div><label>Main courante gardée (ans)</label><input id="cans" type="number" min="1" max="30" value="${c.ansTexte}"></div><div><label>Photos gardées (ans)</label><input id="cph" type="number" min="1" max="30" value="${c.ansPhotos}"></div></div>
      <button class="btn red" id="csave" style="margin-top:8px">Enregistrer</button><p class="mut">${c.actif ? `✅ Active : ${c.ansTexte} ans, photos ${c.ansPhotos} ans.` : "⏸️ Désactivée : rien n'est supprimé."}</p></div>` : ""}</div>`;
  $("#arw").onclick = async (e) => {
    const v = e.target.closest("[data-voir]"), cs = e.target.closest("[data-csv]"), en = e.target.closest("[data-env]");
    if (v) { MC.mois = v.dataset.voir; MC.ev = null; location.hash = "#/mc"; }
    if (cs) { try { const l = await api("incidents?mois=" + cs.dataset.csv); const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csvMCc(l)], { type: "text/csv;charset=utf-8" })); a.download = `main-courante-${cs.dataset.csv}.csv`; a.click(); } catch (err) { toast(err.message); } }
    if (en && confirm(`Envoyer la copie de ${nomMoisC(en.dataset.env)} au PC et à Lucas ?`)) { try { const r = await api("incidents/copie", { method: "POST", body: { mois: en.dataset.env } }); toast(`📨 Copie envoyée (${r.nb} saisies) à ${r.destinataires.join(", ")}`, 5000); vMCArchives(); } catch (err) { toast(err.message); } }
  };
  if ($("#aressai")) $("#aressai").onclick = async () => { try { const r = await api("incidents/copie", { method: "POST", body: { mois: new Date().toISOString().slice(0, 7), essai: true } }); toast(`📨 Essai envoyé (${r.nb} saisies) à ${r.destinataires.join(", ")}`, 5000); } catch (err) { toast(err.message); } };
  if ($("#csave")) $("#csave").onclick = async () => { if ($("#cact").checked && !confirm("Activer la suppression automatique des données anciennes ?")) return;
    try { await api("incidents/conservation", { method: "PUT", body: { actif: $("#cact").checked, ansTexte: $("#cans").value, ansPhotos: $("#cph").value } }); toast("✅ Enregistré"); vMCArchives(); } catch (err) { toast(err.message); } };
}

/* ================= Dossier des agents : diplômes, carte pro, habilitations, recyclages, visite médicale ================= */
const DOS_ICO = { ok: "🟢", bientot: "🟠", expire: "🔴", manquant: "⚪" }, DOS_TXT = { ok: "valide", bientot: "expire bientôt", expire: "expiré", manquant: "manquant" };
const frD = (x) => (x ? x.split("-").reverse().join("/") : "");
let DOS_POUR = null; // { id, nom } quand le propriétaire / coordinateur ajoute pour un agent
const lireFichier = (f) => new Promise((ok, ko) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = ko; r.readAsDataURL(f); });
const ligneDoc = (d, sup) => `<div class="item" style="display:flex;gap:8px;align-items:center;padding:8px"><span style="flex:1;min-width:0">${DOS_ICO[statutDocC(d)]} <b>${esc(d.libelle)}</b>
  <br><span class="mut" style="font-size:.82rem">${[d.numero && "n° " + d.numero, d.obtention && "obtenu le " + frD(d.obtention), d.echeance && "échéance " + frD(d.echeance)].filter(Boolean).map(esc).join(" · ") || "—"}</span></span>
  ${d.fichier ? `<button class="btn sm" data-voir="${esc(d.id)}" data-t="${esc(d.libelle)}" style="flex:none">👁️</button>` : ""}${sup ? `<button class="btn sm" data-sup="${esc(d.id)}" style="flex:none">🗑️</button>` : ""}</div>`;
const ligneConf = (e) => `<div class="item" style="padding:8px;border-left:3px solid ${{ ok: "var(--ok)", bientot: "orange", expire: "var(--red)", manquant: "#888" }[e.statut]}">
  <div class="h"><b>${DOS_ICO[e.statut]} ${esc(e.lb)}</b><span class="mut" style="white-space:nowrap">${DOS_TXT[e.statut]}${e.echeance ? " · " + frD(e.echeance) : ""}</span></div>
  ${e.statut !== "ok" || e.echeance ? `<div style="font-size:.9rem;margin-top:2px">${e.statut === "ok" ? `Valable jusqu'au ${frD(e.echeance)}${e.jours != null ? ` (${e.jours} j)` : ""}` : esc(e.action)}</div>` : ""}
  ${e.suggestion ? `<div style="margin-top:3px">📅 Date conseillée : <b>${frD(e.suggestion)}</b></div>` : ""}
  ${e.note ? `<div class="mut" style="font-size:.8rem">⚠️ ${esc(e.note)}</div>` : ""}<div class="mut" style="font-size:.75rem">📖 ${esc(e.ref)}</div></div>`;
const statutDocC = (d) => { if (!d.echeance) return "ok"; const j = (new Date(d.echeance) - Date.now()) / 864e5; return j < 0 ? "expire" : j < 60 ? "bientot" : "ok"; };
async function vDossier() {
  const d = await api("dossier"), TY = Object.fromEntries(d.types.map(([k, l, a]) => [k, { l, a }]));
  const pour = DOS_POUR; DOS_POUR = null;
  const docs = pour ? [] : d.docs;
  view.innerHTML = `<div id="dosw">${pour ? "" : `<div class="card"><h2>📁 Mon dossier</h2>
    <p class="mut" style="margin-top:0">Diplômes initiaux, carte pro, habilitation électrique, recyclages${d.pcs ? ", visite médicale" : ""} : photographie ou joins le PDF de chaque document, avec sa date d'échéance. Tu es prévenu avant qu'un document expire.</p>
    ${d.etat.length ? `<h3>Ma conformité réglementaire${d.pcs ? " (équipe du PCS)" : ""}</h3>${d.etat.map(ligneConf).join("")}` : ""}
    <h3>Mes documents (${docs.length})</h3><div id="dosl">${docs.length ? docs.map((x) => ligneDoc(x, true)).join("") : `<p class="mut">Aucun document pour l'instant.</p>`}</div></div>`}
    <div class="card"><h2>➕ Ajouter un document${pour ? " pour " + esc(pour.nom) : ""}</h2><form id="fdos">
      <label>Type</label><select name="type" id="dost">${d.types.filter(([k]) => k !== "visite" || d.pcs || pour).map(([k, l]) => `<option value="${k}" >${esc(l)}</option>`).join("")}</select>
      <div id="doslib" class="hidden"><label>Intitulé</label><input name="libelle" placeholder="ex. PSE1, permis B, H0B0…"></div>
      <div class="row"><div><label>N° du diplôme / de la carte</label><input name="numero"></div></div>
      <div class="row"><div><label>Date d'obtention</label><input name="obtention" type="date" id="doso"></div><div><label>Date d'échéance</label><input name="echeance" type="date" id="dose"></div></div>
      <p class="mut" id="dosaide" style="margin:2px 0 0"></p>
      <div class="row" style="margin-top:10px"><label class="btn" style="margin:0;text-align:center;color:var(--txt)">📷 Photographier<input type="file" accept="image/*" capture="environment" id="dosph" hidden></label>
        <label class="btn" style="margin:0;text-align:center;color:var(--txt)">📄 PDF / image<input type="file" accept="application/pdf,image/jpeg,image/png" id="dosf" hidden></label></div>
      <p id="dosfi" class="mut"></p>
      <button class="btn red" style="margin-top:8px">💾 Enregistrer le document</button></form></div></div>`;
  let fichier = "", nomFichier = "";
  const aide = () => { const k = $("#dost").value, a = TY[k].a; $("#doslib").classList.toggle("hidden", k !== "autre");
    $("#dosaide").textContent = a ? `Validité habituelle : ${a} an${a > 1 ? "s" : ""}. L'échéance se calcule toute seule depuis la date d'obtention (tu peux la changer).` : "";
    calc(); };
  const calc = () => { const a = TY[$("#dost").value].a, o = $("#doso").value; if (a && o && !$("#dose").dataset.manuel) { const x = new Date(o + "T12:00:00"); x.setFullYear(x.getFullYear() + a); x.setDate(x.getDate() - 1); $("#dose").value = x.toISOString().slice(0, 10); } };
  $("#dost").onchange = aide; $("#doso").onchange = calc; $("#dose").oninput = () => ($("#dose").dataset.manuel = "1"); aide();
  $("#dosph").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; fichier = await compress(f); nomFichier = f.name; $("#dosfi").textContent = "📷 Photo prête : " + f.name; };
  $("#dosf").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; if (f.size > 4e6) return toast("4 Mo maximum");
    fichier = f.type === "application/pdf" ? await lireFichier(f) : await compress(f); nomFichier = f.name; $("#dosfi").textContent = "📄 Fichier prêt : " + f.name; };
  $("#fdos").onsubmit = async (e) => { e.preventDefault(); const btn = e.submitter; btn.disabled = true;
    try { await api("dossier", { method: "POST", body: { ...Object.fromEntries(new FormData(e.target)), fichier, nomFichier, pour: pour ? pour.id : "" } }); toast("✅ Document enregistré");
      if (pour) { location.hash = "#/dossiers"; } else vDossier(); } catch (err) { toast(err.message); btn.disabled = false; } };
  $("#dosw").onclick = clicDossier(vDossier);
}
const clicDossier = (again) => async (e) => {
  const v = e.target.closest("[data-voir]"), su = e.target.closest("[data-sup]"), aj = e.target.closest("[data-pour]");
  if (v) voirDoc({ titre: v.dataset.t, src: "dossier/fichier/" + v.dataset.voir });
  if (su && confirm("Supprimer ce document ?")) { try { await api("dossier/" + su.dataset.sup, { method: "DELETE" }); toast("Document supprimé"); again(); } catch (err) { toast(err.message); } }
  if (aj) { DOS_POUR = { id: aj.dataset.pour, nom: aj.dataset.nom }; location.hash = "#/dossier"; }
};
let DOS_FILTRE = "pcs";
async function vDossiers() {
  if (!staff() && !coord() && !proprio()) return (location.hash = "#/");
  const list = await api("dossier/agents");
  const gere = proprio() || coord();
  const alertes = list.flatMap((u) => u.etat.filter((e) => e.statut !== "ok").map((e) => ({ u, e })));
  const nb = (s) => alertes.filter((a) => a.e.statut === s).length;
  const draw = () => {
    const l = list.filter((u) => DOS_FILTRE === "tous" || (DOS_FILTRE === "pcs" ? u.pcs : u.etat.some((e) => e.statut !== "ok")));
    $("#dosag").innerHTML = l.map((u) => { const pire = ["expire", "manquant", "bientot", "ok"].find((s) => u.etat.some((e) => e.statut === s)) || "ok";
      return `<details data-row><summary><span>${DOS_ICO[pire]} <b>${esc(u.nom)}</b> <span class="mut">· ${u.pcs ? "Équipe PCS · " : ""}${esc((u.q || u.role || "").toUpperCase().replace("SSIAP", "SSIAP "))}${u.sansCompte ? " · pas encore de compte" : ""}</span></span></summary><div class="c">
        ${u.etat.map(ligneConf).join("")}
        ${u.docs.length ? `<h3 style="margin:10px 0 4px">Documents (${u.docs.length})</h3>${u.docs.map((x) => ligneDoc(x, gere)).join("")}` : `<p class="mut">Aucun document déposé.</p>`}
        ${gere && u.id ? `<button class="btn sm" data-pour="${esc(u.id)}" data-nom="${esc(u.nom)}" style="margin-top:8px">➕ Ajouter un document pour ${esc(u.nom)}</button>` : ""}</div></details>`; }).join("") || `<p class="mut">Personne.</p>`;
  };
  view.innerHTML = `<div id="dosw"><div class="card"><h2>🗂️ Dossiers des agents</h2>
    <p class="mut" style="margin-top:0">Diplômes initiaux (ADS, SSIAP 1, 2, 3), carte pro, habilitation électrique, recyclages et autres. Visite médicale en plus pour l'équipe du PCS.</p>
    <p>🔴 ${nb("expire")} expiré(s) · 🟠 ${nb("bientot")} bientôt expiré(s) · ⚪ ${nb("manquant")} manquant(s)</p>
    ${gere || admin() ? `<button class="btn sm red" id="dosessai">📨 Envoyer un essai d'alerte au PC et à Lucas</button>` : ""}
    <p class="mut" style="margin:6px 0 0">Chaque matin, l'appli lit les dossiers selon la réglementation et prévient le PC sécurité et Lucas Fontaine par mail et notification quand un document approche de son échéance, avec une date conseillée.</p></div>
    ${alertes.filter((a) => a.e.statut !== "manquant").length ? `<div class="card"><h2>⏰ Bientôt expirés</h2>${alertes.filter((a) => a.e.statut !== "manquant").sort((x, y) => x.e.jours - y.e.jours).map(({ u, e }) => `<div style="margin-top:6px"><b>${esc(u.nom)}</b>${ligneConf(e)}</div>`).join("")}</div>` : ""}
    <div class="card"><h2>👥 Agents</h2>
    <div class="seg" id="dosf2" style="margin-top:0"><button type="button" data-f="pcs">Équipe PCS</button><button type="button" data-f="alerte">À régulariser</button><button type="button" data-f="tous">Tous</button></div>
    <input id="dosq" placeholder="Rechercher un agent…" style="margin-top:8px"><div id="dosag" style="margin-top:8px"></div></div>
    ${proprio() ? `<div class="card"><h2>👥 Équipe du PCS (visite médicale obligatoire)</h2><p class="mut" style="margin-top:0">Une personne par ligne : Prénom Nom ; qualification (ssiap2 ou ssiap3).</p>
      <textarea id="dospcs" style="min-height:130px"></textarea><button class="btn red" id="dospcsok" style="margin-top:8px">Enregistrer l'équipe</button></div>` : ""}</div>`;
  const seg = () => [...$("#dosf2").children].forEach((b) => b.classList.toggle("on", b.dataset.f === DOS_FILTRE));
  $("#dosf2").onclick = (e) => { const b = e.target.closest("[data-f]"); if (!b) return; DOS_FILTRE = b.dataset.f; seg(); draw(); };
  $("#dosq").oninput = (e) => { const q = e.target.value.toLowerCase(); if (q && DOS_FILTRE !== "tous") { DOS_FILTRE = "tous"; seg(); draw(); } view.querySelectorAll("[data-row]").forEach((r) => (r.style.display = r.textContent.toLowerCase().includes(q) ? "" : "none")); };
  seg(); draw();
  $("#dosw").onclick = clicDossier(vDossiers);
  if ($("#dosessai")) $("#dosessai").onclick = async (e) => { e.target.disabled = true;
    try { const r = await api("dossier/essai-alertes", { method: "POST" }); toast(r.envoyes ? `📨 Essai envoyé : ${r.envoyes} document(s) à ${r.destinataires.join(", ")}` : "Aucun document bientôt expiré : rien à envoyer", 6000); } catch (err) { toast(err.message); } e.target.disabled = false; };
  if ($("#dospcs")) { api("dossier/equipe").then((l) => ($("#dospcs").value = l.map((x) => `${x.nom} ; ${x.q}`).join("\n")));
    $("#dospcsok").onclick = async () => { const items = $("#dospcs").value.split("\n").map((x) => x.split(";")).filter((x) => x[0].trim()).map(([nom, q]) => ({ nom: nom.trim(), q: (q || "ssiap2").trim().toLowerCase().replace(/\s/g, "") }));
      try { const r = await api("dossier/equipe", { method: "PUT", body: { items } }); toast(`✅ ${r.nb} personne(s) dans l'équipe PCS`); vDossiers(); } catch (e) { toast(e.message); } }; }
}

/* ================= Équipe ADS Arena du jour par groupe (coordinateur Arena) ================= */
let EQ_DATE = null;
async function vEquipeArena() {
  if (!S.user.coordArena && !staff() && !coord()) return (location.hash = "#/");
  const q = EQ_DATE ? "?date=" + EQ_DATE : "";
  const [d, noms] = await Promise.all([api("arena-equipe" + q), api("arena-equipe/agents").catch(() => [])]);
  EQ_DATE = d.date;
  const G = [{ k: "aplacer", lb: "❓ À placer", requis: 0 }, ...d.groupes], ed = d.modifiable;
  const actifs = d.agents.filter((a) => !a.retire), retires = d.agents.filter((a) => a.retire);
  const requisTot = d.groupes.reduce((n, g) => n + g.requis, 0), manqueTot = d.groupes.reduce((n, g) => n + Math.max(0, g.requis - actifs.filter((a) => a.groupe === g.k).length), 0), place = actifs.filter((a) => a.groupe !== "aplacer").length;
  const tel = (a) => (a.tel ? `<a class="btn sm" href="tel:${esc(a.tel)}" style="flex:none;text-decoration:none">📞</a>` : "");
  const ligne = (a) => `<div class="item" style="display:flex;gap:8px;align-items:center;padding:8px">
    <span style="flex:1;min-width:0"><b>${esc(a.nom)}</b>${a.ajoute ? " 🆕" : ""}<br><span class="mut" style="font-size:.82rem">${esc(a.debut || "")}${a.fin ? "-" + esc(a.fin) : ""}${a.poste ? " · " + esc(a.poste) : ""}</span></span>
    ${tel(a)}${ed ? `<select data-mv="${esc(a.id)}" style="flex:0 0 120px;font-size:.85rem">${G.map((g) => `<option value="${g.k}" ${g.k === a.groupe ? "selected" : ""}>${esc(g.lb.replace(/^\S+\s/, ""))}</option>`).join("")}</select>
    <button class="btn sm" data-rm="${esc(a.id)}" style="flex:none" title="Retirer">✕</button>` : ""}</div>`;
  view.innerHTML = `<div id="eqw"><div class="card"><h2>🏟️ Équipe ADS Arena</h2>
    ${d.choixDate ? `<label>Jour de la mission</label><input type="date" id="eqd" value="${d.date}">` : `<p style="margin:0">Mission du <b>${new Date(d.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}</b></p>`}
    ${d.evenement ? `<p class="mut" style="margin:6px 0 0">🎫 ${esc(d.evenement)}</p>` : ""}${d.coordinateurs.length ? `<p class="mut" style="margin:4px 0 0">Coordinateur : ${d.coordinateurs.map(esc).join(", ")}</p>` : ""}
    <p style="margin:8px 0 0"><b>${actifs.length}</b> ADS · <b>${place}</b> placé(s)${requisTot ? ` · besoin <b>${requisTot}</b>${manqueTot ? ` <span style="color:var(--red)">(il manque ${manqueTot} ADS)</span>` : " ✅"}` : ""}</p>
    ${d.maj ? `<p class="mut" style="margin:2px 0 0">Mis à jour ${fmt(d.maj)} par ${esc(d.par)}</p>` : ""}
    <p class="mut" style="margin:6px 0 0">Les ADS du planning Arena de ce jour sont placés selon leur poste. Change le groupe avec la liste, règle le nombre d'ADS qu'il faut par groupe et ajoute ceux qui manquent.</p></div>
    ${G.map((g) => { const l = actifs.filter((a) => a.groupe === g.k); if (g.k === "aplacer" && !l.length) return "";
      const manque = g.requis && l.length < g.requis;
      return `<div class="card" style="${manque ? "border-color:var(--red)" : ""}"><div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px">
        <h2 style="margin:0;font-size:1.05rem">${esc(g.lb)}</h2>
        <span style="white-space:nowrap"><b style="color:${manque ? "var(--red)" : "var(--ok)"}">${l.length}</b>${g.k !== "aplacer" ? ` / ${ed ? `<input type="number" min="0" max="200" data-rq="${g.k}" value="${g.requis || ""}" placeholder="?" style="width:56px;padding:4px;display:inline-block">` : g.requis || "?"}` : ""}</span></div>
        ${l.length ? l.map(ligne).join("") : `<p class="mut" style="margin:6px 0 0">Personne.</p>`}
        ${ed && g.k !== "aplacer" ? `<button class="btn sm" data-add="${g.k}" style="margin-top:8px">➕ Ajouter un ADS</button>` : ""}</div>`; }).join("")}
    ${retires.length ? `<div class="card"><h2 style="font-size:1rem">Retirés de la mission</h2>${retires.map((a) => `<div class="item" style="display:flex;gap:8px;align-items:center;padding:8px"><span style="flex:1">${esc(a.nom)} <span class="mut">${esc(a.debut || "")}</span></span>${ed ? `<button class="btn sm" data-back="${esc(a.id)}">↩︎ Remettre</button>` : ""}</div>`).join("")}</div>` : ""}
    <datalist id="eqnoms">${noms.map((n) => `<option value="${esc(n.nom)}">`).join("")}</datalist></div>`;
  const put = async (body, msg) => { try { await api("arena-equipe", { method: "PUT", body: { date: d.date, ...body } }); if (msg) toast(msg); vEquipeArena(); } catch (e) { toast(e.message); } };
  if ($("#eqd")) $("#eqd").onchange = (e) => { EQ_DATE = e.target.value; vEquipeArena(); };
  if (!ed) return;
  $("#eqw").onchange = (e) => {
    const mv = e.target.closest("[data-mv]"), rq = e.target.closest("[data-rq]");
    if (mv) put({ affect: { [mv.dataset.mv]: mv.value } }, "✅ Groupe changé");
    if (rq) put({ requis: { [rq.dataset.rq]: rq.value } });
  };
  $("#eqw").onclick = (e) => {
    const rm = e.target.closest("[data-rm]"), add = e.target.closest("[data-add]"), back = e.target.closest("[data-back]");
    if (rm && confirm("Retirer cet ADS de la mission ?")) put({ retirer: rm.dataset.rm }, "ADS retiré");
    if (back) put({ remettre: back.dataset.back }, "ADS remis");
    if (add) { const box = document.createElement("div"); box.className = "item"; box.innerHTML = `<label>Nom de l'ADS</label><input list="eqnoms" id="eqn" placeholder="Tape le nom…" autocomplete="off">
      <div class="row"><div><label>Téléphone</label><input id="eqt" type="tel"></div><div><label>Début</label><input id="eqdb" type="time"></div><div><label>Fin</label><input id="eqf" type="time"></div></div>
      <button class="btn sm red" id="eqok" style="margin-top:6px">Ajouter</button>`;
      add.replaceWith(box); $("#eqn").focus();
      $("#eqn").onchange = () => { const n = noms.find((x) => x.nom === $("#eqn").value); if (n && n.tel) $("#eqt").value = n.tel; };
      $("#eqok").onclick = () => { if (!$("#eqn").value.trim()) return toast("Indique le nom"); put({ ajout: { nom: $("#eqn").value, tel: $("#eqt").value, debut: $("#eqdb").value, fin: $("#eqf").value, groupe: add.dataset.add } }, "✅ ADS ajouté"); }; }
  };
}

/* ================= Demandes de DPAE (SSIAP 3) ================= */
async function vDPAE() {
  const peut = peutDPAE();
  if (!peut && !coord() && !lecture()) return (location.hash = "#/");
  const [list, agents, mail] = await Promise.all([api("dpae"), peut || coord() ? api("dpae/agents") : [], api("dpae/mail").catch(() => ({}))]);
  let nouveau = false;
  const fr = (x) => (x ? x.split("-").reverse().join("/") : "");
  const demain = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
  view.innerHTML = `${peut ? `<div class="card"><h2>📝 Demande de DPAE</h2>
    <p class="mut" style="margin-top:0">Déclaration préalable à l'embauche : choisis un agent de la liste ou crée-le. La demande part par mail au service qui fait la DPAE (${esc(mail.email || "—")}) et reste suivie ici.</p>
    <form id="fd">
      <div class="seg" id="dmode"><button type="button" data-m="0" class="on">👥 Agent de la liste</button><button type="button" data-m="1">➕ Nouvel agent</button></div>
      <div id="dliste"><label>Agent</label><input name="agent" id="dag" list="dagl" placeholder="Tape le nom…" autocomplete="off">
        <datalist id="dagl">${agents.map((a) => `<option value="${esc(a.nom)}">`).join("")}</datalist><p class="mut" id="dinfo" style="margin:4px 0 0"></p></div>
      <div id="dnew" class="hidden"><div class="row"><div><label>Prénom</label><input name="prenom"></div><div><label>Nom</label><input name="nom" autocapitalize="characters"></div></div>
        <p class="mut" style="margin:4px 0 0">Le nouvel agent est ajouté à la liste des agents.</p></div>
      <div class="row"><div><label>Téléphone</label><input name="tel" type="tel"></div><div><label>E-mail</label><input name="email" type="email"></div></div>
      <div class="row"><div><label>Date de naissance</label><input name="naissance" type="date"></div><div><label>Lieu de naissance</label><input name="lieuNaissance"></div></div>
      <div class="row"><div><label>Nationalité</label><input name="nationalite" value="Française"></div><div><label>N° de sécurité sociale</label><input name="nir" inputmode="numeric" placeholder="si connu"></div></div>
      <p class="mut" style="margin:2px 0 0">🔒 Le n° de sécurité sociale part seulement dans le mail : il n'est pas gardé dans l'appli.</p>
      <label>Adresse</label><input name="adresse">
      <div class="row"><div><label>Qualification</label><select name="qualif">${["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "ADS + SSIAP 1"].map((x) => `<option>${x}</option>`).join("")}</select></div>
        <div><label>Contrat</label><select name="contrat">${["CDD d'usage", "CDD", "CDI", "Extra / vacation"].map((x) => `<option>${esc(x)}</option>`).join("")}</select></div></div>
      <div class="row"><div><label>Embauche le</label><input name="debut" type="date" value="${demain}" required></div><div><label>Heure de prise de poste</label><input name="heure" type="time"></div></div>
      <div class="row"><div><label>Fin de contrat</label><input name="fin" type="date"></div><div><label>Site</label><select name="site"><option>Parc Expo Valmont</option><option>Valmont Arena</option><option>Parc + Arena</option></select></div></div>
      <div class="row"><div><label>Événement</label><input name="evenement"></div><div><label>Poste prévu</label><input name="poste" placeholder="ex. ADS P3"></div></div>
      <label>Commentaire</label><textarea name="commentaire" style="min-height:60px"></textarea>
      <button class="btn red" style="margin-top:10px">📨 Envoyer la demande de DPAE</button>
    </form></div>` : ""}
    ${proprio() || coord() ? `<div class="card"><h2>📧 Adresse des demandes de DPAE</h2><p class="mut" style="margin-top:0">Service RH / planification qui fait la DPAE. Plusieurs adresses possibles, séparées par une virgule.</p>
      <div class="row"><input id="dmail" type="text" value="${esc(mail.email || "")}"><button class="btn sm red" id="dmailsave" style="flex:0 0 auto">OK</button></div></div>` : ""}
    <div class="card"><h2>📋 Demandes envoyées</h2><div id="dlist">${list.length ? list.map((d) => `<div class="item">
      <div class="h"><b>${esc(d.numero)} · ${esc(d.agent)}${d.nouveau ? " 🆕" : ""}</b><span class="badge ${d.statut === "faite" ? "clos" : d.statut === "annulée" ? "info" : "moyenne"}">${esc(d.statut)}</span></div>
      <div class="mut">${esc(d.qualif)} · ${esc(d.contrat)} · embauche le ${fr(d.debut)}${d.heure ? " à " + esc(d.heure) : ""}${d.fin ? " → " + fr(d.fin) : ""}${d.site ? " · " + esc(siteCourt(d.site) || d.site) : ""}${d.evenement ? " · " + esc(d.evenement) : ""}</div>
      <div class="mut">Demandée par ${esc(d.demandeur)} le ${fmt(d.t)}</div>
      ${(d.suivi || []).map((x) => `<div class="mut">↳ ${fmt(x.t)} ${esc(x.qui)} : ${esc(x.note)}</div>`).join("")}
      ${peut || coord() ? `<div class="row" style="margin-top:6px"><button class="btn sm" data-ds="${d.id}" data-v="faite">✅ DPAE faite</button><button class="btn sm" data-ds="${d.id}" data-v="annulée">✕ Annuler</button></div>` : ""}
    </div>`).join("") : `<p class="mut">Aucune demande.</p>`}</div></div>`;
  if ($("#dmailsave")) $("#dmailsave").onclick = async () => { try { await api("dpae/mail", { method: "PUT", body: { email: $("#dmail").value } }); toast("✅ Adresse enregistrée"); } catch (e) { toast(e.message); } };
  $("#dlist").onclick = async (e) => { const b = e.target.closest("[data-ds]"); if (!b) return;
    try { await api("dpae/" + b.dataset.ds, { method: "PATCH", body: { statut: b.dataset.v, note: b.dataset.v === "faite" ? "DPAE faite" : "Demande annulée" } }); toast("✅ Mis à jour"); vDPAE(); } catch (err) { toast(err.message); } };
  if (!peut) return;
  const f = $("#fd");
  $("#dmode").onclick = (e) => { const b = e.target.closest("[data-m]"); if (!b) return; nouveau = b.dataset.m === "1";
    [...$("#dmode").children].forEach((x) => x.classList.toggle("on", x === b)); $("#dliste").classList.toggle("hidden", nouveau); $("#dnew").classList.toggle("hidden", !nouveau); };
  $("#dag").onchange = () => { const a = agents.find((x) => x.nom === $("#dag").value); if (!a) { $("#dinfo").textContent = ""; return; }
    const el = f.elements; if (a.tel) el.tel.value = a.tel; if (a.email) el.email.value = a.email; if (a.naissance) el.naissance.value = a.naissance; if (a.adresse) el.adresse.value = a.adresse;
    const q = { ads: "ADS", ssiap1: "SSIAP 1", ssiap2: "SSIAP 2", ssiap3: "SSIAP 3" }[a.qualif]; if (q) el.qualif.value = q;
    $("#dinfo").textContent = a.naissance ? "✅ Fiche de renseignement trouvée : champs pré-remplis." : "Agent de la liste (pas de fiche) : complète les champs."; };
  f.onsubmit = async (e) => { e.preventDefault(); const btn = e.submitter; const fd = Object.fromEntries(new FormData(f));
    if (!nouveau && !agents.some((x) => x.nom === fd.agent) && !confirm("Agent absent de la liste. Le créer comme nouvel agent ?")) return;
    if (!nouveau && !agents.some((x) => x.nom === fd.agent)) { const [pr, ...n] = String(fd.agent).trim().split(/\s+/); fd.prenom = pr; fd.nom = n.join(" "); nouveau = true; }
    btn.disabled = true;
    try { const d = await api("dpae", { method: "POST", body: { ...fd, nouveau } }); toast(`✅ ${d.numero} envoyée`); vDPAE(); } catch (err) { toast(err.message); btn.disabled = false; } };
}

/* ================= Diagnostic des notifications ================= */
async function vNotifDiag() {
  const ios = /iPhone|iPad/.test(navigator.userAgent), standalone = matchMedia("(display-mode: standalone)").matches || navigator.standalone;
  const sw = "serviceWorker" in navigator ? await navigator.serviceWorker.getRegistration() : null;
  const sub = sw && "pushManager" in sw ? await sw.pushManager.getSubscription().catch(() => null) : null;
  const perm = "Notification" in window ? Notification.permission : "absent";
  const ok = (b) => `<i class="dot ${b ? "dot-ok" : "dot-rouge"}"></i>`;
  const lignes = [
    [ok(!ios || standalone), "Appli installée sur l'écran d'accueil", ios ? (standalone ? "oui" : "non : obligatoire sur iPhone (Partager ➜ Sur l'écran d'accueil, puis ouvrir depuis l'icône)") : standalone ? "oui" : "conseillé"],
    [ok(perm === "granted"), "Autorisation des notifications", { granted: "accordée", denied: "refusée : à réactiver dans les réglages du téléphone", default: "pas encore demandée", absent: "non gérée par ce navigateur" }[perm]],
    [ok(!!sw && !!sw.active), "Service de l'appli en arrière-plan", sw && sw.active ? "actif" : "inactif : recharge l'appli"],
    [ok(!!sub), "Abonnement de ce téléphone", sub ? new URL(sub.endpoint).host : "aucun"],
  ];
  view.innerHTML = `<div class="card"><h2>Notifications sonores</h2><p class="mut" style="margin-top:0">Vérification point par point de ce téléphone, puis envoi d'un test.</p>
    <div class="pkvs">${lignes.map(([d, l, v]) => `<div class="pkv"><span>${d}${l}</span><b>${esc(v)}</b></div>`).join("")}</div>
    <div class="pactions"><button class="btn red" id="ndon">${sub && perm === "granted" ? "Réactiver l'abonnement" : "Activer les notifications"}</button><button class="btn" id="ndloc">Test sur ce téléphone (sans serveur)</button><button class="btn" id="ndpush">Test complet (via le serveur)</button></div>
    <div id="ndres" style="margin-top:10px"></div>
    <p class="mut" style="font-size:.78rem;margin-top:12px">Si le test sur ce téléphone ne sonne pas : vérifie le mode silencieux / Ne pas déranger / Concentration, et dans les réglages du téléphone ➜ Notifications ➜ SSIAP Pro (ou Chrome) : sons et bannières autorisés.</p></div>`;
  const res = (h) => ($("#ndres").innerHTML = h);
  $("#ndon").onclick = async () => { try { if (sub) await sub.unsubscribe().catch(() => {}); if (await activerPush()) vNotifDiag(); } catch (e) { res(`<p style="color:var(--g-urg)">${esc(e.message)}</p>`); } };
  $("#ndloc").onclick = async () => { audioOk(); sonAlerte();
    try { if (Notification.permission !== "granted") await Notification.requestPermission(); const r = await navigator.serviceWorker.ready;
      await r.showNotification("SSIAP Pro — test local", { body: "Si tu vois et entends ceci, le téléphone affiche bien les notifications.", icon: "/img/icon-192.png", vibrate: [400, 150, 400], tag: "ssiap-test", renotify: true });
      res(`<p class="mut">Notification locale envoyée : elle doit s'afficher tout de suite.</p>`); } catch (e) { res(`<p style="color:var(--g-urg)">Impossible d'afficher une notification : ${esc(e.message)}</p>`); } };
  $("#ndpush").onclick = async () => { res(`<p class="mut">Envoi en cours…</p>`);
    try { const r = await api("push/test", { method: "POST" });
      res(`<div class="pkvs"><div class="pkv"><span>Abonnements de ton compte</span><b>${r.abonnements}</b></div><div class="pkv"><span>Notifications acceptées</span><b>${r.envoyes}</b></div>
        ${(r.details || []).map((d) => `<div class="pkv"><span>${esc(d.service)}</span><b style="color:${d.status >= 200 && d.status < 300 ? "#4ade80" : "#ff6b7d"}">${d.status || "erreur"}${d.texte ? " · " + esc(d.texte) : ""}</b></div>`).join("")}</div>
        <p class="mut" style="margin-top:8px">${r.envoyes ? "Le service de notification a accepté : le téléphone doit sonner d'ici quelques secondes (écran verrouillé compris)." : r.abonnements ? "Le service de notification a refusé : appuie sur « Réactiver l'abonnement » puis refais le test." : "Aucun téléphone abonné pour ton compte : appuie sur « Activer les notifications »."}</p>`);
    } catch (e) { res(`<p style="color:var(--g-urg)">${esc(e.message)}</p>`); } };
}

/* ================= Prise de poste SMS (PC, responsables, admin) ================= */
const cleanTel = (t) => String(t || "").replace(/[^\d+]/g, "");
async function vSms() {
  if (!staff()) return (location.hash = "#/");
  const d = await withCode(() => api("sms")); if (!d) return;
  const today = new Date().toISOString().slice(0, 10);
  // liste unique : agents avec compte + annuaire (dédoublonné par numéro)
  const seen = new Set(), all = [];
  [...d.agents.map((a) => ({ nom: a.nom, tel: cleanTel(a.tel), src: ROLE_LBL[a.role] || "" })),
   ...d.annuaire.map((a) => ({ nom: a.nom, tel: cleanTel(a.tel), src: "Annuaire" }))]
    .forEach((a) => { if (a.tel && !seen.has(a.tel)) { seen.add(a.tel); all.push(a); } });
  all.sort((a, b) => a.nom.localeCompare(b.nom));
  const demainISO = new Date(Date.now() + 864e5).toISOString().slice(0, 10), ajd = new Date().toISOString().slice(0, 10);
  const plan = await api(`planning?du=${ajd}&au=${demainISO}`).catch(() => []);
  const nbA = plan.filter((v) => v.date === ajd), nbD = plan.filter((v) => v.date === demainISO);
  view.innerHTML = `<div class="card" style="border-color:var(--red)"><h2>📅 SMS selon le planning</h2>
    <p class="mut">Chaque agent reçoit son SMS avec <b>son heure, son site et son poste</b>, tirés du planning (octobre déjà chargé), avec la mission du poste et la signature du PC.</p>
    <div class="grid2">
      <button class="btn red" data-go="${demainISO}">Demain<br><small>${nbD.length} vacation(s) · ${nbD.filter((v) => !v.rappel).length} à envoyer</small></button>
      <button class="btn" data-go="${ajd}">Aujourd'hui<br><small>${nbA.length} vacation(s) · ${nbA.filter((v) => !v.rappel).length} à envoyer</small></button>
    </div>
    <a class="btn sm" href="#/planning" style="display:block;text-align:center;text-decoration:none;margin-top:10px">Choisir un autre jour / postes et missions</a></div>
  <div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">${T("sms.titre")}</h2><button class="btn sm" id="smslock">🔒 Verrouiller</button></div><div style="height:10px"></div>
    <label>Modèle ({prenom} {nom} {date} {heure} {lieu})</label><textarea id="mod">${esc(d.modele)}</textarea>
    <div class="row"><div><label>Date</label><input type="date" id="dt" value="${today}"></div><div><label>Heure</label><input type="time" id="hr" value="07:00"></div></div>
    <label>Lieu / poste</label><input id="lieu" value="Parc Expo Valmont — PC Sécurité">
    <button class="btn sm" data-proprio id="savemod" style="margin-top:10px">💾 Enregistrer le modèle</button></div>

    <div class="card"><h2>📇 Agents (${all.length})</h2>
    <input id="q" placeholder="Rechercher un agent…">
    <div class="row" style="margin-top:10px"><button class="btn sm" id="selall">Tout cocher</button><button class="btn sm" id="selnone">Tout décocher</button></div>
    <div id="ag">${all.map((a, i) => `<div class="item" data-row="${i}" style="display:flex;gap:10px;align-items:center">
      <input type="checkbox" data-c="${i}" style="width:22px;height:22px;flex:none">
      <span style="flex:1"><b>${esc(a.nom)}</b> <span class="mut">${esc(a.src)} · ${esc(a.tel)}</span></span>
      <button class="btn sm red" data-one="${i}" style="flex:none">Envoyer</button></div>`).join("") || `<p class="mut">Aucun numéro. Ajoute-les dans l'annuaire ci-dessous.</p>`}</div>
    <button class="btn red" id="group" style="margin-top:12px">${T("sms.groupe")}</button>
    <p class="mut">Individuel = message personnalisé avec le prénom. Groupé = même message pour tous ({prenom} remplacé par « à tous »).</p></div>

    <div class="card"><h2>📒 Annuaire SMS</h2>
    <p class="mut">Agents sans compte dans l'appli. Une ligne par agent : <b>Nom Prénom ; 06 12 34 56 78</b>. Tu peux coller une colonne depuis Excel.</p>
    <textarea id="annu" style="min-height:180px">${esc(d.annuaire.map((a) => `${a.nom} ; ${a.tel}`).join("\n"))}</textarea>
    <button class="btn sm red" data-proprio="coord" id="saveannu" style="margin-top:10px">💾 Enregistrer l'annuaire</button></div>`;

  const fill = (nom) => {
    const [prenom, ...rest] = (nom || "").split(" ");
    const date = new Date($("#dt").value).toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" });
    return $("#mod").value.replaceAll("{prenom}", prenom).replaceAll("{nom}", rest.join(" ")).replaceAll("{date}", date)
      .replaceAll("{heure}", $("#hr").value.replace(":", "h")).replaceAll("{lieu}", $("#lieu").value);
  };
  const ios = /iPhone|iPad/.test(navigator.userAgent);
  const open = (tels, msg) => {
    location.href = ios ? (tels.length > 1 ? `sms:/open?addresses=${tels.join(",")}&body=${encodeURIComponent(msg)}` : `sms:${tels[0]}&body=${encodeURIComponent(msg)}`)
      : `sms:${tels.join(",")}?body=${encodeURIComponent(msg)}`;
  };
  $("#ag").onclick = (e) => {
    const b = e.target.closest("[data-one]"); if (!b) return;
    const a = all[+b.dataset.one]; open([a.tel], fill(a.nom)); b.textContent = "✓ Envoyé"; b.classList.remove("red");
  };
  $("#group").onclick = () => {
    const sel = [...view.querySelectorAll("[data-c]:checked")].map((c) => all[+c.dataset.c]);
    if (!sel.length) return toast("Coche au moins un agent");
    open(sel.map((a) => a.tel), fill("à tous"));
  };
  const vis = () => [...view.querySelectorAll("[data-row]")].filter((r) => r.style.display !== "none");
  $("#selall").onclick = () => vis().forEach((r) => (r.querySelector("[data-c]").checked = true));
  $("#selnone").onclick = () => view.querySelectorAll("[data-c]").forEach((c) => (c.checked = false));
  $("#q").oninput = (e) => { const q = e.target.value.toLowerCase(); view.querySelectorAll("[data-row]").forEach((r) => (r.style.display = r.textContent.toLowerCase().includes(q) ? "" : "none")); };
  view.querySelectorAll("[data-go]").forEach((b) => (b.onclick = () => { try { sessionStorage.setItem("ssiap-rafale", b.dataset.go); } catch {} location.hash = "#/planning"; }));
  $("#savemod").onclick = async () => { try { await api("sms", { method: "PUT", body: { modele: $("#mod").value } }); toast("Modèle enregistré"); } catch (e) { toast(e.message); } };
  $("#saveannu").onclick = async () => {
    const annuaire = $("#annu").value.split("\n").map((l) => {
      const m = l.match(/^(.*?)[;,\t]\s*([+\d][\d\s.+-]{8,})\s*$/) || l.match(/^(.*?)\s+((?:\+33|0)[\d\s.]{8,})\s*$/);
      return m ? { nom: m[1].trim(), tel: cleanTel(m[2]) } : null;
    }).filter(Boolean);
    try { await api("sms", { method: "PUT", body: { annuaire } }); toast(`${annuaire.length} numéro(s) enregistré(s)`); vSms(); } catch (e) { toast(e.message); }
  };
}

/* ================= Fiche de renseignement agent ================= */
const DIPLOMES = [
  ["SSIAP 1", "Date de recyclage"], ["SSIAP 2", "Date de recyclage"], ["SSIAP 3", "Date de recyclage"],
  ["Carte professionnelle CNAPS", "Date de fin de validité", true], ["CQP APS / TFP APS", ""],
  ["SST", "Date de fin de validité"], ["PSE 1 / PSE 2", "Date de recyclage"],
  ["Habilitation électrique H0B0", "Date de fin de validité"], ["Palpation / sûreté événementielle", ""],
];
const age = (d) => { if (!d) return ""; const b = new Date(d), n = new Date(); let a = n.getFullYear() - b.getFullYear(); if (n < new Date(n.getFullYear(), b.getMonth(), b.getDate())) a--; return a; };
async function vFiche() {
  const f = (await api("fiche").catch(() => null)) || {};
  const first = !S.user.ficheOk;
  const dip = (code) => (f.diplomes || []).find((d) => d.code === code);
  const [p0, ...n0] = (S.user.nom || "").split(" ");
  view.innerHTML = `<div class="card">
    <h2>${T("fiche.titre")}</h2>
    ${first ? `<div class="alerte orange">${T("fiche.bienvenue")}</div>` : ""}
    <form id="ff">
      <div class="row"><div><label>Nom *</label><input name="nom" required value="${esc(f.nom || n0.join(" "))}"></div>
        <div><label>Prénom *</label><input name="prenom" required value="${esc(f.prenom || p0)}"></div></div>
      <div class="row"><div><label>Date de naissance *</label><input name="naissance" type="date" required value="${esc(f.naissance || "")}"></div>
        <div><label>Âge</label><input id="age" disabled value="${f.naissance ? age(f.naissance) + " ans" : ""}"></div></div>
      <label>Adresse *</label><input name="adresse" required value="${esc(f.adresse || "")}" autocomplete="street-address">
      <div class="row"><div><label>Code postal</label><input name="cp" inputmode="numeric" value="${esc(f.cp || "")}"></div>
        <div><label>Ville</label><input name="ville" value="${esc(f.ville || "")}"></div></div>
      <div class="row"><div><label>Téléphone *</label><input name="tel" type="tel" required value="${esc(f.tel || "")}"></div>
        <div><label>E-mail *</label><input name="email" type="email" required value="${esc(f.email || "")}"></div></div>
      <h3 style="margin-top:18px">🎓 Diplômes et habilitations</h3>
      ${DIPLOMES.map(([code, lbl, num], i) => { const d = dip(code); return `<div class="item">
        <label style="display:flex;gap:10px;align-items:center;color:var(--txt);margin:0"><input type="checkbox" data-d="${i}" ${d ? "checked" : ""} style="width:22px;height:22px;flex:none"> ${code}</label>
        <div class="row ${d ? "" : "hidden"}" data-dz="${i}">
          ${num ? `<div><label>Numéro de carte</label><input data-num="${i}" value="${esc(d?.numero || "")}"></div>` : ""}
          ${lbl ? `<div><label>${lbl}</label><input type="date" data-ech="${i}" value="${esc(d?.echeance || "")}"></div>` : ""}</div></div>`; }).join("")}
      <label>Autre diplôme</label><input id="autre" value="${esc((f.diplomes || []).find((d) => d.code.startsWith("Autre : "))?.code.slice(8) || "")}">
      <label style="display:flex;gap:10px;align-items:flex-start;color:var(--txt);margin-top:16px"><input type="checkbox" name="consentement" ${f.consentement ? "checked" : ""} style="width:22px;height:22px;flex:none" required>
        <span style="font-size:.85rem">J'accepte que ces informations soient utilisées uniquement pour la gestion du personnel de sécurité (plannings, prise de poste, suivi des diplômes). Adresse, date de naissance et e-mail : visibles uniquement par les responsables et administrateurs. Le PC sécurité voit seulement mon nom, mon téléphone et mes diplômes. Je peux demander leur modification ou leur suppression à tout moment.</span></label>
      <button class="btn red" style="margin-top:14px">${first ? "Valider ma fiche" : "Mettre à jour"}</button>
    </form></div>`;
  $("[name=naissance]").oninput = (e) => ($("#age").value = e.target.value ? age(e.target.value) + " ans" : "");
  view.querySelectorAll("[data-d]").forEach((c) => (c.onchange = () => $(`[data-dz="${c.dataset.d}"]`).classList.toggle("hidden", !c.checked)));
  $("#ff").onsubmit = async (e) => {
    e.preventDefault();
    const fd = Object.fromEntries(new FormData(e.target));
    const diplomes = DIPLOMES.map(([code], i) => $(`[data-d="${i}"]`).checked ? { code, numero: $(`[data-num="${i}"]`)?.value || "", echeance: $(`[data-ech="${i}"]`)?.value || "" } : null).filter(Boolean);
    if ($("#autre").value.trim()) diplomes.push({ code: "Autre : " + $("#autre").value.trim() });
    try {
      await api("fiche", { method: "PUT", body: { ...fd, consentement: !!fd.consentement, diplomes } });
      S.user.ficheOk = true; persist(); toast("✅ Fiche enregistrée"); location.hash = "#/"; render();
    } catch (err) { toast(err.message); }
  };
}

/* ================= Fiches agents (PC = contact + diplômes, responsables/admin = tout) ================= */
async function vFiches() {
  if (!staff()) return (location.hash = "#/");
  const list = await withCode(() => api("fiches")); if (!list) return;
  const now = Date.now(), soon = now + 60 * 864e5;
  const state = (e) => !e ? "" : new Date(e) < now ? "expire" : new Date(e) < soon ? "bientot" : "ok";
  const alertes = [];
  list.forEach((u) => (u.fiche?.diplomes || []).forEach((d) => { const s = state(d.echeance); if (s === "expire" || s === "bientot") alertes.push({ u, d, s }); }));
  view.innerHTML = `
  ${alertes.length ? `<div class="card"><h2>⏰ Diplômes à renouveler (60 jours)</h2>${alertes.map(({ u, d, s }) =>
    `<div class="alerte ${s === "expire" ? "rouge" : "orange"}"><b>${esc(u.nom)}</b> — ${esc(d.code)} : ${s === "expire" ? "expiré" : "expire"} le ${new Date(d.echeance).toLocaleDateString("fr-FR")}</div>`).join("")}</div>` : ""}
  <div class="card"><h2>🪪 Fiches agents (${list.filter((u) => u.fiche).length}/${list.length} remplies)</h2>
    <input id="q" placeholder="Rechercher : nom, diplôme, ville…">
    <div id="fl" style="margin-top:8px">${list.map((u) => { const f = u.fiche; return `<details data-row><summary><span>${esc(u.nom)} <span class="mut">· ${ROLE_LBL[u.role] || ""}${f ? "" : " · fiche non remplie"}</span></span></summary><div class="c">
      ${f ? `<table>
        <tr><td>Nom</td><td><b>${esc(f.nom)} ${esc(f.prenom)}</b></td></tr>
        ${f.naissance ? `<tr><td>Naissance</td><td>${new Date(f.naissance).toLocaleDateString("fr-FR")} (${age(f.naissance)} ans)</td></tr>` : ""}
        ${f.adresse ? `<tr><td>Adresse</td><td>${esc(f.adresse)}, ${esc(f.cp)} ${esc(f.ville)}</td></tr>` : ""}
        <tr><td>Téléphone</td><td><a href="tel:${esc(cleanTel(f.tel))}">${esc(f.tel)}</a></td></tr>
        ${f.email ? `<tr><td>E-mail</td><td><a href="mailto:${esc(f.email)}">${esc(f.email)}</a></td></tr>` : ""}
        <tr><td>Diplômes</td><td>${(f.diplomes || []).map((d) => { const s = state(d.echeance); return `${s === "expire" ? "🔴" : s === "bientot" ? "🟠" : "🟢"} ${esc(d.code)}${d.numero ? " n° " + esc(d.numero) : ""}${d.echeance ? " — " + new Date(d.echeance).toLocaleDateString("fr-FR") : ""}`; }).join("<br>") || "—"}</td></tr>
        ${f.maj ? `<tr><td>Mise à jour</td><td class="mut">${fmt(f.maj)}</td></tr>` : ""}</table>` : `<p class="mut">L'agent remplira sa fiche à sa prochaine connexion.</p>`}
    </div></details>`; }).join("")}</div></div>`;
  $("#q").oninput = (e) => { const q = e.target.value.toLowerCase(); view.querySelectorAll("[data-row]").forEach((r) => (r.style.display = r.textContent.toLowerCase().includes(q) ? "" : "none")); };
}

/* ================= Administration ================= */
async function vAdmin() {
  if (!proprio()) return (location.hash = "#/");
  view.innerHTML = `
  <div class="card"><h2>👥 Comptes</h2><div id="users"></div>
    <h3 style="margin-top:14px">Ajouter / modifier</h3><form id="fu">
    <div class="row"><div><label>Adresse e-mail (identifiant)</label><input name="email" type="email" required autocapitalize="none"></div><div><label>Nom complet</label><input name="nom" required></div></div>
    <div class="row"><div><label>Rôle</label><select name="role">${Object.entries(ROLE_LBL).map(([k, v]) => `<option value="${k}">${v}</option>`).join("")}</select></div>
      <div><label>Mot de passe (facultatif)</label><input name="mdp" placeholder="vide = généré et envoyé par mail" autocomplete="new-password"></div></div>
    <label>Téléphone (pour SMS de prise de poste)</label><input name="tel" type="tel">
    <label style="display:flex;gap:10px;align-items:center;color:var(--txt);margin-top:12px"><input type="checkbox" name="horsPlanning" style="width:22px;height:22px;flex:none"> Accès hors planning (remplaçant, renfort non planifié)</label>
    <button class="btn red" style="margin-top:12px">Enregistrer le compte</button></form>
    <p class="mut">Agents ADS/SSIAP : ne voient que leurs propres signalements et rondes. PC & Admin : voient tout.</p></div>

  <div class="card"><h2>📞 Contacts d'appel (numéros cachés aux agents)</h2><div id="contacts"></div>
    <button class="btn sm" id="addc">+ Contact</button> <button class="btn sm red" id="savec">Enregistrer</button></div>

  <div class="card"><h2>📧 Liste de diffusion (alertes météo + incidents urgents)</h2><div id="dest"></div>
    <button class="btn sm" id="addd">+ Destinataire</button> <button class="btn sm red" id="saved">Enregistrer</button> <button class="btn sm" id="test">✉️ Mail de test</button></div>

  <div class="card"><h2>🔦 Points de ronde</h2><textarea id="pts" style="min-height:160px"></textarea>
    <p class="mut">Un point par ligne. Pour le scan, colle sur place un QR code contenant « SSIAPPRO: » suivi du nom exact du point.</p><button class="btn sm red" id="savep">Enregistrer</button></div>

  <div class="card"><h2>🆕 Inscription et accès des agents</h2>
    <p class="mut">Les agents (ADS, SSIAP 1-2-3) ne peuvent se connecter <b>que pendant leurs vacations au planning</b>, de 1 h avant à 1 h après. Ils sont reconnus par leur téléphone ou leur nom. Pour un remplaçant non planifié : Comptes ➜ « Accès hors planning ». Responsables, PC et admins ne sont pas concernés.</p>
    <label>Inscriptions</label><select id="imode"><option value="libre">Libres : tout le monde peut créer son compte</option><option value="code">Avec le code PIN agents</option><option value="ferme">Fermées</option></select>
    <p class="mut" id="cagetat"></p>
    <div class="row"><input id="newcag" type="password" placeholder="Code PIN agents (4 caractères min.)" autocomplete="new-password"><button class="btn sm red" id="savecag" style="flex:0 0 auto">Enregistrer</button></div></div>

  <div class="card"><h2>🗺️ Sites et zones</h2>
    <p class="mut">Utilisés pour la prise de service, la main courante, les rapports et le filtre En direct. Format : <b>## Nom du site</b> sur une ligne, puis <b>Secteur : zone 1, zone 2…</b></p>
    <textarea id="zed" style="min-height:260px;font-family:monospace;font-size:.85rem"></textarea>
    <button class="btn sm red" id="zsave" style="margin-top:8px">💾 Enregistrer les zones</button></div>

  <div class="card"><h2>🏢 Client et prestataires</h2>
    <p class="mut">Proposés dans la main courante (« Prestataire concerné ») et affichés dans le Mémo. Format : <b>Groupe : nom 1, nom 2…</b>, un groupe par ligne.</p>
    <textarea id="ped" style="min-height:120px;font-family:monospace;font-size:.85rem"></textarea>
    <button class="btn sm red" id="psave" style="margin-top:8px">💾 Enregistrer les prestataires</button></div>

  <div class="card"><h2>📤 Rédacteurs (documents PC sécurité)</h2>
    <p class="mut">Par défaut : le PC sécurité (pc@valmont.test). Lucas Fontaine (l.fontaine@valmont.test). Ces personnes ont l'accès superviseur (lecture 24h/24) <b>et</b> peuvent téléverser des PDF : plans des halls, consignes particulières, brief sécurité, feuille de route, fiche technique… Elles ne peuvent rien modifier d'autre. Une adresse par ligne.</p>
    <textarea id="redac" style="min-height:70px" placeholder="lucas.fontaine@…"></textarea>
    <button class="btn sm red" id="redacsave" style="margin-top:8px">💾 Enregistrer</button></div>

  <div class="card"><h2>Planificateurs</h2>
    <p class="mut">Accès complet à la planification (planning, devis, tarifs). Une adresse par ligne. Tant que la liste est vide, Julien Moreau et Antoine Rivière sont reconnus par leur nom. Les administrateurs y ont accès en lecture seule.</p>
    <textarea id="plmails" style="min-height:60px" placeholder="julien.moreau@…&#10;antoine.riviere@…"></textarea>
    <button class="btn sm red" id="plmailsave" style="margin-top:8px">Enregistrer</button>
    <label>Rédacteurs (saisies publiées après validation de Julien Moreau)</label><textarea id="plredac" style="min-height:60px"></textarea>
    <button class="btn sm red" id="plredacsave" style="margin-top:8px">Enregistrer les rédacteurs</button></div>

  <div class="card"><h2>🛡️ Administrateurs</h2>
    <p class="mut">Ces comptes voient et font tout dans l'appli : main courante, rapports, dossiers des agents (visite médicale comprise), DPAE, équipe Arena, numéros, mails, planning. L'écran Administration (comptes, codes, boutons) reste à toi seul. Une adresse par ligne.</p>
    <textarea id="admpc" style="min-height:70px" placeholder="pc@valmont.test"></textarea>
    <button class="btn sm red" id="admpcsave" style="margin-top:8px">💾 Enregistrer</button></div>

  <div class="card"><h2>👁️ Accès 24h/24 (lecture seule)</h2>
    <p class="mut">Les personnes dont l'adresse est ici se connectent <b>24 h / 24</b> et voient tout ce qui se passe (en direct, main courante, rapports, notifications), <b>sans rien pouvoir modifier ni saisir</b>. Elles créent leur compte avec cette adresse, ou tu le crées dans Comptes. Une adresse par ligne.</p>
    <textarea id="a24" style="min-height:120px" placeholder="julien.moreau@…&#10;lucas.fontaine@…"></textarea>
    <div class="row" style="margin-top:8px"><button class="btn sm" id="a24dest" style="flex:0 0 auto">⤵️ Reprendre la liste de diffusion</button><button class="btn sm red" id="a24save">💾 Enregistrer</button></div></div>

  <div class="card"><h2>👔 Code PIN responsables</h2>
    <p class="mut" id="cretat">…</p>
    <p class="mut">Un responsable qui s'inscrit avec <b>ce code</b> obtient directement le rôle Responsable : il voit tout en direct (🔴 En direct, main courante, rapports, fiches). Donne-le uniquement aux responsables.</p>
    <div class="row"><input id="newcr" type="password" placeholder="Code responsables (6 caractères min.)" autocomplete="new-password"><button class="btn sm red" id="savecr" style="flex:0 0 auto">Enregistrer</button></div>
    <button class="btn sm" id="closecr" style="margin-top:8px">⛔ Supprimer ce code</button></div>

  <div class="card"><h2>📧 Adresse mail du PC sécurité</h2>
    <p class="mut">Chaque main courante, prise et fin de service, DI et rapport (avec ses photos) envoyé par un agent arrive à cette adresse. Plusieurs adresses possibles, séparées par une virgule.</p>
    <div class="row"><input id="mailpc" type="email" placeholder="pc.securite@exemple.fr"><button class="btn sm red" id="savemailpc" style="flex:0 0 auto">Enregistrer</button></div></div>

  <div class="card"><h2>🔐 Code d'accès aux contacts</h2>
    <p class="mut" id="codeetat">…</p>
    <p class="mut">Demandé pour ouvrir la Prise de poste SMS, les Fiches agents et le Planning. Donne-le seulement aux personnes habilitées, et change-le si quelqu'un quitte l'équipe.</p>
    <div class="row"><input id="newcode" type="password" placeholder="Nouveau code PIN (4 caractères min.)" autocomplete="new-password"><button class="btn sm red" id="savecode" style="flex:0 0 auto">Enregistrer</button></div></div>

  <div class="card"><h2>🧑‍💻 Mode programmeur — intitulés et boutons</h2>
    <p class="mut">Change n'importe quel texte de l'appli. Vide = texte d'origine. Les modifications s'appliquent à tous les téléphones.</p>
    <input id="tq" placeholder="Filtrer : bouton, titre, accueil…" style="margin-bottom:8px">
    <div id="textes" style="max-height:480px;overflow:auto"></div>
    <div class="row" style="margin-top:10px"><button class="btn sm red" id="savet">💾 Enregistrer les intitulés</button><button class="btn sm" id="resett">↺ Tout remettre d'origine</button></div></div>

  <div class="card"><h2>🕑 Historique</h2><p class="mut">Toutes les actions (connexions, main courante, SMS, accès aux contacts, comptes…) sont dans 🔔 Notifications.</p><a class="btn" href="#/notifs" style="display:block;text-align:center;text-decoration:none">Ouvrir l'historique</a></div>`;
  view.insertAdjacentHTML("afterbegin", `<div class="card" id="sauv"><h2>Sauvegarde complète des données</h2>
    <p class="mut" style="margin-top:0">Télécharge dans un seul fichier toutes les données de l'appli : comptes, planning, main courante, rapports, rondes, clés, documents, dossiers des agents, photos, devis, tarifs et réglages. Garde ce fichier en lieu sûr : il est confidentiel (données personnelles des agents).</p>
    <button class="btn red" id="sauvgo">Télécharger la sauvegarde</button><p class="mut" id="sauvst" style="margin:8px 0 0"></p></div>`);
  $("#sauvgo").onclick = async () => { const b = $("#sauvgo"), st = $("#sauvst"); b.disabled = true;
    try { const L = await api("sauvegarde"), parts = [], n = L.cles.length; let fait = 0, err = 0;
      parts.push(`{"application":"SSIAP Pro","creePar":"Rochdi Mecheti","version":${JSON.stringify(L.version)},"date":${JSON.stringify(L.t)},"nombre":${n},"donnees":{`);
      const file = [...L.cles]; let premier = true;
      const travail = async () => { while (file.length) { const k = file.shift();
        try { const d = await api("sauvegarde/valeur?k=" + encodeURIComponent(k)); parts.push((premier ? "" : ",") + JSON.stringify(k) + ":" + JSON.stringify(d.v)); premier = false; } catch { err++; }
        fait++; st.textContent = `Téléchargement… ${fait} / ${n}`; } };
      await Promise.all([travail(), travail(), travail(), travail()]);
      parts.push("}}");
      const blob = new Blob(parts, { type: "application/json" }), a = document.createElement("a");
      a.href = URL.createObjectURL(blob); a.download = `ssiap-pro-sauvegarde-${new Date().toLocaleDateString("fr-CA")}.json`; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 60000);
      st.textContent = `Sauvegarde téléchargée : ${n - err} élément(s), ${(blob.size / 1048576).toFixed(1).replace(".", ",")} Mo${err ? ` · ${err} élément(s) illisible(s)` : ""}.`;
    } catch (e) { st.textContent = e.message; } b.disabled = false; };

  const users = async () => {
    const u = await api("admin/users");
    $("#users").innerHTML = u.map((x) => `<div class="item h" style="display:flex;justify-content:space-between;align-items:center;gap:6px">
      <span><b>${esc(x.nom)}</b> <span class="mut">${esc(x.id)} · ${ROLE_LBL[x.role]}${x.tel ? " · 📱" : ""}${x.actif === false ? " · désactivé" : ""}${x.horsPlanning ? " · 🔓 hors planning" : ""}</span></span>
      <span><button class="btn sm" data-mail="${esc(x.id)}" title="Envoyer un nouveau mot de passe">✉️</button> <button class="btn sm" data-edit='${esc(JSON.stringify(x))}'>✏️</button> <button class="btn sm" data-del="${esc(x.id)}">🗑️</button></span></div>`).join("") || `<p class="mut">Aucun compte. Crée le tien en premier (rôle Admin), avec ton adresse e-mail.</p>`;
  };
  $("#users").onclick = async (e) => {
    const ed = e.target.closest("[data-edit]"), dl = e.target.closest("[data-del]"), ml = e.target.closest("[data-mail]");
    if (ml && confirm("Générer un nouveau mot de passe et l'envoyer à " + ml.dataset.mail + " ?")) {
      try { const r = await api("admin/users/" + encodeURIComponent(ml.dataset.mail) + "/renvoyer", { method: "POST" });
        r.envoye ? toast("✉️ Mot de passe envoyé à " + ml.dataset.mail) : alert("Mail impossible (" + r.erreur + ").\nTransmets ce mot de passe en main propre : " + r.mdp); } catch (err) { toast(err.message); }
    }
    if (ed) { const x = JSON.parse(ed.dataset.edit), f = $("#fu"); const el = f.elements; el.email.value = x.id; el.nom.value = x.nom; el.role.value = x.role; el.tel.value = x.tel || ""; el.mdp.value = ""; el.horsPlanning.checked = !!x.horsPlanning; f.scrollIntoView({ behavior: "smooth" }); }
    if (dl && confirm("Supprimer le compte " + dl.dataset.del + " ?")) { await api("admin/users/" + encodeURIComponent(dl.dataset.del), { method: "DELETE" }); users(); }
  };
  $("#fu").onsubmit = async (e) => {
    e.preventDefault();
    try {
      const r = await api("admin/users", { method: "PUT", body: { ...Object.fromEntries(new FormData(e.target)), horsPlanning: e.target.elements.horsPlanning.checked } });
      if (r.envoye === true) toast("✅ Compte créé, mot de passe envoyé par mail", 4000);
      else if (r.envoye === false) alert("Compte créé, mais le mail n'est pas parti (" + r.erreur + ").\nTransmets ce mot de passe en main propre : " + r.mdp);
      else toast("Compte enregistré");
      e.target.reset(); users();
    }
    catch (err) { toast(err.message); }
  };

  const listEditor = (box, items, fields) => {
    const draw = () => { $(box).innerHTML = items.map((it, i) => `<div class="item"><div class="row">${fields.map(([k, ph, type]) =>
      `<input data-i="${i}" data-k="${k}" type="${type || "text"}" placeholder="${ph}" value="${esc(it[k] || "")}">`).join("")}
      <button class="btn sm" data-rm="${i}" style="flex:0">✕</button></div></div>`).join(""); };
    $(box).oninput = (e) => { const t = e.target; if (t.dataset.k) items[t.dataset.i][t.dataset.k] = t.value; };
    $(box).onclick = (e) => { const r = e.target.closest("[data-rm]"); if (r) { items.splice(+r.dataset.rm, 1); draw(); } };
    draw(); return draw;
  };
  const contacts = await api("admin/contacts");
  const drawC = listEditor("#contacts", contacts, [["nom", "Nom"], ["fonction", "Fonction"], ["tel", "Téléphone", "tel"]]);
  $("#addc").onclick = () => { contacts.push({ id: "c" + Date.now().toString(36), nom: "", fonction: "", tel: "" }); drawC(); };
  $("#savec").onclick = async () => { try { await api("admin/contacts", { method: "PUT", body: { items: contacts } }); toast("Contacts enregistrés"); } catch (e) { toast(e.message); } };

  const dest = await api("admin/destinataires");
  const drawD = listEditor("#dest", dest, [["nom", "Nom"], ["email", "E-mail", "email"]]);
  $("#addd").onclick = () => { dest.push({ nom: "", email: "" }); drawD(); };
  $("#saved").onclick = async () => { try { await api("admin/destinataires", { method: "PUT", body: { items: dest } }); toast("Liste enregistrée"); } catch (e) { toast(e.message); } };
  $("#test").onclick = async () => { try { const r = await api("admin/test-mail", { method: "POST" }); toast(`Mail envoyé à ${r.envoyes} destinataire(s)`); } catch (e) { toast(e.message, 5000); } };

  $("#pts").value = (await api("admin/rondes-points")).join("\n");
  $("#savep").onclick = async () => { try { await api("admin/rondes-points", { method: "PUT", body: { items: $("#pts").value.split("\n").map((s) => s.trim()).filter(Boolean) } }); toast("Points enregistrés"); } catch (e) { toast(e.message); } };

  api("zones").then((z) => ($("#zed").value = Object.entries(z).map(([site, secs]) => `## ${site}\n` + Object.entries(secs).map(([sec, zs]) => `${sec} : ${zs.join(", ")}`).join("\n")).join("\n\n"))).catch(() => {});
  $("#zsave").onclick = async () => {
    const zones = {}; let site = null;
    for (const l of $("#zed").value.split("\n")) {
      const t = l.trim(); if (!t) continue;
      if (t.startsWith("##")) { site = t.replace(/^#+/, "").trim(); zones[site] = {}; continue; }
      const i = t.indexOf(":"); if (!site || i < 0) continue;
      zones[site][t.slice(0, i).trim()] = t.slice(i + 1).split(",").map((x) => x.trim()).filter(Boolean);
    }
    if (!Object.keys(zones).length) return toast("Aucun site trouvé");
    try { await api("admin/zones", { method: "PUT", body: { zones } }); ZONES = null; toast("✅ Zones enregistrées"); } catch (e) { toast(e.message); }
  };
  api("prestataires").then((z) => ($("#ped").value = Object.entries(z).map(([g, l]) => `${g} : ${l.join(", ")}`).join("\n"))).catch(() => {});
  $("#psave").onclick = async () => {
    const prestataires = {};
    for (const l of $("#ped").value.split("\n")) { const i = l.indexOf(":"); if (i < 0) continue; prestataires[l.slice(0, i).trim()] = l.slice(i + 1).split(",").map((x) => x.trim()).filter(Boolean); }
    if (!Object.keys(prestataires).length) return toast("Aucun groupe trouvé");
    try { await api("admin/prestataires", { method: "PUT", body: { prestataires } }); PRESTA = null; toast("✅ Prestataires enregistrés"); } catch (e) { toast(e.message); }
  };
  api("admin/redacteurs").then((d) => ($("#redac").value = (d.emails || []).join("\n"))).catch(() => {});
  $("#redacsave").onclick = async () => { try { const r = await api("admin/redacteurs", { method: "PUT", body: { emails: $("#redac").value.split(/[\s,;]+/).filter(Boolean) } }); toast(`✅ ${r.nb} rédacteur(s)`); } catch (e) { toast(e.message); } };
  api("planif/redacteurs").then((d) => ($("#plredac").value = (d.emails || []).join("\n"))).catch(() => {});
  $("#plredacsave").onclick = async () => { try { const r = await api("planif/redacteurs", { method: "PUT", body: { emails: $("#plredac").value.split(/[\s,;]+/).filter(Boolean) } }); toast(`${r.nb} rédacteur(s)`); } catch (e) { toast(e.message); } };
  api("planif/planificateurs").then((d) => ($("#plmails").value = (d.emails || []).join("\n"))).catch(() => {});
  $("#plmailsave").onclick = async () => { try { const r = await api("planif/planificateurs", { method: "PUT", body: { emails: $("#plmails").value.split(/[\s,;]+/).filter(Boolean) } }); toast(`${r.nb} planificateur(s)`); } catch (e) { toast(e.message); } };
  api("admin/admins-pc").then((d) => ($("#admpc").value = (d.emails || []).join("\n"))).catch(() => {});
  $("#admpcsave").onclick = async () => { try { const r = await api("admin/admins-pc", { method: "PUT", body: { emails: $("#admpc").value.split(/[\s,;]+/).filter(Boolean) } }); toast(`✅ ${r.nb} administrateur(s)`); } catch (e) { toast(e.message); } };
  api("admin/acces24").then((d) => ($("#a24").value = (d.emails || []).join("\n"))).catch(() => {});
  $("#a24dest").onclick = async () => { const d = await api("admin/destinataires"); const cur = new Set($("#a24").value.split(/\s+/).filter(Boolean)); d.forEach((x) => x.email && x.email !== "mr.mecheti@gmail.com" && cur.add(x.email)); $("#a24").value = [...cur].join("\n"); };
  $("#a24save").onclick = async () => { try { const r = await api("admin/acces24", { method: "PUT", body: { emails: $("#a24").value.split(/[\s,;]+/).filter(Boolean) } }); toast(`✅ ${r.nb} personne(s) en accès 24h/24`); } catch (e) { toast(e.message); } };
  const crEtat = () => api("admin/code-resp").then((c) => ($("#cretat").textContent = c.defini ? "✅ Code responsables défini" : "Aucun code responsables.")).catch(() => {});
  crEtat();
  $("#savecr").onclick = async () => { try { await api("admin/code-resp", { method: "PUT", body: { code: $("#newcr").value } }); $("#newcr").value = ""; toast("Code responsables enregistré"); crEtat(); } catch (e) { toast(e.message); } };
  $("#closecr").onclick = async () => { if (!confirm("Supprimer le code responsables ?")) return; await api("admin/code-resp", { method: "PUT", body: { fermer: true } }); crEtat(); };
  api("admin/mail-pc").then((d) => ($("#mailpc").value = d.email || "")).catch(() => {});
  $("#savemailpc").onclick = async () => { try { await api("admin/mail-pc", { method: "PUT", body: { email: $("#mailpc").value } }); toast("Adresse du PC enregistrée"); } catch (e) { toast(e.message); } };
  const cagEtat = () => api("admin/code-agents").then((c) => { $("#imode").value = c.mode || "libre"; $("#cagetat").textContent = c.defini ? "Code PIN agents : défini" : "Code PIN agents : aucun"; }).catch(() => {});
  cagEtat();
  $("#imode").onchange = async () => { try { await api("admin/inscription-mode", { method: "PUT", body: { mode: $("#imode").value } }); toast("Réglage des inscriptions enregistré"); } catch (e) { toast(e.message); } };
  $("#savecag").onclick = async () => { try { await api("admin/code-agents", { method: "PUT", body: { code: $("#newcag").value } }); $("#newcag").value = ""; toast("Code PIN agents enregistré"); cagEtat(); } catch (e) { toast(e.message); } };
  api("admin/code-contacts").then((c) => ($("#codeetat").textContent = c.defini ? "✅ Code défini" : "⚠️ Aucun code défini : les contacts sont inaccessibles tant que tu n'en mets pas un.")).catch(() => {});
  $("#savecode").onclick = async () => { try { await api("admin/code-contacts", { method: "PUT", body: { code: $("#newcode").value } }); $("#newcode").value = ""; CONTACTS = null; $("#codeetat").textContent = "✅ Code défini"; toast("Code enregistré"); } catch (e) { toast(e.message); } };
  const TX = window.TEXTES_DEFAUT;
  $("#textes").innerHTML = Object.keys(TX).map((k) => `<div class="item" data-tk="${k}"><label style="margin:0 0 4px">${k}</label>
    <input data-t="${k}" value="${esc(CUSTOM[k] ?? "")}" placeholder="${esc(TX[k])}"></div>`).join("");
  $("#tq").oninput = (e) => { const q = e.target.value.toLowerCase(); view.querySelectorAll("[data-tk]").forEach((r) => (r.style.display = (r.dataset.tk + r.querySelector("input").placeholder + r.querySelector("input").value).toLowerCase().includes(q) ? "" : "none")); };
  $("#savet").onclick = async () => {
    const textes = {}; view.querySelectorAll("[data-t]").forEach((i) => { if (i.value.trim()) textes[i.dataset.t] = i.value.trim(); });
    try { await api("admin/textes", { method: "PUT", body: { textes } }); CUSTOM = textes; try { localStorage.setItem("ssiap-textes", JSON.stringify(textes)); } catch {} toast("✅ Intitulés enregistrés"); applyChrome(); }
    catch (e) { toast(e.message); }
  };
  $("#resett").onclick = async () => { if (!confirm("Remettre tous les textes d'origine ?")) return; view.querySelectorAll("[data-t]").forEach((i) => (i.value = "")); $("#savet").click(); };

  users();
}

/* ================= Rapports terrain : DI, malaise, incident, rixe, intrusion… ================= */
// Catalogue des rapports : public/rapports-types.js (partagé avec le serveur)
const RAP_TYPES = window.RAP_CATS.flatMap((c) => c.types.map((t) => [t.k, t.ic, t.lb, t.champs, c.cat]));
const INTERV = ["Pompiers (18)", "SAMU (15)", "Police (17)", "Poste de secours", "Responsable sécurité", "Organisateur", "Technique / maintenance"];
const RT = (k) => RAP_TYPES.find((x) => x[0] === k) || RAP_TYPES[RAP_TYPES.length - 1];
function ouvrirRapport(k) { try { sessionStorage.setItem("ssiap-rap", k); } catch {} location.hash = "#/rap"; }
async function vRap() {
  await chargerZones(); await chargerPresta();
  let kind = null; try { kind = sessionStorage.getItem("ssiap-rap"); sessionStorage.removeItem("ssiap-rap"); } catch {}
  if (location.hash === "#/di") kind = "di";
  const peut = !lecture();
  view.innerHTML = `${peut ? `<div class="card" style="border-color:var(--red)"><h2>📋 Faire un rapport</h2>
    <p class="mut" style="margin-top:0">Choisis le type. Dès que tu valides, le rapport est enregistré pour les responsables, noté en main courante et envoyé par mail au PC sécurité avec les photos, ton nom et ton poste du planning.</p>
    <input id="rq" placeholder="🔎 Chercher un type : feu, vol, ascenseur, clés…" style="margin-bottom:6px">
    <div id="rtypes">${window.RAP_CATS.map((c) => `<div class="rcat"><h3 style="margin:12px 0 6px;font-size:.95rem">${c.cat}</h3><div class="tiles" style="grid-template-columns:repeat(3,1fr)">${c.types.map((t) => `<a class="tile" role="button" tabindex="0" data-k="${t.k}" data-s="${esc((t.lb + " " + c.cat).toLowerCase())}" style="font-size:.74rem;padding:9px 3px;line-height:1.15"><span>${t.ic}</span>${esc(t.lb.replace("DI – défaut technique / anomalie", "DI technique"))}</a>`).join("")}</div></div>`).join("")}</div>
    <div id="rform"></div></div>` : ""}
    <div class="card"><h2>${staff() ? "🗂️ Tous les rapports" : "🗂️ Mes rapports"}</h2>
      ${staff() ? `<div class="row" style="margin-bottom:8px"><select id="rfk"><option value="">Tous les types</option>${window.RAP_CATS.map((c) => `<optgroup label="${c.cat}">${c.types.map((t) => `<option value="${t.k}">${t.ic} ${esc(t.lb)}</option>`).join("")}</optgroup>`).join("")}</select>
        <select id="rfs" style="flex:0 0 130px"><option value="ouverts">Non clos</option><option value="">Tous</option></select></div>` : ""}
      <div id="rlist"><p class="mut">Chargement…</p></div></div>`;
  const form = (k) => {
    const [, ic, lb, champs] = RT(k);
    view.querySelectorAll("#rtypes .tile").forEach((t) => (t.style.borderColor = t.dataset.k === k ? "var(--red)" : ""));
    let photos = [], gps = null, urg = "normale";
    $("#rform").innerHTML = `<form id="frap" style="margin-top:14px"><h3 style="margin:0 0 4px">${ic} ${lb}</h3>
      <div class="row"><div><label>Heure du fait</label><input type="datetime-local" name="heure" value="${nowLocal()}"></div></div>
      <label>Urgence</label><div class="seg" id="rurg"><button type="button" data-u="normale" class="on">Normale</button><button type="button" data-u="urgente">🚨 Urgente</button></div>
      ${htmlLieu("rpz")}
      ${champs.map(([n, ty, o], i) => ty === "s" ? `<label>${n}</label><select data-d="${esc(n)}"><option value="">—</option>${o.map((x) => `<option>${esc(x)}</option>`).join("")}</select>`
        : ty === "c" ? `<label>${n}</label><div class="chips" data-dc="${esc(n)}" style="display:flex;flex-wrap:wrap;gap:6px">${o.map((x) => `<label class="chip" style="display:flex;gap:6px;align-items:center;border:1px solid var(--line);border-radius:20px;padding:6px 10px;margin:0;color:var(--txt)"><input type="checkbox" value="${esc(x)}" style="width:18px;height:18px">${esc(x)}</label>`).join("")}</div>`
        : ty === "h" ? `<label>${n}</label><input type="time" data-d="${esc(n)}">`
        : `<label>${n}</label><input data-d="${esc(n)}">`).join("")}
      <label>${k === "di" ? "Constat" : "Déroulé des faits"}</label><textarea name="texte" required placeholder="Uniquement des faits : qui, quoi, où, comment, dans l'ordre."></textarea>
      <label>Mesures prises</label><input name="securise" placeholder="ex. zone balisée, personne mise à l'écart, PC prévenu…">
      <label>Intervenants</label><div style="display:flex;flex-wrap:wrap;gap:6px" id="rint">${INTERV.map((x) => `<label style="display:flex;gap:6px;align-items:center;border:1px solid var(--line);border-radius:20px;padding:6px 10px;margin:0;color:var(--txt)"><input type="checkbox" value="${esc(x)}" style="width:18px;height:18px">${esc(x)}</label>`).join("")}</div>
      ${["di", "degradation", "incident", "alarme", "ssi", "coupure", "eau", "porte", "radio", "prestataire", "travaux", "extincteur", "issue", "ascenseur", "permisfeu", "isolement"].includes(k) ? `<label>Prestataire concerné (facultatif)</label><select name="prestataire"><option value="">— Je ne sais pas —</option>
        ${Object.entries(prestaSeuls()).map(([g, l]) => `<optgroup label="${esc(g)}">${l.map((x) => `<option>${esc(x)}</option>`).join("")}</optgroup>`).join("")}</select>` : ""}
      <div class="row" style="margin-top:12px">
        <label class="btn red" style="margin:0;text-align:center">📷 Photo<input type="file" accept="image/*" capture="environment" id="rph2" hidden></label>
        <button type="button" class="btn" id="rgeo2">📍 Position</button></div>
      <div id="rprev2" style="display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:8px"></div><p id="rgps2" class="mut"></p>
      <button class="btn ok" style="margin-top:10px">✅ OK — envoyer au PC</button>
      <p class="mut">4 photos maximum. Ton nom, ton poste du planning, le numéro, la date et l'heure sont ajoutés automatiquement.</p></form>`;
    brancherLieu("rpz");
    if (k === "di") {
      const box = document.createElement("div"); box.id = "spiebox"; box.className = "alerte"; box.style.marginTop = "10px";
      const rowSite = $("#rpz-site").closest(".row"); if (rowSite) rowSite.after(box); else $("#frap").prepend(box);
      const majSpie = () => { const arena = /arena/i.test($("#rpz-site").value), ref = arena ? "VA site : ARN-0002" : "PEX site : PEX-0001";
        box.innerHTML = `<b>📞 Astreinte Elektra — défaut technique</b><br>Référence à rappeler : <b style="color:var(--red2)">${ref}</b> (${arena ? "Arena" : "Parc Expo Valmont"})
          <br><span class="mut">Ascenseur : indiquer le n° de l'appareil noté dans la cabine.</span>
          <div class="row" style="margin-top:8px"><a class="btn sm red" href="tel:0465710099">📞 Appeler l'astreinte Elektra</a><button type="button" class="btn sm" id="spieref">📋 Mettre la référence</button></div>`;
        $("#spieref").onclick = () => { const f = $('#frap [data-d="Référence Elektra communiquée"]'); if (f) { f.value = ref.split(": ")[1]; toast("Référence ajoutée au rapport"); } }; };
      $("#rpz-site").addEventListener("change", majSpie); majSpie();
      const sp = $('#frap [data-d="Intervention Elektra"]'); if (sp) sp.onchange = () => { if (/^Urgent/.test(sp.value)) { urg = "urgente"; [...$("#rurg").children].forEach((x) => x.classList.toggle("on", x.dataset.u === "urgente")); } };
    }
    $("#rurg").onclick = (e) => { const b = e.target.closest("button"); if (!b) return; urg = b.dataset.u; [...$("#rurg").children].forEach((x) => x.classList.toggle("on", x === b)); };
    const prev = () => ($("#rprev2").innerHTML = photos.map((p, i) => `<div style="position:relative"><img src="${p}" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:8px"><button type="button" data-rm="${i}" style="position:absolute;top:2px;right:2px;border:0;border-radius:50%;width:22px;height:22px">✕</button></div>`).join(""));
    $("#rph2").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; if (photos.length >= 4) return toast("4 photos maximum"); photos.push(await compress(f)); e.target.value = ""; prev(); };
    $("#rprev2").onclick = (e) => { const b = e.target.closest("[data-rm]"); if (b) { photos.splice(+b.dataset.rm, 1); prev(); } };
    $("#rgeo2").onclick = () => navigator.geolocation?.getCurrentPosition((p) => { gps = { lat: p.coords.latitude, lon: p.coords.longitude }; $("#rgps2").textContent = "📍 Position ajoutée"; }, () => toast("Position indisponible"), { enableHighAccuracy: true, timeout: 10000 });
    $("#frap").onsubmit = async (e) => {
      e.preventDefault(); const btn = e.submitter;
      const L = lireLieu("rpz"); if (!L.lieu) return toast("Choisis la zone");
      if (k === "di" && !photos.length && !confirm("Aucune photo. Envoyer quand même ?")) return;
      const details = {};
      $("#frap").querySelectorAll("[data-d]").forEach((x) => x.value && (details[x.dataset.d] = x.value));
      $("#frap").querySelectorAll("[data-dc]").forEach((g) => { const v = [...g.querySelectorAll("input:checked")].map((c) => c.value); if (v.length) details[g.dataset.dc] = v; });
      const intervenants = [...$("#rint").querySelectorAll("input:checked")].map((c) => c.value);
      btn.disabled = true;
      try { const d = await api("rap", { method: "POST", body: { ...Object.fromEntries(new FormData(e.target)), ...L, kind: k, urgence: urg, details, intervenants, photos, gps } });
        toast(`✅ ${d.numero} envoyé au PC`); vRap(); }
      catch (err) { toast(err.message); btn.disabled = false; }
    };
    $("#frap").scrollIntoView({ behavior: "smooth", block: "start" });
  };
  if (peut) {
    $("#rtypes").onclick = (e) => { const t = e.target.closest("[data-k]"); if (t) form(t.dataset.k); };
    $("#rq").oninput = (e) => { const q = e.target.value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      view.querySelectorAll("#rtypes .tile").forEach((t) => (t.style.display = !q || t.dataset.s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").includes(q) ? "" : "none"));
      view.querySelectorAll("#rtypes .rcat").forEach((c) => (c.style.display = [...c.querySelectorAll(".tile")].some((t) => t.style.display !== "none") ? "" : "none")); };
    if (kind) form(kind);
  }
  let list = [];
  const draw = () => {
    const fk = $("#rfk")?.value || "", fs = $("#rfs") ? $("#rfs").value : "";
    const l = list.filter((d) => (!fk || d.kind === fk) && (fs !== "ouverts" || d.statut !== "clos"));
    $("#rlist").innerHTML = l.length ? l.map((d) => `<div class="item" style="border-left:3px solid ${d.statut === "clos" ? "var(--ok)" : d.urgence === "urgente" ? "var(--red)" : "orange"}">
      <div class="h"><b>${RT(d.kind)[1]} ${esc(d.numero)} · ${esc(d.label || RT(d.kind)[2])}</b><span class="badge ${d.statut === "clos" ? "clos" : d.statut === "en cours" ? "encours" : "ouvert"}">${esc(d.statut)}</span></div>
      <div class="mut">${fmt(d.heure || d.t)} · ${esc(d.lieu)}${d.site ? " (" + esc(siteCourt(d.site)) + ")" : ""}${staff() ? " · " + esc(d.auteur) : ""}${d.poste ? " · poste : " + esc(d.poste) : ""}${d.urgence === "urgente" ? " · 🚨 urgente" : ""}${d.gps ? ` · <a target="_blank" rel="noopener" href="https://maps.google.com/?q=${d.gps.lat},${d.gps.lon}">carte</a>` : ""}</div>
      ${Object.entries(d.details || {}).map(([k, v]) => `<div class="mut">• ${esc(k)} : <b>${esc(v)}</b></div>`).join("")}
      <div style="white-space:pre-wrap;margin-top:4px">${esc(d.texte)}</div>
      ${d.securise ? `<div class="mut">🛡️ ${esc(d.securise)}</div>` : ""}${d.intervenants ? `<div class="mut">👥 ${esc(d.intervenants)}</div>` : ""}${d.prestataire ? `<div class="mut">🏢 Prestataire : <b>${esc(d.prestataire)}</b></div>` : ""}
      ${d.photos ? `<button class="btn sm" data-dp="${d.id}" data-n="${d.photos}" style="margin-top:6px">📷 Voir ${d.photos} photo(s)</button>` : ""}
      ${(d.suivi || []).map((s) => `<div class="mut" style="margin-top:4px">↳ ${fmt(s.t)} ${esc(s.qui)} : ${esc(s.note)}</div>`).join("")}
      ${staff() && !lecture() && d.statut !== "clos" ? `<div class="row" style="margin-top:8px">${d.statut === "ouvert" ? `<button class="btn sm" data-st="en cours" data-id="${d.id}">⏳ En cours</button>` : ""}<button class="btn sm ok" data-st="clos" data-id="${d.id}">✅ Traité / clos</button></div>` : ""}</div>`).join("")
      : `<p class="mut">Aucun rapport.</p>`;
  };
  if ($("#rfk")) { $("#rfk").onchange = draw; $("#rfs").onchange = draw; }
  $("#rlist").onclick = async (e) => {
    const st = e.target.closest("[data-st]");
    if (st) { const note = st.dataset.st === "clos" ? prompt("Commentaire (facultatif) : suite donnée, qui est intervenu…", "") : ""; if (note === null) return;
      try { const d = await api("rap/" + st.dataset.id, { method: "PATCH", body: { statut: st.dataset.st, note } }); list = list.map((x) => (x.id === d.id ? d : x)); draw(); toast("Rapport mis à jour"); } catch (err) { toast(err.message); } return; }
    const b = e.target.closest("[data-dp]"); if (!b) return;
    const box = document.createElement("div"); box.style.cssText = "display:grid;grid-template-columns:repeat(2,1fr);gap:6px;margin-top:6px";
    for (let i = 0; i < +b.dataset.n; i++) { try { const p = await api(`photo/${b.dataset.dp}-${i}`); const im = new Image(); im.src = p.d; im.className = "thumb"; box.appendChild(im); } catch {} }
    b.replaceWith(box);
  };
  try { list = await api("rap"); draw(); } catch (e) { $("#rlist").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}

/* ================= Mon planning (chaque agent voit uniquement ses vacations) ================= */
function htmlMonPlanning(list) {
  if (!list || !list.length) return `<p class="mut">Aucune vacation à venir à ton nom au planning. Si c'est une erreur, contacte le PC sécurité (04 65 71 00 00).</p>`;
  const auj = new Date().toLocaleDateString("fr-CA");
  return list.map((v) => `<div class="item" style="${v.date === auj ? "border-left:3px solid var(--red)" : ""}">
    <div class="h"><b>${new Date(v.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })}${v.date === auj ? " · aujourd'hui" : ""}</b><span><b>${esc(v.debut)} – ${esc(v.fin)}</b></span></div>
    <div class="mut">${[v.poste, v.evenement, v.site].filter(Boolean).map(esc).join(" · ")}</div></div>`).join("");
}
async function vMonPlanning() {
  view.innerHTML = `<div class="card"><h2>📅 Mon planning</h2><p class="mut" style="margin-top:0">Tes vacations à venir.</p>${staff() ? `<a class="btn sm" href="#/plangen" style="margin-bottom:8px">🗓️ Planning général</a>` : ""}<div id="mp"><p class="mut">Chargement…</p></div></div>`;
  try { $("#mp").innerHTML = htmlMonPlanning(await api("monplanning")); } catch (e) { $("#mp").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}

/* ================= Documents PC sécurité (lecture pour tous, téléversement : responsable PC + propriétaire) ================= */
const CATS_DOC = ["Plan des halls / du site", "Consignes particulières", "Brief sécurité", "Feuille de route", "Fiche technique", "Note de service", "Autre"];
async function voirDoc(doc) {
  const ov = document.createElement("div");
  ov.style.cssText = "position:fixed;inset:0;background:#0b0e13;z-index:200;overflow:auto;padding:10px 10px 80px";
  ov.innerHTML = `<div style="position:sticky;top:0;display:flex;gap:8px;align-items:center;background:#0b0e13;padding:6px 0;z-index:1">
    <b style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(doc.titre)}</b><a class="btn sm" id="dl" style="flex:0 0 auto">⬇️</a><button class="btn sm red" id="cl" style="flex:0 0 auto">✕ Fermer</button></div>
    <div id="pages"><p class="mut">Chargement du document…</p></div>`;
  document.body.appendChild(ov);
  ov.querySelector("#cl").onclick = () => ov.remove();
  try {
    const f = await api(doc.src || "docs/" + doc.id);
    const dl = ov.querySelector("#dl"); dl.href = f.d; dl.download = f.nom || doc.titre + (f.type === "application/pdf" ? ".pdf" : ".jpg");
    const box = ov.querySelector("#pages");
    if (f.type !== "application/pdf") { box.innerHTML = `<img src="${f.d}" style="width:100%;border-radius:8px">`; return; }
    const pdfjs = await import(new URL("vendor/pdfjs/pdf.min.mjs", location.href).href);
    pdfjs.GlobalWorkerOptions.workerSrc = new URL("vendor/pdfjs/pdf.worker.min.mjs", location.href).href;
    const bin = atob(f.d.split(",")[1]), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
    const pdf = await pdfjs.getDocument({ data: u8 }).promise;
    box.innerHTML = `<p class="mut">${pdf.numPages} page(s) · pince pour zoomer</p>`;
    for (let n = 1; n <= pdf.numPages; n++) {
      if (!document.body.contains(ov)) break;
      const page = await pdf.getPage(n), w = Math.min(box.clientWidth || 360, 1100), v0 = page.getViewport({ scale: 1 });
      const vp = page.getViewport({ scale: (w / v0.width) * Math.min(2, window.devicePixelRatio || 1) });
      const c = document.createElement("canvas"); c.width = vp.width; c.height = vp.height; c.style.cssText = "width:100%;background:#fff;border-radius:6px;margin-bottom:8px";
      box.appendChild(c); await page.render({ canvasContext: c.getContext("2d"), viewport: vp }).promise;
    }
  } catch (e) { ov.querySelector("#pages").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}
async function vDocs() {
  const redac = !!S.user.redac;
  view.innerHTML = `${redac ? `<div class="card" style="border-color:var(--red)"><h2>📤 Téléverser un document</h2><form id="fdoc">
      <label>Fichier (PDF, JPG ou PNG — 4 Mo max.)</label><input type="file" id="dfile" accept="application/pdf,image/jpeg,image/png" required>
      <label>Titre</label><input name="titre" placeholder="ex. Plan hall B5 — salon de l'habitat" required>
      <div class="row"><div><label>Catégorie</label><select name="categorie">${CATS_DOC.map((c) => `<option>${c}</option>`).join("")}</select></div>
        <div><label>Site</label><select name="site"><option value="">Parc et Arena</option><option>Parc Expo Valmont</option><option>Valmont Arena</option></select></div></div>
      <div class="row"><div><label>Événement (facultatif)</label><input name="evenement"></div><div><label>Date (facultatif)</label><input type="date" name="date"></div></div>
      <button class="btn red" style="margin-top:12px">📤 Mettre en ligne</button>
      <p class="mut">Visible tout de suite par les agents et les responsables, sans possibilité de le modifier.</p></form></div>` : ""}
    <div class="card"><h2>📂 Documents PC sécurité</h2>
      <div class="row"><input id="dq" placeholder="Rechercher…"><select id="dc" style="flex:0 0 150px"><option value="">Toutes catégories</option>${CATS_DOC.map((c) => `<option>${c}</option>`).join("")}</select></div>
      <div id="dlist" style="margin-top:8px"><p class="mut">Chargement…</p></div></div>`;
  let docs = [];
  const draw = () => {
    const q = $("#dq").value.toLowerCase(), c = $("#dc").value;
    const l = docs.filter((d) => (!c || d.categorie === c) && (!q || [d.titre, d.evenement, d.site, d.categorie].join(" ").toLowerCase().includes(q)));
    $("#dlist").innerHTML = l.length ? l.map((d) => `<div class="item"><div class="h"><b>${d.type === "application/pdf" ? "📄" : "🖼️"} ${esc(d.titre)}</b><span class="mut">${(d.taille / 1e6).toFixed(1)} Mo</span></div>
      <div class="mut">${[d.categorie, d.site || "Parc et Arena", d.evenement, d.date && new Date(d.date + "T12:00:00").toLocaleDateString("fr-FR")].filter(Boolean).map(esc).join(" · ")}</div>
      <div class="mut">Mis en ligne le ${fmt(d.t)} par ${esc(d.par)}</div>
      <div class="row" style="margin-top:8px"><button class="btn sm" data-voir="${d.id}">👁️ Ouvrir</button>${redac ? `<button class="btn sm" data-sup="${d.id}" style="flex:0 0 auto">🗑️</button>` : ""}</div></div>`).join("")
      : `<p class="mut">Aucun document pour le moment.</p>`;
  };
  $("#dq").oninput = draw; $("#dc").onchange = draw;
  $("#dlist").onclick = async (e) => {
    const v = e.target.closest("[data-voir]"); if (v) return voirDoc(docs.find((d) => d.id === v.dataset.voir));
    const s = e.target.closest("[data-sup]"); if (!s || !confirm("Supprimer ce document ?")) return;
    try { await api("docs/" + s.dataset.sup, { method: "DELETE" }); docs = docs.filter((d) => d.id !== s.dataset.sup); draw(); toast("Document supprimé"); } catch (err) { toast(err.message); }
  };
  if (redac) $("#fdoc").onsubmit = async (e) => {
    e.preventDefault(); const btn = e.submitter, f = $("#dfile").files[0]; if (!f) return;
    if (f.size > 4.1e6) return toast("Fichier trop lourd (4 Mo maximum)", 4000);
    btn.disabled = true; btn.textContent = "Envoi en cours…";
    try { const d = await api("docs", { method: "POST", body: { ...Object.fromEntries(new FormData(e.target)), nom: f.name, data: await lireFichier(f) } }); toast("✅ Document en ligne"); docs.unshift(d); e.target.reset(); draw(); }
    catch (err) { toast(err.message, 4000); }
    btn.disabled = false; btn.textContent = "📤 Mettre en ligne";
  };
  try { docs = await api("docs"); draw(); } catch (e) { $("#dlist").innerHTML = `<p class="mut">${esc(e.message)}</p>`; }
}

/* ================= Coordination PC (Lucas Fontaine) : numéros, adresses mail, planning ================= */
async function vCoord() {
  if (!coord()) return (location.hash = "#/");
  view.innerHTML = `<div class="card"><h2>🗂️ Coordination PC sécurité</h2>
    <p class="mut" style="margin-top:0">Tu peux gérer les numéros, les adresses mail et le planning. Tout le reste (boutons, textes, zones, comptes) reste réservé au propriétaire.</p>
    <div class="grid2"><a class="btn" href="#/planning">🗓️ Planning (import Comète)</a><a class="btn" href="#/sms">📒 Numéros des agents</a><a class="btn" href="#/risques">⚠️ Évaluation des risques</a></div></div>
  <div class="card"><h2>📞 Numéros d'appel rapide</h2><p class="mut">Les numéros ne sont jamais affichés aux agents : ils servent seulement au bouton d'appel.</p>
    <div id="ccontacts"></div><div class="row" style="margin-top:8px"><button class="btn sm" id="caddc">＋ Ajouter</button><button class="btn sm red" id="csavec">💾 Enregistrer</button></div></div>
  <div class="card"><h2>📧 Adresse mail du PC</h2><p class="mut">Reçoit tous les rapports, la main courante et les photos.</p>
    <div class="row"><input id="cmailpc" type="text" inputmode="email"><button class="btn sm red" id="csavepc" style="flex:0 0 auto">💾</button></div></div>
  <div class="card"><h2>📨 Liste de diffusion (alertes météo, urgences)</h2><div id="cdest"></div>
    <div class="row" style="margin-top:8px"><button class="btn sm" id="caddd">＋ Ajouter</button><button class="btn sm red" id="csaved">💾 Enregistrer</button><button class="btn sm" id="ctest">✉️ Test</button></div></div>
  <div class="card"><h2>👁️ Accès 24h/24 (lecture seule)</h2><p class="mut">Une adresse par ligne. Ces personnes voient tout sans rien pouvoir modifier.</p>
    <textarea id="ca24" style="min-height:110px"></textarea><button class="btn sm red" id="csavea24" style="margin-top:8px">💾 Enregistrer</button></div>`;
  const editeur = (box, items, fields) => {
    const draw = () => { $(box).innerHTML = items.map((it, i) => `<div class="item"><div class="row">${fields.map(([k, ph, type]) =>
      `<input data-i="${i}" data-k="${k}" type="${type || "text"}" placeholder="${ph}" value="${esc(it[k] || "")}">`).join("")}<button class="btn sm" data-rm="${i}" style="flex:0">✕</button></div></div>`).join(""); };
    $(box).oninput = (e) => { const t = e.target; if (t.dataset.k) items[t.dataset.i][t.dataset.k] = t.value; };
    $(box).onclick = (e) => { const r = e.target.closest("[data-rm]"); if (r) { items.splice(+r.dataset.rm, 1); draw(); } };
    draw(); return draw;
  };
  try {
    const contacts = await api("admin/contacts"), dc = editeur("#ccontacts", contacts, [["nom", "Nom"], ["fonction", "Fonction"], ["tel", "Téléphone", "tel"]]);
    $("#caddc").onclick = () => { contacts.push({ id: "c" + Date.now().toString(36), nom: "", fonction: "", tel: "" }); dc(); };
    $("#csavec").onclick = async () => { try { await api("admin/contacts", { method: "PUT", body: { items: contacts } }); toast("✅ Numéros enregistrés"); } catch (e) { toast(e.message); } };
    const dest = await api("admin/destinataires"), dd = editeur("#cdest", dest, [["nom", "Nom"], ["email", "E-mail", "email"]]);
    $("#caddd").onclick = () => { dest.push({ nom: "", email: "" }); dd(); };
    $("#csaved").onclick = async () => { try { await api("admin/destinataires", { method: "PUT", body: { items: dest } }); toast("✅ Liste enregistrée"); } catch (e) { toast(e.message); } };
    $("#ctest").onclick = async () => { try { const r = await api("admin/test-mail", { method: "POST" }); toast(`Mail envoyé à ${r.envoyes} destinataire(s)`); } catch (e) { toast(e.message, 5000); } };
    $("#cmailpc").value = (await api("admin/mail-pc")).email || "";
    $("#csavepc").onclick = async () => { try { await api("admin/mail-pc", { method: "PUT", body: { email: $("#cmailpc").value } }); toast("✅ Adresse du PC enregistrée"); } catch (e) { toast(e.message); } };
    $("#ca24").value = ((await api("admin/acces24")).emails || []).join("\n");
    $("#csavea24").onclick = async () => { try { const r = await api("admin/acces24", { method: "PUT", body: { emails: $("#ca24").value.split(/[\s,;]+/).filter(Boolean) } }); toast(`✅ ${r.nb} personne(s) en accès 24h/24`); } catch (e) { toast(e.message); } };
  } catch (e) { toast(e.message); }
}

/* ================= Évaluation des risques (rédaction : propriétaire + coordinateur PC) ================= */
const CRIT = (c) => (c >= 12 ? ["Critique", "var(--rouge)", "#fff"] : c >= 8 ? ["Élevé", "var(--orange)", "#111"] : c >= 4 ? ["Modéré", "var(--jaune)", "#111"] : ["Faible", "var(--ok)", "#fff"]);
const NIV_P = ["", "1 · Rare", "2 · Possible", "3 · Probable", "4 · Très probable"], NIV_G = ["", "1 · Faible", "2 · Sérieuse", "3 · Grave", "4 · Très grave"];
function matriceRisques(risques) {
  const cell = (p, g) => { const n = risques.filter((r) => r.p === p && r.g === g).length, [, bg, fg] = CRIT(p * g);
    return `<td style="background:${bg};color:${fg};text-align:center;font-weight:700;opacity:${n ? 1 : 0.35};padding:8px 0">${n || ""}</td>`; };
  return `<table style="width:100%;border-collapse:separate;border-spacing:3px;font-size:.8rem"><tr><td></td>${[1, 2, 3, 4].map((g) => `<td class="mut" style="text-align:center">G${g}</td>`).join("")}</tr>
    ${[4, 3, 2, 1].map((p) => `<tr><td class="mut">P${p}</td>${[1, 2, 3, 4].map((g) => cell(p, g)).join("")}</tr>`).join("")}</table>
    <p class="mut" style="margin:4px 0 0">P = probabilité, G = gravité. Criticité = P × G : 1-3 faible · 4-6 modéré · 8-9 élevé · 12-16 critique.</p>`;
}
function imprimerRisques(e) {
  const tri = [...e.risques].sort((a, b) => b.p * b.g - a.p * a.g);
  const w = document.createElement("div"); w.id = "print";
  w.innerHTML = `<div class="ph"><div><b style="font-size:20px">SSIAP Pro</b> — Évaluation des risques</div><div>Édité le ${new Date().toLocaleString("fr-FR")} par ${esc(S.user.nom)}</div></div>
    <h1>${esc(e.titre)}</h1><p>${[e.site, e.date && new Date(e.date + "T12:00:00").toLocaleDateString("fr-FR"), e.type, e.effectif && "Effectif : " + e.effectif, e.organisateur && "Organisateur : " + e.organisateur].filter(Boolean).map(esc).join(" · ")}</p>
    <p>${e.statut === "validee" ? "✅ Évaluation validée" : "📝 Brouillon"} · ${tri.length} risque(s) · ${tri.filter((r) => r.p * r.g >= 12).length} critique(s) · rédigée par ${esc(e.auteur)}</p>
    <table><thead><tr><th>Risque</th><th>P</th><th>G</th><th>Criticité</th><th>Mesures de prévention</th><th>Responsable</th></tr></thead><tbody>
    ${tri.map((r) => `<tr><td><b>${esc(r.r)}</b><br><small>${esc(r.fam)}</small></td><td>${r.p}</td><td>${r.g}</td><td><b>${r.p * r.g}</b> ${CRIT(r.p * r.g)[0]}</td><td>${esc(r.mesures)}</td><td>${esc(r.resp)}</td></tr>`).join("")}</tbody></table>
    ${e.obs ? `<p><b>Observations :</b> ${esc(e.obs)}</p>` : ""}
    <div class="sig"><div>Le responsable sécurité<br><br><br>Signature</div><div>Visa organisateur / exploitant (VEV)<br><br><br>Signature</div></div>`;
  document.body.appendChild(w); window.print(); setTimeout(() => w.remove(), 1000);
}
async function vRisques() {
  const red = coord();
  view.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2 style="margin:0">⚠️ Évaluation des risques</h2>
      ${red ? `<button class="btn sm red" id="rnew" style="flex:0 0 auto">＋ Nouvelle</button>` : ""}</div>
    <p class="mut">Une évaluation par événement : chaque risque est noté en probabilité et en gravité, avec les mesures de prévention. ${red ? "" : "Consultation seulement."}</p>
    <div id="rlst"><p class="mut">Chargement…</p></div></div><div id="red"></div>`;
  const charger = async () => {
    const l = await api("risques");
    $("#rlst").innerHTML = l.length ? l.map((e) => { const [lb, bg, fg] = CRIT(e.max); return `<div class="item" data-id="${e.id}" style="cursor:pointer">
      <div class="h"><b>${esc(e.titre)}</b><span class="badge" style="background:${bg};color:${fg}">${e.critiques ? e.critiques + " critique(s)" : lb}</span></div>
      <div class="mut">${[e.site, e.date && new Date(e.date + "T12:00:00").toLocaleDateString("fr-FR"), e.nb + " risque(s)", e.statut === "validee" ? "✅ validée" : "📝 brouillon"].filter(Boolean).map(esc).join(" · ")}</div></div>`; }).join("")
      : `<p class="mut">Aucune évaluation pour le moment.</p>`;
  };
  $("#rlst").onclick = async (ev) => { const it = ev.target.closest("[data-id]"); if (it) ouvrir(await api("risques/" + it.dataset.id)); };
  if (red) $("#rnew").onclick = () => ouvrir({ titre: "", site: "", date: "", type: "", effectif: "", organisateur: "", obs: "", statut: "brouillon", risques: [] });
  const ouvrir = (e) => {
    const box = $("#red");
    if (!red) {
      const tri = [...e.risques].sort((a, b) => b.p * b.g - a.p * a.g);
      box.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center"><h2 style="margin:0">${esc(e.titre)}</h2><button class="btn sm" id="rprint" style="flex:0 0 auto">🖨️ PDF</button></div>
        <p class="mut">${[e.site, e.date && new Date(e.date + "T12:00:00").toLocaleDateString("fr-FR"), e.type, e.effectif && "Effectif : " + e.effectif].filter(Boolean).map(esc).join(" · ")}</p>
        ${matriceRisques(e.risques)}
        ${tri.map((r) => { const [lb, bg, fg] = CRIT(r.p * r.g); return `<div class="item" style="border-left:4px solid ${bg}"><div class="h"><b>${esc(r.r)}</b><span class="badge" style="background:${bg};color:${fg}">${r.p * r.g} · ${lb}</span></div>
          <div class="mut">${esc(r.fam)} · P${r.p} × G${r.g}${r.resp ? " · " + esc(r.resp) : ""}</div><div style="margin-top:4px">🛡️ ${esc(r.mesures)}</div></div>`; }).join("")}
        ${e.obs ? `<p><b>Observations :</b> ${esc(e.obs)}</p>` : ""}</div>`;
      $("#rprint").onclick = () => imprimerRisques(e); box.scrollIntoView({ behavior: "smooth" }); return;
    }
    const familles = [...new Set(window.RISQUES_BIB.map((x) => x[0]))];
    box.innerHTML = `<div class="card" style="border-color:var(--red)"><h2>${e.id ? "✏️ Modifier l'évaluation" : "＋ Nouvelle évaluation"}</h2>
      <label>Événement</label><input id="rt" value="${esc(e.titre)}" placeholder="ex. Salon de l'habitat, concert…">
      <div class="row"><div><label>Site</label><select id="rs"><option value="">Parc et Arena</option><option>Parc Expo Valmont</option><option>Valmont Arena</option></select></div><div><label>Date</label><input type="date" id="rd" value="${esc(e.date)}"></div></div>
      <div class="row"><div><label>Type</label><input id="rty" value="${esc(e.type)}" placeholder="Salon, concert, sport…"></div><div><label>Effectif attendu</label><input id="ref" value="${esc(e.effectif)}" inputmode="numeric"></div></div>
      <label>Organisateur</label><input id="ror" value="${esc(e.organisateur)}">
      <h3 style="margin:16px 0 6px">Matrice</h3><div id="rmat"></div>
      <h3 style="margin:16px 0 6px">Risques</h3><div id="rrows"></div>
      <details style="margin-top:10px"><summary>📚 Ajouter depuis la bibliothèque (${window.RISQUES_BIB.length} risques types)</summary><div class="c" id="rbib">
        ${familles.map((f) => `<p style="margin:8px 0 4px"><b>${f}</b></p>${window.RISQUES_BIB.map((x, i) => x[0] === f ? `<label style="display:flex;gap:8px;align-items:center;color:var(--txt);margin:4px 0"><input type="checkbox" data-b="${i}" style="width:20px;height:20px;flex:none"> ${esc(x[1])}</label>` : "").join("")}`).join("")}
        <button class="btn sm" id="rbadd" style="margin-top:8px">＋ Ajouter les risques cochés</button></div></details>
      <button class="btn sm" id="rcust" style="margin-top:8px">＋ Risque personnalisé</button>
      <label>Observations</label><textarea id="robs">${esc(e.obs)}</textarea>
      <div class="row" style="margin-top:12px"><button class="btn" id="rsave">💾 Brouillon</button><button class="btn ok" id="rval">✅ Valider et envoyer au PC</button></div>
      <div class="row" style="margin-top:8px">${e.id ? `<button class="btn sm" id="rprint">🖨️ PDF</button><button class="btn sm" id="rdel">🗑️ Supprimer</button>` : ""}</div></div>`;
    $("#rs").value = e.site || "";
    const R = e.risques.map((r) => ({ ...r }));
    const draw = () => {
      $("#rmat").innerHTML = matriceRisques(R);
      $("#rrows").innerHTML = R.map((r, i) => { const [lb, bg, fg] = CRIT(r.p * r.g); return `<div class="item" style="border-left:4px solid ${bg}">
        <div class="h"><input data-i="${i}" data-k="r" value="${esc(r.r)}" placeholder="Risque" style="font-weight:700"><span class="badge" style="background:${bg};color:${fg};flex:none;margin-left:6px">${r.p * r.g} · ${lb}</span></div>
        <div class="row"><select data-i="${i}" data-k="p">${[1, 2, 3, 4].map((n) => `<option value="${n}" ${r.p === n ? "selected" : ""}>P ${NIV_P[n]}</option>`).join("")}</select>
          <select data-i="${i}" data-k="g">${[1, 2, 3, 4].map((n) => `<option value="${n}" ${r.g === n ? "selected" : ""}>G ${NIV_G[n]}</option>`).join("")}</select></div>
        <textarea data-i="${i}" data-k="mesures" placeholder="Mesures de prévention" style="min-height:60px">${esc(r.mesures)}</textarea>
        <div class="row"><input data-i="${i}" data-k="resp" value="${esc(r.resp)}" placeholder="Responsable (PC, SSIAP 2, organisateur…)"><button class="btn sm" data-rm="${i}" style="flex:0 0 auto">✕</button></div></div>`; }).join("") || `<p class="mut">Ajoute des risques depuis la bibliothèque ci-dessous.</p>`;
    };
    draw();
    $("#rrows").oninput = (ev) => { const t = ev.target; if (!t.dataset.k) return; const r = R[t.dataset.i]; r[t.dataset.k] = t.dataset.k === "p" || t.dataset.k === "g" ? +t.value : t.value; if (t.tagName === "SELECT") draw(); };
    $("#rrows").onchange = $("#rrows").oninput;
    $("#rrows").onclick = (ev) => { const b = ev.target.closest("[data-rm]"); if (b) { R.splice(+b.dataset.rm, 1); draw(); } };
    $("#rbadd").onclick = () => { $("#rbib").querySelectorAll("input:checked").forEach((c) => { const x = window.RISQUES_BIB[+c.dataset.b]; if (!R.some((r) => r.r === x[1])) R.push({ fam: x[0], r: x[1], p: x[2], g: x[3], mesures: x[4], resp: "" }); c.checked = false; }); draw(); toast("Risques ajoutés"); };
    $("#rcust").onclick = () => { R.push({ fam: "Autre", r: "", p: 2, g: 2, mesures: "", resp: "" }); draw(); };
    const enreg = async (statut) => {
      const body = { titre: $("#rt").value, site: $("#rs").value, date: $("#rd").value, type: $("#rty").value, effectif: $("#ref").value, organisateur: $("#ror").value, obs: $("#robs").value, statut, risques: R };
      if (!body.titre.trim()) return toast("Indique l'événement");
      try { const r = await api(e.id ? "risques/" + e.id : "risques", { method: e.id ? "PUT" : "POST", body }); toast(statut === "validee" ? "✅ Validée et envoyée au PC" : "💾 Brouillon enregistré"); e = r; await charger(); ouvrir(r); }
      catch (err) { toast(err.message); }
    };
    $("#rsave").onclick = () => enreg("brouillon"); $("#rval").onclick = () => enreg("validee");
    if ($("#rprint")) $("#rprint").onclick = () => imprimerRisques({ ...e, risques: R });
    if ($("#rdel")) $("#rdel").onclick = async () => { if (!confirm("Supprimer cette évaluation ?")) return; await api("risques/" + e.id, { method: "DELETE" }); box.innerHTML = ""; charger(); };
    box.scrollIntoView({ behavior: "smooth" });
  };
  try { await charger(); } catch (err) { $("#rlst").innerHTML = `<p class="mut">${esc(err.message)}</p>`; }
}

/* ================= Planning général (responsables) : lecture seule, jour par jour ================= */
async function vPlanGen() {
  if (!staff()) return (location.hash = "#/monplanning");
  let jour = new Date().toLocaleDateString("fr-CA"), site = "";
  view.innerHTML = `<div class="card"><h2>🗓️ Planning général</h2>
    <div class="row"><button class="btn sm" id="pgp" style="flex:0 0 auto">◀</button><input type="date" id="pgd"><button class="btn sm" id="pgn" style="flex:0 0 auto">▶</button></div>
    <div class="row" style="margin-top:8px"><select id="pgs"><option value="">Parc et Arena</option><option>Parc Expo Valmont</option><option>Valmont Arena</option></select><input id="pgq" placeholder="Nom, poste…"></div>
    <div class="row" style="margin-top:8px"><a class="btn sm" href="#/monplanning">📅 Mon planning</a>${proprio() || coord() ? `<a class="btn sm" href="#/planning">📥 Import / rappels SMS</a>` : ""}</div></div>
    <div id="pgl"><p class="mut">Chargement…</p></div>`;
  let list = [];
  const draw = () => {
    const q = $("#pgq").value.toLowerCase(), l = list.filter((v) => (!site || v.site === site) && (!q || (v.nom + " " + v.poste + " " + v.evenement).toLowerCase().includes(q)));
    const parSite = {}; l.forEach((v) => (parSite[v.site || "Autre"] ||= []).push(v));
    $("#pgl").innerHTML = Object.entries(parSite).map(([s, vs]) => `<div class="card"><h2>${esc(s)} <span class="mut" style="font-size:.9rem">· ${vs.length} agent(s)</span></h2>
      ${vs.map((v) => `<div class="item"><div class="h"><b>${esc(v.nom)}</b><span><b>${esc(v.debut)} – ${esc(v.fin)}</b></span></div><div class="mut">${[v.poste, v.evenement, v.qualif].filter(Boolean).map(esc).join(" · ")}</div></div>`).join("")}</div>`).join("")
      || `<div class="card"><p class="mut">Aucune vacation ce jour-là.</p></div>`;
  };
  const charger = async () => { $("#pgd").value = jour; try { list = await api(`plangen?du=${jour}&au=${jour}`); draw(); } catch (e) { $("#pgl").innerHTML = `<div class="card"><p class="mut">${esc(e.message)}</p></div>`; } };
  const decale = (n) => { const d = new Date(jour + "T12:00:00"); d.setDate(d.getDate() + n); jour = d.toLocaleDateString("fr-CA"); charger(); };
  $("#pgp").onclick = () => decale(-1); $("#pgn").onclick = () => decale(1);
  $("#pgd").onchange = (e) => { if (e.target.value) { jour = e.target.value; charger(); } };
  $("#pgs").onchange = (e) => { site = e.target.value; draw(); }; $("#pgq").oninput = draw;
  charger();
}

/* ================= Disponibilités (agents CDD…) ================= */
const DQ = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3"];
const DCR = { jour: ["J", "Jour", "#f5c400", "#111"], nuit: ["N", "Nuit", "#4b8cff", "#fff"], jn: ["J/N", "Jour ou nuit", "#22b573", "#fff"], indispo: ["✖", "Indisponible", "#3a4250", "#cfd6df"] };
const DCYCLE = ["", "jour", "nuit", "jn", "indispo"];
const moisListe = () => { const l = [], d = new Date(); d.setDate(1); for (let i = 0; i < 4; i++) { l.push(d.toLocaleDateString("fr-CA").slice(0, 7)); d.setMonth(d.getMonth() + 1); } return l; };
const moisLabel = (m) => new Date(m + "-15T12:00:00").toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
const joursDuMois = (m) => { const [y, mo] = m.split("-").map(Number), n = new Date(y, mo, 0).getDate(); return Array.from({ length: n }, (_, i) => `${m}-${String(i + 1).padStart(2, "0")}`); };
const decal = (m) => (new Date(m + "-01T12:00:00").getDay() + 6) % 7; // lundi = 0
function vHors() {
  view.innerHTML = `<div class="card" style="border-color:var(--orange)"><h2>🕑 Hors vacation</h2>
    <p>${esc(MSG_HORS || "Tu n'es pas en vacation en ce moment : l'appli complète s'ouvre de 1 h avant à 1 h après tes vacations.")}</p>
    <p class="mut">En attendant, tu peux consulter ton planning et donner tes disponibilités pour travailler avec nous.</p>
    <div style="display:grid;gap:10px"><a class="btn red" href="#/dispos">🙋 Mes disponibilités</a><a class="btn" href="#/monplanning">📅 Mon planning</a>
    ${S.user.planif ? `<a class="btn red" href="#/planif">Planification</a>` : ""}<a class="btn" href="#/fiche">🪪 Ma fiche</a><a class="btn" href="#/dossier">📁 Mon dossier : diplômes, carte pro…</a>${peutDPAE() ? `<a class="btn" href="#/dpae">📝 Demande de DPAE</a>` : ""}<button class="btn" id="hout">Déconnexion</button></div></div>`;
  $("#hout").onclick = logout;
}
async function vDispos() {
  let mois = moisListe()[1], d = null;
  const draw = () => {
    const jours = joursDuMois(mois), dispo = jours.filter((j) => d.jours[j] && d.jours[j] !== "indispo").length;
    view.innerHTML = `<div class="card"><h2>🙋 Mes disponibilités</h2>
      <p class="mut" style="margin-top:0">Indique les jours où tu peux travailler. La coordination les voit tout de suite et te retient selon les besoins.</p>
      <div class="seg" id="dmois">${moisListe().map((m) => `<button type="button" data-m="${m}" class="${m === mois ? "on" : ""}">${moisLabel(m).split(" ")[0]}</button>`).join("")}</div>
      <label>Mes qualifications</label><div style="display:flex;flex-wrap:wrap;gap:6px" id="dq">${DQ.map((q) => `<label style="display:flex;gap:6px;align-items:center;border:1px solid var(--line);border-radius:20px;padding:6px 12px;margin:0;color:var(--txt)"><input type="checkbox" value="${q}" ${d.qualifs.includes(q) ? "checked" : ""} style="width:18px;height:18px">${q}</label>`).join("")}</div>
      <label>${esc(moisLabel(mois))} · touche un jour pour changer</label>
      <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:4px;text-align:center" id="dcal">
        ${["L", "M", "M", "J", "V", "S", "D"].map((x) => `<div class="mut" style="font-size:.75rem">${x}</div>`).join("")}
        ${"<div></div>".repeat(decal(mois))}
        ${jours.map((j) => { const v = d.jours[j] || "", c = DCR[v], ret = d.retenus && d.retenus[j];
          return `<button type="button" data-j="${j}" style="border:1px solid ${ret ? "var(--red)" : "var(--line)"};border-radius:8px;padding:6px 0;background:${c ? c[2] : "var(--card2)"};color:${c ? c[3] : "var(--txt)"};font-weight:700;font-size:.85rem;line-height:1.1">${+j.slice(8)}<br><span style="font-size:.7rem">${c ? c[0] : "·"}${ret ? " ✔" : ""}</span></button>`; }).join("")}
      </div>
      <p class="mut" style="font-size:.8rem;margin:6px 0">${Object.values(DCR).map((c) => `<b style="background:${c[2]};color:${c[3]};padding:1px 6px;border-radius:5px">${c[0]}</b> ${c[1]}`).join(" · ")} · <b style="color:var(--red)">✔</b> retenu par la coordination</p>
      <div class="row" style="flex-wrap:wrap;gap:6px"><button class="btn sm" data-tout="jour">Tout en jour</button><button class="btn sm" data-tout="nuit">Tout en nuit</button><button class="btn sm" data-tout="jn">Tout jour ou nuit</button><button class="btn sm" data-tout="we">Week-ends J/N</button><button class="btn sm" data-tout="">Effacer</button></div>
      <label>Remarque (facultatif)</label><input id="dnote" value="${esc(d.note || "")}" placeholder="ex. pas avant 8 h, permis B, dispo dernière minute…">
      <button class="btn red" id="dsend" style="margin-top:12px">📤 Envoyer mes disponibilités (${dispo} jour${dispo > 1 ? "s" : ""})</button>
      ${d.maj ? `<p class="mut">Dernier envoi : ${fmt(d.maj)}</p>` : ""}</div>`;
    $("#dmois").onclick = async (e) => { const b = e.target.closest("[data-m]"); if (b) { mois = b.dataset.m; await charger(); } };
    $("#dcal").onclick = (e) => { const b = e.target.closest("[data-j]"); if (!b) return; const v = d.jours[b.dataset.j] || ""; const n = DCYCLE[(DCYCLE.indexOf(v) + 1) % DCYCLE.length]; if (n) d.jours[b.dataset.j] = n; else delete d.jours[b.dataset.j]; garder(); draw(); };
    view.querySelectorAll("[data-tout]").forEach((b) => (b.onclick = () => { garder(); const t = b.dataset.tout; joursDuMois(mois).forEach((j) => { const we = [0, 6].includes(new Date(j + "T12:00:00").getDay());
      if (t === "we") { if (we) d.jours[j] = "jn"; } else if (t) d.jours[j] = t; else delete d.jours[j]; }); draw(); }));
    $("#dsend").onclick = async () => { garder(); if (!d.qualifs.length) return toast("Coche au moins une qualification");
      try { d = await api("dispos", { method: "PUT", body: { mois, ...d } }); toast("✅ Disponibilités envoyées"); draw(); } catch (e) { toast(e.message); } };
  };
  const garder = () => { d.qualifs = [...view.querySelectorAll("#dq input:checked")].map((c) => c.value); d.note = $("#dnote") ? $("#dnote").value : d.note; };
  const charger = async () => { try { d = await api("dispos?mois=" + mois); d.jours ||= {};
    if (!d.qualifs.length) d.qualifs = { ads: ["ADS"], ssiap1: ["SSIAP 1"], ssiap2: ["SSIAP 2"], ssiap3: ["SSIAP 3"] }[S.user.role] || []; draw(); } catch (e) { view.innerHTML = `<div class="card"><p>${esc(e.message)}</p></div>`; } };
  await charger();
}
async function vDisposAdmin() {
  if (!staff()) return (location.hash = "#/dispos");
  let mois = moisListe()[1], jour = mois + "-01", fq = "", list = [];
  const tr = coord();
  view.innerHTML = `<div class="card"><h2>🙋 Disponibilités des agents</h2>
    <div class="row"><select id="am">${moisListe().map((m) => `<option value="${m}">${moisLabel(m)}</option>`).join("")}</select>
      <select id="aq" style="flex:0 0 120px"><option value="">Toutes qualifs</option>${DQ.map((q) => `<option>${q}</option>`).join("")}</select></div>
    <div class="seg" id="av" style="margin-top:8px"><button type="button" data-v="jour" class="on">Par jour</button><button type="button" data-v="agents">Par agent</button></div>
    ${tr ? `<button class="btn sm" id="acsv" style="margin-top:8px">⬇️ Exporter le mois (Excel / CSV)</button>` : ""}
    <p class="mut" style="margin-bottom:0">${tr ? "Touche ✔ pour retenir un agent sur une date : il le voit sur son calendrier." : "Consultation seulement."}</p></div>
    <div id="abody"></div>`;
  $("#am").value = mois;
  let vue = "jour";
  const filtre = () => list.filter((a) => !fq || (a.qualifs || []).includes(fq));
  const draw = () => {
    const l = filtre();
    if (vue === "jour") {
      const dispo = l.filter((a) => a.jours[jour] && a.jours[jour] !== "indispo");
      $("#abody").innerHTML = `<div class="card"><div class="row"><button class="btn sm" id="ap" style="flex:0 0 auto">◀</button><input type="date" id="ad" value="${jour}" min="${mois}-01" max="${joursDuMois(mois).at(-1)}"><button class="btn sm" id="an" style="flex:0 0 auto">▶</button></div>
        <h2 style="margin:12px 0 4px">${new Date(jour + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} · ${dispo.length} disponible(s)</h2>
        ${dispo.map((a) => { const c = DCR[a.jours[jour]], ret = a.retenus && a.retenus[jour]; return `<div class="item" style="border-left:4px solid ${c[2]}"><div class="h"><b>${esc(a.nom)}</b>
          <span class="badge" style="background:${c[2]};color:${c[3]}">${c[1]}</span></div>
          <div class="mut">${esc((a.qualifs || []).join(" · "))}${a.note ? " · " + esc(a.note) : ""}${a.tel ? ` · <a href="tel:${esc(a.tel)}">📞 appeler</a>` : ""}</div>
          ${tr ? `<button class="btn sm ${ret ? "ok" : ""}" data-ret="${esc(a.id)}" data-v="${ret ? 0 : 1}" style="margin-top:6px">${ret ? "✔ Retenu" : "Retenir"}</button>` : ret ? `<div class="mut">✔ retenu</div>` : ""}</div>`; }).join("") || `<p class="mut">Personne de disponible ce jour-là${fq ? " avec cette qualification" : ""}.</p>`}</div>`;
      const set = (j) => { jour = j; draw(); };
      $("#ad").onchange = (e) => e.target.value && set(e.target.value);
      $("#ap").onclick = () => { const js = joursDuMois(mois), i = js.indexOf(jour); if (i > 0) set(js[i - 1]); };
      $("#an").onclick = () => { const js = joursDuMois(mois), i = js.indexOf(jour); if (i < js.length - 1) set(js[i + 1]); };
    } else {
      $("#abody").innerHTML = `<div class="card"><h2>${l.length} agent(s) ont répondu</h2>${l.map((a) => { const n = Object.values(a.jours).filter((v) => v !== "indispo").length, r = Object.keys(a.retenus || {}).length;
        return `<details class="item"><summary><b>${esc(a.nom)}</b> <span class="mut">· ${esc((a.qualifs || []).join(", "))} · ${n} j dispo${r ? ` · ${r} retenu(s)` : ""}</span></summary>
          ${a.note ? `<p class="mut">${esc(a.note)}</p>` : ""}${a.tel ? `<p><a href="tel:${esc(a.tel)}">📞 ${esc(a.tel)}</a></p>` : ""}
          <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:3px;text-align:center;margin-top:6px">${"<div></div>".repeat(decal(mois))}${joursDuMois(mois).map((j) => { const c = DCR[a.jours[j]], ret = a.retenus && a.retenus[j];
            return `<div style="border-radius:6px;padding:3px 0;font-size:.72rem;background:${c ? c[2] : "var(--card2)"};color:${c ? c[3] : "var(--mut)"};outline:${ret ? "2px solid var(--red)" : "none"}">${+j.slice(8)}<br>${c ? c[0] : "·"}</div>`; }).join("")}</div>
          <p class="mut" style="font-size:.75rem">Envoyé le ${fmt(a.maj)}</p></details>`; }).join("") || `<p class="mut">Aucune réponse pour ce mois.</p>`}</div>`;
    }
  };
  $("#abody").onclick = async (e) => { const b = e.target.closest("[data-ret]"); if (!b) return;
    try { const d = await api("dispos", { method: "PATCH", body: { mois, agentId: b.dataset.ret, jour, retenu: b.dataset.v === "1" } }); list = list.map((a) => (a.id === b.dataset.ret ? { ...a, ...d } : a)); draw(); } catch (err) { toast(err.message); } };
  $("#av").onclick = (e) => { const b = e.target.closest("[data-v]"); if (!b) return; vue = b.dataset.v; [...$("#av").children].forEach((x) => x.classList.toggle("on", x === b)); draw(); };
  $("#aq").onchange = (e) => { fq = e.target.value; draw(); };
  $("#am").onchange = async (e) => { mois = e.target.value; jour = mois + "-01"; await charger(); };
  if ($("#acsv")) $("#acsv").onclick = () => {
    const js = joursDuMois(mois), lab = { jour: "J", nuit: "N", jn: "J/N", indispo: "X" };
    const lignes = [["Agent", "Téléphone", "Qualifications", "Remarque", ...js.map((j) => j.slice(8))], ...filtre().map((a) => [a.nom, a.tel || "", (a.qualifs || []).join(" + "), a.note || "", ...js.map((j) => (lab[a.jours[j]] || "") + (a.retenus && a.retenus[j] ? " ✔" : ""))])];
    const csv = "﻿" + lignes.map((l) => l.map((x) => `"${String(x).replace(/"/g, '""')}"`).join(";")).join("\n");
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" })); a.download = `disponibilites-${mois}.csv`; a.click();
  };
  const charger = async () => { try { list = await api(`dispos?mois=${mois}&tous=1`); draw(); } catch (err) { $("#abody").innerHTML = `<div class="card"><p class="mut">${esc(err.message)}</p></div>`; } };
  await charger();
}

/* ================= Gestion des clés ================= */
async function vCles() {
  let D = await api("cles"), filtre = { q: "", b: "", sorties: false }, ouvert = null;
  await chargerPresta();
  const peut = !lecture() || coord();
  const enRetard = (e) => { if (!e || !e.retour) return false; const [h, m] = e.retour.split(":").map(Number), d = new Date(e.t); const r = new Date(d); r.setHours(h, m, 0, 0); if (r < d) r.setDate(r.getDate() + 1); return Date.now() > r; };
  const boites = [...new Set(D.liste.map((c) => c.boite))];
  view.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2 style="margin:0">🔑 Clés</h2>
      ${coord() ? `<div class="row" style="flex:0 0 auto;gap:6px"><button class="btn sm" id="kedit">✏️ Liste</button><button class="btn sm" id="kcsv">⬇️ Sorties</button></div>` : ""}</div>
    <div class="alerte" style="border-color:var(--red);margin-top:10px;text-align:center"><span class="temp" id="kout">–</span> <span class="mut">clé(s) sortie(s) au total</span></div>
    <div id="kstats" style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:6px"></div>
    <div class="row" style="margin-top:10px"><input id="kq" placeholder="N° ou nom : 104, salle de presse, Hall B5…"><select id="kb" style="flex:0 0 130px"><option value="">Toutes</option>${boites.map((b) => `<option>${esc(b)}</option>`).join("")}</select></div>
    <label style="display:flex;gap:8px;align-items:center;color:var(--txt);margin-top:8px"><input type="checkbox" id="ks" style="width:20px;height:20px"> Seulement les clés sorties</label></div>
    <div id="kedbox"></div><div id="klist"></div>
    <div class="card"><h2>🕑 Derniers mouvements</h2><div id="khist"><p class="mut">Chargement…</p></div></div>
    <datalist id="kagents"></datalist><datalist id="kpresta">${Object.values(prestaSeuls()).flat().map((x) => `<option>${esc(x)}</option>`).join("")}<option>Organisateur</option><option>Exposant</option><option>Garde Sud Sécurité</option></datalist>`;
  const histo = async () => { try { const h = await api("cles/historique");
    $("#khist").innerHTML = h.slice(0, 60).map((x) => `<div class="item"><div class="h"><b>${x.type === "sortie" ? "🔴" : "✅"} ${esc(x.n)} · ${esc(x.cle)}</b><span class="mut">${fmt(x.t)}</span></div>
      <div class="mut">${x.type === "sortie" ? `Remise à <b>${esc(x.nom)}</b>${x.cat ? " · " + esc(({ agent: "Agent sécurité", sploe: "VEV", prestataire: "Prestataire", orga: "Chef de projet" })[x.cat] || "") : ""}${x.societe && x.societe !== "VEV" ? " (" + esc(x.societe) + ")" : ""}${x.motif ? " · " + esc(x.motif) : ""}` : `Rendue par <b>${esc(x.nom)}</b> le ${new Date(x.t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })} (sortie le ${fmt(x.sortie)}, ${x.duree >= 1440 ? Math.round(x.duree / 1440) + " j" : x.duree >= 60 ? Math.round(x.duree / 60) + " h" : x.duree + " min"})${x.obs ? " · ⚠️ " + esc(x.obs) : ""}`} · par ${esc(x.par)}</div></div>`).join("") || `<p class="mut">Aucun mouvement.</p>`; } catch (e) { $("#khist").innerHTML = `<p class="mut">${esc(e.message)}</p>`; } };
  const draw = () => {
    const sorties = Object.keys(D.etat); $("#kout").textContent = sorties.length;
    const court = (b) => /organisateurs parc/i.test(b) ? "Orga Parc" : /organisateurs arena/i.test(b) ? "Orga Arena" : /boîte|boite/i.test(b) ? "Boîte Parc / Arena" : b;
    $("#kstats").innerHTML = boites.map((b) => { const l = D.liste.filter((c) => c.boite === b), o = l.filter((c) => D.etat[c.n]).length;
      return `<div class="alerte" data-kb="${esc(b)}" style="padding:8px;text-align:center;cursor:pointer;border-color:${o ? "var(--red)" : "var(--line)"}"><div style="font-weight:800;font-size:1.3rem">${o}</div><div class="mut" style="font-size:.72rem">sortie(s) · ${esc(court(b))}</div><div class="mut" style="font-size:.66rem">sur ${l.length}</div></div>`; }).join("");
    const nq = (x) => x.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, ""), q = nq(filtre.q);
    const l = D.liste.filter((c) => (!filtre.b || c.boite === filtre.b) && (!filtre.sorties || D.etat[c.n]) && (!q || nq(c.n + " " + c.nom).includes(q)));
    $("#klist").innerHTML = boites.filter((b) => l.some((c) => c.boite === b)).map((b) => `<div class="card"><h2 style="font-size:1rem">${esc(b)}</h2>
      ${l.filter((c) => c.boite === b).map((c) => { const e = D.etat[c.n], late = false;
        return `<div class="item" data-k="${esc(c.n)}" style="cursor:pointer;border-left:4px solid ${e ? (late ? "var(--orange)" : "var(--red)") : "var(--ok)"}">
          <div class="h"><b><span style="display:inline-block;min-width:38px;color:var(--red2)">${esc(c.n)}</span> ${esc(c.nom)}</b><span class="badge ${e ? "urgente" : "clos"}">${e ? (late ? "en retard" : "sortie") : "au tableau"}</span></div>
          ${e ? `<div class="mut">${orga(c) ? "Chef de projet" : esc(TYPE_LBL[e.cat] || "Remise à")} : <b>${esc(e.nom)}</b>${e.societe && e.societe !== "VEV" ? " · " + esc(e.societe) : ""}${e.motif ? " · " + esc(e.motif) : ""} · le ${fmt(e.t)}</div>` : ""}
          ${ouvert === c.n ? panneau(c, e) : ""}</div>`; }).join("")}</div>`).join("") || `<div class="card"><p class="mut">Aucune clé ${filtre.sorties ? "sortie" : "trouvée"}.</p></div>`;
  };
  const orga = (c) => /organisateurs/i.test(c.boite || "");
  const TYPE_LBL = { agent: "Agent sécurité", sploe: "VEV", prestataire: "Prestataire", orga: "Chef de projet" };
  let ktype = "agent", AGENTS_NOMS = null;
  api("cles/agents").then((l) => { AGENTS_NOMS = l; const dl = $("#kagents"); if (dl) dl.innerHTML = l.map((n) => `<option>${esc(n)}</option>`).join(""); }).catch(() => {});
  const quand = (t) => new Date(t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
  const formPC = () => `<div class="seg" id="ktype" style="margin-top:6px">${[["agent", "👮 Agent sécurité"], ["sploe", "🏢 VEV"], ["prestataire", "🔧 Prestataire"]].map(([k, l]) => `<button type="button" data-t="${k}" class="${k === ktype ? "on" : ""}">${l}</button>`).join("")}</div>
        ${ktype === "prestataire" ? `<label>Prestataire</label><select id="ksoc"><option value="">— Choisir —</option>${Object.values(prestaSeuls()).flat().map((x) => `<option>${esc(x)}</option>`).join("")}<option>Autre</option></select>` : ""}
        <label>${ktype === "agent" ? "Nom de l'agent (liste, ou tape le nom s'il n'y est pas)" : "Nom et prénom"}</label><input id="knom" ${ktype === "agent" ? 'list="kagents"' : ""} autocomplete="off">`;
  const panneau = (c, e) => !peut ? `<p class="mut" style="margin-top:6px">Consultation seulement.</p>` : e
    ? `<div style="margin-top:8px" data-stop><div class="mut">Remise le ${quand(e.t)} par ${esc(e.par)}</div>
        <label style="display:flex;gap:10px;align-items:center;color:var(--txt);margin-top:10px;font-weight:700"><input type="checkbox" id="kretchk" style="width:26px;height:26px"> Clé rendue : elle se remet au tableau</label></div>`
    : `<div style="margin-top:8px" data-stop>${orga(c) ? `<label>Remise à : chef de projet événementiel (nom et prénom)</label><input id="knom"><label>Organisation / production</label><input id="ksoc">` : `<label>Remise à</label>${formPC()}`}
        <div class="mut" style="margin-top:8px">📅 Date : ${quand(Date.now())} (automatique)</div>
        <label>${orga(c) ? "Événement" : "Manifestation"}</label><input id="kmot" placeholder="Nom de la manifestation">
        <button class="btn red" id="ksort" style="margin-top:10px">🔑 Remettre la clé</button></div>`;
  $("#klist").onclick = async (ev) => {
    if (ev.target.closest("[data-stop]") && !ev.target.closest("button") && ev.target.id !== "kretchk") return;
    if (ev.target.closest("#ktype")) { const tb2 = ev.target.closest("[data-t]"); if (tb2) { ktype = tb2.dataset.t; draw(); } return; }
    const it = ev.target.closest("[data-k]"); if (!it) return; const n = it.dataset.k;
    const tb = ev.target.closest("#ktype [data-t]"); if (tb) { ktype = tb.dataset.t; draw(); return; }
    if (ev.target.id === "ksort") {
      try { D.etat = (await api(`cles/${encodeURIComponent(n)}/sortie`, { method: "POST", body: { type: orga(D.liste.find((c) => c.n === n)) ? "orga" : ktype, nom: $("#knom").value, societe: $("#ksoc")?.value || (ktype === "sploe" ? "VEV" : ""), motif: $("#kmot").value } })).etat;
        toast("🔑 Sortie enregistrée"); ouvert = null; draw(); histo(); } catch (e) { toast(e.message); } return; }
    if (ev.target.id === "kretchk") { if (!ev.target.checked) return;
      try { D.etat = (await api(`cles/${encodeURIComponent(n)}/retour`, { method: "POST", body: {} })).etat; toast(`✅ Clé rendue le ${new Date().toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" })}`); ouvert = null; draw(); histo(); } catch (e) { ev.target.checked = false; toast(e.message); } return; }
    if (ev.target.id === "kret") {
      try { D.etat = (await api(`cles/${encodeURIComponent(n)}/retour`, { method: "POST", body: { obs: $("#kobs").value } })).etat; toast("✅ Clé restituée"); ouvert = null; draw(); histo(); } catch (e) { toast(e.message); } return; }
    ouvert = ouvert === n ? null : n; draw();
  };
  $("#kstats").onclick = (e) => { const t = e.target.closest("[data-kb]"); if (!t) return; filtre.b = t.dataset.kb; filtre.sorties = true; $("#kb").value = filtre.b; $("#ks").checked = true; draw(); };
  $("#kq").oninput = (e) => { filtre.q = e.target.value; draw(); };
  try { const q = sessionStorage.getItem("ssiap-kq"); if (q) { sessionStorage.removeItem("ssiap-kq"); $("#kq").value = q; filtre.q = q; draw(); } } catch {}
  $("#kb").onchange = (e) => { filtre.b = e.target.value; draw(); };
  $("#ks").onchange = (e) => { filtre.sorties = e.target.checked; draw(); };
  if (coord()) {
    $("#kedit").onclick = () => {
      $("#kedbox").innerHTML = `<div class="card" style="border-color:var(--red)"><h2>✏️ Liste des clés</h2><p class="mut">Une clé par ligne : <b>Boîte ; N° ; Nom du local</b>. Le N° doit être unique.</p>
        <textarea id="ked" style="min-height:300px;font-family:monospace;font-size:.76rem">${esc(D.liste.map((c) => `${c.boite} ; ${c.n} ; ${c.nom}`).join("\n"))}</textarea><button class="btn red sm" id="kedsave" style="margin-top:8px">💾 Enregistrer</button></div>`;
      $("#kedsave").onclick = async () => { const liste = $("#ked").value.split("\n").map((l) => l.split(";").map((x) => x.trim())).filter((a) => a.length >= 3 && a[1]).map(([boite, n, ...r]) => ({ boite, n, nom: r.join(" ; ") }));
        try { const r = await api("cles", { method: "PUT", body: { liste } }); toast(`✅ ${r.nb} clé(s)`); vCles(); } catch (e) { toast(e.message); } };
    };
    $("#kcsv").onclick = () => { const l = [["N°", "Clé", "Remise à", "Société", "Téléphone", "Motif", "Sortie", "Retour prévu", "Laissé", "Par"], ...Object.entries(D.etat).map(([n, e]) => [n, (D.liste.find((c) => c.n === n) || {}).nom || "", e.nom, e.societe, e.tel, e.motif, fmt(e.t), e.retour, e.piece, e.par])];
      const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿" + l.map((r) => r.map((x) => `"${String(x || "").replace(/"/g, '""')}"`).join(";")).join("\n")], { type: "text/csv" })); a.download = "cles-sorties.csv"; a.click(); };
  }
  draw(); histo();
}

/* ================= Prêt de matériel (casques, radios, PTI, autres) ================= */
async function vMateriel() {
  let D = await api("materiel"), q = "", ty = "", seul = "", ouvert = null;
  const peut = !lecture() || coord(), types = () => [...new Set(D.liste.map((c) => c.type))];
  const quand = (t) => new Date(t).toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
  view.innerHTML = `<div class="card"><div class="h" style="display:flex;justify-content:space-between;align-items:center;gap:8px"><h2 style="margin:0">📦 Prêt de matériel</h2>
      ${coord() ? `<button class="btn sm" id="medit" style="flex:0 0 auto">✏️ Liste</button>` : ""}</div>
    <div id="mstats" style="display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-top:10px"></div>
    <div class="row" style="margin-top:10px"><input id="mq" placeholder="N° ou nom d'agent…"><select id="mt" style="flex:0 0 130px"><option value="">Tout</option>${types().map((x) => `<option>${esc(x)}</option>`).join("")}</select></div>
    <div class="seg" id="mseul" style="margin-top:8px"><button type="button" data-s="" class="on">Tout</button><button type="button" data-s="pret">Prêtés</button><button type="button" data-s="dispo">Disponibles</button><button type="button" data-s="hs">Hors service</button></div></div>
    <div id="medbox"></div><div id="mlist"></div>
    <div class="card"><h2>🕑 Derniers mouvements</h2><div id="mhist"></div></div><datalist id="magents"></datalist>`;
  api("cles/agents").then((l) => ($("#magents").innerHTML = l.map((n) => `<option>${esc(n)}</option>`).join(""))).catch(() => {});
  const histo = async () => { const h = await api("materiel/historique").catch(() => []);
    $("#mhist").innerHTML = h.slice(0, 60).map((x) => `<div class="item"><div class="h"><b>${x.sens === "prêt" ? "📤" : x.sens === "retour" ? (x.ok ? "📥" : "⚠️") : "🔧"} ${esc(x.objet)}</b><span class="mut">${quand(x.t)}</span></div>
      <div class="mut">${x.sens === "prêt" ? `Prêté à <b>${esc(x.nom)}</b>${x.manif ? " · " + esc(x.manif) : ""} · ${x.ok ? "✅ en état de fonctionnement" : "⚠️ état non confirmé"}${x.remarque ? " · " + esc(x.remarque) : ""}`
        : x.sens === "retour" ? `Rendu par <b>${esc(x.nom)}</b> · ${x.ok ? "✅ fonctionne" : "⚠️ hors service"}${x.remarque ? " · " + esc(x.remarque) : ""}` : "Remis en service"} · par ${esc(x.par)}</div></div>`).join("") || `<p class="mut">Aucun mouvement.</p>`; };
  const draw = () => {
    const st = types().map((x) => { const l = D.liste.filter((c) => c.type === x); return `<div class="alerte" style="padding:8px"><div style="font-weight:800">${l.filter((c) => !D.etat[c.n] && !D.hs[c.n]).length}/${l.length}</div><div class="mut" style="font-size:.72rem">${esc(x.split(" (")[0])} dispo</div></div>`; });
    $("#mstats").innerHTML = st.join("");
    const nq = q.toLowerCase(), l = D.liste.filter((c) => (!ty || c.type === ty) && (!nq || (c.n + " " + c.nom + " " + (D.etat[c.n]?.nom || "")).toLowerCase().includes(nq))
      && (!seul || (seul === "pret" ? D.etat[c.n] : seul === "hs" ? D.hs[c.n] : !D.etat[c.n] && !D.hs[c.n])));
    $("#mlist").innerHTML = types().filter((x) => l.some((c) => c.type === x)).map((x) => `<div class="card"><h2 style="font-size:1rem">${esc(x)}</h2>${l.filter((c) => c.type === x).map((c) => { const e = D.etat[c.n], h = D.hs[c.n];
      return `<div class="item" data-m="${esc(c.n)}" style="cursor:pointer;border-left:4px solid ${h ? "var(--orange)" : e ? "var(--red)" : "var(--ok)"}">
        <div class="h"><b>${esc(c.nom)}</b><span class="badge ${h ? "moyenne" : e ? "urgente" : "clos"}">${h ? "hors service" : e ? "prêté" : "disponible"}</span></div>
        ${e ? `<div class="mut">👮 <b>${esc(e.nom)}</b>${e.manif ? " · " + esc(e.manif) : ""} · depuis ${quand(e.t)} · ${e.ok ? "✅ fonctionnait" : "⚠️ état non confirmé"}</div>` : ""}
        ${h ? `<div class="mut">⚠️ ${esc(h.remarque)} · ${quand(h.t)}</div>` : ""}
        ${ouvert === c.n ? panneau(c, e, h) : ""}</div>`; }).join("")}</div>`).join("") || `<div class="card"><p class="mut">Aucun matériel.</p></div>`;
  };
  const panneau = (c, e, h) => !peut ? `<p class="mut">Consultation seulement.</p>` : `<div data-stop style="margin-top:8px">${e
    ? `<label style="display:flex;gap:10px;align-items:center;color:var(--txt);font-weight:700"><input type="checkbox" id="mok" checked style="width:24px;height:24px"> Rendu en état de fonctionnement</label>
       <input id="mrem" placeholder="Remarque (batterie faible, antenne cassée…)" style="margin-top:6px">
       <label style="display:flex;gap:10px;align-items:center;color:var(--txt);margin-top:10px;font-weight:700"><input type="checkbox" id="mret" style="width:26px;height:26px"> Matériel rendu : il se remet en place</label>`
    : h ? `<button class="btn ok" id="mserv">🔧 Remettre en service (réparé / vérifié)</button>`
    : `<label>Agent (liste, ou tape le nom s'il n'y est pas)</label><input id="mnom" list="magents" autocomplete="off">
       <label>Manifestation (facultatif)</label><input id="mmanif">
       <label style="display:flex;gap:10px;align-items:center;color:var(--txt);margin-top:10px;font-weight:700"><input type="checkbox" id="mok" style="width:24px;height:24px"> En état de fonctionnement</label>
       <input id="mrem" placeholder="Remarque (facultatif)" style="margin-top:6px">
       <div class="mut" style="margin-top:6px">📅 ${quand(Date.now())} (automatique)</div>
       <button class="btn red" id="mpret" style="margin-top:10px">📤 Prêter</button>`}</div>`;
  $("#mlist").onclick = async (ev) => {
    const it = ev.target.closest("[data-m]"); if (!it) return; const n = it.dataset.m, id = ev.target.id;
    const go = async (path, body, msg) => { try { const r = await api(`materiel/${encodeURIComponent(n)}/${path}`, { method: "POST", body }); D.etat = r.etat; D.hs = r.hs; ouvert = null; toast(msg); draw(); histo(); } catch (e) { toast(e.message); } };
    if (id === "mpret") { if (!$("#mok").checked && !confirm("État de fonctionnement non coché : prêter quand même ?")) return; return go("pret", { nom: $("#mnom").value, manif: $("#mmanif").value, ok: $("#mok").checked, remarque: $("#mrem").value }, "📤 Prêt enregistré"); }
    if (id === "mret") { if (!ev.target.checked) return; return go("retour", { ok: $("#mok").checked, remarque: $("#mrem").value }, $("#mok").checked ? "📥 Matériel rendu" : "⚠️ Rendu, mis hors service"); }
    if (id === "mserv") return go("service", {}, "🔧 Remis en service");
    if (ev.target.closest("[data-stop]")) return;
    ouvert = ouvert === n ? null : n; draw();
  };
  $("#mq").oninput = (e) => { q = e.target.value; draw(); };
  $("#mt").onchange = (e) => { ty = e.target.value; draw(); };
  $("#mseul").onclick = (e) => { const b = e.target.closest("[data-s]"); if (!b) return; seul = b.dataset.s; [...$("#mseul").children].forEach((x) => x.classList.toggle("on", x === b)); draw(); };
  if (coord()) $("#medit").onclick = () => {
    $("#medbox").innerHTML = `<div class="card" style="border-color:var(--red)"><h2>✏️ Liste du matériel</h2><p class="mut">Une ligne par objet : <b>Catégorie ; Code ; Nom</b>. Ex. « Autres ; L1 ; Lampe torche n° 1 », « Autres ; DAE1 ; DAE portable ».</p>
      <textarea id="med" style="min-height:260px;font-family:monospace;font-size:.78rem">${esc(D.liste.map((c) => `${c.type} ; ${c.n} ; ${c.nom}`).join("\n"))}</textarea><button class="btn red sm" id="medsave" style="margin-top:8px">💾 Enregistrer</button></div>`;
    $("#medsave").onclick = async () => { const liste = $("#med").value.split("\n").map((l) => l.split(";").map((x) => x.trim())).filter((a) => a.length >= 3 && a[1]).map(([type, n, ...r]) => ({ type, n, nom: r.join(" ; ") }));
      try { const r = await api("materiel", { method: "PUT", body: { liste } }); toast(`✅ ${r.nb} objet(s)`); vMateriel(); } catch (e) { toast(e.message); } };
  };
  draw(); histo();
}

/* ================= Fil de l'eau général Parc / Arena ================= */
async function vFil() {
  if (!staff()) return (location.hash = "#/");
  const ICO = { Alerte: "🚨", "Bâtiment": "🏢", "Main courante": "📝", Service: "🟢", Rapport: "📋", Ronde: "🔦", "Check-list": "✅", "Clés": "🔑", "Matériel": "📦", Document: "📂" };
  let periode = "1", site = "", type = "", q = "", list = [];
  view.innerHTML = `<div class="card"><h2>📜 Fil de l'eau — Parc Expo Valmont / Arena</h2>
    <input id="fq" placeholder="🔎 Rechercher : nom, lieu, porte, clé, Hall B5, malaise…" style="margin-top:4px">
    <div class="seg" id="fp" style="margin-top:8px"><button type="button" data-p="1" class="on">24 h</button><button type="button" data-p="7">7 jours</button><button type="button" data-p="30">30 jours</button><button type="button" data-p="d">Date</button></div>
    <input type="date" id="fd" class="hidden" style="margin-top:6px">
    <div class="row" style="margin-top:8px"><div class="seg" id="fs" style="flex:1"><button type="button" data-s="" class="on">Tout</button><button type="button" data-s="Parc">Parc</button><button type="button" data-s="Arena">Arena</button></div>
      <select id="ft" style="flex:0 0 130px"><option value="">Tous types</option>${Object.keys(ICO).map((k) => `<option>${k}</option>`).join("")}</select></div>
    <div class="row" style="margin-top:8px;align-items:center"><span class="mut" id="fn" style="flex:1"></span>${coord() ? `<button class="btn sm" id="fcsv" style="flex:0 0 auto">⬇️ Export</button>` : ""}</div></div>
    ${proprio() || S.user.role === "admin" ? `<div class="card" id="fhist"><h2>Historique · présentation</h2>
      <p class="mut" style="margin-top:0">Réservé au propriétaire et aux administrateurs. Le planning n'est jamais touché.</p>
      <div class="row"><button class="btn sm" id="fex">Créer des exemples avec les agents du planning</button><button class="btn sm" id="fexr">Retirer les exemples</button></div>
      <button class="btn sm" id="fnotif" style="margin-top:8px">Vider les notifications (cloche)</button>
      <button class="btn sm" id="fpurge" style="margin-top:8px;border-color:var(--red);color:#ff8a98">Supprimer tout l'historique</button><p class="mut" id="fhn" style="margin:6px 0 0;font-size:.8rem"></p></div>` : ""}
    <div id="fl"><p class="mut">Chargement…</p></div>`;
  if ($("#fhist")) {
    const compte = async () => { try { const h = await api("historique"); $("#fhn").textContent = `${h.mc} main(s) courante(s), ${h.rap + h.rapports} rapport(s), ${h.rondes_nfc} ronde(s), ${h.alertes} alerte(s) · dont ${h.demo} exemple(s)`; } catch {} };
    compte();
    $("#fex").onclick = async () => { try { const r = await api("historique/exemples", { method: "POST" }); toast(`${r.nb} exemples créés (planning du ${frDate(r.jour)}) : ${r.agents.slice(0, 4).join(", ")}…`, 6000); compte(); charger(); } catch (e) { toast(e.message); } };
    $("#fexr").onclick = async () => { if (!confirm("Retirer tous les exemples de présentation ?")) return; try { const r = await api("historique/exemples-retirer", { method: "POST" }); toast(`${r.n} exemple(s) retiré(s)`); compte(); charger(); } catch (e) { toast(e.message); } };
    $("#fnotif").onclick = viderNotifs;
    $("#fpurge").onclick = async () => { const c = prompt("Toute la main courante, les rapports, rondes, check-lists, mouvements de clés et de matériel, ouvertures de bâtiments, alertes et notifications seront supprimés définitivement. Le planning, les comptes, les documents et les devis sont conservés.\n\nTape SUPPRIMER pour confirmer :");
      if (c === null) return; try { await api("historique/purger", { method: "POST", body: { confirmation: c.trim().toUpperCase() } }); toast("Historique supprimé"); compte(); charger(); } catch (e) { toast(e.message); } };
  }
  const nq = (x) => String(x || "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  const filtre = () => { const k = nq(q).split(/\s+/).filter(Boolean);
    return list.filter((x) => (!site || x.site === site) && (!type || x.type === type) && (!k.length || k.every((m) => nq([x.titre, x.texte, x.auteur, x.lieu, x.type, x.site].join(" ")).includes(m)))); };
  const surligne = (t) => { let h = esc(t || ""); nq(q).split(/\s+/).filter((m) => m.length > 1).forEach(() => {}); return h; };
  const draw = () => {
    const l = filtre(); $("#fn").textContent = `${l.length} événement(s)`;
    const parJour = {}; l.forEach((x) => (parJour[new Date(x.t).toLocaleDateString("fr-CA")] ||= []).push(x));
    $("#fl").innerHTML = Object.entries(parJour).map(([j, xs]) => `<div class="card"><h2 style="font-size:1rem">${new Date(j + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} · ${xs.length}</h2>
      ${xs.map((x) => `<a class="item" href="${x.lien || "#/fil"}" style="display:block;color:inherit;text-decoration:none;border-left:4px solid ${x.niveau === "urgente" ? "var(--red)" : x.niveau === "moyenne" ? "var(--orange)" : "var(--line)"}">
        <div class="h"><b>${ICO[x.type] || "•"} ${surligne(x.titre)}</b><span class="mut">${new Date(x.t).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}</span></div>
        <div class="mut">${[x.site, x.lieu, x.auteur && "par " + x.auteur, x.fait && "fait à " + x.fait.slice(11, 16), x.statut, x.photos && "📷 " + x.photos].filter(Boolean).map(esc).join(" · ")}</div>
        ${x.texte ? `<div style="font-size:.9rem;margin-top:2px">${surligne(String(x.texte).slice(0, 400))}</div>` : ""}</a>`).join("")}</div>`).join("") || `<div class="card"><p class="mut">Aucun événement${q ? " pour cette recherche" : ""}.</p></div>`;
  };
  const charger = async () => {
    let du, au; const d = (n) => new Date(Date.now() - n * 864e5).toLocaleDateString("fr-CA");
    if (periode === "d") { du = au = $("#fd").value || d(0); } else { du = d(+periode); au = d(-1); }
    $("#fl").innerHTML = `<p class="mut">Chargement…</p>`;
    try { list = await api(`fil?du=${du}&au=${au}`); if (periode === "1") { const lim = Date.now() - 864e5; list = list.filter((x) => Date.parse(x.t) >= lim); } draw(); }
    catch (e) { $("#fl").innerHTML = `<div class="card"><p class="mut">${esc(e.message)}</p></div>`; }
  };
  $("#fq").oninput = (e) => { q = e.target.value; draw(); };
  $("#fp").onclick = (e) => { const b = e.target.closest("[data-p]"); if (!b) return; periode = b.dataset.p; [...$("#fp").children].forEach((x) => x.classList.toggle("on", x === b)); $("#fd").classList.toggle("hidden", periode !== "d"); if (periode === "d" && !$("#fd").value) $("#fd").value = new Date().toLocaleDateString("fr-CA"); charger(); };
  $("#fd").onchange = charger;
  $("#fs").onclick = (e) => { const b = e.target.closest("[data-s]"); if (!b) return; site = b.dataset.s; [...$("#fs").children].forEach((x) => x.classList.toggle("on", x === b)); draw(); };
  $("#ft").onchange = (e) => { type = e.target.value; draw(); };
  if ($("#fcsv")) $("#fcsv").onclick = () => { const l = [["Date", "Heure", "Type", "Titre", "Détail", "Site", "Lieu", "Auteur"], ...filtre().map((x) => [new Date(x.t).toLocaleDateString("fr-FR"), new Date(x.t).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" }), x.type, x.titre, x.texte, x.site, x.lieu, x.auteur])];
    const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob(["﻿" + l.map((r) => r.map((v) => `"${String(v || "").replace(/"/g, '""')}"`).join(";")).join("\n")], { type: "text/csv" })); a.download = "fil-de-l-eau.csv"; a.click(); };
  charger();
}

/* ================= Alertes (enfant perdu…) : 1 h, visibles par tous ================= */
const NATURES_ALERTE = ["Enfant perdu", "Personne recherchée", "Personne vulnérable / malaise", "Objet suspect", "Comportement suspect", "Véhicule recherché", "Évacuation / mise à l'abri", "Alerte météo", "Autre"];
let alerteTimer = null, ALERTES = [];
const resteMin = (a) => Math.max(0, Math.ceil((Date.parse(a.exp) - Date.now()) / 60000));
async function majAlertes() {
  if (!S.token || S.user?.hors || S.user?.ficheOk === false) { $("#alertbar").innerHTML = ""; return; }
  try {
    const d = await api("alertes"); ALERTES = d.actives;
    alerteForcee(ALERTES.find((x) => x.forcee && x.auteurId !== S.user.id && !(x.vus || []).some((v) => v.id === S.user.id)));
    let vues = []; try { vues = JSON.parse(localStorage.getItem("ssiap-alertes-vues") || "[]"); } catch {}
    const nouvelles = ALERTES.filter((a) => !vues.includes(a.id) && a.auteurId !== S.user.id);
    if (nouvelles.length) { sonAlerte(); notifSysteme(`ALERTE — ${nouvelles[0].nature}`, nouvelles[0].texte.slice(0, 140), "/#/alertes"); toast(`🚨 ${nouvelles[0].nature} : ${nouvelles[0].texte.slice(0, 80)}`, 8000);
      try { localStorage.setItem("ssiap-alertes-vues", JSON.stringify([...vues, ...nouvelles.map((a) => a.id)].slice(-100))); } catch {} }
    $("#alertbar").innerHTML = ALERTES.map((a) => `<a href="#/alertes" style="display:flex;gap:10px;justify-content:space-between;align-items:center;background:var(--rouge);color:#fff;text-decoration:none;padding:9px 14px;font-weight:700;font-size:.92rem;border-bottom:1px solid rgba(255,255,255,.25)">
      🚨 ${esc(a.nature)}${a.lieu ? " · " + esc(a.lieu) : ""} — ${esc(a.texte.slice(0, 90))}<span style="flex:none;font-weight:400;opacity:.85">${resteMin(a)} min</span></a>`).join("");
    const tab = document.querySelector('nav.tab a[data-r="alertes"]'); if (tab) tab.classList.toggle("alerte-on", !!ALERTES.length);
  } catch {}
}
/* ---------- Alerte forcée : plein écran + sirène en boucle jusqu'à confirmation ---------- */
let FORCEE = null;
function alerteForcee(a) {
  if (!a) { if (FORCEE && !ALERTES.some((x) => x.id === FORCEE.id)) { clearInterval(FORCEE.timer); document.getElementById("aforcee")?.remove(); FORCEE = null; } return; }
  if (FORCEE && FORCEE.id === a.id) return;
  if (FORCEE) { clearInterval(FORCEE.timer); document.getElementById("aforcee")?.remove(); }
  const ov = document.createElement("div"); ov.id = "aforcee";
  ov.innerHTML = `<div class="afin"><div class="psur" style="color:#fff;opacity:.85">Alerte forcée</div><h1>${esc(a.nature)}</h1>${a.lieu ? `<p class="alieu">${esc(a.lieu)}${a.site ? " · " + esc(a.site) : ""}</p>` : ""}
    <p class="atxt">${esc(a.texte)}</p><p class="mut" style="color:#ffd2d8">Lancée par ${esc(a.auteur)} à ${fmt(a.t).slice(-5)}</p>
    <button class="btn" id="afok">Je confirme la réception</button><p style="font-size:.78rem;opacity:.8;margin-top:10px">La sirène continue tant que tu n'as pas confirmé.</p></div>`;
  document.body.appendChild(ov);
  const sonne = () => { sonAlerte(); notifSysteme(`ALERTE FORCÉE — ${a.nature}`, a.texte.slice(0, 140), "/#/alertes"); };
  sonne(); FORCEE = { id: a.id, timer: setInterval(sonne, 4000) };
  ov.querySelector("#afok").onclick = async () => { const b = ov.querySelector("#afok"); b.disabled = true;
    try { await api(`alertes/${a.id}/vu`, { method: "POST" }); a.vus = [...(a.vus || []), { id: S.user.id, nom: S.user.nom }]; clearInterval(FORCEE.timer); ov.remove(); FORCEE = null; toast("Réception confirmée"); location.hash = "#/alertes"; }
    catch (e) { b.disabled = false; toast(e.message); } };
}
function lancerAlertes() { if (alerteTimer) return; majAlertes(); alerteTimer = setInterval(majAlertes, 20000); }
async function vAlertes() {
  await chargerZones();
  view.innerHTML = `<div class="card" style="border-color:var(--red)"><h2>🚨 Lancer une alerte</h2>
    <p class="mut" style="margin-top:0">L'alerte s'affiche aussitôt en haut de l'écran de tous les agents et responsables, part par mail au PC, et disparaît toute seule au bout d'<b>1 heure</b>.</p>
    <label>Nature</label><select id="anat">${NATURES_ALERTE.map((n) => `<option>${n}</option>`).join("")}</select>
    ${htmlLieu("alz", false)}
    <label>Description</label><textarea id="atxt" placeholder="Ex. garçon 6 ans, t-shirt rouge, short bleu, prénom Lucas, perdu vers le Hall B3. Parents au PC."></textarea>
    <label style="display:flex;gap:10px;align-items:flex-start;color:var(--txt);margin-top:12px"><input type="checkbox" id="afor" checked style="width:22px;height:22px;flex:none;margin-top:2px"><span><b>Alerte forcée</b><br><span class="mut">Plein écran et sirène en boucle sur tous les téléphones en service jusqu'à ce que chacun confirme la réception ; rappel toutes les 2 minutes sur les téléphones verrouillés.</span></span></label>
    <button class="btn red" id="ago" style="margin-top:10px">🚨 Lancer l'alerte</button></div>
    <div class="card"><h2>🔴 Alertes en cours</h2><div id="aact"><p class="mut">Chargement…</p></div></div>
    ${staff() ? `<div class="card"><h2>🕑 Dernières 24 h</h2><div id="arec"></div></div>` : ""}`;
  brancherLieu("alz");
  const charger = async () => {
    const d = await api("alertes"); ALERTES = d.actives;
    $("#aact").innerHTML = d.actives.map((a) => `<div class="item" style="border-left:4px solid var(--red)"><div class="h"><b>🚨 ${esc(a.nature)}</b><span class="badge urgente">${resteMin(a)} min</span></div>
      <div class="mut">${[a.site, a.lieu, "par " + a.auteur, "à " + fmt(a.t).slice(-5)].filter(Boolean).map(esc).join(" · ")}</div><div style="white-space:pre-wrap;margin-top:4px">${esc(a.texte)}</div>
      ${a.forcee ? `<div class="mut" style="margin-top:6px">${a.forcee ? "Alerte forcée · " : ""}confirmée par <b style="color:var(--txt)">${(a.vus || []).length}</b> : ${(a.vus || []).map((v) => esc(v.nom)).join(", ")}</div>` : ""}
      ${a.auteurId === S.user.id || staff() ? `<button class="btn sm ok" data-fin="${a.id}" style="margin-top:6px">✅ Lever l'alerte (résolue)</button>` : ""}</div>`).join("") || `<p class="mut">Aucune alerte en cours.</p>`;
    if ($("#arec")) $("#arec").innerHTML = d.recentes.map((a) => `<div class="item"><div class="h"><b>${a.fin ? "✅" : Date.parse(a.exp) > Date.now() ? "🔴" : "⌛"} ${esc(a.nature)}</b><span class="mut">${fmt(a.t)}</span></div>
      <div class="mut">${esc(a.texte.slice(0, 160))}${a.fin ? ` — levée par ${esc(a.fin.par)}${a.fin.note ? " : " + esc(a.fin.note) : ""}` : Date.parse(a.exp) <= Date.now() ? " — expirée" : ""}</div></div>`).join("") || `<p class="mut">Aucune alerte.</p>`;
    majAlertes();
  };
  $("#ago").onclick = async () => {
    if (!$("#atxt").value.trim()) return toast("Ajoute une description");
    if (!confirm("Lancer l'alerte pour tout le monde ?")) return;
    try { await api("alertes", { method: "POST", body: { nature: $("#anat").value, texte: $("#atxt").value, forcee: $("#afor").checked, ...lireLieu("alz") } }); $("#atxt").value = ""; toast("🚨 Alerte lancée"); charger(); } catch (e) { toast(e.message); }
  };
  $("#aact").onclick = async (e) => { const b = e.target.closest("[data-fin]"); if (!b) return; const note = prompt("Comment s'est-elle terminée ? (ex. enfant retrouvé, remis aux parents)", ""); if (note === null) return;
    try { await api(`alertes/${b.dataset.fin}/fin`, { method: "POST", body: { note } }); toast("✅ Alerte levée"); charger(); } catch (err) { toast(err.message); } };
  charger();
}

/* ================= Ouverture / fermeture des bâtiments et éclairage ================= */
async function vBatiments() {
  await chargerPresta();
  let D = await api("batiments"), sel = new Set(), acts = new Set(), dem = "prestataire";
  try { const b = sessionStorage.getItem("ssiap-bat"); if (b) { sessionStorage.removeItem("ssiap-bat"); sel.add(b); } } catch {}
  const peut = !lecture() || coord();
  const ACT = [["ouverture", "🔓 Ouverture"], ["fermeture", "🔒 Fermeture"], ["eclairage_on", "💡 Mise en fonction éclairage"], ["eclairage_off", "⚫ Mise hors fonction éclairage"]];
  const OPP = { ouverture: "fermeture", fermeture: "ouverture", eclairage_on: "eclairage_off", eclairage_off: "eclairage_on" };
  const DEM = [["prestataire", "🔧 Prestataire"], ["organisateur", "🎪 Organisateur"], ["sploe", "🏢 VEV"], ["pc", "🛡️ PC sécurité"], ["autre", "Autre"]];
  const chip = (on) => `display:flex;gap:6px;align-items:center;justify-content:center;border:2px solid ${on ? "var(--red)" : "var(--line)"};background:${on ? "rgba(215,16,46,.18)" : "var(--card2)"};border-radius:10px;padding:9px 6px;margin:0;color:var(--txt);font-weight:700;font-size:.85rem;cursor:pointer;text-align:center`;
  const draw = () => {
    view.innerHTML = `<div class="card"><h2>🏢 Ouverture / fermeture · éclairage</h2>
      <p class="mut" style="margin-top:0">État actuel des bâtiments. ${peut ? "Touche un ou plusieurs halls, choisis l'opération, puis valide." : "Consultation seulement."}</p>
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px" id="bh">${D.halls.map((h) => { const e = D.etat[h] || {};
        return `<div data-h="${esc(h)}" style="${chip(sel.has(h))};flex-direction:column;align-items:flex-start;justify-content:flex-start;text-align:left"><span>${esc(h)}</span>
          <span class="mut" style="font-weight:400;font-size:.75rem">${e.ouvert === true ? "🔓 ouvert" : e.ouvert === false ? "🔒 fermé" : "— état inconnu"} · ${e.eclairage === true ? "💡 allumé" : e.eclairage === false ? "⚫ éteint" : "éclairage ?"}</span>
          ${e.maj ? `<span class="mut" style="font-weight:400;font-size:.68rem">${fmt(e.maj)} · ${esc(e.par)}</span>` : ""}</div>`; }).join("")}</div>
      ${peut ? `<div class="row" style="margin-top:6px"><button class="btn sm" id="ball">Tout le Parc</button><button class="btn sm" id="bnone">Aucun</button></div>
      <label>Opération</label><div style="display:grid;grid-template-columns:repeat(2,1fr);gap:6px" id="ba">${ACT.map(([k, l]) => `<div data-a="${k}" style="${chip(acts.has(k))}">${l}</div>`).join("")}</div>
      <label>À la demande de</label><div style="display:flex;flex-wrap:wrap;gap:6px" id="bd">${DEM.map(([k, l]) => `<div data-d="${k}" style="${chip(dem === k)};flex:1 1 30%">${l}</div>`).join("")}</div>
      ${dem === "prestataire" ? `<label>Prestataire</label><select id="bsoc"><option value="">— Choisir —</option>${Object.values(prestaSeuls()).flat().map((x) => `<option>${esc(x)}</option>`).join("")}</select>` : ""}
      ${dem !== "pc" ? `<label>Nom de la personne${dem === "prestataire" ? " (facultatif)" : ""}</label><input id="bnom" ${dem === "organisateur" ? 'placeholder="Chef de projet, organisation…"' : ""}>` : ""}
      <label>Commentaire (facultatif)</label><input id="bcom" placeholder="Ex. ouverture pour montage, éclairage coupé après départ des exposants…">
      <div class="mut" style="margin-top:6px">📅 ${new Date().toLocaleString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" })} (automatique)</div>
      <button class="btn red" id="bgo" style="margin-top:10px">✅ Valider (${sel.size} hall${sel.size > 1 ? "s" : ""})</button>` : ""}</div>
      <div class="card"><h2>🕑 Historique</h2><div id="bhist"><p class="mut">Chargement…</p></div></div>`;
    $("#bh").onclick = (e) => { const c = e.target.closest("[data-h]"); if (!c || !peut) return; const h = c.dataset.h; garder(); sel.has(h) ? sel.delete(h) : sel.add(h); draw(); };
    if (!peut) return histo();
    $("#ball").onclick = () => { garder(); D.halls.filter((h) => !/arena/i.test(h)).forEach((h) => sel.add(h)); draw(); };
    $("#bnone").onclick = () => { sel.clear(); draw(); };
    $("#ba").onclick = (e) => { const c = e.target.closest("[data-a]"); if (!c) return; const a = c.dataset.a; if (acts.has(a)) acts.delete(a); else { acts.add(a); acts.delete(OPP[a]); } garder(); draw(); };
    $("#bd").onclick = (e) => { const c = e.target.closest("[data-d]"); if (!c) return; dem = c.dataset.d; garder(); draw(); };
    $("#bgo").onclick = async () => {
      if (!sel.size) return toast("Choisis au moins un hall"); if (!acts.size) return toast("Choisis l'opération");
      if (dem === "prestataire" && !$("#bsoc").value) return toast("Choisis le prestataire");
      if ((dem === "organisateur" || dem === "sploe" || dem === "autre") && !$("#bnom").value.trim()) return toast("Indique le nom de la personne");
      try { const r = await api("batiments", { method: "POST", body: { halls: [...sel], actions: [...acts], demType: dem, demSociete: $("#bsoc")?.value || "", demNom: $("#bnom")?.value || "", commentaire: $("#bcom").value } });
        D.etat = r.etat; toast(`✅ ${r.mv.libelle} enregistrée`); sel.clear(); acts.clear(); memo = {}; draw(); } catch (err) { toast(err.message); }
    };
    if (memo.bnom && $("#bnom")) $("#bnom").value = memo.bnom; if (memo.bcom) $("#bcom").value = memo.bcom; if (memo.bsoc && $("#bsoc")) $("#bsoc").value = memo.bsoc;
    histo();
  };
  let memo = {};
  const garder = () => { memo = { bnom: $("#bnom")?.value, bcom: $("#bcom")?.value, bsoc: $("#bsoc")?.value }; };
  const histo = async () => { const h = await api("batiments/historique").catch(() => []);
    const QUI = { prestataire: "Prestataire", organisateur: "Organisateur", sploe: "VEV", pc: "PC sécurité", autre: "Autre" };
    $("#bhist").innerHTML = h.slice(0, 60).map((x) => `<div class="item"><div class="h"><b>${x.actions.map((a) => ({ ouverture: "🔓", fermeture: "🔒", eclairage_on: "💡", eclairage_off: "⚫" })[a]).join("")} ${esc(x.libelle)}</b><span class="mut">${fmt(x.t)}</span></div>
      <div class="mut">${esc(x.halls.join(", "))}</div><div class="mut">Demande : ${esc(QUI[x.dem.type])}${x.dem.societe ? " " + esc(x.dem.societe) : ""}${x.dem.nom ? " (" + esc(x.dem.nom) + ")" : ""} · par ${esc(x.par)}</div>
      ${x.commentaire ? `<div style="font-size:.9rem">${esc(x.commentaire)}</div>` : ""}</div>`).join("") || `<p class="mut">Aucune opération.</p>`; };
  draw();
}

/* ================= Routeur ================= */
const ROUTES = { "": vHome, notifdiag: vNotifDiag, planif: vPlanif, plan: vPlan, "mc-archives": vMCArchives, dossier: vDossier, dossiers: vDossiers, equipe: vEquipeArena, dpae: vDPAE, batiments: vBatiments, alertes: vAlertes, fil: vFil, materiel: vMateriel, cles: vCles, hors: vHors, dispos: vDispos, "dispos-admin": vDisposAdmin, plangen: vPlanGen, risques: vRisques, coord: vCoord, docs: vDocs, monplanning: vMonPlanning, di: vRap, rap: vRap, rapports: vRapports, direct: vDirect, site: vSite, mc: vMC, incidents: vMC, planning: vPlanning, notifs: vNotifs, rondes: vRondes, memo: vMemo, plus: vPlus, sms: vSms, admin: vAdmin, fiche: vFiche, fiches: vFiches };
async function render() {
  stopScan(); applyChrome();
  const logged = !!S.token;
  $("#tabbar").classList.toggle("hidden", !logged);
  $("#userbar").classList.toggle("hidden", !logged); document.body.classList.toggle("logged", logged);
  if ($("#tabplanif")) $("#tabplanif").classList.toggle("hidden", !(logged && (S.user.voitPlanif || S.user.planif || S.user.niveauPlanif)));
  if (!logged) { document.body.classList.remove("compact"); $("#alertbar").innerHTML = ""; clearInterval(alerteTimer); alerteTimer = null; return vLogin(); }
  if (!notifTimer && admin()) startNotifs();
  if (!S.user.hors) lancerAlertes(); else $("#alertbar").innerHTML = "";
  $("#userchip").textContent = `${S.user.nom} · ${S.user.role === "admin" && !proprio() ? "Administrateur" : S.user.redac && !proprio() ? (S.user.coord ? "Coordinateur PC · Rédaction" : "Superviseur · Rédaction") : ROLE_LBL[S.user.role] || ""}`;
  let r = location.hash.replace(/^#\/?/, "");
  if (r.startsWith("nfc/")) { NFC_EN_ATTENTE = r.slice(4); history.replaceState(null, "", "#/rondes"); r = "rondes"; } // pointeau NFC lu par l'iPhone (lien)
  const forced = S.user.ficheOk === false && S.user.id !== "__admin";
  if (forced) r = "fiche"; // fiche obligatoire à la 1re connexion
  else if (S.user.hors && !["monplanning", "dispos", "fiche", "dossier"].includes(r) && !(r === "dpae" && peutDPAE()) && !(r === "planif" && (S.user.planif || S.user.niveauPlanif))) r = "hors"; // hors vacation : accès limité
  $("#tabbar").classList.toggle("hidden", forced || !!S.user.hors);
  document.body.classList.toggle("compact", r !== ""); document.body.classList.toggle("large", r === "planif");
  document.querySelectorAll("nav.tab a").forEach((a) => a.classList.toggle("on", a.dataset.r === r));
  window.scrollTo(0, 0);
  try { await (ROUTES[r] || vHome)(); } catch (e) { view.innerHTML = `<div class="card"><p>${esc(e.message)}</p></div>`; }
  if (!proprio()) view.querySelectorAll("[data-proprio]").forEach((el) => { if (!(coord() && el.dataset.proprio === "coord")) el.style.display = "none"; }); // seul le propriétaire modifie
  if (lecture()) view.querySelectorAll("[data-action]").forEach((el) => (el.style.display = "none")); // lecture seule
}
window.addEventListener("hashchange", render);
document.addEventListener("click", (e) => { // boutons sans script en ligne (compatibles avec la politique de sécurité CSP)
  const p = e.target.closest("[data-pr]"); if (p) { if (p.dataset.pr === "1") window.print(); else document.getElementById("print")?.remove(); }
  if (e.target.closest("#smslock") && window.__lock) window.__lock();
});
let deferredPrompt = null;
window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); deferredPrompt = e; });
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
if (S.token) api("me").then((u) => { const was = S.user.ficheOk, h = !!S.user.hors; S.user = { ...S.user, ...u, hors: !!u.hors }; if (u.horsMessage) MSG_HORS = u.horsMessage; persist(); if (was !== u.ficheOk || h !== S.user.hors) render(); }).catch(() => {});
render(); loadTextes();
})();
