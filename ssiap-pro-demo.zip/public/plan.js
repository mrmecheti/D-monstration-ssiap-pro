// SSIAP Pro — plan de masse FICTIF (Parc Expo Valmont + Valmont Arena) pour la version de démonstration
// Coordonnées dans le repère du plan (viewBox). Application créée par Rochdi Mecheti
(function () {
  const R = (x1, y1, x2, y2) => `${x1},${y1} ${x2},${y1} ${x2},${y2} ${x1},${y2}`;
  // hall rectangulaire avec un sas d'entrée (décroché) sur un côté
  const H = (x1, y1, x2, y2, cote = "s") => { const mx = (x1 + x2) / 2, my = (y1 + y2) / 2, s = 7;
    if (cote === "s") return `${x1},${y1} ${x2},${y1} ${x2},${y2} ${mx + 9},${y2} ${mx + 9},${y2 + s} ${mx - 9},${y2 + s} ${mx - 9},${y2} ${x1},${y2}`;
    if (cote === "n") return `${x1},${y1} ${mx - 9},${y1} ${mx - 9},${y1 - s} ${mx + 9},${y1 - s} ${mx + 9},${y1} ${x2},${y1} ${x2},${y2} ${x1},${y2}`;
    if (cote === "o") return `${x1},${y1} ${x2},${y1} ${x2},${y2} ${x1},${y2} ${x1},${my + 9} ${x1 - s},${my + 9} ${x1 - s},${my - 9} ${x1},${my - 9}`;
    return `${x1},${y1} ${x2},${y1} ${x2},${my - 9} ${x2 + s},${my - 9} ${x2 + s},${my + 9} ${x2},${my + 9} ${x2},${y2} ${x1},${y2}`; };
  const OCT = (x1, y1, x2, y2, c = 22) => `${x1 + c},${y1} ${x2 - c},${y1} ${x2},${y1 + c} ${x2},${y2 - c} ${x2 - c},${y2} ${x1 + c},${y2} ${x1},${y2 - c} ${x1},${y1 + c}`;
  const Z = [
    // ---- Zone B (nord)
    { id: "accB", nom: "Accueil B", type: "accueil", grp: "B", pts: R(520, 300, 600, 345), surface: 1100, mc: "Accueil B", bat: "Accueil B", extra: "Salles B1 (90 m²) et B2 (110 m²) · Parvis B" },
    { id: "B1", nom: "Hall B1", type: "hall", grp: "B", pts: H(380, 365, 470, 440, "e"), surface: 4800, mc: "B1", bat: "Hall B1" },
    { id: "B4", nom: "Hall B4", type: "hall", grp: "B", pts: H(492, 368, 592, 468, "n"), surface: 7000, mc: "B4", bat: "Hall B4" },
    { id: "B2", nom: "Hall B2", type: "hall", grp: "B", pts: H(615, 365, 760, 470, "o"), surface: 10700, mc: "B2", bat: "Hall B2" },
    { id: "B5", nom: "Hall B5", type: "hall", grp: "B", pts: H(380, 460, 470, 560, "e"), surface: 6300, mc: "B5", bat: "Hall B5" },
    { id: "cc", nom: "Centre de conférences", type: "hall", grp: "B", pts: OCT(495, 488, 590, 560, 12), surface: 3600, mc: "Centre de conférence", bat: "Centre de conférences" },
    { id: "B3", nom: "Hall B3", type: "hall", grp: "B", pts: H(615, 488, 760, 600, "o"), surface: 11500, mc: "B3", bat: "Hall B3" },
    // ---- Zone A (sud)
    { id: "A1", nom: "Hall A1", type: "hall", grp: "A", pts: H(380, 690, 500, 800, "n"), surface: 9300, mc: "A1", bat: "Hall A1" },
    { id: "A2", nom: "Hall A2", type: "hall", grp: "A", pts: H(518, 690, 600, 800, "n"), surface: 6400, mc: "A2", bat: "Hall A2" },
    { id: "A3", nom: "Hall A3", type: "hall", grp: "A", pts: H(618, 690, 760, 795, "n"), surface: 10500, mc: "A3", bat: "Hall A3" },
    { id: "A6", nom: "Hall A6", type: "hall", grp: "A", pts: H(380, 820, 500, 905, "s"), surface: 7200, mc: "A6", bat: "Hall A6", extra: "Salles A5 (40 m²) et A6 (120 m²)" },
    { id: "A5", nom: "Hall A5", type: "hall", grp: "A", pts: H(518, 820, 600, 905, "s"), surface: 4900, mc: "A5", bat: "Hall A5" },
    { id: "A4", nom: "Hall A4", type: "hall", grp: "A", pts: H(618, 815, 760, 905, "s"), surface: 9000, mc: "A4", bat: "Hall A4", extra: "Salle A4 (85 m²)" },
    { id: "accA", nom: "Accueil A", type: "accueil", grp: "A", pts: "470,935 640,935 640,975 600,990 510,990 470,975", surface: 1600, mc: "Accueil A", bat: "Accueil A", extra: "Parvis A · PC sécurité" },
    // ---- Arena (ERP type L)
    { id: "arena", nom: "Valmont Arena", type: "arena", grp: "L", pts: OCT(300, 1010, 470, 1150, 34), surface: 0, mc: "", bat: "Valmont Arena", site: "Valmont Arena", extra: "portes 1 à 8 + PMR" },
    // ---- technique
    { id: "expl", nom: "Service Exploitation", type: "tech", pts: R(292, 380, 352, 445), mc: "" },
    { id: "tech", nom: "Bâtiment technique", type: "tech", pts: R(292, 470, 352, 560), mc: "" },
    // ---- parkings
    { id: "pk1B", nom: "Parking 1B", type: "parking", pts: R(292, 118, 495, 262), surface: 21000, places: 860, mc: "Parking B (accès P6 Rond-point)" },
    { id: "pk2B", nom: "Parking 2B — Ouest", type: "parking", pts: R(625, 118, 805, 262), surface: 18500, places: 760 },
    { id: "pk3B", nom: "Parking 3B — Est", type: "parking", pts: R(292, 590, 352, 670), surface: 3400, places: 130 },
    { id: "pk4A", nom: "Parking 4A — Exposants", type: "parking", pts: R(292, 690, 352, 905), surface: 9100, places: 240 },
    { id: "pk3A", nom: "Parking 3A — VIP Arena", type: "parking", pts: R(300, 1170, 470, 1245), surface: 9000, places: 260 },
    { id: "pk1A", nom: "Parking 1A — Ouest", type: "parking", pts: R(490, 1080, 805, 1240), surface: 35500, places: 1250, mc: "Parking A (Parc)" },
    { id: "pk2A", nom: "Parking 2A — Est", type: "parking", pts: R(490, 1260, 805, 1420), surface: 35500, places: 1250, mc: "Parking A (Parc)" },
    { id: "pkTAM", nom: "Parking tram", type: "parking", pts: R(300, 1265, 470, 1420), surface: 18600, places: 520 },
  ];
  globalThis.PLAN_SITE = {
    vb: [255, 80, 670, 1400],
    zones: Z,
    reperes: [
      { t: "ENTRÉE B", x: 560, y: 285, c: "entree" },
      { t: "ENTRÉE A", x: 555, y: 1030, c: "entree" },
      { t: "Portail 3 (P3)", x: 279, y: 684, c: "portail", id: "p3", mc: "P3 (par l'avenue des Pins)" },
      { t: "Place des Arts", x: 680, y: 345, c: "rue" },
      { t: "Mail central", x: 570, y: 650, c: "rue" },
      { t: "Allée des Tilleuls", x: 481, y: 460, c: "rue", r: -90 },
      { t: "Allée des Cèdres", x: 604, y: 480, c: "rue", r: -90 },
      { t: "Allée des Platanes", x: 570, y: 813, c: "rue" },
      { t: "Allée des Saules", x: 509, y: 860, c: "rue", r: -90 },
      { t: "Allée des Ormes", x: 609, y: 860, c: "rue", r: -90 },
      { t: "Avenue des Pins", x: 268, y: 640, c: "rue", r: -90 },
      { t: "Boulevard des Expositions", x: 848, y: 700, c: "rue", r: -90 },
      { t: "Square des Fontaines", x: 700, y: 1062, c: "rue" },
      { t: "Station tram Parc Expo", x: 848, y: 1330, c: "rue", r: -90 },
      { t: "Zone d'activités", x: 892, y: 1100, c: "voisin", r: -90 },
    ],
    dae: [
      { id: "dae-pcs", lieu: "PC sécurité (PCS)", detail: "Accueil A, couloir du PC sécurité, à gauche en entrant", photo: "", x: 488, y: 972 },
      { id: "dae-expl", lieu: "Service d'exploitation", detail: "Hall d'entrée du service d'exploitation", x: 344, y: 437 },
      { id: "dae-accB", lieu: "Accueil B", detail: "À l'accueil B, derrière la banque d'accueil", x: 590, y: 336 },
    ],
    contour: "282,100 830,100 860,130 860,1445 830,1460 282,1460 270,1440 270,120",
    verts: [R(370, 272, 512, 352), R(608, 272, 760, 352), R(370, 575, 600, 625), R(612, 612, 770, 628), "650,1000 770,1000 770,1070 650,1070", R(365, 920, 460, 995), R(370, 1155, 480, 1162)],
    eau: ["548,590 572,590 578,600 572,610 548,610 542,600"],
    lac: "662,1012 700,1006 742,1012 758,1030 745,1052 700,1060 662,1050 652,1030",
    voies: [
      "M840,90 L840,1465",
      "M280,92 L280,1462",
      "M362,640 L780,640 L840,640",
      "M280,1000 L470,1000",
      "M480,1252 L840,1252",
      "M560,995 L560,1080",
    ],
    infosType: { hall: "Hall d'exposition — ERP type T", accueil: "Accueil / hall d'entrée — ERP type T", arena: "Salle de spectacle — ERP type L", parking: "Parking", tech: "Bâtiment technique — accès réservé" },
  };
})();
