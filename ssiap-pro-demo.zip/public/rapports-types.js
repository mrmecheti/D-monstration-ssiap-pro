// SSIAP Pro — types de rapports terrain (SSIAP / ADS). Utilisé par l'appli ET par le serveur.
// Application créée par Rochdi Mecheti
// Champ : [libellé, type, options]  — s = liste, c = cases à cocher, x = texte, h = heure
(function () {
const ON = ["Non", "Oui"];
const VICTIME = ["Homme", "Femme", "Enfant"];
const PEC = ["Laissée sur place après avis", "Poste de secours", "Évacuée par les pompiers", "Évacuée par le SAMU", "Partie par ses propres moyens", "Refus de prise en charge"];
const GESTES = ["PLS", "Massage cardiaque", "DAE posé", "Compression / pansement", "Mise au repos", "Couverture", "Brûlure refroidie", "Immobilisation"];
const SIGN = ["Signalement (tenue, taille, signes distinctifs)", "x"];
const DI = ["Issue de secours / porte coupe-feu", "Moyens de secours (extincteur, RIA, DAE)", "Éclairage / BAES", "SSI / détection / désenfumage",
  "Électricité", "Fuite d'eau / plomberie", "Sanitaires / propreté", "Ascenseur / escalator", "Chauffage / climatisation",
  "Porte / serrure / portail / barrière", "Vidéo / contrôle d'accès / radio", "Voirie / parking / signalétique", "Mobilier / structure / stand", "Autre anomalie"];
globalThis.RAP_CATS = [
 { cat: "🚑 Secours à personne", types: [
  { k: "malaise", ic: "🚑", lb: "Malaise / secours à personne", pre: "MAL", grav: "moyenne", champs: [["Victime", "s", VICTIME], ["Âge approximatif", "x"], ["Nom de la victime (si connu)", "x"],
    ["État constaté", "c", ["Consciente", "Inconsciente", "Respire", "Ne respire pas", "Saigne", "Malaise chaleur", "Crise (épilepsie, diabète…)"]], ["Gestes effectués", "c", GESTES], ["Prise en charge", "s", PEC]] },
  { k: "blessure", ic: "🩹", lb: "Blessure / chute", pre: "BLE", grav: "moyenne", champs: [["Victime", "s", VICTIME], ["Âge approximatif", "x"], ["Type de blessure", "c", ["Chute", "Coupure / plaie", "Brûlure", "Entorse / fracture possible", "Choc à la tête", "Écrasement / coincement"]],
    ["Cause", "x"], ["Gestes effectués", "c", GESTES], ["Prise en charge", "s", PEC]] },
  { k: "arret", ic: "❤️", lb: "Arrêt cardiaque / DAE", pre: "ACR", grav: "urgente", champs: [["Victime", "s", VICTIME], ["Âge approximatif", "x"], ["Heure de début du massage", "h"], ["DAE posé", "s", ON], ["Nombre de chocs délivrés", "x"],
    ["Heure d'arrivée des secours", "h"], ["Issue", "s", ["Reprise d'activité cardiaque", "Évacuée par le SAMU / pompiers", "Décès constaté par les secours"]]] },
  { k: "secours", ic: "🚒", lb: "Intervention secours extérieurs", pre: "SEC", grav: "moyenne", champs: [["Service", "c", ["Pompiers (18)", "SAMU (15)", "Police (17)", "Ambulance privée"]], ["Motif", "x"], ["Heure d'appel", "h"], ["Heure d'arrivée", "h"],
    ["Accès utilisé / point de rendez-vous", "x"], ["Agent qui a guidé les secours", "x"], ["Heure de départ", "h"]] },
  { k: "ivresse", ic: "🍺", lb: "Ivresse / stupéfiants", pre: "IVR", champs: [["Personne", "x"], ["Issue", "s", ["Mise à l'écart / surveillance", "Exclue du site", "Prise en charge secours", "Remise à la police"]]] },
  { k: "perdu", ic: "🧒", lb: "Personne perdue / enfant égaré", pre: "PER", grav: "moyenne", champs: [["Prénom, âge, description", "x"], ["Dernier endroit vu", "x"], ["Retrouvé(e)", "s", ON], ["Heure où retrouvé(e)", "h"], ["Remis(e) à", "x"]] },
 ]},
 { cat: "🔥 Incendie / SSI", types: [
  { k: "alarme", ic: "🔔", lb: "Alarme incendie / levée de doute", pre: "ALA", grav: "moyenne", champs: [["Origine", "s", ["Détecteur automatique", "Déclencheur manuel", "Sprinkler", "Désenfumage", "Autre"]], ["Zone / détecteur", "x"],
    ["Heure de l'alarme", "h"], ["Heure d'arrivée sur place", "h"], ["Résultat", "s", ["Fausse alarme", "Feu confirmé", "Travaux / poussière / fumée de cuisson", "Malveillance", "Cause inconnue"]], ["Réarmement effectué", "s", ON]] },
  { k: "feu", ic: "🔥", lb: "Départ de feu / feu", pre: "FEU", grav: "urgente", champs: [["Localisation précise", "x"], ["Moyens utilisés", "c", ["Extincteur eau", "Extincteur CO₂", "Extincteur poudre", "RIA", "Couverture anti-feu", "Aucun"]],
    ["Feu éteint par les agents", "s", ON], ["Pompiers appelés", "s", ON], ["Évacuation", "s", ["Aucune", "Partielle", "Totale"]], ["Victimes", "x"]] },
  { k: "odeur", ic: "👃", lb: "Odeur de fumée / brûlé / gaz", pre: "ODE", grav: "moyenne", champs: [["Type d'odeur", "s", ["Fumée / brûlé", "Gaz", "Produit chimique", "Autre"]], ["Origine trouvée", "x"], ["Mesures", "c", ["Zone évacuée", "Gaz coupé", "Électricité coupée", "Aération", "Pompiers appelés"]]] },
  { k: "ssi", ic: "🖥️", lb: "Défaut / dérangement SSI", pre: "SSI", grav: "moyenne", champs: [["Type", "s", ["Dérangement CMSI / ECS", "Défaut alimentation", "Défaut ligne / boucle", "Détecteur hors service", "Désenfumage en défaut", "Autre"]], ["Zone / équipement", "x"],
    ["Technicien / mainteneur prévenu", "s", ON], ["Mesure compensatoire", "c", ["Ronde renforcée", "Agent en poste fixe", "Information du responsable"]]] },
  { k: "isolement", ic: "🔕", lb: "Mise hors service / isolement SSI", pre: "ISO", champs: [["Zone isolée", "x"], ["Raison", "s", ["Travaux", "Permis de feu", "Montage / démontage", "Défaut", "Essai"]], ["Demandeur", "x"],
    ["Heure d'isolement", "h"], ["Heure de remise en service", "h"], ["Mesure compensatoire", "c", ["Ronde renforcée", "Agent en surveillance", "Extincteur à proximité"]]] },
  { k: "permisfeu", ic: "🧑‍🏭", lb: "Permis de feu", pre: "PDF", champs: [["Entreprise", "x"], ["Nature des travaux", "s", ["Soudure", "Découpe / meulage", "Chalumeau", "Autre point chaud"]], ["Zone", "x"], ["Heure de début", "h"], ["Heure de fin", "h"],
    ["Surveillance après travaux", "s", ["Faite (2 h)", "En cours", "Non faite"]], ["Extincteur sur place", "s", ON]] },
  { k: "extincteur", ic: "🧯", lb: "Extincteur utilisé / manquant / déplacé", pre: "EXT", champs: [["Problème", "s", ["Utilisé", "Manquant", "Déplacé", "Goupille absente / percuté", "Accès encombré", "Vérification dépassée"]], ["N° ou emplacement", "x"], ["Type", "s", ["Eau", "CO₂", "Poudre", "Autre"]]] },
  { k: "issue", ic: "🚪", lb: "Issue de secours encombrée / bloquée", pre: "ISS", grav: "moyenne", champs: [["Issue", "x"], ["Problème", "s", ["Encombrée", "Verrouillée / cadenassée", "Bloquée par un stand / matériel", "Signalétique absente", "Ferme-porte HS", "Calée ouverte (porte coupe-feu)"]], ["Remise en conformité", "s", ["Faite immédiatement", "Demandée à l'exposant / organisateur", "À faire"]]] },
  { k: "desenfumage", ic: "💨", lb: "Désenfumage déclenché", pre: "DES", champs: [["Zone / canton", "x"], ["Déclenchement", "s", ["Automatique", "Manuel", "Intempestif"]], ["Réarmement", "s", ON]] },
  { k: "ascenseur", ic: "🛗", lb: "Personne bloquée dans un ascenseur", pre: "ASC", grav: "moyenne", champs: [["Ascenseur", "x"], ["Nombre de personnes", "x"], ["Heure d'appel de l'ascensoriste", "h"], ["Heure de délivrance", "h"], ["État des personnes", "x"]] },
  { k: "exercice", ic: "📣", lb: "Exercice d'évacuation", pre: "EXE", champs: [["Zone", "x"], ["Heure de déclenchement", "h"], ["Durée d'évacuation", "x"], ["Effectif évacué", "x"], ["Observations", "x"]] },
  { k: "evacuation", ic: "🏃", lb: "Évacuation réelle", pre: "EVA", grav: "urgente", champs: [["Zone évacuée", "x"], ["Motif", "x"], ["Nombre de personnes", "x"], ["Heure de début", "h"], ["Heure de réintégration", "h"]] },
 ]},
 { cat: "🛡️ Sûreté / malveillance", types: [
  { k: "rixe", ic: "🥊", lb: "Rixe / bagarre", pre: "RIX", grav: "moyenne", champs: [["Nombre de personnes", "x"], ["Blessé(s)", "s", ON], ["Issue", "s", ["Séparés par les agents", "Exclus du site", "Remis à la police", "Auteurs en fuite"]], SIGN] },
  { k: "agression", ic: "🚨", lb: "Agression / violence", pre: "AGR", grav: "moyenne", champs: [["Victime", "s", ["Agent de sécurité", "Visiteur", "Exposant / staff", "Autre"]], ["Blessé(s)", "s", ON], ["Auteur", "s", ["Maîtrisé / remis à la police", "En fuite", "Identifié"]], SIGN] },
  { k: "incivilite", ic: "🗯️", lb: "Insultes / menaces / incivilité", pre: "INC", champs: [["Visé(e)", "s", ["Agent de sécurité", "Visiteur", "Exposant / staff"]], ["Propos tenus (mot pour mot)", "x"], ["Suite", "s", ["Recadrage verbal", "Exclusion", "Police prévenue", "Personne partie"]], SIGN] },
  { k: "harcelement", ic: "🙅", lb: "Harcèlement / comportement déplacé", pre: "HAR", grav: "moyenne", champs: [["Victime prise en charge", "s", ON], ["Auteur", "s", ["Identifié", "Exclu", "Remis à la police", "En fuite"]], SIGN] },
  { k: "intrusion", ic: "🚷", lb: "Intrusion", pre: "INT", grav: "moyenne", champs: [["Point d'entrée", "x"], ["Nombre de personnes", "x"], ["Issue", "s", ["Raccompagné(s) vers la sortie", "Remis à la police", "En fuite", "Recherche en cours"]], SIGN] },
  { k: "forcing", ic: "🏃", lb: "Forcing / passage en force", pre: "FOR", grav: "moyenne", champs: [["Accès forcé", "x"], ["Nombre de personnes", "x"], ["Issue", "s", ["Rattrapé(s) et contrôlé(s)", "Exclu(s) du site", "Non rattrapé(s)", "Remis à la police"]], SIGN] },
  { k: "vol", ic: "👜", lb: "Vol / tentative de vol", pre: "VOL", champs: [["Objet volé", "x"], ["Victime", "x"], ["Auteur", "s", ["Interpellé", "En fuite", "Inconnu"]], ["Plainte", "s", ["Victime orientée vers la police", "Déjà déposée", "Non"]]] },
  { k: "degradation", ic: "🔨", lb: "Dégradation / tags / vandalisme", pre: "DEG", champs: [["Bien dégradé", "x"], ["Auteur identifié", "s", ON]] },
  { k: "interpellation", ic: "👮", lb: "Interpellation (art. 73 CPP)", pre: "IPL", grav: "urgente", champs: [["Motif (flagrant délit)", "x"], ["Heure de l'interpellation", "h"], ["Heure d'appel police (17)", "h"], ["Heure de remise à l'OPJ", "h"], ["Service / nom de l'OPJ", "x"], SIGN] },
  { k: "suspect", ic: "👁️", lb: "Comportement suspect", pre: "SUS", champs: [SIGN, ["Suite donnée", "s", ["Surveillance", "Contrôle / échange", "Signalé à la police", "Personne partie"]]] },
  { k: "objet", ic: "🎒", lb: "Objet suspect / colis abandonné", pre: "OBJ", grav: "moyenne", champs: [["Description de l'objet", "x"], ["Périmètre de sécurité", "s", ON], ["Levée de doute", "s", ["Propriétaire retrouvé", "Police / déminage appelés", "En cours"]]] },
  { k: "menace", ic: "☎️", lb: "Menace / alerte attentat / appel malveillant", pre: "MEN", grav: "urgente", champs: [["Forme", "s", ["Appel téléphonique", "Courrier / mail", "Oral sur place", "Réseaux sociaux"]], ["Contenu exact", "x"], ["Heure", "h"], ["Police prévenue", "s", ON]] },
  { k: "vehicule", ic: "🚗", lb: "Véhicule suspect / stationnement gênant", pre: "VEH", champs: [["Immatriculation", "x"], ["Marque / modèle / couleur", "x"], ["Problème", "s", ["Véhicule suspect", "Stationnement sur voie pompiers", "Stationnement gênant", "Véhicule ventouse"]], ["Suite", "s", ["Propriétaire retrouvé", "Fourrière demandée", "Police prévenue", "En attente"]]] },
  { k: "drone", ic: "🛸", lb: "Survol de drone", pre: "DRO", grav: "moyenne", champs: [["Zone survolée", "x"], ["Télépilote localisé", "s", ON], ["Police prévenue", "s", ON]] },
  { k: "rassemblement", ic: "📢", lb: "Manifestation / rassemblement", pre: "RAS", grav: "moyenne", champs: [["Nombre de personnes", "x"], ["Motif / banderoles", "x"], ["Police prévenue", "s", ON]] },
  { k: "sauvette", ic: "🎫", lb: "Vente à la sauvette / revente de billets", pre: "SAU", champs: [["Marchandise", "x"], ["Suite", "s", ["Éloigné(s)", "Police prévenue", "Parti(s)"]], SIGN] },
  { k: "animal", ic: "🐕", lb: "Animal errant / dangereux", pre: "ANI", champs: [["Animal", "x"], ["Suite", "s", ["Capturé / isolé", "Fourrière / mairie prévenue", "Propriétaire retrouvé", "Parti"]]] },
 ]},
 { cat: "🎟️ Accès / filtrage", types: [
  { k: "refus", ic: "⛔", lb: "Refus d'entrée", pre: "REF", champs: [["Motif", "s", ["Sans billet / accréditation", "Ivresse manifeste", "Objet interdit", "Refus de palpation / inspection", "Comportement agressif", "Personne interdite de site", "Mineur non accompagné", "Tenue / signe interdit", "Autre"]], ["Nombre de personnes", "x"], ["Réaction", "s", ["Calme", "Contestation verbale", "Insultes / menaces", "Tentative de forcing"]]] },
  { k: "saisie", ic: "🔪", lb: "Objet interdit découvert / consigné", pre: "SAI", champs: [["Objet", "s", ["Arme blanche", "Arme / réplique", "Bouteille / verre", "Fumigène / pyrotechnie", "Stupéfiants", "Alcool", "Bombe lacrymogène", "Drone", "Autre"]], ["Description", "x"],
    ["Suite", "s", ["Consigné (récupérable)", "Abandonné / détruit", "Remis à la police", "Refus d'entrée"]]] },
  { k: "fraude", ic: "🎟️", lb: "Billet / badge frauduleux ou invalide", pre: "FRA", champs: [["Type", "s", ["Billet déjà scanné", "Faux billet", "Badge / accréditation prêté", "Badge expiré / mauvaise zone"]], ["Suite", "s", ["Refus d'entrée", "Renvoyé à la billetterie", "Régularisé"]]] },
  { k: "livraison", ic: "🚚", lb: "Livraison / accès véhicule", pre: "LIV", champs: [["Société", "x"], ["Immatriculation", "x"], ["Destination", "x"], ["Heure d'entrée", "h"], ["Heure de sortie", "h"], ["Contrôle du véhicule", "s", ["Fait, RAS", "Fait, anomalie", "Non fait"]]] },
  { k: "cles", ic: "🔑", lb: "Remise / restitution de clés ou badges", pre: "CLE", champs: [["Clé / badge n°", "x"], ["Opération", "s", ["Remise", "Restitution", "Perte signalée"]], ["Personne / société", "x"], ["Heure", "h"]] },
  { k: "jauge", ic: "👥", lb: "Mouvement de foule / saturation", pre: "JAU", grav: "moyenne", champs: [["Zone", "x"], ["Effectif estimé", "x"], ["Mesures", "c", ["Fermeture temporaire de l'accès", "Fluidification / déviation", "Renfort d'agents", "Annonce sonore", "Information de l'organisateur"]]] },
  { k: "ouverture", ic: "🔓", lb: "Ouverture / fermeture du site ou d'un hall", pre: "OUV", champs: [["Opération", "s", ["Ouverture", "Fermeture"]], ["Zone / hall", "x"], ["Vérifications", "c", ["Issues de secours libres", "SSI normal (pas de défaut)", "Éclairage de sécurité OK", "Personne restée à l'intérieur", "Portes / portails verrouillés", "Alarme intrusion activée"]]] },
 ]},
 { cat: "🛠️ Technique / DI", types: [
  { k: "di", ic: "🛠️", lb: "DI – défaut technique / anomalie", pre: "DI", champs: [["Type de défaut", "s", DI], ["Intervention Elektra", "s", ["Non urgent", "Urgent sans déplacement d'astreinte", "Urgent avec déplacement d'astreinte"]], ["Référence Elektra communiquée", "x"], ["N° de l'appareil (ascenseur…)", "x"]] },
  { k: "coupure", ic: "⚡", lb: "Coupure électrique / panne", pre: "COU", grav: "moyenne", champs: [["Zone touchée", "x"], ["Heure de coupure", "h"], ["Heure de rétablissement", "h"], ["Éclairage de sécurité OK", "s", ON], ["Technicien prévenu", "s", ON]] },
  { k: "eau", ic: "💧", lb: "Fuite / inondation / dégât des eaux", pre: "EAU", grav: "moyenne", champs: [["Origine", "x"], ["Mesures", "c", ["Zone balisée", "Eau coupée", "Électricité coupée", "Matériel protégé", "Technicien prévenu"]]] },
  { k: "porte", ic: "🚪", lb: "Porte / accès trouvé ouvert", pre: "POR", champs: [["Porte / accès", "x"], ["Constat", "s", ["Ouvert sans raison", "Serrure forcée", "Calé ouvert", "Ne ferme plus"]], ["Action", "s", ["Refermé", "Signalé à la technique", "Agent laissé en surveillance"]]] },
  { k: "intrusionalarme", ic: "🚨", lb: "Alarme intrusion / anti-intrusion", pre: "AIN", champs: [["Zone", "x"], ["Résultat de la levée de doute", "s", ["Fausse alarme", "Intrusion constatée", "Personnel autorisé (oubli de code)", "Cause inconnue"]], ["Réarmement", "s", ON]] },
  { k: "radio", ic: "📻", lb: "Défaut vidéo / radio / téléphone", pre: "RAD", champs: [["Équipement", "s", ["Caméra", "Enregistreur vidéo", "Radio / talkie", "Téléphone PC", "Interphone", "Contrôle d'accès"]], ["Repère / emplacement", "x"]] },
 ]},
 { cat: "🔦 Rondes / exploitation", types: [
  { k: "ronde", ic: "🔦", lb: "Rapport de ronde", pre: "RON", champs: [["Type de ronde", "s", ["Ouverture", "Fermeture", "Nuit", "Sécurité incendie", "Sûreté / périmétrique", "Parking"]], ["Heure de début", "h"], ["Heure de fin", "h"], ["Anomalies relevées", "s", ["Aucune (RAS)", "Oui, voir déroulé"]]] },
  { k: "releve", ic: "🤝", lb: "Relève / passation de consignes", pre: "REL", champs: [["Relevé par / relève de", "x"], ["Matériel remis", "c", ["Radio", "Clés", "Badge", "Téléphone", "Lampe", "Main courante papier"]], ["Consignes transmises", "x"]] },
  { k: "consigne", ic: "📌", lb: "Consigne reçue / information", pre: "CON", champs: [["Donnée par", "x"], ["Valable jusqu'à", "x"]] },
  { k: "travaux", ic: "🏗️", lb: "Travaux / entreprise extérieure", pre: "TRA", champs: [["Entreprise", "x"], ["Zone", "x"], ["Plan de prévention / autorisation", "s", ON], ["Heure d'arrivée", "h"], ["Heure de départ", "h"]] },
  { k: "prestataire", ic: "🏢", lb: "Problème avec un prestataire", pre: "PRE", champs: [["Problème", "x"]] },
  { k: "meteo", ic: "⛈️", lb: "Intempérie / alerte météo", pre: "MET", grav: "moyenne", champs: [["Phénomène", "s", ["Vent fort", "Orage", "Pluie intense / inondation", "Canicule", "Grêle", "Brouillard"]], ["Mesures", "c", ["Structures / barrières sécurisées", "Zone fermée", "Public mis à l'abri", "Organisateur informé"]]] },
  { k: "accident", ic: "🚙", lb: "Accident / accrochage sur parking", pre: "ACC", champs: [["Véhicules (immatriculations)", "x"], ["Blessé(s)", "s", ON], ["Constat amiable", "s", ON], ["Police / secours", "s", ON]] },
  { k: "reclamation", ic: "🗣️", lb: "Réclamation visiteur / exposant", pre: "REC", champs: [["Personne", "x"], ["Objet de la réclamation", "x"], ["Suite", "s", ["Réglé sur place", "Orienté vers l'organisateur", "Transmis au responsable"]]] },
  { k: "trouve", ic: "🔍", lb: "Objet trouvé", pre: "OBT", champs: [["Objet", "x"], ["Lieu de découverte", "x"], ["Remis à", "x"]] },
  { k: "incident", ic: "⚠️", lb: "Incident", pre: "IND", champs: [["Nature de l'incident", "x"], ["Personnes impliquées", "x"], ["Dommages", "s", ["Aucun", "Matériel", "Corporel", "Matériel et corporel"]]] },
  { k: "autre", ic: "📝", lb: "Autre rapport", pre: "RAP", champs: [] },
 ]},
];
})();
