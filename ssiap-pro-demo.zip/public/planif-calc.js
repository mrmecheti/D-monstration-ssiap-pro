// SSIAP Pro — planification : calcul des heures, contrôles réglementaires et devis. Utilisé par l'appli ET par le serveur.
// Contrôles signalés (rien n'est modifié) : Code du travail + CCN Prévention et sécurité (brochure 3196, IDCC 1351).
// Application créée par Rochdi Mecheti
(function () {
  const pad = (n) => String(n).padStart(2, "0");
  const iso = (d) => `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())}`;
  const jour = (s) => new Date(s + "T00:00:00Z");
  const min = (hm) => { const [h, m] = String(hm || "0:0").split(":").map(Number); return (h || 0) * 60 + (m || 0); };
  // jours fériés en France (fixes + Pâques)
  const feriesCache = {};
  function feries(an) {
    if (feriesCache[an]) return feriesCache[an];
    const a = an % 19, b = Math.floor(an / 100), c = an % 100, d = Math.floor(b / 4), e = b % 4, f = Math.floor((b + 8) / 25), g = Math.floor((b - f + 1) / 3),
      h = (19 * a + b - d - g + 15) % 30, i = Math.floor(c / 4), k = c % 4, l = (32 + 2 * e + 2 * i - h - k) % 7, m = Math.floor((a + 11 * h + 22 * l) / 451),
      mois = Math.floor((h + l - 7 * m + 114) / 31), j = ((h + l - 7 * m + 114) % 31) + 1, paques = Date.UTC(an, mois - 1, j);
    const plus = (n) => iso(new Date(paques + n * 864e5));
    return (feriesCache[an] = new Set([`${an}-01-01`, plus(1), `${an}-05-01`, `${an}-05-08`, plus(39), plus(50), `${an}-07-14`, `${an}-08-15`, `${an}-11-01`, `${an}-11-11`, `${an}-12-25`]));
  }
  const estFerie = (s) => feries(+s.slice(0, 4)).has(s);
  // une vacation : début, fin (le lendemain si fin <= début), durée et répartition des heures
  function vacation(v, nuit = ["21:00", "06:00"]) {
    const d0 = min(v.debut), d1 = min(v.fin), duree = (d1 > d0 ? d1 - d0 : d1 + 1440 - d0) || 0;
    const debut = jour(v.date).getTime() + d0 * 60e3, fin = debut + duree * 60e3;
    let hNuit = 0, hDim = 0, hFer = 0; const n0 = min(nuit[0]), n1 = min(nuit[1]);
    for (let t = 0; t < duree; t += 15) { // par quart d'heure
      const dt = new Date(debut + t * 60e3), m = dt.getUTCHours() * 60 + dt.getUTCMinutes(), j = iso(dt), q = Math.min(15, duree - t) / 60;
      if (n0 > n1 ? m >= n0 || m < n1 : m >= n0 && m < n1) hNuit += q;
      if (estFerie(j)) hFer += q; else if (dt.getUTCDay() === 0) hDim += q;
    }
    return { debut, fin, heures: duree / 60, hNuit, hDim, hFer };
  }
  const lundi = (t) => { const d = new Date(t); const w = (d.getUTCDay() + 6) % 7; return iso(new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - w))); };
  const cleAgent = (n) => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toUpperCase().split(/[\s().,-]+/).filter(Boolean).sort().join(" ");
  // contrôles : rouge = règle dépassée, orange = à vérifier
  function controles(lignes) {
    const par = {}, out = [];
    for (const v of lignes) { if (!v.nom || !v.debut || !v.fin) continue; (par[cleAgent(v.nom)] ||= []).push({ v, ...vacation(v) }); }
    for (let liste of Object.values(par)) {
      liste.sort((a, b) => a.debut - b.debut); const nom = liste[0].v.nom;
      const add = (niveau, type, texte, items, date) => out.push({ niveau, type, nom, texte, date, ids: items.map((x) => x.v.id).filter(Boolean) });
      // doublons exacts ignorés ; vacations qui se touchent (pause < 1 h) = une même période de travail
      const vus = new Set(); liste = liste.filter((x) => { const k = x.debut + "|" + x.fin; if (vus.has(k)) return false; vus.add(k); return true; });
      const per = [];
      for (const x of liste) { const p = per[per.length - 1], gap = p ? (x.debut - p.fin) / 36e5 : 99;
        if (p && gap < 0) add("rouge", "chevauchement", `Deux vacations se chevauchent (${p.items[p.items.length - 1].v.date} ${p.items[p.items.length - 1].v.debut}-${p.items[p.items.length - 1].v.fin} et ${x.v.date} ${x.v.debut}-${x.v.fin})`, [p.items[p.items.length - 1], x], x.v.date);
        if (p && gap < 1) { p.fin = Math.max(p.fin, x.fin); p.items.push(x); } else per.push({ debut: x.debut, fin: x.fin, items: [x] }); }
      // durée d'une période de travail > 12 h (CCN 3196)
      for (const p of per) { const h = (p.fin - p.debut) / 36e5; if (h > 12) add("rouge", "vacation12", `${p.items.length > 1 ? "Vacations enchaînées" : "Vacation"} de ${h.toFixed(1).replace(".0", "")} h : plus de 12 h`, p.items, p.items[0].v.date); }
      // repos quotidien < 11 h entre deux périodes de travail
      for (let i = 1; i < per.length; i++) { const a = per[i - 1], b = per[i], gap = (b.debut - a.fin) / 36e5;
        if (gap < 11) add("rouge", "repos11", `Repos de ${gap.toFixed(1).replace(".0", "")} h seulement entre deux vacations (11 h minimum)`, [...a.items.slice(-1), b.items[0]], b.items[0].v.date); }
      // 48 h par semaine (lundi-dimanche)
      const sem = {}; for (const x of liste) (sem[lundi(x.debut)] ||= []).push(x);
      const hSem = {};
      for (const [l, xs] of Object.entries(sem)) { const h = xs.reduce((s, x) => s + x.heures, 0); hSem[l] = h;
        if (h > 48) add("rouge", "hebdo48", `${h.toFixed(1).replace(".0", "")} h la semaine du ${l.split("-").reverse().join("/")} : plus de 48 h`, xs, l); }
      // un dimanche sur deux : deux dimanches travaillés de suite
      const dims = [...new Set(liste.filter((x) => x.hDim + x.hFer > 0 && (new Date(x.debut).getUTCDay() === 0 || new Date(x.fin - 1).getUTCDay() === 0)).map((x) => iso(new Date(new Date(x.debut).getUTCDay() === 0 ? x.debut : x.fin - 1))))].sort();
      for (let i = 1; i < dims.length; i++) if ((jour(dims[i]) - jour(dims[i - 1])) / 864e5 === 7)
        add("rouge", "dimanche", `Deux dimanches travaillés de suite (${dims[i - 1].split("-").reverse().join("/")} et ${dims[i].split("-").reverse().join("/")}) : un dimanche sur deux doit être libre`,
          liste.filter((x) => [dims[i - 1], dims[i]].includes(iso(new Date(x.debut))) || [dims[i - 1], dims[i]].includes(iso(new Date(x.fin - 1)))), dims[i]);
      // à vérifier : plus de 6 jours travaillés de suite, moyenne > 46 h sur 12 semaines
      const jours = [...new Set(liste.map((x) => x.v.date))].sort(); let suite = 1;
      for (let i = 1; i < jours.length; i++) { suite = (jour(jours[i]) - jour(jours[i - 1])) / 864e5 === 1 ? suite + 1 : 1;
        if (suite === 7) add("orange", "jours6", `7 jours travaillés de suite (jusqu'au ${jours[i].split("-").reverse().join("/")}) : vérifier le repos hebdomadaire`, liste.filter((x) => x.v.date <= jours[i] && x.v.date >= jours[i - 6]), jours[i]); }
      const semaines = Object.keys(hSem).sort();
      for (const l of semaines) { const fen = semaines.filter((s) => s <= l && (jour(l) - jour(s)) / 864e5 < 84); if (fen.length < 12) continue;
        const moy = fen.reduce((s, k) => s + hSem[k], 0) / 12; if (moy > 46) add("orange", "moyenne46", `Moyenne de ${moy.toFixed(1)} h sur 12 semaines : plus de 46 h`, [], l); }
    }
    return out;
  }
  // jours couverts par une ligne de devis : à l'événement (du … au) ou au mois (jours de la semaine cochés)
  function joursLigne(l, dv = {}) {
    let du, au;
    if (dv.mode === "mois" && /^\d{4}-\d{2}$/.test(dv.mois || "")) { const [y, m] = dv.mois.split("-").map(Number); du = `${dv.mois}-01`; au = iso(new Date(Date.UTC(y, m, 0))); }
    else { du = l.date; au = l.au && l.au >= l.date ? l.au : l.date; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(du || "")) return [];
    const js = Array.isArray(l.jours) && l.jours.length ? l.jours.map(Number) : [0, 1, 2, 3, 4, 5, 6], out = [];
    for (let t = jour(du).getTime(), fin = jour(au).getTime(); t <= fin && out.length < 400; t += 864e5) { const d = new Date(t); if (js.includes(d.getUTCDay())) out.push(iso(d)); }
    return out;
  }
  // devis : heures × tarif (champ libre) + majorations nuit / dimanche / férié, calculé à l'événement ou au mois
  function calcDevis(dv, tarifs = {}) {
    const taux = tarifs.taux || {}, maj = (k) => (parseFloat(String(tarifs[k] ?? "").replace(",", ".")) || 0) / 100, nuit = [tarifs.nuitDebut || "21:00", tarifs.nuitFin || "06:00"];
    const parQualif = {};
    const lignes = (dv.lignes || []).map((l) => {
      const dates = joursLigne(l, dv), nb = Math.max(0, parseInt(l.nb) || 0); let heures = 0, hNuit = 0, hDim = 0, hFer = 0;
      for (const date of dates) { const v = vacation({ date, debut: l.debut, fin: l.fin }, nuit); heures += v.heures; hNuit += v.hNuit; hDim += v.hDim; hFer += v.hFer; }
      const grille = l.chef ? (tarifs.tauxChef || {})[l.qualif] : taux[l.qualif], brut = String(l.taux ?? "").trim() !== "" ? l.taux : grille; const t = parseFloat(String(brut ?? "").replace(",", "."));
      const tx = Number.isFinite(t) ? t : 0, base = heures * tx, majo = hNuit * tx * maj("majNuit") + hDim * tx * maj("majDimanche") + hFer * tx * maj("majFerie");
      const r = { ...l, chef: !!l.chef, nb, nbJours: dates.length, du: dates[0] || "", auR: dates[dates.length - 1] || "", heures, hNuit, hDim, hFer, taux: tx, tarifManquant: !Number.isFinite(t), montant: Math.round(nb * (base + majo) * 100) / 100 };
      const k = (l.qualif || "—") + (l.chef ? " · chef d'équipe" : ""), q = (parQualif[k] ||= { qualif: k, agents: 0, vacations: 0, heures: 0, montant: 0 });
      q.agents += nb; q.vacations += nb * dates.length; q.heures += nb * heures; q.montant = Math.round((q.montant + r.montant) * 100) / 100;
      return r;
    });
    const frais = (dv.frais || []).reduce((s, f) => s + (parseFloat(String(f.montant || 0).replace(",", ".")) || 0), 0);
    const sous = lignes.reduce((s, l) => s + l.montant, 0) + frais, remise = sous * ((parseFloat(String(dv.remise || 0).replace(",", ".")) || 0) / 100);
    const ht = Math.round((sous - remise) * 100) / 100, tva = 0; // montants hors taxes (pas de TVA)
    return { lignes, parQualif: Object.values(parQualif), frais, remise: Math.round(remise * 100) / 100, ht, tva, ttc: Math.round((ht + tva) * 100) / 100, heures: lignes.reduce((s, l) => s + l.nb * l.heures, 0), manquants: lignes.some((l) => l.tarifManquant) };
  }
  globalThis.PLANIF = { vacation, controles, calcDevis, joursLigne, feries, estFerie, lundi, cleAgent, iso };
})();
