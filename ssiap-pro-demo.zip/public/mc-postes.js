// SSIAP Pro — main courante par poste (familles / types repris de la main courante Guardtek du site, priorité 1 à 4)
// Application créée par Rochdi Mecheti
(function () {
const PEX = " (réf. PEX PEX-0001)";
const PC_SSIAP2 = {
  "SST": [["Secourisme", 3]],
  "VEV - Secours": [["Arrivée du dispositif de secours", 1], ["Départ du dispositif de secours", 1], ["Secours à victime", 4], ["Évacuation d'une victime", 4], ["Intervention des secours externes", 4]],
  "VEV - Incendie": [["Permis de feu", 3], ["Évacuation", 4], ["Alarme incendie (PEX)", 4]],
  "VEV - Sûreté": [["Entrée d'un représentant des forces de l'ordre avec son arme de service", 1], ["Odeur suspecte", 3], ["Intrusion", 3], ["Arrivée des forces de l'ordre sur requête", 3], ["Départ des forces de l'ordre", 3], ["Vol", 3], ["Alerte à la bombe", 4], ["Colis suspect", 4], ["Violences physiques ou verbales", 4]],
  "VEV - Exploitation": [["Prise de service", 1], ["Fin de service", 1], ["Ronde", 1], ["Ouverture hall(s)", 1], ["Fermeture hall(s)", 1], ["Demande d'éclairage", 1], ["Extinction éclairage", 1], ["Ouverture chapiteau(x)", 1], ["Fermeture chapiteau(x)", 1], ["Ouverture bungalow(s)", 1], ["Fermeture bungalow(s)", 1],
    ["Balisage", 1], ["Livraison", 1], ["Anomalie stationnement", 1], ["Objet(s) trouvé(s)", 1], ["Test ligne directe pompiers", 1], ["Retour de consignes", 1], ["Rapport événement", 1], ["Rapport libre", 1]],
  "VEV - Contrôle d'accès": [["Ouverture parking A", 1], ["Fermeture parking A", 1], ["Ouverture parking B", 1], ["Fermeture parking B", 1], ["Entrée sur site par le Mail central", 1], ["Entrée sur site par le P3", 1], ["Sortie du site véhicule non autorisé par le P3", 3]],
  "VEV - Contrôle réglementaire": [["Contrôle extincteur" + PEX, 2], ["Contrôle RIA" + PEX, 2], ["Contrôle DAE", 2]],
  "VEV - Anomalie / Technique": [["Anomalie mur vidéo (PC Parc / poste P3)" + PEX, 2], ["Anomalie informatique", 2], ["Anomalie contrôle d'accès" + PEX, 2], ["Anomalie climatisation / chauffage (PEX)", 2],
    ["Anomalie ascenseur / monte-charge" + PEX, 3], ["Anomalie local technique" + PEX, 3], ["Anomalie ligne directe pompiers (PC Parc)" + PEX, 4], ["Coupure électrique", 4], ["Anomalie électrique", 4]],
  "VEV - DATI": [["Dysfonctionnement DATI", 3]],
  "VEV - REX": [["Sortie de matériel interne à N Sécurité", 1], ["Retour du matériel interne à N Sécurité", 1], ["Prise en compte agent de tenue N Sécurité", 1], ["Prolongation agent(s)", 1], ["Abandon de poste", 1], ["Absent à sa vacation", 1], ["Retard prise de service", 1], ["Départ anticipé d'un agent", 1]],
};
const P3 = {
  "Service": [["Prise de service", 1], ["Fin de service", 1]],
  "Contrôle d'accès": [["Entrée sur site par le P3", 1], ["Sortie du site par le P3", 1], ["Refus d'accès", 2]],
  "Colis": [["Dépôt de colis", 1], ["Refus de colis", 2]],
  "Rapport libre": [["Rapport libre", 1]],
};
const PORTAIL = {
  "Service": [["Prise de service", 1], ["Fin de service", 1]],
  "Portail / barrière": [["Ouverture portail / barrière", 1], ["Fermeture portail / barrière", 1], ["Anomalie portail / barrière", 2]],
  "Entrées / sorties": [["Entrée prestataire", 1], ["Sortie prestataire", 1], ["Entrée véhicule autorisé", 1], ["Livraison", 1], ["Dépôt de colis", 1], ["Refus d'accès", 2], ["Véhicule non autorisé", 3]],
  "Sûreté": [["Colis suspect", 4], ["Comportement suspect", 3]],
  "Divers": [["Retour de consignes", 1], ["Rapport libre", 1]],
};
const SSIAP1 = {
  "Service": [["Prise de service", 1], ["Fin de service", 1]],
  "Rondes": [["Ronde effectuée — RAS", 1], ["Ronde — anomalie", 2], ["Ronde moyens de secours et d'extinction", 1]],
  "Incendie": [["Alarme incendie / levée de doute", 3], ["Départ de feu", 4], ["Évacuation", 4], ["Permis de feu", 2], ["Mise en fumée sur scène", 2]],
  "Secours": [["Malaise", 3], ["Secours à personne", 4], ["Arrivée du dispositif de secours", 1], ["Départ du dispositif de secours", 1]],
  "Moyens de secours": [["Contrôle extincteur", 2], ["Contrôle RIA", 2], ["Contrôle DAE", 2], ["Issue de secours obstruée", 3], ["Éclairage de sécurité défaillant", 2], ["Désenfumage", 2]],
  "Sûreté": [["Colis suspect", 4], ["Intrusion", 3], ["Vol / dégradation", 3], ["Altercation / rixe", 4], ["Objet(s) trouvé(s)", 1]],
  "Technique": [["DI – défaut technique / anomalie", 2], ["Ascenseur / monte-charge", 3], ["Problème technique", 2]],
  "Divers": [["Information / consigne", 1], ["Retour de consignes", 1], ["Rapport libre", 1]],
};
const ADS = {
  "Service": [["Prise de service", 1], ["Fin de service", 1]],
  "Contrôle d'accès": [["Accès / contrôle entrée", 1], ["Palpation / inspection des sacs", 1], ["Refus d'entrée", 2], ["Objet interdit / saisie", 2], ["Contrôle de passe / badge", 1]],
  "Public": [["Mouvement de foule", 3], ["Personne en état d'ivresse", 2], ["Enfant / personne perdue", 3], ["Comportement suspect", 3]],
  "Secours": [["Malaise", 3], ["Secours à personne", 4]],
  "Sûreté": [["Colis suspect", 4], ["Altercation / rixe", 4], ["Vol / dégradation", 3], ["Intrusion", 3], ["Objet(s) trouvé(s)", 1]],
  "Parking": [["Anomalie stationnement", 1], ["Véhicule non autorisé", 2]],
  "Divers": [["Information / consigne", 1], ["Retour de consignes", 1], ["Rapport libre", 1]],
};
const PAUSES = { "Pauses": [["Début de relève de pause", 1], ["Fin de relève de pause", 1], ["Remplacement temporaire d'un poste", 1], ["Pause non prise / agent non relevé", 2]] };
const avecPauses = (o) => Object.assign({ "Service": o["Service"] }, PAUSES, o);
const SSIAP3 = Object.assign({ "SSIAP 3 - Encadrement": [["Briefing des équipes", 1], ["Contrôle des postes", 1], ["Ronde de contrôle SSIAP 3", 1], ["Mise en place du dispositif", 1],
  ["Réajustement des effectifs", 2], ["Visite organisateur / exploitant (VEV)", 1], ["Accueil commission de sécurité", 2], ["Contrôle du registre de sécurité", 2], ["Délivrance permis de feu", 2],
  ["Levée de doute encadrée", 3], ["Gestion de crise / cellule de crise", 4], ["Débriefing de fin de manifestation", 1], ["Rapport de fin de manifestation", 1]] }, PC_SSIAP2);
const VA = " (réf. VA ARN-0002)";
const ARENA = JSON.parse(JSON.stringify(PC_SSIAP2).split(PEX).join(VA).split("(PEX)").join("(Arena)").split("PC Parc").join("PCS Arena").split("poste P3").join("PCS Arena"));
for (const f in ARENA) ARENA[f] = ARENA[f].map(([t, p]) => [t.replace("(PCS Arena / PCS Arena)", "(PCS Arena)"), p]);
ARENA["VEV - Contrôle d'accès"] = [["Ouverture parking A (Arena)", 1], ["Fermeture parking A (Arena)", 1], ["Ouverture portes Arena", 1], ["Fermeture portes Arena", 1], ["Entrée par la porte face au P3", 1], ["Entrée par la cour de service", 1], ["Véhicule non autorisé", 3]];
globalThis.MC_POSTES = [
  { k: "pcsarena", lb: "🏟️ SSIAP 2 PCS Arena", familles: ARENA, acces: false },
  { k: "ssiap2", lb: "🖥️ SSIAP 2 PC Parc", familles: PC_SSIAP2, acces: false },
  { k: "ssiap3", lb: "🎖️ SSIAP 3", familles: SSIAP3, acces: false },
  { k: "ssiap1", lb: "🧯 SSIAP 1", familles: SSIAP1, acces: false },
  { k: "ssiap1v", lb: "🧯 SSIAP 1 volant (pauses)", familles: avecPauses(SSIAP1), acces: false },
  { k: "ads", lb: "🦺 ADS", familles: ADS, acces: false },
  { k: "adsv", lb: "🦺 ADS volant (pauses)", familles: avecPauses(ADS), acces: false },
  { k: "p3", lb: "🚧 Poste P3 (av. de l'Élevade)", familles: P3, acces: true },
  { k: "portail", lb: "🚪 Portail / barrière prestataires", familles: PORTAIL, acces: true },
];
globalThis.MC_PRIO_GRAV = (p) => (p >= 4 ? "urgente" : p >= 3 ? "moyenne" : "info");
})();
