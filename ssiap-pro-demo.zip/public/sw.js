// SSIAP Pro — Application créée par Rochdi Mecheti
const V = "ssiap-demo-v76";
const SHELL = ["/", "/index.html", "/app.css", "/app.js", "/textes.js", "/memo.js", "/site.js", "/rapports-types.js", "/risques.js", "/mc-postes.js", "/plan.js", "/planif-calc.js", "/img/fond-ssiap.jpg", "/img/icon-192.png", "/img/icon-512.png", "/img/icon-maskable-512.png", "/img/apple-touch-icon.png", "/img/favicon-64.png", "/manifest.webmanifest"];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(V).then((c) => c.addAll(SHELL))); self.skipWaiting(); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((k) => Promise.all(k.filter((x) => x !== V).map((x) => caches.delete(x)))));
  self.clients.claim();
});
self.addEventListener("fetch", (e) => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.pathname.startsWith("/api/") || u.origin !== location.origin) return;
  // réseau d'abord (toujours la dernière version), cache si pas de réseau
  e.respondWith(fetch(e.request).then((r) => { const c = r.clone(); caches.open(V).then((x) => x.put(e.request, c)); return r; })
    .catch(() => caches.match(e.request).then((r) => r || caches.match("/index.html"))));
});

// Notifications push : le téléphone reçoit un « réveil » et vient chercher le message (avec le jeton de l'agent)
self.addEventListener("push", (e) => {
  e.waitUntil((async () => {
    let d = { titre: "SSIAP Pro", texte: "Nouvelle notification", url: "/#/" };
    try {
      const r = await (await caches.open("ssiap-auth")).match("/jeton"); const tok = r ? await r.text() : "";
      const x = await fetch("/api/push/dernier", { headers: tok ? { authorization: "Bearer " + tok } : {} }); if (x.ok) d = await x.json();
    } catch {}
    await self.registration.showNotification(d.titre, { body: d.texte, icon: "/img/icon-192.png", badge: "/img/favicon-64.png", tag: "ssiap-" + (d.t || Date.now()),
      renotify: true, requireInteraction: !!d.alerte, vibrate: d.alerte ? [400, 150, 400, 150, 800] : [200, 100, 200], data: { url: d.url || "/#/" } });
  })());
});
self.addEventListener("notificationclick", (e) => {
  e.notification.close();
  const url = (e.notification.data && e.notification.data.url) || "/#/";
  e.waitUntil(self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((l) => { const c = l.find((x) => "focus" in x); if (c) { c.navigate(url).catch(() => {}); return c.focus(); } return self.clients.openWindow(url); }));
});
