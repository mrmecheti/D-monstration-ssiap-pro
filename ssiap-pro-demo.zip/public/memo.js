// SSIAP Pro — Mémo terrain SSIAP / ADS
// Application créée par Rochdi Mecheti
window.MEMO = [
{ cat:"Technique", titre:"🛠️ Défaut technique : astreinte Elektra (Parc / Arena)", html:`
<p><b>Astreinte Elektra</b> : <a href="tel:0465710099"><b>04 65 71 00 99</b></a> (voir aussi la procédure affichée au PC).</p>
<table>
<tr><th>Site</th><th>Référence à rappeler</th></tr>
<tr><td>Parc Expo Valmont (PEX)</td><td><b>PEX-0001</b></td></tr>
<tr><td>Valmont Arena (VA)</td><td><b>ARN-0002</b></td></tr>
</table>
<p><b>Niveau de la demande</b></p>
<ul>
<li><b>Urgent avec déplacement d'astreinte</b> : risque pour les personnes ou la sécurité incendie, panne qui bloque l'exploitation (coupure générale, fuite importante, personne bloquée dans un ascenseur, SSI hors service…).</li>
<li><b>Urgent sans déplacement</b> : l'astreinte doit être informée tout de suite mais peut traiter à distance ou guider par téléphone.</li>
<li><b>Non urgent</b> : défaut à reprendre en heures ouvrées (BAES isolé, porte qui ferme mal, éclairage d'un local…).</li>
</ul>
<p><b>Comment faire</b></p>
<ol>
<li>Sécurise la zone si besoin (balisage, coupure, information du PC).</li>
<li>Dans l'appli : <b>Rapports ➜ DI</b>. Choisis le site : la bonne référence Elektra s'affiche, avec le bouton d'appel.</li>
<li>Indique le niveau d'intervention, le n° de l'appareil pour un ascenseur, ajoute une photo et envoie : le PC reçoit tout par mail.</li>
<li>Note dans le rapport l'heure d'appel et ce que Elektra a répondu.</li>
</ol>
<p class="mut">Le choix « urgent / non urgent » reste celui du PC ou du responsable en cas de doute.</p>`},

{ cat:"Incendie", titre:"🧯 Ronde moyens de secours — guide du nouvel SSIAP 1", html:`
<p><b>Pourquoi cette ronde ?</b> Le SSIAP 1 assure l'entretien élémentaire des moyens de secours : s'il y a un feu ou un malaise, l'extincteur, le RIA, le DAE et les issues doivent être prêts tout de suite. Une anomalie vue pendant la ronde, c'est un problème évité pendant l'intervention.</p>
<p><b>Comment faire</b></p>
<ol>
<li>Préviens le PC du début de ta ronde, avec ton itinéraire.</li>
<li>Dans l'appli : onglet <b>Site</b> ➜ check-list <b>« SSIAP 1 — Ronde moyens de secours et d'extinction »</b>. Touche ⓘ sur chaque ligne pour savoir quoi regarder.</li>
<li>Pour chaque point : <b>✔</b> si tout est bon, <b>✖</b> s'il y a un problème.</li>
<li>Ce que tu peux régler toi-même (porte coupe-feu calée, issue encombrée, stand devant un extincteur) : règle-le et note-le dans les observations.</li>
<li>Ce que tu ne peux pas régler : <b>Rapport DI avec photo</b> (onglet Rapports) et préviens le PC.</li>
<li>Envoie la check-list à la fin : elle part au PC avec ton nom et ton poste.</li>
</ol>
<p><b>Les 5 réflexes à ne jamais oublier</b></p>
<ul>
<li>Une <b>issue de secours cadenassée ou bloquée</b> en présence du public = urgence, PC tout de suite.</li>
<li>Un <b>extincteur sans goupille ou sans scellé</b> a peut-être servi : on le remplace.</li>
<li>Une <b>porte coupe-feu ne se cale jamais</b>.</li>
<li>Un <b>DAE avec voyant rouge</b> n'est pas utilisable : signalement immédiat.</li>
<li>Les <b>voies pompiers</b> restent libres en permanence.</li>
</ul>
<p class="mut">Les consignes propres au site (emplacements, numéros des DM, itinéraire) priment : demande au PC ou à ton chef d'équipe.</p>`},

{ cat:"Urgence", titre:"📞 Message d'alerte aux secours (18 / 112 / 15)", html:`
<ol>
<li><b>Qui</b> : nom, fonction (agent SSIAP / PC sécurité), numéro de rappel.</li>
<li><b>Où</b> : Parc Expo Valmont / Valmont Arena — Route des Salons, 99100 Valmont-sur-Mer. Précise le hall, la porte, l'étage, l'accès secours.</li>
<li><b>Quoi</b> : nature (feu, fumée, malaise, chute, accident, odeur de gaz…).</li>
<li><b>Combien</b> : nombre de victimes, état apparent (conscient, respire, saigne).</li>
<li><b>Actions engagées</b> : extinction, évacuation, gestes de secours, DAE posé…</li>
<li><b>Accueil</b> : point de rendez-vous et agent qui guide les secours.</li>
</ol>
<p>⚠️ Ne raccroche jamais le premier : c'est l'opérateur qui met fin à l'appel. Informe le PC dès l'appel passé.</p>`},

{ cat:"Incendie", titre:"🔥 Levée de doute sur alarme feu", html:`
<ol>
<li>Réception de l'alarme au PC (CMSI / ECS) : noter heure, zone, type de détecteur.</li>
<li>Envoyer un agent (idéalement deux) avec radio, extincteur adapté et passe.</li>
<li>Sur place : ne jamais ouvrir une porte chaude d'un coup — toucher la porte, observer fumée et odeur.</li>
<li><b>Feu confirmé</b> : alarme générale, appel 18, attaque du feu si possible sans prendre de risque, évacuation, accueil des secours.</li>
<li><b>Fausse alarme / alarme intempestive</b> : identifier la cause, informer le PC, réarmer selon la procédure, noter en main courante.</li>
</ol>
<p class="mut">Respecter la temporisation prévue au dossier SSI et les consignes propres au site.</p>`},

{ cat:"Incendie", titre:"🧯 Classes de feu & extincteurs", html:`
<table>
<tr><th>Classe</th><th>Feux de…</th><th>Extincteur</th></tr>
<tr><td><b>A</b></td><td>Solides (bois, papier, tissu, plastique) — braises</td><td>Eau pulvérisée + additif, poudre ABC</td></tr>
<tr><td><b>B</b></td><td>Liquides ou solides liquéfiables (essence, solvants, cire)</td><td>CO₂, eau + additif, poudre</td></tr>
<tr><td><b>C</b></td><td>Gaz (propane, butane, gaz naturel)</td><td>Poudre — couper d'abord l'arrivée de gaz</td></tr>
<tr><td><b>D</b></td><td>Métaux (sodium, magnésium)</td><td>Poudre spéciale D</td></tr>
<tr><td><b>F</b></td><td>Huiles et graisses de cuisson</td><td>Extincteur classe F — jamais d'eau</td></tr>
</table>
<ul>
<li>Origine électrique : CO₂ (ou extincteur marqué « essai diélectrique ») et couper le courant si possible.</li>
<li>Attaquer à la base des flammes, dos au vent / à la sortie, en balayant.</li>
<li>CO₂ : ne pas tenir le diffuseur (brûlure par le froid), attention à l'asphyxie en petit local.</li>
</ul>`},

{ cat:"Incendie", titre:"🔺 Triangle du feu & propagation", html:`
<p><b>Triangle du feu</b> : combustible + comburant (oxygène) + énergie d'activation (chaleur). Supprimer un élément = éteindre le feu.</p>
<p><b>Propagation</b> :</p>
<ul><li><b>Conduction</b> : à travers les matériaux (poutres, tuyaux métalliques).</li>
<li><b>Convection</b> : gaz chauds et fumées qui montent (cages d'escalier, gaines).</li>
<li><b>Rayonnement</b> : la chaleur émise enflamme les objets voisins.</li>
<li><b>Projection</b> : particules ou matières enflammées.</li></ul>
<p>Les fumées sont la première cause de décès : rester bas, fermer les portes derrière soi.</p>`},

{ cat:"Incendie", titre:"🚪 Évacuation & personnes à mobilité réduite", html:`
<ul>
<li>Guides en tête, serre-files en fin de groupe : personne ne reste derrière.</li>
<li>Vérifier les locaux (sanitaires, loges, réserves), fermer les portes sans les verrouiller.</li>
<li>Ne jamais utiliser les ascenseurs (sauf ascenseur d'évacuation prévu).</li>
<li>Personnes à mobilité réduite : les accompagner vers les espaces d'attente sécurisés (EAS) ou les évacuer, signaler leur position aux secours.</li>
<li>Point de rassemblement : comptage, remontée des absents au PC / COS.</li>
<li>Pas de retour dans le bâtiment sans autorisation des secours.</li>
</ul>`},

{ cat:"SSI", titre:"🖥️ SSI — vocabulaire", html:`
<table>
<tr><td><b>SSI</b></td><td>Système de sécurité incendie (catégories A à E, A = le plus complet avec détection automatique)</td></tr>
<tr><td><b>SDI</b></td><td>Système de détection incendie (détecteurs + tableau de signalisation)</td></tr>
<tr><td><b>CMSI</b></td><td>Centralisateur de mise en sécurité incendie</td></tr>
<tr><td><b>ECS</b></td><td>Équipement de contrôle et de signalisation</td></tr>
<tr><td><b>DAS</b></td><td>Dispositifs actionnés de sécurité (portes coupe-feu, clapets, volets de désenfumage, exutoires)</td></tr>
<tr><td><b>UGA</b></td><td>Unité de gestion d'alarme</td></tr>
<tr><td><b>DM / DAD</b></td><td>Déclencheur manuel / détecteur automatique</td></tr>
<tr><td><b>EA</b></td><td>Équipement d'alarme (types 1, 2a, 2b, 3, 4)</td></tr>
</table>
<p class="mut">Toute mise hors service ou dérangement doit être noté au registre de sécurité et signalé.</p>`},

{ cat:"Réglementation", titre:"🏛️ ERP — types et catégories", html:`
<p><b>Catégories</b> (effectif public + personnel) :</p>
<ul><li>1re : plus de 1 500 personnes</li><li>2e : 701 à 1 500</li><li>3e : 301 à 700</li><li>4e : 300 et moins (au-dessus du seuil de 5e)</li><li>5e : sous le seuil fixé par type</li></ul>
<p><b>Types utiles sur site</b> :</p>
<ul><li><b>T</b> : salles d'exposition</li><li><b>L</b> : salles de spectacles, conférences, réunions, usage multiple</li>
<li><b>X</b> : établissements sportifs couverts</li><li><b>N</b> : restaurants et débits de boissons</li>
<li><b>M</b> : magasins</li><li><b>W</b> : bureaux, administrations</li>
<li><b>CTS</b> : chapiteaux, tentes et structures</li><li><b>PA</b> : établissements de plein air</li>
<li><b>SG</b> : structures gonflables</li><li><b>PS</b> : parcs de stationnement couverts</li></ul>`},

{ cat:"Réglementation", titre:"🎖️ Missions SSIAP 1 / 2 / 3", html:`
<p><b>SSIAP 1 — Agent</b> : prévention des incendies, sensibilisation du personnel, entretien élémentaire des moyens de secours, alerte et accueil des secours, évacuation du public, intervention précoce, assistance aux personnes, exploitation du PC.</p>
<p><b>SSIAP 2 — Chef d'équipe</b> : management de l'équipe, formation du personnel, application des consignes, direction du PC en cas de sinistre, contrôle des installations, rédaction des rapports.</p>
<p><b>SSIAP 3 — Chef de service</b> : management du service, conseil au chef d'établissement, suivi de la réglementation et des commissions de sécurité, budget, organisation des exercices.</p>
<p class="mut">Référence : arrêté du 2 mai 2005 modifié. Recyclage tous les 3 ans, remise à niveau si diplôme non exercé.</p>`},

{ cat:"ADS", titre:"🛡️ Agent de sécurité (ADS) — ce que tu peux / ne peux pas faire", html:`
<p><b>Obligatoire</b> : carte professionnelle CNAPS valide, tenue sans confusion possible avec la police, respect du code de déontologie (Code de la sécurité intérieure, livre VI).</p>
<p><b>Autorisé</b> :</p>
<ul>
<li>Inspection visuelle des bagages ; fouille du bagage avec le consentement de la personne.</li>
<li>Palpation de sécurité dans le cadre prévu par la loi (manifestations de plus de 300 personnes, ou circonstances particulières fixées par arrêté), avec consentement exprès et par un agent du même sexe.</li>
<li>Refuser l'accès à une personne qui refuse le contrôle.</li>
<li>En cas de crime ou délit flagrant puni d'emprisonnement (art. 73 du Code de procédure pénale) : appréhender l'auteur et appeler immédiatement le 17 pour le remettre à un OPJ.</li>
</ul>
<p><b>Interdit</b> : contrôle d'identité, fouille à corps, retenir une personne hors flagrant délit, violence disproportionnée, discrimination à l'entrée.</p>`},

{ cat:"Sûreté", titre:"🚨 Menace terroriste & Vigipirate", html:`
<p><b>Niveaux Vigipirate</b> : Vigilance · Sécurité renforcée – risque attentat · Urgence attentat.</p>
<p><b>Attaque en cours</b> : <b>s'échapper</b> (si possible, aider les autres, ne pas s'exposer), <b>se cacher</b> (s'enfermer, éteindre la lumière, couper la sonnerie des téléphones), <b>alerter</b> (17 / 112 dès que tu es en sécurité). À l'arrivée des forces de l'ordre : mains visibles, pas de geste brusque.</p>
<p><b>Colis / objet suspect</b> : ne pas toucher ni déplacer, éloigner le public, établir un large périmètre, alerter PC et 17, ne pas utiliser de radio ou de téléphone tout près de l'objet, noter l'heure et la description.</p>`},

{ cat:"Secours", titre:"❤️ Secours à personne", html:`
<p><b>Arrêt cardiaque</b> (ne répond pas, ne respire pas normalement) :</p>
<ol><li>Faire appeler le 15 / 18 / 112 et faire apporter le DAE.</li>
<li>Massage cardiaque : mains au centre du thorax, 100 à 120 compressions/min, enfoncer de 5 à 6 cm.</li>
<li>Poser le DAE dès qu'il arrive et suivre ses instructions vocales.</li></ol>
<p><b>Inconscient qui respire</b> : position latérale de sécurité (PLS), surveiller la respiration.</p>
<p><b>Hémorragie</b> : compression directe sur la plaie, allonger la victime, alerter.</p>
<p class="mut">Toujours informer le PC et noter en main courante (heure, victime, gestes faits, prise en charge).</p>`},

{ cat:"Technique", titre:"🛗 Ascenseur bloqué · coupure · odeur de gaz", html:`
<p><b>Personne bloquée en ascenseur</b> : rassurer par l'interphone, prévenir l'ascensoriste (astreinte), ne pas manœuvrer sans habilitation, appeler le 18 si malaise.</p>
<p><b>Coupure électrique</b> : vérifier l'éclairage de sécurité, le report SSI au PC, guider le public, informer la technique.</p>
<p><b>Odeur de gaz</b> : ne toucher à aucun interrupteur, pas de flamme ni de téléphone sur place, aérer, couper le gaz si accessible, évacuer, appeler le 18.</p>`},

{ cat:"Météo", titre:"🌪️ Météo & événementiel", html:`
<ul>
<li><b>Vent</b> : contrôle des barrières, stands, signalétique, nacelles. Pour les structures (CTS), évacuation à la vitesse de vent indiquée dans leur extrait de registre de sécurité (au plus tard 100 km/h selon le règlement CTS).</li>
<li><b>Orage</b> : mise à l'abri du public extérieur, arrêt des travaux en hauteur, surveillance SSI et électricité.</li>
<li><b>Fortes pluies / crue</b> : parkings bas, sous-sols, locaux techniques, balisage des zones glissantes.</li>
<li><b>Canicule</b> : points d'eau, ombre, rotation des agents en extérieur, vigilance malaises.</li>
</ul>
<p class="mut">L'onglet Accueil affiche les alertes en direct ; la liste de diffusion reçoit les alertes par mail.</p>`},

{ cat:"Méthode", titre:"✍️ Rédiger une main courante", html:`
<ul>
<li>Date, heure précise, lieu exact.</li>
<li>Faits observés uniquement — pas d'avis, pas de supposition.</li>
<li>Personnes concernées (description si identité inconnue), témoins.</li>
<li>Actions menées, personnes prévenues, heure d'arrivée des secours.</li>
<li>Phrases courtes, pas d'abréviations obscures, relire avant d'envoyer.</li>
</ul>`},
];
