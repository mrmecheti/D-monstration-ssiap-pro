// SSIAP Pro — lecture des plannings PDF « Comète » (Planning site par Agents et par Activités)
// Application créée par Rochdi Mecheti
// Le PDF est lu directement sur le téléphone : rien n'est envoyé ailleurs que dans l'appli.
(function () {
  const LEG = /^\s*([JN]\d{1,3})\s+\.\s+(.*?)\(Activit[ée]\s*:\s*([^)]*)\)\s*de\s+(\d\d:\d\d)\s+à\s+(\d\d:\d\d)/;
  const IND = /^\s*([A-Z]{2,4})\s+\.\s+([A-ZÉÈÀ][^()]*)$/;
  const TIME = /^\d{2}:\d{2}$/;
  const titre = (s) => s.toLowerCase().replace(/(^|[\s'-])\S/g, (c) => c.toUpperCase());

  // pages = [{ height, items: [{ x, y, w, str }] }]  (y mesuré depuis le haut de la page)
  function analyser(pages, nomFichier = "") {
    // 1) lignes de texte reconstituées (pour la légende et le nom du site)
    const lignesTexte = [];
    for (const p of pages) {
      const rows = [];
      for (const it of [...p.items].sort((a, b) => a.y - b.y || a.x - b.x)) {
        const r = rows.find((r) => Math.abs(r.y - it.y) <= 2.5);
        r ? r.items.push(it) : rows.push({ y: it.y, items: [it] });
      }
      rows.forEach((r) => lignesTexte.push(r.items.sort((a, b) => a.x - b.x).map((i) => i.str).join(" ").replace(/\s+/g, " ")));
    }
    const legende = {}, indispo = {};
    for (const l of lignesTexte) {
      let m = l.match(LEG);
      if (m) {
        const [, code, desc, act, d, f] = m, parts = desc.split(" / ").map((s) => s.trim());
        legende[code] = { evenement: parts.length > 1 ? titre(parts[0]) : "", poste: parts.length > 1 ? parts.slice(1).join(" / ") : parts[0], activite: act.trim(), debut: d, fin: f };
      } else if ((m = l.match(IND))) indispo[m[1]] = m[2].trim();
    }
    const siteTxt = lignesTexte.find((l) => /Site\s*:/.test(l)) || nomFichier;
    const site = /ARENA/i.test(siteTxt) ? "Valmont Arena" : /PARC|EXPO/i.test(siteTxt) ? "Parc Expo Valmont" : (siteTxt.match(/Site\s*:\s*[^/]*\/([^(]*)/) || [, ""])[1].trim();
    let mois = null; // « d'Octobre 2026 » → 2026-10
    const MOIS = ["janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet", "aout", "septembre", "octobre", "novembre", "decembre"];
    for (const l of lignesTexte) {
      const m = l.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().match(/(janvier|fevrier|mars|avril|mai|juin|juillet|aout|septembre|octobre|novembre|decembre)\s+(\d{4})/);
      if (m) { mois = `${m[2]}-${String(MOIS.indexOf(m[1]) + 1).padStart(2, "0")}`; break; }
    }
    if (!mois) throw new Error("Mois du planning introuvable");
    const CODES = new Set([...Object.keys(legende), ...Object.keys(indispo)]);
    if (!Object.keys(legende).length) throw new Error("Légende des vacations introuvable : ce n'est pas un planning Comète ?");

    // 2) grille agents × jours
    const lignes = [], stats = { nonAffectees: 0, indispo: {} };
    for (const p of pages) {
      const cand = {};
      p.items.forEach((it) => { if (/^\d{2}$/.test(it.str.trim()) && it.y < 160 && it.x > 160) (cand[Math.round(it.y)] ||= []).push(it); });
      const best = Object.entries(cand).sort((a, b) => b[1].length - a[1].length)[0];
      if (!best || best[1].length < 28) continue;
      const top = +best[0], dx = {};
      best[1].forEach((it) => (dx[+it.str] = it.x + it.w / 2));
      const xmin = Math.min(...Object.values(dx)) - 12;
      const dayOf = (it) => { const c = it.x + it.w / 2; let best = null, dist = 99; for (const d in dx) { const e = Math.abs(dx[d] - c); if (e < dist) { dist = e; best = +d; } } return dist < 11 ? best : null; };
      const rows = [];
      for (const it of p.items.filter((i) => i.y > top + 8 && i.y < p.height - 70 && i.str.trim()).sort((a, b) => a.y - b.y || a.x - b.x)) {
        const r = rows[rows.length - 1];
        r && Math.abs(r.y - it.y) <= 2.5 ? r.items.push(it) : rows.push({ y: it.y, items: [it] });
      }
      for (let i = 0; i < rows.length;) {
        const L = rows[i].items;
        const codes = L.filter((w) => w.x >= xmin && CODES.has(w.str.trim()));
        const left = L.filter((w) => w.x < xmin);
        if (!codes.length && !left.some((w) => /^VACATIONS/.test(w.str))) { i++; continue; }
        const nom = left.filter((w) => w.x < 97).map((w) => w.str.trim()), qualif = left.filter((w) => w.x >= 97).map((w) => w.str.trim());
        const t1 = rows[i + 1]?.items || [], t2 = rows[i + 2]?.items || [];
        const debuts = {}, fins = {};
        t1.forEach((w) => { if (TIME.test(w.str.trim())) debuts[dayOf(w)] = w.str.trim(); });
        const aFins = t2.some((w) => TIME.test(w.str.trim()));
        if (aFins) t2.forEach((w) => { if (TIME.test(w.str.trim())) fins[dayOf(w)] = w.str.trim(); });
        [...t1, ...(aFins ? t2 : [])].forEach((w) => { if (w.x < xmin && !TIME.test(w.str.trim())) (w.x < 97 ? nom : qualif).push(w.str.trim()); });
        let nm = nom.join(" ").replace(/\s+/g, " ").trim(), extra = "";
        const cut = nm.match(/^(.*?)\s*((?:AGENT DE S[ÉE]CURIT[ÉE]|SSIAP \d|CHEF D'EQUIPE|AGENT$|SSIAP$|CHEF$).*)$/); // nom collé à la qualification
        if (cut && cut[1]) { nm = cut[1].trim(); extra = /^(AGENT|SSIAP|CHEF)$/.test(cut[2]) ? "" : cut[2]; }
        let ql = [extra, ...qualif].join(" ").replace(/\s+/g, " ").trim(); if (/^DE SÉCURITÉ/.test(ql)) ql = "AGENT " + ql;
        const nonAff = /^VACATIONS/.test(nm);
        for (const c of codes) {
          const d = dayOf(c), k = c.str.trim(), lg = legende[k];
          if (d == null) continue;
          if (!lg) { stats.indispo[indispo[k] || k] = (stats.indispo[indispo[k] || k] || 0) + 1; continue; }
          if (nonAff) { stats.nonAffectees++; continue; }
          lignes.push({ date: `${mois}-${String(d).padStart(2, "0")}`, nom: nm, qualif: ql, code: k, site,
            poste: lg.poste, evenement: lg.evenement, debut: debuts[d] || lg.debut, fin: fins[d] || lg.fin });
        }
        i += aFins ? 3 : Object.keys(debuts).length ? 2 : 1;
      }
    }
    return { site, mois, lignes, stats, nbCodes: Object.keys(legende).length };
  }

  async function lireComete(file) {
    const pdfjs = await import(new URL("vendor/pdfjs/pdf.min.mjs", location.href).href);
    pdfjs.GlobalWorkerOptions.workerSrc = new URL("vendor/pdfjs/pdf.worker.min.mjs", location.href).href;
    const doc = await pdfjs.getDocument({ data: new Uint8Array(await file.arrayBuffer()) }).promise;
    const pages = [];
    for (let n = 1; n <= doc.numPages; n++) {
      const pg = await doc.getPage(n), h = pg.getViewport({ scale: 1 }).height, tc = await pg.getTextContent();
      pages.push({ height: h, items: tc.items.filter((it) => it.str && it.str.trim()).map((it) => ({ x: it.transform[4], y: h - it.transform[5], w: it.width, str: it.str })) });
    }
    return analyser(pages, file.name);
  }
  if (typeof window !== "undefined") { window.lireComete = lireComete; window.analyserComete = analyser; }
  if (typeof module !== "undefined") module.exports = { analyser };
})();
