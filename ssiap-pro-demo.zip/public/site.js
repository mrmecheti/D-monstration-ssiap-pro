// SSIAP Pro — Site : Parc Expo Valmont (type T) & Arena (type L) — événementiel
// Application créée par Rochdi Mecheti
window.SITE_FICHES = [
{ titre:"🏛️ Organisation du site", html:`
<p><b>Un seul site, deux établissements</b>, route des Salons à Valmont-sur-Mer :</p>
<ul>
<li><b>Parc Expo Valmont</b> : ERP de <b>type T</b> (salons, foires, expositions).</li>
<li><b>Valmont Arena</b> : ERP de <b>type L</b> (spectacles, concerts, sport, usage multiple).</li>
</ul>
<p><b>Client / exploitant</b> : la <b>VEV</b> gère les deux établissements.</p>
<p><b>Sécurité</b> : assurée par les agents de sécurité (ADS, SSIAP 1, 2 et 3), coordonnés par le PC sécurité.</p>
<p><b>PC sécurité</b> : 04 65 71 00 00 · pc@valmont.test</p>
<p><b>Encadrement sécurité</b></p>
<ol>
<li><b>Antoine Rivière</b> — chef de secteur</li>
<li><b>Julien Moreau</b> — responsable d'exploitation et de planification, SSIAP 3</li>
<li><b>Karim Benali</b> — adjoint planification, SSIAP 2, chef d'équipe terrain</li>
<li><b>Mehdi Caron</b> — SSIAP 2 de nuit, SSIAP 3 terrain</li>
<li><b>Lucas Fontaine</b> — responsable PC Sécurité</li>
<li><b>Thomas Garnier</b> — responsable PCS journée, SSIAP 2</li>
</ol>`},

{ titre:"🏢 Type T — Salles d'expositions (Parc Expo Valmont)", html:`
<p><b>Effectif (T 2)</b> : salle à vocation temporaire (foires, salons) = <b>1 personne/m²</b> de surface totale accessible au public ; salle permanente = 1 personne/9 m².</p>
<p><b>Autorisation (T 5)</b> : l'organisateur dépose sa demande auprès de l'autorité administrative <b>2 mois avant l'ouverture</b>, avec le dossier technique.</p>
<p><b>Cahier des charges (T 4)</b> : le propriétaire remet à l'organisateur un cahier des charges sur les mesures de sécurité propres aux halls loués et les obligations de chacun.</p>
<p><b>Exposants (T 8)</b> : stands terminés à la visite de réception, exposant présent, renseignements fournis sur les matériaux et installations. Machines, moteurs, lasers et produits dangereux déclarés <b>1 mois avant</b> l'ouverture.</p>
<p><b>Stands</b> : ossature et cloisons au minimum M3 (ou équivalent euroclasse) ; vélums et plafonds M1 (M2 si sprinklé) ; stands couverts limités en surface et espacés (voir T 23). Machines en fonctionnement : parties dangereuses à <b>plus de 1 m de l'allée</b> ou protégées par un écran rigide (T 39).</p>
<p><b>Service de sécurité (T 48)</b> : composition fixée selon la catégorie, l'effectif et le nombre de niveaux (minimum 4 agents en 1re catégorie au-delà de 6 000 personnes sur 1 ou 2 niveaux, 5 au-delà de 10 000).</p>
<p><b>Alarme (T 49 / T 50)</b> : en 1re catégorie, message préenregistré d'évacuation obligatoire si sonorisation.</p>
<p class="mut">Chiffres à confirmer dans la version à jour du règlement (Légifrance) avant tout dossier officiel.</p>`},

{ titre:"🎖️ Chargé de sécurité salon (T 6) — ce que permet ton SSIAP 3", html:`
<p>L'organisateur d'une manifestation en type T doit désigner un <b>chargé de sécurité</b>.</p>
<p><b>Missions</b> : examiner le dossier d'aménagement, faire respecter les prescriptions, contrôler <b>du début du montage jusqu'à la fin de l'ouverture</b>, être présent en permanence pendant la présence du public, rédiger le <b>rapport final</b> remis avant l'ouverture au public.</p>
<p><b>Qualification</b> : SSIAP 3, PRV 2, AP 2 ou équivalent, recyclage à jour.</p>
<p>⚠️ Avec le <b>SSIAP 3</b> seul, la fonction n'est possible que pour une manifestation dont l'effectif public ne dépasse pas <b>1 500 personnes</b>. Au-delà : PRV 2 ou AP 2.</p>`},

{ titre:"🎤 Type L — Salles de spectacles, réunions, usage multiple (Arena)", html:`
<p><b>Service de sécurité (L 14) — salles de spectacles</b> :</p>
<ul>
<li>1re catégorie, plus de 3 000 personnes : service SSIAP selon MS 46, et pendant la représentation au minimum <b>1 SSIAP 2 + 2 SSIAP 1</b>. À partir de 6 000 personnes, <b>+1 SSIAP 1 par tranche de 3 000</b>.</li>
<li>1re catégorie, 1 501 à 3 000 personnes : au minimum 1 SSIAP 1 pendant la représentation.</li>
<li>2e à 4e catégorie avec espace scénique et décors : personnes désignées + 1 SSIAP 1 pendant la représentation.</li>
</ul>
<p><b>Salles polyvalentes / usage multiple</b> : règles des « autres établissements » de leur catégorie (MS 46 au-delà de 3 000 personnes).</p>
<p><b>SSI (L 15)</b> : catégorie A en 1re catégorie au-delà de 3 000 personnes ou avec dessous de scène.</p>
<p><b>Alerte (L 17)</b> : liaison avec les sapeurs-pompiers conforme MS 70 en 1re catégorie au-delà de 3 000 personnes.</p>
<p class="mut">Effectif, espace scénique, décors et effets spéciaux : se référer au dossier de l'établissement et à la notice de sécurité de l'événement.</p>`},

{ titre:"⛺ CTS — Chapiteaux, tentes, structures (parvis, extérieurs)", html:`
<ul>
<li><b>Vent (CTS 7)</b> : évacuation du public si le vent normal dépasse <b>100 km/h</b>, ou la vitesse plus basse indiquée dans l'extrait du registre de sécurité de la structure.</li>
<li><b>Anémomètre (CTS 58)</b> : relié à un dispositif qui informe l'exploitant à tout moment de la vitesse du vent.</li>
<li><b>Extrait du registre (CTS 31)</b> : remis au maire au moins <b>8 jours avant</b> l'ouverture.</li>
<li>Attestation de bon montage signée avant l'ouverture au public.</li>
</ul>
<p>Les alertes vent de l'accueil t'aident à anticiper : orange à partir de 70 km/h de rafales, rouge à partir de 90.</p>`},

{ titre:"📄 GN 6 — Utilisation exceptionnelle des locaux", html:`
<p>Dès qu'un hall ou l'Arena accueille une activité différente de celle autorisée (concert dans un hall d'expo, banquet, salon dans l'Arena, gradins ou décors temporaires…), une demande d'autorisation est obligatoire.</p>
<ul>
<li>Délai : au moins <b>2 mois avant</b> la manifestation (règle en vigueur depuis fin 2023).</li>
<li>Déposée par l'exploitant (et l'organisateur s'il est différent) auprès du maire.</li>
<li>Dossier : nature de l'événement, dates et horaires, effectif, plans d'aménagement, installations temporaires, moyens de secours, service de sécurité prévu.</li>
</ul>`},

{ titre:"🏛️ Commission de sécurité & registre", html:`
<p><b>Visites périodiques (GE 4)</b> pour les types L et T : tous les <b>3 ans</b> en 1re, 2e et 3e catégorie, tous les 5 ans en 4e catégorie.</p>
<p><b>Registre de sécurité</b> : vérifications techniques (SSI, désenfumage, électricité, gaz, ascenseurs, extincteurs, RIA, BAES), exercices, formation du personnel, travaux, interventions. Il est présenté à chaque visite de commission.</p>
<p><b>À préparer avant une visite</b> : registre à jour, rapports de vérifications sans observation en suspens, levée des prescriptions précédentes, plans d'intervention affichés, personnel du service de sécurité présent avec ses diplômes et recyclages.</p>`},

{ titre:"🎖️ SSIAP 3 — Chef de service, tes missions", html:`
<ul>
<li>Management du service de sécurité : plannings, effectifs conformes au règlement (MS 46, L 14, T 48).</li>
<li>Conseil au chef d'établissement et à l'organisateur, relation avec la commission de sécurité.</li>
<li>Suivi des vérifications périodiques et de la levée des observations.</li>
<li>Avis sur les dossiers d'aménagement, GN 6 et notices de sécurité des événements.</li>
<li>Organisation des exercices d'évacuation et de la formation du personnel.</li>
<li>Gestion des travaux : plan de prévention, permis de feu, maintien des dégagements.</li>
</ul>`},

{ titre:"🔧 Montage / démontage — coactivité", html:`
<ul>
<li><b>Plan de prévention</b> écrit avec chaque entreprise extérieure si les travaux dépassent <b>400 heures sur 12 mois</b> ou figurent parmi les travaux dangereux (travail en hauteur, électricité, etc.).</li>
<li><b>Permis de feu</b> pour tout travail par point chaud (soudure, meulage, découpe) : surveillance pendant les travaux puis au moins 2 h après.</li>
<li>Nacelles et chariots : CACES ou autorisation de conduite, balisage des zones.</li>
<li>Dégagements, issues de secours, voies engins et poteaux incendie jamais encombrés, même pendant le montage.</li>
<li>Port des EPI : casque, chaussures de sécurité, gilet haute visibilité.</li>
</ul>`},
];

// Check-lists par fonction : le premier groupe correspondant au rôle de l'agent est proposé d'office
window.CHECKLISTS_GROUPES = [
 { groupe: "🧑‍🚒 SSIAP 1", roles: ["ssiap1"], listes: {
  "SSIAP 1 — Prise de service / ouverture du salon": [
    "Prise de poste signalée au PC, radio testée",
    "Mise en éclairage du hall faite",
    "Vacuité des dégagements : allées libres, largeurs respectées",
    "Issues de secours déverrouillées, dégagées et signalées",
    "Aucun véhicule stationné contre le hall ni devant une issue",
    "Effets de fumée sur une scène dans le hall : signalés au PC (risque de déclenchement de la détection)",
    "Sac d'intervention pris (s'il n'y a pas d'équipe de secours sur place)",
  ],
  "SSIAP 1 — Ronde moyens de secours et d'extinction": [
    ["Prise de ronde : matériel complet", "Avant de partir : radio testée avec le PC, lampe, passe / clés, sac d'intervention, clé de réarmement des DM, plan du site. Annonce au PC le début de ta ronde et ton itinéraire."],
    ["Extincteurs : présents, signalés, accessibles", "À chaque emplacement prévu, l'extincteur est là, sur son support, avec son panneau rouge visible. Rien devant (stand, chariot, carton). Si un emplacement est vide : rapport « Extincteur manquant »."],
    ["Extincteurs : goupille, scellé, manomètre, date", "Goupille et scellé (plomb) en place = jamais utilisé. Manomètre dans le vert quand il y en a un. Étiquette de vérification de moins d'un an. Pas de choc, de rouille ni de tuyau fendu. Rappel : eau + additif (feux A et B), CO₂ (appareils électriques), poudre ABC (polyvalent)."],
    ["RIA : armoire accessible et en état", "Armoire signalée, rien devant, porte qui s'ouvre. Tuyau bien enroulé, lance fermée, aucune fuite. Vanne d'alimentation dans sa position normale (ouverte, sauf consigne contraire). Étiquette de vérification présente."],
    ["DAE : présent et opérationnel", "Le défibrillateur est dans son boîtier signalé. Voyant d'état OK (vert ou sablier selon le modèle). Électrodes présentes et dans leur date. Boîtier non bloqué. Un voyant rouge ou un bip = rapport DI immédiat."],
    ["Déclencheurs manuels (DM) visibles et libres", "Boîtier rouge « Alarme incendie » visible, accessible, jamais masqué par un stand ou une bâche. Membrane ou vitre intacte, pas en position déclenchée. Note le repère du DM en cas de problème."],
    ["Commandes de désenfumage accessibles", "Boîtiers ou treuils de désenfumage signalés, rien devant, en position normale (non déclenchés). Un désenfumage ouvert sans raison se signale au PC."],
    ["BAES / éclairage de sécurité", "Chaque bloc a son voyant vert allumé (il est en charge). Un bloc éteint, arraché, cassé ou une flèche qui indique la mauvaise direction : rapport DI « Éclairage / BAES »."],
    ["Issues de secours dégagées et déverrouillées", "Pendant la présence du public : issue déverrouillée, barre antipanique qui fonctionne, rien devant ni derrière (contrôle les deux côtés), panneau « Sortie de secours » visible. Une issue cadenassée est une urgence : préviens le PC tout de suite."],
    ["Dégagements et circulations libres", "Allées et couloirs à la bonne largeur, aucun stockage, aucun câble non protégé au sol, aucun obstacle vers les sorties."],
    ["Portes coupe-feu fermées ou sur ventouse", "Une porte coupe-feu est fermée, ou maintenue ouverte uniquement par sa ventouse reliée au SSI. Jamais calée (cale, chaise, sangle). Ferme-porte présent, la porte se referme complètement seule."],
    ["Traiteurs et points chauds : couverture anti-feu et extincteur", "Chaque traiteur, cuisine ou point chaud a une couverture anti-feu et un extincteur adapté à portée de main. Bouteilles de gaz uniquement si autorisées et hors public."],
    ["Colonnes sèches, poteaux incendie, raccords pompiers", "Accessibles, signalés, capots en place, aucun véhicule ni matériel devant. Les pompiers doivent pouvoir s'y brancher immédiatement."],
    ["Voies engins et accès pompiers libres", "Aucune voiture ni camion sur les voies pompiers. Barrières et portails ouvrables rapidement. Un stationnement gênant se signale au PC."],
    ["Sprinklers : têtes non masquées", "Là où il y a des sprinklers : aucune tête cachée ou abîmée, aucun stockage collé dessous (garder au moins 50 cm d'espace)."],
    ["Locaux à risques fermés et rangés", "TGBT, chaufferie, réserves, locaux techniques : porte fermée à clé, pas de stockage devant ni à l'intérieur s'il est interdit, accès dégagé."],
    ["Plans d'évacuation et consignes affichés", "Plans « Vous êtes ici » et consignes de sécurité présents, lisibles, non arrachés."],
    ["Fin de ronde : compte rendu au PC", "Annonce la fin de ta ronde au PC. Chaque anomalie non réglée sur place = rapport DI avec photo dans l'appli (onglet Rapports). Ce que tu as corrigé toi-même (porte refermée, issue dégagée) se note dans les observations."],
  ],
  "SSIAP 1 — Moyens d'extinction et de secours": [
    "RIA accessibles, signalés, non masqués",
    "Extincteurs en place, goupillés, accessibles",
    "Couverture anti-feu présente chez les traiteurs et aux points chauds",
    "Déclencheurs manuels (DM) accessibles et non masqués",
    "Commandes de désenfumage accessibles",
    "BAES / éclairage de sécurité allumés",
  ] } },
 { groupe: "🖥️ SSIAP 2 — PC / SSI", roles: ["ssiap2", "ssiap3", "pc"], listes: {
  "SSIAP 2 — Prise de poste PC / contrôle SSI": [
    "CMSI / ECS : aucun défaut, aucun dérangement",
    "Zones ou détecteurs isolés connus et notés en main courante",
    "Test des voyants du tableau SSI",
    "Désenfumage : aucun défaut, commandes en position normale",
    "Diffusion d'évacuation / sonorisation opérationnelle",
    "SSIAP 1 en poste : positions et liaison radio vérifiées",
    "Main courante lue, consignes de la relève prises",
    "Clés, plans, registre de sécurité et DAE du PC en place",
    "Accès pompiers et voies engins dégagés",
  ] } },
 { groupe: "👮 ADS — selon le poste", roles: ["ads"], listes: {
  "ADS — Fouille / palpation": [
    "Prise de poste signalée au PC, radio testée",
    "Gants portés",
    "Palpation par un agent du même sexe",
    "Sacs ouverts par leur propriétaire, inspection visuelle seulement",
    "Liste des objets interdits de l'événement connue",
    "Point de consigne / dépôt des objets connu",
    "Refus de palpation = refus d'entrée, PC informé",
  ],
  "ADS — Gardiennage": [
    "Prise de poste signalée au PC, consignes de la relève lues",
    "Clés et badges reçus et vérifiés",
    "Tour des accès du secteur fait",
    "Portes et accès fermés / ouverts selon les consignes",
    "Aucune personne non autorisée dans le secteur",
  ],
  "ADS — Contrôle d'accès": [
    "Prise de poste signalée au PC, radio testée",
    "Titres d'accès valides connus (billets, badges, bracelets)",
    "Zones autorisées par type de badge connues",
    "Aucun passage sans titre valable",
    "Flux fluide, file d'attente sécurisée",
    "Tentative de forcing signalée immédiatement au PC",
  ],
  "ADS — Volant / rondier": [
    "Prise de poste signalée au PC, radio et lampe OK",
    "Itinéraire et points sensibles connus",
    "Soutien des postes et relèves de pause organisés avec le PC",
    "Anomalies signalées au PC et notées en main courante",
  ],
  "ADS — Accueil": [
    "Prise de poste signalée au PC, tenue correcte",
    "Plans du site et informations de l'événement à disposition",
    "Cheminements PMR connus",
    "Procédure enfant perdu / objet trouvé connue",
    "Public renseigné et orienté",
  ],
  "ADS — Contrôle de passe / accréditations": [
    "Prise de poste signalée au PC, radio testée",
    "Couleurs et zones des badges connues",
    "Liste des personnes et véhicules autorisés à jour",
    "Badge porté visiblement, aucun prêt de badge",
    "Badge non conforme : refus et PC informé",
  ],
  "ADS — Sanitaires": [
    "Prise de poste signalée au PC",
    "Surveillance des sanitaires et de leurs abords",
    "Problème de propreté ou de fuite signalé (Sud Service / DI)",
    "Aucun rassemblement ni comportement suspect",
    "Aucun objet abandonné",
  ],
  "ADS — Accès privé / zone réservée": [
    "Prise de poste signalée au PC, radio testée",
    "Liste nominative ou badges autorisés connus",
    "Porte fermée entre chaque passage",
    "Aucun visiteur non autorisé dans la zone",
  ],
  "ADS — Vigilance / Vigipirate": [
    "Niveau Vigipirate en cours connu",
    "Colis ou bagages abandonnés surveillés",
    "Comportements suspects repérés et signalés",
    "Véhicules suspects ou stationnés aux abords signalés",
    "PC informé de toute anomalie",
  ],
  "ADS — Parking": [
    "Prise de poste signalée au PC, gilet haute visibilité porté",
    "Voies pompiers et accès secours libres",
    "Placement des véhicules selon le plan",
    "Stationnement gênant signalé",
    "Sécurité des piétons assurée",
    "Barrières et portails ouverts / fermés selon les consignes",
  ] } },
 { groupe: "📋 Événement (chef d'équipe / SSIAP 3)", roles: ["ssiap3"], listes: {
  "Ouverture au public": [
    "SSI : aucun défaut ni dérangement au CMSI / ECS",
    "Issues de secours déverrouillées et dégagées",
    "Dégagements et allées libres, largeurs respectées",
    "BAES / éclairage de sécurité fonctionnels",
    "Extincteurs et RIA accessibles et signalés",
    "Voies engins et accès pompiers dégagés",
    "Désenfumage : commandes accessibles, aucun obstacle",
    "Sonorisation / message d'évacuation testé",
    "DAE en place, contrôlé",
    "Radios testées, canaux attribués",
    "Effectif communiqué aux portes",
    "Emplacements PMR et espaces d'attente sécurisés libres",
    "Consignes de sécurité et plans affichés",
  ],
  "Réception des stands (type T)": [
    "Matériaux avec PV de réaction au feu (M3 mini, vélums M1)",
    "Stand terminé, exposant présent",
    "Allées et largeurs de circulation respectées",
    "Machines déclarées, parties dangereuses à plus de 1 m ou protégées",
    "Installation électrique conforme (pas de multiprises en cascade)",
    "Aucun stockage hors stand ni dans les allées",
    "Gaz / produits dangereux : uniquement si déclarés et autorisés",
    "Extincteur à disposition si exigé",
    "Moyens de secours du hall non masqués (RIA, DM, extincteurs)",
    "Stands couverts / à étage : surface et hauteur conformes",
  ],
  "Avant spectacle Arena (type L)": [
    "Effectif et configuration conformes à l'autorisation",
    "SSIAP de représentation en place (L 14)",
    "Décors et rideaux avec PV de réaction au feu",
    "Effets spéciaux / pyrotechnie déclarés et autorisés",
    "Espace scénique : dégagements et rideau / dispositifs OK",
    "Fosse et barrières anti-écrasement en place",
    "Places PMR et cheminements libres",
    "Liaison secours / pompiers vérifiée, poste de secours en place",
    "Briefing équipes fait (sûreté, SSIAP, secours, organisateur)",
  ],
  "Montage / démontage": [
    "Plan de prévention signé avec les entreprises",
    "Permis de feu délivré pour les points chauds",
    "Conducteurs d'engins habilités, zones balisées",
    "EPI portés",
    "Issues de secours et voies engins non encombrées",
    "Moyens de secours accessibles malgré le montage",
  ],
  "CTS / structures extérieures": [
    "Attestation de bon montage signée",
    "Extrait du registre de sécurité présent",
    "Vitesse de vent maximale connue et notée",
    "Anémomètre fonctionnel et relié",
    "Ancrages et lestages vérifiés",
    "Issues et éclairage de sécurité OK",
  ],
  "Fermeture / ronde de fin": [
    "Plus aucun public (halls, sanitaires, loges, parkings)",
    "Pas de point chaud ni de mégot suspect",
    "Matériels électriques des stands coupés",
    "Portes et accès fermés",
    "SSI en veille sans défaut",
    "Main courante complétée",
  ],
} },
];
window.CHECKLISTS = Object.assign({}, ...window.CHECKLISTS_GROUPES.map((g) => g.listes));

