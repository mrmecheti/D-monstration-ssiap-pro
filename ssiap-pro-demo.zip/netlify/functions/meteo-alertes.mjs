// SSIAP Pro — surveillance météo automatique toutes les 30 min, envoi mail à la liste de diffusion
// Application créée par Rochdi Mecheti
import { load, save, sendMail, DEFAULT_RECIPIENTS } from "../lib/core.mjs";
import { fetchPrevisions, analyser, vigilanceMF, SITE } from "../lib/meteo.mjs";

export const config = { schedule: "*/30 * * * *" };

const COUL = { jaune: "#f5c400", orange: "#ff7a00", rouge: "#d7002e" };
const RANG = { jaune: 1, orange: 2, rouge: 3 };
const CONSIGNES = {
  vent: "Vérifier barrières, structures temporaires (CTS), stands, signalétique, nacelles. Consulter le registre de sécurité des structures pour la vitesse limite d'exploitation.",
  pluie: "Surveiller parkings bas, sous-sols, locaux techniques et cheminements. Prévoir balisage des zones glissantes.",
  orage: "Anticiper la mise à l'abri du public en extérieur, suspendre les travaux en hauteur, surveiller les coupures électriques et le SSI.",
  chaleur: "Points d'eau, zones d'ombre, rotation des agents en poste extérieur, vigilance malaises (public et personnel).",
  froid: "Salage des accès, vigilance chutes, équipements chauds pour les agents extérieurs.",
  neige: "Déneigement accès secours, vigilance toitures et structures légères.",
  brouillard: "Renforcer le guidage parkings et la visibilité des agents (gilets haute visibilité).",
  uv: "Protection des agents en poste extérieur, rotation, hydratation.",
  vigilance: "Suivre les consignes officielles Météo-France / préfecture de l'Hérault et informer la hiérarchie.",
};

export default async () => {
  const data = await fetchPrevisions();
  const alertes = [...(await vigilanceMF().catch(() => [])), ...analyser(data)];
  const deja = await load("alertes_envoyees", {});
  const now = Date.now();

  // Nouvelle alerte, niveau qui monte, ou rappel après 12 h
  const aEnvoyer = alertes.filter((a) => {
    const prev = deja[a.type];
    return !prev || RANG[a.niveau] > RANG[prev.niveau] || now - prev.t > 12 * 3600e3;
  });
  for (const k of Object.keys(deja)) if (!alertes.some((a) => a.type === k) && now - deja[k].t > 6 * 3600e3) delete deja[k];

  if (aEnvoyer.length) {
    const dest = (await load("destinataires", DEFAULT_RECIPIENTS)).filter((d) => d.email);
    const pire = aEnvoyer.reduce((a, b) => (RANG[b.niveau] > RANG[a.niveau] ? b : a));
    const html = `<div style="font-family:Arial,sans-serif;max-width:600px">
      <h2 style="margin:0 0 4px">⚠️ Alerte météo — ${SITE.nom}</h2>
      <p style="color:#666;margin:0 0 16px">${new Date().toLocaleString("fr-FR", { timeZone: "Europe/Paris" })} · prévisions 12 h</p>
      ${aEnvoyer.map((a) => `<div style="border-left:6px solid ${COUL[a.niveau]};padding:8px 12px;margin:0 0 10px;background:#f6f6f6">
        <b>${a.titre}</b> — niveau ${a.niveau}${a.heure ? " · vers " + a.heure : ""}<br>${a.detail}<br>
        <span style="color:#444;font-size:13px">👉 ${CONSIGNES[a.type] || ""}</span></div>`).join("")}
      <p style="font-size:12px;color:#888">SSIAP Pro — Application créée par Rochdi Mecheti</p></div>`;
    await sendMail(dest, `⚠️ SSIAP Pro — ${pire.titre} (${pire.niveau}) — Valmont-sur-Mer`, html);
    for (const a of aEnvoyer) deja[a.type] = { niveau: a.niveau, t: now };
  }
  await save("alertes_envoyees", deja);
  return new Response(JSON.stringify({ alertes: alertes.length, envoyees: aEnvoyer.length }));
};
