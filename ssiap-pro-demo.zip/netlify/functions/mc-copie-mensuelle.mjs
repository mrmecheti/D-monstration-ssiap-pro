// SSIAP Pro — le 1er de chaque mois : copie de la main courante du mois écoulé (Excel CSV + version imprimable)
// envoyée au PC sécurité et au coordinateur PC. Applique la durée de conservation si le propriétaire l'a activée.
// Application créée par Rochdi Mecheti
import { copieMensuelleMC } from "./api.mjs";

export const config = { schedule: "20 5 1 * *" }; // le 1er du mois vers 7 h 20 à Valmont

export default async () => {
  const r = await copieMensuelleMC();
  return new Response(JSON.stringify({ mois: r.mois, nb: r.nb, purge: r.purge }), { headers: { "content-type": "application/json" } });
};
