// SSIAP Pro — chaque matin, lecture réglementaire des dossiers des agents :
// diplômes, recyclages, carte pro, secourisme, habilitation électrique, visite médicale.
// Mail au PC sécurité et au coordinateur PC quand un document approche de son échéance (J-150/90/60/30/15/7, puis chaque semaine si expiré).
// Application créée par Rochdi Mecheti
import { alertesDossiers } from "./api.mjs";

export const config = { schedule: "40 5 * * *" }; // vers 7 h 40 à Valmont

export default async () => {
  const r = await alertesDossiers();
  return new Response(JSON.stringify({ nb: r.nb, envoyes: r.envoyes }), { headers: { "content-type": "application/json" } });
};
