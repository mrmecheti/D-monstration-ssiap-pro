// SSIAP Pro — alertes forcées : relance toutes les 2 minutes des téléphones qui n'ont pas confirmé la réception (5 relances au plus)
// Application créée par Rochdi Mecheti
import { relancerAlertes } from "./api.mjs";

export const config = { schedule: "*/2 * * * *" };

export default async () => {
  const n = await relancerAlertes();
  return new Response(JSON.stringify({ relances: n }), { headers: { "content-type": "application/json" } });
};
