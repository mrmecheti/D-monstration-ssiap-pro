// SSIAP Pro — API (toutes les routes /api/*)
// Application créée par Rochdi Mecheti
import {
  load, save, listeCles, json, deny, uid, currentUser, isStaff, isAdmin, isRH, signToken, checkPin, hashPin, sendMail,
  DEFAULT_CONTACTS, DEFAULT_RECIPIENTS, DEFAULT_RONDES, DEFAULT_ZONES, DEFAULT_PRESTATAIRES, ROLES,
} from "../lib/core.mjs";
import "../../public/rapports-types.js"; // catalogue des rapports partagé avec l'appli
import "../../public/planif-calc.js"; // planification : heures, contrôles réglementaires, devis
import { fetchPrevisions, analyser, vigilanceMF, SITE } from "../lib/meteo.mjs";

import crypto from "node:crypto";
import ANNUAIRE_INITIAL from "../lib/annuaire-initial.json" with { type: "json" };
import PLANNING_INITIAL from "../lib/planning-demo.mjs";
import PARCOURS_INITIAL from "../lib/parcours-initial.json" with { type: "json" };
import CLES_INITIAL from "../lib/cles-initial.json" with { type: "json" };
import MATERIEL_INITIAL from "../lib/materiel-initial.json" with { type: "json" };

export const config = { path: "/api/*" };

const MAX_PHOTO = 900_000; // ~650 Ko d'image (compressée côté téléphone)

// Historique : chaque action est notée ici et remonte en direct aux administrateurs (cloche 🔔)
async function journal(type, qui, detail, niveau = "info", lien = "") {
  const j = await load("journal", []);
  j.unshift({ id: uid(), t: new Date().toISOString(), type, qui, detail, niveau, lien });
  await save("journal", j.slice(0, 5000));
}
const fmtParis = (t) => new Date(t).toLocaleString("fr-FR", { timeZone: "Europe/Paris", day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
const fmtHeure = (h) => (h ? `${h.slice(8, 10)}/${h.slice(5, 7)} ${h.slice(11, 16)}` : ""); // heure saisie sur le téléphone (déjà en heure de Paris)
function genMdp() { // 10 caractères faciles à recopier (sans 0/O/l/1)
  const c = "ABCDEFGHJKMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789";
  return Array.from({ length: 10 }, () => c[crypto.randomInt(c.length)]).join("");
}
/* ---------- Propriétaire : seul compte autorisé à modifier l'application ---------- */
const PROPRIO = () => String(process.env.OWNER_EMAIL || process.env.ADMIN_EMAIL || "mr.mecheti@gmail.com").trim().toLowerCase();
const estProprio = (u) => !!u && (u.id === "__admin" || u.id === PROPRIO());
const refusProprio = () => json({ error: "Seul le propriétaire de l'application peut modifier ce réglage" }, 403);

/* ---------- Accès des agents selon le planning ---------- */
const AGENTS = ["ads", "ssiap1", "ssiap2", "ssiap3"];
const MAIL_PC_DEFAUT = "pc@valmont.test";
const ACCES24_DEFAUT = [MAIL_PC_DEFAUT];
const ADMINS_DEFAUT = [MAIL_PC_DEFAUT, "t.garnier@valmont.test"]; // PC sécurité + Thomas Garnier (responsable PCS journée) // comptes administrateurs : voient et font tout (l'écran Administration reste au propriétaire)
async function estAdminPC(id) { return !!id && id !== "__admin" && (await load("admins_pc", ADMINS_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(id).toLowerCase()); }
const REDAC_DEFAUT = [MAIL_PC_DEFAUT, "l.fontaine@valmont.test"]; // le PC sécurité peut téléverser des documents (Lucas Fontaine à ajouter)
const TYPES_RAPPORT = Object.fromEntries(globalThis.RAP_CATS.flatMap((c) => c.types).map((t) => [t.k, t]));
const MARGE_AVANT = 60, MARGE_APRES = 60; // minutes autour de la vacation
const toksNom = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z ]/g, " ").split(/\s+/).filter(Boolean);
const lev = (a, b) => { const m = [...Array(b.length + 1).keys()]; for (let i = 1; i <= a.length; i++) { let p = m[0]; m[0] = i; for (let j = 1; j <= b.length; j++) { const t = m[j]; m[j] = Math.min(m[j] + 1, m[j - 1] + 1, p + (a[i - 1] === b[j - 1] ? 0 : 1)); p = t; } } return m[b.length]; };
const tel9 = (t) => String(t || "").replace(/\D/g, "").slice(-9);
function memeAgent(u, v) {
  if (tel9(u.tel).length === 9 && tel9(u.tel) === tel9(v.tel)) return true;
  const a = toksNom(u.nom), b = toksNom(v.nom);
  if (!a.length || !b.length) return false;
  if ([...a].sort().join(" ") === [...b].sort().join(" ")) return true;
  const ok = a.filter((x) => b.some((y) => x === y || (x.length >= 5 && lev(x, y) <= (x.length >= 8 ? 2 : 1)))).length;
  return ok >= Math.min(2, a.length) && ok >= Math.min(2, b.length);
}
const minutesLocales = (date, hm) => { const [y, mo, d] = date.split("-").map(Number), [h, mi] = (hm || "00:00").split(":").map(Number); return Date.UTC(y, mo - 1, d, h, mi) / 60000; };
function maintenantParis() {
  const p = Object.fromEntries(new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" })
    .formatToParts(new Date()).map((x) => [x.type, x.value]));
  return minutesLocales(`${p.year}-${p.month}-${p.day}`, `${p.hour}:${p.minute}`);
}
const fenetre = (v) => { const d = minutesLocales(v.date, v.debut); let f = minutesLocales(v.date, v.fin || v.debut); if (f <= d) f += 1440; return [d - MARGE_AVANT, f + MARGE_APRES]; };
async function accesPlanning(u) {
  if (!u || !AGENTS.includes(u.role) || u.horsPlanning || u.id === "__admin") return { ok: true };
  const pl = await load("planning", PLANNING_INITIAL), now = maintenantParis();
  const siens = pl.filter((v) => v.debut && memeAgent(u, v));
  const enCours = siens.find((v) => { const [a, b] = fenetre(v); return now >= a && now <= b; });
  if (enCours) return { ok: true, vacation: enCours };
  const proch = siens.map((v) => [fenetre(v)[0], v]).filter(([a]) => a > now).sort((x, y) => x[0] - y[0])[0];
  const msg = !siens.length ? "Tu n'apparais pas au planning : l'accès est réservé aux agents planifiés. Contacte le PC sécurité (04 65 71 00 00)."
    : proch ? `Accès possible uniquement pendant tes vacations (1 h avant à 1 h après). Prochaine vacation : ${new Date(proch[1].date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} de ${proch[1].debut} à ${proch[1].fin} — ${proch[1].site || ""}.`
    : "Aucune vacation à venir au planning : accès impossible pour le moment. Contacte le PC sécurité (04 65 71 00 00).";
  return { ok: false, message: msg };
}

// Planning personnel d'un agent (ses vacations à venir seulement)
async function planningDe(u) {
  if (u && (u.id === "__admin" || estProprio(u))) u = { ...u, nom: process.env.OWNER_NOM || "Rochdi Mecheti" }; // planning du propriétaire
  const pl = await load("planning", PLANNING_INITIAL), d1 = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
  return pl.filter((v) => v.date >= d1 && memeAgent(u, v)).sort((a, b) => (a.date + a.debut).localeCompare(b.date + b.debut))
    .map(({ date, debut, fin, poste, evenement, site, code }) => ({ date, debut, fin, poste, evenement, site, code }));
}
// Périmètre d'un agent selon son poste au planning : PCS Arena, P3, portail, ou SSIAP 2 du PC Parc (voit et gère tout)
function perimetreDe(poste) {
  const p = String(poste || "").toUpperCase();
  if (/PCS?\s*ARENA/.test(p)) return "arena";
  if (/\bP\s?3\b/.test(p)) return "p3";
  if (/PORTAIL|BARRI[EÈ]RE/.test(p)) return "portail";
  if (/SSIAP\s?2/.test(p) && !/ARENA/.test(p)) return "pcparc";
  return "";
}
// Dossier des agents : diplômes, carte pro, habilitations, recyclages (+ visite médicale pour l'équipe du PCS)
// [type, libellé, validité en années (0 = pas d'échéance)]
const DOC_TYPES = [["ads", "Diplôme initial ADS (CQP / TFP APS)", 0], ["cartepro", "Carte professionnelle CNAPS", 5], ["macaps", "MAC APS (maintien des compétences)", 5],
  ["ssiap1", "Diplôme initial SSIAP 1", 0], ["ssiap2", "Diplôme initial SSIAP 2", 0], ["ssiap3", "Diplôme initial SSIAP 3", 0],
  ["recyclage", "Recyclage SSIAP", 3], ["ran", "Remise à niveau SSIAP (RAN)", 3], ["sst", "SST / MAC SST", 2], ["pse1", "PSE1 (formation continue)", 1],
  ["habelec", "Habilitation électrique", 3], ["visite", "Visite médicale (fiche d'aptitude)", 3], ["autre", "Autre document", 0]];
const EQUIPE_PCS_DEFAUT = [{ nom: "Julien Moreau", q: "ssiap3" }, { nom: "Lucas Fontaine", q: "ssiap2" }, { nom: "Nicolas Perret", q: "ssiap2" }, { nom: "Thomas Garnier", q: "ssiap2" }, { nom: "Sébastien Roux", q: "ssiap2" }, { nom: "Mehdi Caron", q: "ssiap2" }];
async function profilDossier(u) {
  const nom = estProprio(u) ? process.env.OWNER_NOM || "Rochdi Mecheti" : u.nom;
  const pcs = (await load("equipe_pcs", EQUIPE_PCS_DEFAUT)).find((x) => memeAgent({ nom }, { nom: x.nom }));
  const q = pcs ? pcs.q : AGENTS.includes(u.role) ? u.role : "";
  return { pcs: !!pcs, q };
}
// Lecture réglementaire du dossier : pour chaque obligation, échéance réelle, statut, action et date conseillée
const isoJ = (d) => d.toISOString().slice(0, 10);
const plusAns = (iso, n) => { const d = new Date(iso + "T12:00:00Z"); d.setUTCFullYear(d.getUTCFullYear() + n); d.setUTCDate(d.getUTCDate() - 1); return isoJ(d); };
const moinsMois = (iso, n) => { const d = new Date(iso + "T12:00:00Z"); d.setUTCMonth(d.getUTCMonth() - n); return isoJ(d); };
const joursAvant = (iso) => Math.floor((new Date(iso + "T23:59:59Z") - Date.now()) / 864e5);
function conformite(q, pcs, docs) {
  const der = (types) => docs.filter((d) => types.includes(d.type) && (d.obtention || d.echeance)).sort((x, y) => String(y.obtention || y.echeance).localeCompare(String(x.obtention || x.echeance)))[0];
  const out = [];
  const item = (k, lb, doc, ech, fenetre, action, conseil, ref, note = "") => {
    const j = ech ? joursAvant(ech) : null;
    const statut = !doc ? "manquant" : !ech ? "ok" : j < 0 ? "expire" : j <= fenetre ? "bientot" : "ok";
    let suggestion = "";
    if (ech && statut !== "ok") { const c = conseil(ech); suggestion = c > isoJ(new Date()) ? c : isoJ(new Date(Date.now() + 7 * 864e5)); }
    out.push({ k, lb, statut, echeance: ech || "", jours: j, action: doc ? action(statut) : `Déposer le document : ${lb.toLowerCase()}`, suggestion, ref, note, doc: doc ? doc.id : "" });
  };
  // échéance : date inscrite sur le document si elle respecte la réglementation, sinon date réglementaire
  const ech = (doc, ans) => { if (!doc) return ""; const regl = doc.obtention && ans ? plusAns(doc.obtention, ans) : "";
    if (doc.echeance && (!regl || doc.echeance <= regl)) return [doc.echeance, ""];
    return [regl || doc.echeance || "", doc.echeance && regl && doc.echeance > regl ? `échéance saisie (${doc.echeance.split("-").reverse().join("/")}) au-delà de la durée réglementaire : ramenée au ${regl.split("-").reverse().join("/")}` : ""]; };
  if (q === "ads") {
    const dip = der(["ads"]); item("ads", "Diplôme ADS (CQP / TFP APS)", dip, "", 0, () => "Diplôme sans date de fin", () => "", "Code de la sécurité intérieure, livre VI");
    const cp = der(["cartepro"]), [e, n] = ech(cp, 5), mac = der(["macaps"]);
    item("cartepro", "Carte professionnelle CNAPS", cp, e, 150,
      (st) => st === "expire" ? "Carte expirée : l'agent ne peut plus exercer. Demande de renouvellement CNAPS immédiate." : `${mac && mac.obtention && e && mac.obtention >= moinsMois(e, 24) ? "MAC APS fait : " : "Faire le MAC APS, puis "}déposer la demande de renouvellement au CNAPS au plus tard le ${e ? moinsMois(e, 3).split("-").reverse().join("/") : "—"} (3 mois avant l'échéance)`,
      (x) => moinsMois(x, 4), "Carte valable 5 ans, renouvellement à demander au moins 3 mois avant l'échéance, MAC APS préalable", n);
  }
  if (/^ssiap[123]$/.test(q)) {
    const niv = q.slice(-1), dip = der([q]);
    item("diplome", `Diplôme SSIAP ${niv}`, dip, "", 0, () => "Diplôme initial", () => "", "Arrêté du 2 mai 2005 modifié");
    const rec = der(["recyclage", "ran"]), base = [dip && dip.obtention, rec && rec.obtention].filter(Boolean).sort().pop();
    const e = base ? plusAns(base, 3) : "";
    item("recyclage", `Recyclage SSIAP ${niv} (tous les 3 ans)`, dip || rec ? { id: (rec || dip).id } : null, e, 90,
      (st) => st === "expire" ? `Recyclage dépassé : remise à niveau (RAN) SSIAP ${niv} obligatoire avant de reprendre la fonction` : `Inscrire au recyclage SSIAP ${niv} avant le ${e.split("-").reverse().join("/")} (secourisme SST / PSE1 valide exigé)`,
      (x) => moinsMois(x, 2), "Arrêté du 2 mai 2005, art. 7 : recyclage tous les 3 ans, sinon remise à niveau", base ? "" : "date d'obtention ou de dernier recyclage manquante");
    const sst = der(["sst"]), pse = der(["pse1"]), [es] = ech(sst, 2), [ep] = ech(pse, 1);
    const best = [[sst, es, "MAC SST (tous les 24 mois)"], [pse, ep, "formation continue PSE1 (annuelle)"]].filter((x) => x[0]).sort((x, y) => String(y[1] || "9").localeCompare(String(x[1] || "9")))[0];
    item("secourisme", "Secourisme SST ou PSE1", best && best[0], best ? best[1] : "", 60, (st) => `${st === "expire" ? "Secourisme expiré : " : ""}${best ? best[2] : ""} à faire avant le ${best && best[1] ? best[1].split("-").reverse().join("/") : "—"}`,
      (x) => moinsMois(x, 1), "SST ou PSE1 en cours de validité exigé pour le recyclage SSIAP");
    const he = der(["habelec"]), [eh, nh] = ech(he, 3);
    item("habelec", "Habilitation électrique", he, eh, 60, (st) => `${st === "expire" ? "Habilitation périmée : " : ""}recyclage habilitation électrique avant le ${eh ? eh.split("-").reverse().join("/") : "—"}, puis nouveau titre signé par l'employeur`,
      (x) => moinsMois(x, 2), "NF C 18-510 : recyclage recommandé tous les 3 ans", nh);
  }
  if (pcs) {
    const vm = der(["visite"]), [ev, nv] = ech(vm, 3);
    item("visite", "Visite médicale", vm, ev, 60, (st) => `${st === "expire" ? "Visite dépassée : " : ""}demander un rendez-vous au service de santé au travail avant le ${ev ? ev.split("-").reverse().join("/") : "—"}`,
      (x) => moinsMois(x, 1), "Code du travail R4624-17 / R4624-18 : au plus tous les 5 ans, 3 ans pour le travail de nuit", nv);
  }
  return out;
}
// Toutes les fiches de conformité (comptes + équipe PCS sans compte)
async function lectureDossiers() {
  const tous = await load("dossiers", {}), users0 = await load("users", []);
  const users = users0.some((u) => u.id === PROPRIO()) ? users0 : [...users0, { id: PROPRIO(), nom: process.env.OWNER_NOM || "Rochdi Mecheti", role: "admin" }];
  const out = [];
  for (const u of users) { if (u.actif === false || u.id === "__admin") continue; const p = await profilDossier(u), docs = tous[u.id] || [];
    if (!p.q && !p.pcs && !docs.length) continue;
    out.push({ id: u.id, nom: u.nom, role: u.role, ...p, docs, etat: conformite(p.q, p.pcs, docs) }); }
  for (const x of await load("equipe_pcs", EQUIPE_PCS_DEFAUT)) if (!users.some((u) => memeAgent({ nom: estProprio(u) ? process.env.OWNER_NOM || "Rochdi Mecheti" : u.nom }, { nom: x.nom })))
    out.push({ id: "", nom: x.nom, role: "", pcs: true, q: x.q, sansCompte: true, docs: [], etat: conformite(x.q, true, []) });
  return out.sort((a, b) => (b.pcs - a.pcs) || a.nom.localeCompare(b.nom, "fr"));
}
// Alertes « bientôt expiré » : mail au PC sécurité et au coordinateur PC (Lucas Fontaine) + notification dans l'appli
export async function alertesDossiers({ essai = false } = {}) {
  const liste = await lectureDossiers(), deja = await load("alertes_dossiers", {}), now = Date.now();
  const seuil = (j) => (j < 0 ? "expire" : j <= 7 ? "7" : j <= 15 ? "15" : j <= 30 ? "30" : j <= 60 ? "60" : j <= 90 ? "90" : "150");
  const items = [];
  for (const a of liste) for (const e of a.etat) if (e.statut === "bientot" || e.statut === "expire") {
    const cle = `${a.id || a.nom}|${e.k}|${e.echeance}`, s = seuil(e.jours), prev = deja[cle];
    const nouveau = !prev || prev.s !== s || (s === "expire" && now - prev.t > 7 * 864e5);
    items.push({ agent: a.nom, pcs: a.pcs, ...e, nouveau, cle, s });
  }
  items.sort((x, y) => x.jours - y.jours);
  const aEnvoyer = essai ? items : items.filter((x) => x.nouveau);
  const fr = (x) => (x ? x.split("-").reverse().join("/") : "");
  const dest = [...new Set([...String(await load("mail_pc", MAIL_PC_DEFAUT)).split(/[,;\s]+/), ...(await load("coordinateurs", COORD_DEFAUT))].map((e) => String(e).trim().toLowerCase()).filter((e) => /@/.test(e)))];
  if (aEnvoyer.length) {
    const nbE = aEnvoyer.filter((x) => x.statut === "expire").length;
    const sujet = `${essai ? "[ESSAI] " : ""}${nbE ? "🔴 " : "🟠 "}SSIAP Pro — ${aEnvoyer.length} document(s) d'agents à renouveler${nbE ? ` dont ${nbE} expiré(s)` : ""}`;
    const td = "padding:6px;border-bottom:1px solid #ddd;vertical-align:top;font-size:13px";
    const html = `<div style="font-family:Arial,sans-serif;max-width:760px"><h2 style="margin:0 0 6px">${escH(sujet)}</h2>
      <p style="color:#555;margin:0 0 10px">Lecture des diplômes et recyclages selon la réglementation. Date conseillée = date à laquelle lancer la démarche pour rester en règle.</p>
      <table style="border-collapse:collapse;width:100%"><tr style="background:#f3f3f3"><th style="${td};text-align:left">Agent</th><th style="${td};text-align:left">Document</th><th style="${td};text-align:left">Échéance</th><th style="${td};text-align:left">À faire</th><th style="${td};text-align:left">Date conseillée</th></tr>
      ${aEnvoyer.map((x) => `<tr><td style="${td}"><b>${escH(x.agent)}</b>${x.pcs ? "<br><span style='color:#888'>équipe PCS</span>" : ""}</td><td style="${td}">${escH(x.lb)}</td>
        <td style="${td};color:${x.statut === "expire" ? "#d7002e" : "#e07000"};white-space:nowrap"><b>${fr(x.echeance)}</b><br>${x.jours < 0 ? `expiré depuis ${-x.jours} j` : `dans ${x.jours} j`}</td>
        <td style="${td}">${escH(x.action)}${x.note ? `<br><i style="color:#888">${escH(x.note)}</i>` : ""}<br><span style="color:#888;font-size:11px">${escH(x.ref)}</span></td><td style="${td};white-space:nowrap"><b>${fr(x.suggestion)}</b></td></tr>`).join("")}</table>
      <p style="color:#888;font-size:12px">SSIAP Pro — Le PC Sécurité Parc Expo Valmont (T) / Valmont Arena (L) · Dossiers des agents : https://ssiap-ads-pro.netlify.app/#/dossiers</p></div>`;
    if (dest.length) await sendMail(dest.map((email) => ({ email, nom: "PC Sécurité" })), sujet, html).catch(() => {});
    await journal("dossiers", "SSIAP Pro", `${essai ? "[essai] " : ""}${aEnvoyer.length} document(s) à renouveler : ${aEnvoyer.slice(0, 3).map((x) => `${x.agent} (${x.lb}, ${fr(x.echeance)})`).join(", ")}${aEnvoyer.length > 3 ? "…" : ""}`, nbE ? "urgent" : "attention", "#/dossiers");
  }
  if (!essai) { for (const x of items) deja[x.cle] = { s: x.s, t: x.nouveau ? now : (deja[x.cle] || {}).t || now }; await save("alertes_dossiers", deja); }
  return { nb: items.length, envoyes: aEnvoyer.length, destinataires: dest, items: aEnvoyer };
}
// Demandes de DPAE : le SSIAP 3 (et le propriétaire) les fait, le coordinateur PC suit
const peutDPAE = (u) => !!u && (estProprio(u) || u.role === "admin" || u.role === "ssiap3" || u.roleAgent === "ssiap3" || u.profilMC === "ssiap3");
// Main courante imposée selon le poste du planning (sinon selon la qualification)
const PROFILS_MC = ["pcsarena", "ssiap2", "ssiap3", "ssiap1", "ssiap1v", "ads", "adsv", "p3", "portail"];
function profilDe(poste, role) {
  const p = String(poste || "").toUpperCase(), volant = /VOLANT/.test(p), per = perimetreDe(p);
  if (per === "arena") return "pcsarena";
  if (per === "p3" || per === "portail") return per;
  if (per === "pcparc") return "ssiap2";
  if (/SSIAP\s?3/.test(p)) return "ssiap3";
  if (/SSIAP\s?1/.test(p)) return volant ? "ssiap1v" : "ssiap1";
  if (/\bADS\b|AGENT DE S[EÉ]CURIT|FOUILLE|PALPATION|ACCUEIL|PARKING|GARDIENNAGE|VIGILANCE|SANITAIRE|R[EÉ]GULATION|CONTR[OÔ]LE/.test(p)) return volant ? "adsv" : "ads";
  if (volant) return role === "ssiap1" ? "ssiap1v" : "adsv";
  return { ssiap1: "ssiap1", ssiap2: "ssiap2", ssiap3: "ssiap3", ads: "ads" }[role] || "";
}
// ---------- Main courante rangée par mois (mc/AAAA-MM) : rien n'est effacé, l'appli ne charge que les mois utiles ----------
const moisDe = (iso) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit" }).format(new Date(iso || Date.now())).slice(0, 7);
const moisPrec = (m, n = 1) => { const [y, mo] = m.split("-").map(Number), d = new Date(Date.UTC(y, mo - 1 - n, 15)); return d.toISOString().slice(0, 7); };
async function mcMigrer() {
  if (await load("mc_migre", false)) return;
  const old = (await load("incidents", null)) || [], par = {};
  for (const i of old) (par[moisDe(i.t)] ||= []).push(i);
  const idx = new Set(await load("mc_index", []));
  for (const [m, l] of Object.entries(par)) { const cur = await load("mc/" + m, []), ids = new Set(cur.map((x) => x.id));
    await save("mc/" + m, [...cur, ...l.filter((x) => !ids.has(x.id))].sort((a, b) => b.t.localeCompare(a.t))); idx.add(m); }
  await save("mc_index", [...idx].sort().reverse());
  if (old.length) await save("incidents_avant_archivage", old); // copie de sécurité de l'ancienne liste
  await save("incidents", []); await save("mc_migre", true);
}
async function mcIndex() { await mcMigrer(); return load("mc_index", []); }
async function mcMois(m) { await mcMigrer(); return load("mc/" + m, []); }
async function mcRecents(n = 2) { const m = moisDe(); let out = []; for (let k = 0; k < n; k++) out = out.concat(await mcMois(moisPrec(m, k))); return out; }
async function mcEntre(du, au) { // du / au : AAAA-MM-JJ
  const idx = await mcIndex(), m1 = String(du || "0000").slice(0, 7), m2 = String(au || "9999").slice(0, 7);
  let out = []; for (const m of idx.filter((x) => x >= m1 && x <= m2).slice(0, 24)) out = out.concat(await mcMois(m)); return out.sort((a, b) => b.t.localeCompare(a.t));
}
async function mcAjouter(inc) {
  const m = moisDe(inc.t), l = await mcMois(m); l.unshift(inc); await save("mc/" + m, l);
  const idx = await load("mc_index", []); if (!idx.includes(m)) await save("mc_index", [...idx, m].sort().reverse());
}
async function mcTrouver(id) { // cherche dans les mois récents puis dans les archives
  const idx = await mcIndex(), cur = moisDe(), ordre = [cur, moisPrec(cur), ...idx.filter((x) => x !== cur && x !== moisPrec(cur))];
  for (const m of ordre) { const l = await load("mc/" + m, []); const inc = l.find((i) => id === i.id || id.startsWith(i.id + "-")); if (inc) return { inc, mois: m, list: l }; }
  return { inc: null };
}
// Copie mensuelle : CSV (Excel) + version imprimable, envoyée au PC et au coordinateur PC
const csvMC = (l) => "﻿" + [["N°", "Date saisie", "Heure du fait", "Poste", "Famille", "Type", "Gravité", "Statut", "Site", "Lieu", "Événement", "Faits", "Intervenants", "Actions", "Prestataire", "Société", "Immatriculation", "Auteur", "Photos", "Suivi"],
  ...[...l].reverse().map((i) => [i.numero, fmtParis(i.t) + " " + i.t.slice(0, 4), i.heure ? fmtHeure(i.heure) : "", i.poste, i.famille, i.categorie, i.gravite, i.statut, i.site, i.lieu, i.evenement, i.description, i.intervenants, i.actions, i.prestataire, i.societe, i.immat, i.auteur, i.photos || (i.photo ? 1 : 0),
    (i.suivi || []).map((x) => `${fmtParis(x.t)} ${x.qui} : ${x.note}`).join(" | ")])]
  .map((r) => r.map((v) => `"${String(v ?? "").replace(/"/g, '""').replace(/\r?\n/g, " ")}"`).join(";")).join("\r\n");
const nomMois = (m) => new Date(m + "-15T12:00:00Z").toLocaleDateString("fr-FR", { month: "long", year: "numeric" });
const htmlMC = (m, l) => `<!doctype html><html lang="fr"><meta charset="utf-8"><title>Main courante ${nomMois(m)}</title>
<style>body{font-family:Arial,sans-serif;font-size:11px;margin:16px}h1{font-size:18px;margin:0}table{border-collapse:collapse;width:100%;margin-top:10px}td,th{border:1px solid #bbb;padding:4px;vertical-align:top;text-align:left}th{background:#eee}.u{color:#c00;font-weight:bold}@media print{a{display:none}}</style>
<h1>Main courante — ${escH(nomMois(m))}</h1><p>Le PC Sécurité Parc Expo Valmont (T) / Valmont Arena (L) · ${l.length} saisie(s) · éditée le ${fmtParis(new Date().toISOString())}<br>SSIAP Pro — Application créée par Rochdi Mecheti</p>
<table><tr><th>N°</th><th>Date</th><th>Type</th><th>Gravité</th><th>Lieu</th><th>Faits / actions</th><th>Auteur</th><th>Statut</th></tr>
${[...l].reverse().map((i) => `<tr><td>${escH(i.numero)}</td><td>${escH(i.heure ? fmtHeure(i.heure) : fmtParis(i.t))}</td><td>${escH([i.famille, i.categorie].filter(Boolean).join(" · "))}</td><td class="${i.gravite === "urgente" ? "u" : ""}">${escH(i.gravite)}</td>
<td>${escH([i.site, i.lieu].filter(Boolean).join(" · "))}</td><td>${escH(i.description)}${i.actions ? "<br>➜ " + escH(i.actions) : ""}${(i.suivi || []).map((x) => `<br>↳ ${escH(fmtParis(x.t))} ${escH(x.qui)} : ${escH(x.note)}`).join("")}</td><td>${escH(i.auteur)}</td><td>${escH(i.statut)}</td></tr>`).join("")}</table></html>`;
export async function copieMensuelleMC({ mois, essai = false } = {}) {
  const m = mois || moisPrec(moisDe()), l = await mcMois(m);
  const dest = [...new Set([...String(await load("mail_pc", MAIL_PC_DEFAUT)).split(/[,;\s]+/), ...(await load("coordinateurs", COORD_DEFAUT))].map((e) => String(e).trim().toLowerCase()).filter((e) => /@/.test(e)))];
  const urg = l.filter((i) => i.gravite === "urgente").length, ouverts = l.filter((i) => i.statut !== "clos").length;
  const sujet = `${essai ? "[ESSAI] " : ""}📦 SSIAP Pro — Main courante — ${nomMois(m)} (${l.length} saisies)`;
  const html = `<div style="font-family:Arial,sans-serif;max-width:620px"><h2 style="margin:0 0 8px">${escH(sujet)}</h2>
    <p>Copie mensuelle de la main courante, à garder hors de l'application.</p><ul><li><b>${l.length}</b> saisie(s)</li><li><b>${urg}</b> urgente(s)</li><li><b>${ouverts}</b> non close(s)</li></ul>
    <p>En pièces jointes : le tableau Excel (CSV) et la version imprimable (ouvrir puis Imprimer ➜ PDF).</p><p style="color:#888;font-size:12px">SSIAP Pro — Le PC Sécurité Parc Expo Valmont (T) / Valmont Arena (L)</p></div>`;
  const b64 = (x) => Buffer.from(x, "utf8").toString("base64");
  if (dest.length) await sendMail(dest.map((email) => ({ email, nom: "PC Sécurité" })), sujet, html,
    [{ name: `main-courante-${m}.csv`, content: b64(csvMC(l)) }, { name: `main-courante-${m}.html`, content: b64(htmlMC(m, l)) }]).catch(() => {});
  const arch = await load("mc_copies", {}); if (!essai) { arch[m] = new Date().toISOString(); await save("mc_copies", arch); }
  await journal("main courante", "SSIAP Pro", `${essai ? "[essai] " : ""}copie mensuelle de ${nomMois(m)} envoyée (${l.length} saisies)`, "info", "#/mc");
  // Conservation (désactivée tant que le propriétaire ne l'a pas validée) : supprime les mois trop anciens et les photos
  const cons = await load("mc_conservation", { actif: false, ansTexte: 5, ansPhotos: 3 });
  let purge = 0;
  if (cons.actif && !essai) {
    const idx = await mcIndex(), limT = moisPrec(moisDe(), cons.ansTexte * 12), limP = moisPrec(moisDe(), cons.ansPhotos * 12);
    for (const mm of idx) {
      if (mm < limT) { for (const i of await mcMois(mm)) for (let k = 0; k < Math.max(i.photos || 0, i.photo ? 1 : 0); k++) await save(`photo/${i.id}-${k}`, null);
        await save("mc/" + mm, null); purge++; }
      else if (mm < limP) { const l2 = await mcMois(mm); let ch = false; for (const i of l2) if (i.photos || i.photo) { for (let k = 0; k < Math.max(i.photos || 0, 1); k++) { await save(`photo/${i.id}-${k}`, null); await save("photo/" + i.id, null); } i.photos = 0; i.photo = false; i.photosSupprimees = true; ch = true; } if (ch) await save("mc/" + mm, l2); }
    }
    if (purge) await save("mc_index", idx.filter((x) => x >= limT));
  }
  return { mois: m, nb: l.length, destinataires: dest, purge };
}
// Infos sécurité de départ du plan (complétées ensuite dans l'appli)
const PLAN_INFOS_DEFAUT = {
  accB: { dae: "DAE à l'accueil B" },
  expl: { dae: "DAE au service d'exploitation" },
};
// ---------- Notifications push (Web Push, sans contenu chiffré : le téléphone vient chercher le message) ----------
const b64u = (buf) => Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
async function vapid() {
  let v = await load("vapid", null);
  if (!v) { const { privateKey, publicKey } = crypto.generateKeyPairSync("ec", { namedCurve: "prime256v1" });
    const jwk = publicKey.export({ format: "jwk" }); v = { prive: privateKey.export({ format: "jwk" }), cle: b64u(Buffer.concat([Buffer.from([4]), Buffer.from(jwk.x, "base64url"), Buffer.from(jwk.y, "base64url")])) };
    await save("vapid", v); }
  return v;
}
async function envoyerPush(dernier, pourQui = () => true) {
  const abos = await load("push_abos", {}), v = await vapid(), cle = crypto.createPrivateKey({ key: v.prive, format: "jwk" });
  dernier = { ...dernier, t: new Date().toISOString() }; await save("push_dernier", dernier);
  const users = await load("users", []); let envoyes = 0, change = false; const details = [];
  for (const [uid_, liste] of Object.entries(abos)) {
    const u = users.find((x) => x.id === uid_) || (estProprio({ id: uid_ }) ? { id: uid_, role: "admin" } : null);
    if (!u || !(await pourQui(u))) continue;
    for (const sub of [...liste]) {
      try {
        const aud = new URL(sub.endpoint).origin, h = b64u(JSON.stringify({ typ: "JWT", alg: "ES256" })), pl = b64u(JSON.stringify({ aud, exp: Math.floor(Date.now() / 1000) + 12 * 3600, sub: "mailto:" + PROPRIO() }));
        const sig = b64u(crypto.sign("sha256", Buffer.from(h + "." + pl), { key: cle, dsaEncoding: "ieee-p1363" }));
        const r = await fetch(sub.endpoint, { method: "POST", headers: { TTL: "3600", Urgency: "high", Authorization: `vapid t=${h}.${pl}.${sig}, k=${v.cle}`, "Content-Length": "0" } });
        const service = /apple/.test(aud) ? "Apple (iPhone)" : /google|fcm/.test(aud) ? "Google (Android / Chrome)" : /mozilla/.test(aud) ? "Mozilla (Firefox)" : /windows|notify/.test(aud) ? "Microsoft (Edge)" : aud;
        details.push({ service, status: r.status, texte: r.ok ? "" : (await r.text().catch(() => "")).slice(0, 160) });
        if (r.status === 404 || r.status === 410) { abos[uid_] = abos[uid_].filter((x) => x.endpoint !== sub.endpoint); change = true; } else if (r.ok) envoyes++;
      } catch (e) { details.push({ service: "?", status: 0, texte: String(e.message || e).slice(0, 160) }); }
    }
  }
  if (change) await save("push_abos", abos);
  const log = await load("push_log", []); log.unshift({ t: new Date().toISOString(), titre: dernier.titre, envoyes, details: details.slice(0, 20) }); await save("push_log", log.slice(0, 30));
  envoyerPush.details = details;
  return envoyes;
}
// qui reçoit : les responsables et le PC toujours ; les agents seulement pendant leur vacation
const enService = async (u) => isStaff(u) || estProprio(u) || !AGENTS.includes(u.role) || u.horsPlanning || (await accesPlanning(u)).ok;
// ---------- Planification (type Comète) : SSIAP 3 Julien Moreau et Antoine Rivière ; administrateurs en lecture ----------
const PLANIFS_NOMS = ["Julien Moreau", "Antoine Rivière"];
async function peutPlanif(u) {
  if (!u) return false; if (estProprio(u)) return true;
  const mails = (await load("planificateurs", [])).map((e) => String(e).toLowerCase());
  if (mails.includes(String(u.id).toLowerCase())) return true;
  return !mails.length && PLANIFS_NOMS.some((n) => memeAgent({ nom: u.nom }, { nom: n })); // tant que la liste n'est pas remplie : reconnus par leur nom
}
// rédacteurs : planifient, mais leurs saisies attendent la validation d'un planificateur (Julien Moreau) avant publication
const REDAC_PLANIF_DEFAUT = ["t.garnier@valmont.test", "l.fontaine@valmont.test"];
async function estRedacPlanif(u) { return !!u && (await load("planif_redacteurs", REDAC_PLANIF_DEFAUT)).map((e) => String(e).toLowerCase()).includes(String(u.id).toLowerCase()); }
async function niveauPlanif(u) { return (await peutPlanif(u)) ? "valideur" : (await estRedacPlanif(u)) ? "redacteur" : ""; }
async function voirPlanif(u) { return (await peutPlanif(u)) || (await estRedacPlanif(u)) || (u && (u.role === "admin" || (await estAdminPC(u.id)) || (await estCoord(u)))); }
// Alertes forcées : nouvelle sonnerie toutes les 2 minutes (5 fois au plus) pour ceux qui n'ont pas confirmé
export async function relancerAlertes() {
  const list = await load("alertes", []), now = Date.now(); let n = 0, change = false;
  for (const a of list) {
    if (!a.forcee || a.fin || Date.parse(a.exp) <= now || (a.relances || 0) >= 5 || now - Date.parse(a.derniereRelance || a.t) < 110e3) continue;
    const vus = new Set((a.vus || []).map((v) => v.id));
    a.relances = (a.relances || 0) + 1; a.derniereRelance = new Date().toISOString(); change = true;
    n += await envoyerPush({ titre: `RAPPEL ALERTE FORCÉE — ${a.nature}`, texte: `${a.lieu ? a.lieu + " · " : ""}${a.texte.slice(0, 150)} — confirme la réception`, url: "/#/alertes", alerte: true },
      async (u) => !vus.has(u.id) && !(estProprio(u) && vus.has("__admin")) && (await enService(u))).catch(() => 0);
  }
  if (change) await save("alertes", list);
  return n;
}
// Exemples de présentation : entrées réalistes avec les vrais agents du planning (marquées demo)
async function genererExemples(me) {
  // agents réels du planning : aujourd'hui, sinon le jour le plus proche qui a des vacations
  const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.nom && v.debut), auj = jourParis();
  const jours = [...new Set(pl.map((v) => v.date))].sort((a, b) => Math.abs(Date.parse(a) - Date.parse(auj)) - Math.abs(Date.parse(b) - Date.parse(auj)));
  let jourPl = "", lignes = [];
  for (const j of jours) { lignes = pl.filter((v) => v.date === j); if (new Set(lignes.map((v) => v.nom)).size >= 3) { jourPl = j; break; } }
  if (!lignes.length) throw new Error("Aucun agent au planning");
  const vus = new Set(), ag = lignes.filter((v) => !vus.has(v.nom) && vus.add(v.nom)).sort(() => Math.random() - 0.5);
  const parc = ag.filter((v) => !/arena/i.test((v.site || "") + " " + (v.poste || ""))), arena = ag.filter((v) => /arena/i.test((v.site || "") + " " + (v.poste || "")));
  const pick = (l, i) => (l.length ? l[i % l.length] : ag[i % ag.length]);
  const nomA = (v) => v.nom.split(/\s+/).map((x) => x.charAt(0) + x.slice(1).toLowerCase()).join(" ");
  const now = Date.now(), T = (minAgo) => new Date(now - minAgo * 60e3).toISOString();
  const hLoc = (iso) => new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Paris", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }).format(new Date(iso)).replace(" ", "T");
  const SITE = (v) => (/arena/i.test((v.site || "") + " " + (v.poste || "")) ? "Valmont Arena" : "Parc Expo Valmont");
  const year = new Date().getFullYear(), cpt = await load("mc_compteur", {}), rcpt = await load("rap_compteur", {});
  const MC = (minAgo, v, x) => { cpt[year] = (cpt[year] || 0) + 1; const t = T(minAgo);
    return { id: uid(), numero: `MC-${year}-${String(cpt[year]).padStart(4, "0")}`, t, heure: hLoc(t), auteurId: "demo", auteur: nomA(v), role: "ads", evenementId: null, evenement: v.evenement || "",
      categorie: "Information / consigne", famille: "", poste: "", societe: "", immat: "", gravite: "info", site: SITE(v), lieu: v.poste || "", description: "", intervenants: "", actions: "", prestataire: "", gps: null,
      statut: "clos", suivi: [], photo: false, photos: 0, demo: true, ...x }; };
  const RAP = (minAgo, v, kind, x) => { const K = TYPES_RAPPORT[kind] || TYPES_RAPPORT.autre; rcpt[K.pre + year] = (rcpt[K.pre + year] || 0) + 1; const t = T(minAgo);
    return { id: uid(), t, kind: TYPES_RAPPORT[kind] ? kind : "autre", label: K.lb, auteurId: "demo", auteur: nomA(v), poste: [v.poste, v.evenement].filter(Boolean).join(" — "), heure: hLoc(t), urgence: "normale", site: SITE(v),
      prestataire: "", details: {}, securise: "", intervenants: "", gps: null, photos: 0, statut: "ouvert", suivi: [], numero: `${K.pre}-${year}-${String(rcpt[K.pre + year]).padStart(4, "0")}`, demo: true, ...x }; };
  const a = [0, 1, 2, 3, 4, 5].map((i) => pick(parc, i)), b = [0, 1].map((i) => pick(arena, i));
  const mc = [
    MC(300, a[0], { categorie: "Prise de service", description: `Prise de service ${a[0].poste || ""}. Matériel radio et clés vérifiés, consignes du jour lues.` }),
    MC(296, a[1], { categorie: "Prise de service", description: `Prise de service ${a[1].poste || ""}. Radio OK, RAS.` }),
    MC(292, b[0], { categorie: "Prise de service", description: `Prise de service ${b[0].poste || ""} à l'Arena. Tour des issues effectué.` }),
    MC(250, a[2], { categorie: "Ouverture / fermeture site", description: "Ouverture du portail principal et des accès piétons pour l'arrivée des exposants.", lieu: "Portail principal" }),
    MC(205, a[3], { categorie: "Accès / contrôle entrée", famille: "Livraison", societe: "Transports Sud Logistique", immat: "GH-512-KL", description: "Livraison stand B12, véhicule orienté vers le quai Hall B.", lieu: "Accès livraisons" }),
    MC(160, a[0], { categorie: "Information / consigne", description: "Consigne PC : fermeture de la passerelle à 19 h, report des flux par le mail central.", lieu: "PC sécurité" }),
    MC(95, b[1], { categorie: "Refus d'entrée", gravite: "moyenne", description: "Personne sans billet refusant de quitter la file, dialogue puis départ sans incident.", lieu: "Porte 3", statut: "clos" }),
    MC(40, a[4], { categorie: "Alarme incendie / levée de doute", gravite: "moyenne", description: "Déclenchement détecteur Hall A1 zone 4. Levée de doute : poussière de montage, aucun feu. Réarmement SSI par le PC.", lieu: "Hall A1", actions: "Levée de doute, réarmement" }),
  ];
  for (const i of mc) await mcAjouter(i);
  await save("mc_compteur", cpt);
  const raps = [
    RAP(230, a[2], "issue", { lieu: "Hall B — issue n°4", texte: "Issue de secours encombrée par des palettes d'un exposant. Exposant prévenu, issue dégagée.", securise: "Issue dégagée et contrôlée", statut: "clos" }),
    RAP(130, a[5], "malaise", { lieu: "Hall A — allée centrale", urgence: "normale", details: { Victime: "Femme", "Âge approximatif": "45" }, texte: "Visiteuse prise d'un malaise, mise au repos et hydratée, partie par ses propres moyens après 20 min.", securise: "Zone sécurisée, victime accompagnée", statut: "clos" }),
    RAP(70, pick(parc, 6), "extincteur", { lieu: "Hall C — stand C08", texte: "Extincteur CO2 déplacé derrière un stand. Remis à son emplacement, signalé au chef de projet.", statut: "ouvert" }),
  ];
  const rapL = (await load("rap", null)) || []; await save("rap", [...raps.reverse(), ...rapL]); await save("rap_compteur", rcpt);
  const rapports = await load("rapports", []);
  rapports.unshift({ id: uid(), t: T(20), auteurId: "demo", auteur: nomA(a[1]), titre: "Point de situation montage", site: "Parc Expo Valmont", lieu: "Halls A et B", texte: "Montage en cours, accès livraisons fluides. Deux issues rappelées aux exposants. Aucun incident à signaler.", gps: null, photos: 0, demo: true });
  await save("rapports", rapports);
  const pc = (await load("parcours", PARCOURS_INITIAL))[0];
  if (pc) { const rondes = await load("rondes_nfc", []), deb = now - 180 * 60e3;
    rondes.unshift({ id: uid(), parcoursId: pc.id, nom: pc.nom, site: pc.site, dureeMax: pc.dureeMax || 0, points: pc.points, agentId: "demo", agent: nomA(a[3]), poste: a[3].poste || "", debut: new Date(deb).toISOString(), fin: new Date(deb + 38 * 60e3).toISOString(), statut: "terminée", duree: 38, oublies: 0, anomalies: 1,
      passages: pc.points.map((p, i) => ({ uid: p.uid, nom: p.nom, t: new Date(deb + (i + 1) * 6 * 60e3).toISOString(), ras: i !== 2, obs: i === 2 ? "Éclairage extérieur défaillant" : "", ordre: i + 1, mode: "nfc" })), ordreOk: true, obs: "", demo: true });
    await save("rondes_nfc", rondes); }
  const ck = await load("checklists", []);
  ck.unshift({ id: uid(), t: T(270), agentId: "demo", agent: nomA(a[0]), modele: "Ouverture du PC sécurité", evenement: a[0].evenement || "", lieu: "PC sécurité", obs: "", items: ["Report SSI vérifié", "Radios chargées", "Main courante ouverte", "Clés au tableau"].map((label) => ({ label, ok: true, nc: false })), conforme: true, demo: true });
  await save("checklists", ck);
  const cm = await load("cles_mvt", []), s1 = T(240);
  cm.unshift({ id: uid(), n: "B4", cle: "Local technique Hall B", type: "retour", nom: "Elektra", societe: "Elektra", sortie: s1, duree: 110, obs: "", t: T(130), par: nomA(a[0]), demo: true },
    { id: uid(), n: "B4", cle: "Local technique Hall B", type: "sortie", cat: "prestataire", nom: "Elektra", societe: "Elektra", motif: "Intervention électrique", t: s1, par: nomA(a[0]), demo: true });
  await save("cles_mvt", cm);
  const bm = await load("batiments_mvt", []);
  bm.unshift({ id: uid(), t: T(280), halls: ["Hall A", "Hall B"], actions: ["ouverture", "eclairage_on"], libelle: "Ouverture + Mise en fonction éclairage", dem: { type: "organisateur", societe: "", nom: "Chef de projet" }, commentaire: "Arrivée des exposants", par: nomA(a[0]), demo: true });
  await save("batiments_mvt", bm);
  const al = await load("alertes", []);
  al.unshift({ id: uid(), t: T(150), exp: T(90), nature: "Enfant perdu", texte: "Garçon 6 ans, t-shirt rouge, vu vers le Hall B.", lieu: "Hall B", site: "Parc Expo Valmont", auteur: nomA(a[2]), auteurId: "demo", forcee: false, vus: [],
    fin: { t: T(135), par: nomA(a[0]), note: "Enfant retrouvé et remis à ses parents au PC" }, demo: true });
  await save("alertes", al);
  await journal("admin", me.nom, `exemples de présentation créés avec ${ag.length} agent(s) du planning du ${jourPl.split("-").reverse().join("/")}`);
  return { ok: true, jour: jourPl, agents: [...new Set([...a, ...b].map(nomA))], nb: mc.length + raps.length + 6 };
}

/* ---------- DÉMONSTRATION : comptes et données d'exemple créés automatiquement (données fictives) ---------- */
const DEMO_MDP = "demo2026";
const DEMO_COMPTES = [
  { id: "pc@valmont.test", nom: "PC SÉCURITÉ", role: "responsable", prenom: "PC", nomF: "SÉCURITÉ", tel: "0465710000" },
  { id: "t.garnier@valmont.test", nom: "Thomas GARNIER", role: "responsable", prenom: "Thomas", nomF: "GARNIER", tel: "0639981101" },
  { id: "l.fontaine@valmont.test", nom: "Lucas FONTAINE", role: "responsable", prenom: "Lucas", nomF: "FONTAINE", tel: "0639981102" },
  { id: "j.moreau@valmont.test", nom: "Julien MOREAU", role: "ssiap3", prenom: "Julien", nomF: "MOREAU", tel: "0639981103", horsPlanning: true },
  { id: "agent.ads@valmont.test", nom: "Yanis MOREL", role: "ads", prenom: "Yanis", nomF: "MOREL", tel: "0639981104", horsPlanning: true },
  { id: "agent.ssiap1@valmont.test", nom: "Camille LEROY", role: "ssiap1", prenom: "Camille", nomF: "LEROY", tel: "0639981105", horsPlanning: true },
  { id: "client@valmont.test", nom: "Client VEV", role: "responsable", prenom: "Client", nomF: "VEV", tel: "0465710010" },
];
let demoPret = false;
async function seedDemo() {
  if (demoPret) return; demoPret = true;
  if (await load("demo_seed_v1", false)) return;
  const users = await load("users", []), fiches = await load("fiches", {});
  for (const c of DEMO_COMPTES) {
    if (!users.some((u) => u.id === c.id)) users.push({ id: c.id, nom: c.nom, role: c.role, tel: c.tel, actif: true, horsPlanning: !!c.horsPlanning, pin: hashPin(DEMO_MDP), cree: new Date().toISOString() });
    fiches[c.id] ||= { nom: c.nomF, prenom: c.prenom, naissance: "1990-01-01", adresse: "1 route des Salons", cp: "99100", ville: "Valmont-sur-Mer", tel: c.tel, email: c.id, diplomes: [], consentement: true, maj: new Date().toISOString() };
  }
  await save("users", users); await save("fiches", fiches);
  try { await genererExemples({ nom: "PC SÉCURITÉ", id: "pc@valmont.test" }); } catch {}
  await save("demo_seed_v1", true);
}
// Coordinateur Arena : poste du planning « COORD… » à l'Arena ➜ il répartit les ADS du jour par groupe
const estCoordArena = (v) => !!v && /COORD/i.test(v.poste || "") && /ARENA/i.test((v.poste || "") + " " + (v.site || ""));
const GROUPES_ARENA = [["portes", "🚪 Portes fouilles", /PORTE|FOUILLE|PALPATION/], ["bord", "🏟️ Bord terrain", /BORD|TERRAIN|PISTE/], ["interv", "🚨 Intervention", /INTERV|VOLANT|R[EÉ]GUL/],
  ["parterre", "👥 Parterre", /PARTERRE|FOSSE|PELOUSE/], ["joueurs", "⛹️ Entrée joueurs", /JOUEUR|VESTIAIRE/], ["artistes", "🎤 Accès artistes", /ARTISTE|LOGE ARTISTE|BACKSTAGE/],
  ["crash", "🛑 Crash", /CRASH/], ["vip", "🥂 Loges VIP partenaires", /VIP|PARTENAIRE|LOGE/]];
const estADS = (v) => /\bADS\b|AGENT DE S[EÉ]CURIT/i.test((v.qualif || "") + " " + (v.poste || "")) || (!/SSIAP|PC\b|COORD|CHEF/i.test(v.poste || "") && !/SSIAP/i.test(v.qualif || ""));
// ADS de l'Arena d'un jour, rangés par groupe (planning + répartition du coordinateur)
async function equipeArenaJour(date) {
  const eq = (await load("arena_equipes", {}))[date] || { affect: {}, requis: {}, ajouts: [], retires: [] };
  const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === date && /ARENA/i.test((v.site || "") + " " + (v.poste || "")) && estADS(v) && !estCoordArena(v));
  const auto = (poste) => (GROUPES_ARENA.find((g) => g[2].test(String(poste || "").toUpperCase())) || ["aplacer"])[0];
  const agents = pl.map((v) => { const id = `${v.nom}|${v.debut}`; return { id, nom: v.nom, debut: v.debut, fin: v.fin, poste: v.poste || "", groupe: eq.affect[id] || auto(v.poste), retire: (eq.retires || []).includes(id) }; })
    .concat((eq.ajouts || []).map((a) => ({ id: a.id, nom: a.nom, debut: a.debut, fin: a.fin, poste: "ajouté par " + a.par, groupe: eq.affect[a.id] || "aplacer", ajoute: true }))).filter((a) => !a.retire);
  return { date, evenement: [...new Set(pl.map((v) => v.evenement).filter(Boolean))].join(" · "),
    groupes: [["aplacer", "❓ À placer"], ...GROUPES_ARENA.map(([k, lb]) => [k, lb])].map(([k, lb]) => ({ k, lb, requis: (eq.requis || {})[k] || 0, agents: agents.filter((a) => a.groupe === k).sort((x, y) => x.nom.localeCompare(y.nom, "fr")) })).filter((g) => g.agents.length || g.requis) };
}
const jourParis = (decal = 0) => new Intl.DateTimeFormat("fr-CA", { timeZone: "Europe/Paris" }).format(new Date(Date.now() + decal * 864e5));
// Rôle, périmètre et main courante d'un agent pour sa vacation en cours
function infosPoste(u, acc) {
  const poste = acc && acc.ok && acc.vacation ? acc.vacation.poste : "";
  const perimetre = acc && acc.vacation ? perimetreDe(acc.vacation.poste) : "";
  return { role: acc && acc.ok && perimetre === "pcparc" ? "pc" : u.role, perimetre, profilMC: AGENTS.includes(u.role) ? profilDe(poste, u.role) : "", postePlanning: poste || "",
    coordArena: estCoordArena(acc && acc.ok ? acc.vacation : null) ? acc.vacation.date : "" };
}
const dansPerimetre = (me, i) => i.auteurId === me.id || (me.perimetre === "arena" && /arena/i.test(i.site || "")) || (me.perimetre === "p3" && i.poste === "p3") || (me.perimetre === "portail" && i.poste === "portail");
// Superviseurs (lecture 24h/24) = accès 24h/24 + rédacteurs de documents
async function superviseurs() { return [...(await load("acces24", ACCES24_DEFAUT)), ...(await load("redacteurs", REDAC_DEFAUT))].map((e) => String(e).toLowerCase()); }
async function estRedac(me) { return !!me && (estProprio(me) || (await load("redacteurs", REDAC_DEFAUT)).map((e) => String(e).toLowerCase()).includes(me.id)); }
const COORD_DEFAUT = ["l.fontaine@valmont.test"]; // coordinateur PC sécurité : numéros, adresses mail, planning
const COORD_ADMIN = ["contacts", "destinataires", "acces24", "mail-pc", "test-mail"];
async function estCoord(me) { return !!me && (estProprio(me) || me.role === "admin" || (await estAdminPC(me.id)) || (await load("coordinateurs", COORD_DEFAUT)).map((e) => String(e).toLowerCase()).includes(me.id)); }
const MAX_DOC = 5_600_000;
const normUID = (x) => String(x || "").toUpperCase().replace(/[^0-9A-F]/g, "").slice(0, 32); // « 04:41:82:6a… » ➜ « 0441826A… » // ≈ 4 Mo de PDF une fois encodé

// Vacation de l'agent en ce moment (ou la plus proche aujourd'hui) — pour signer les rapports avec son poste
async function vacationDe(u) {
  if (!u || u.id === "__admin") return null;
  const pl = await load("planning", PLANNING_INITIAL), now = maintenantParis();
  const siens = pl.filter((v) => v.debut && memeAgent(u, v));
  return siens.find((v) => { const [a, b] = fenetre(v); return now >= a && now <= b; })
    || siens.map((v) => [Math.abs(fenetre(v)[0] - now), v]).filter(([d]) => d < 12 * 60).sort((a, b) => a[0] - b[0]).map((x) => x[1])[0] || null;
}
const ERP = (site) => (/arena/i.test(site || "") ? "Valmont Arena (ERP type L)" : /parc/i.test(site || "") ? "Parc Expo Valmont (ERP type T)" : site || "");
async function lignesAgent(me) {
  const v = await vacationDe(me);
  return [["Agent", me.nom], ["Téléphone", me.tel || ""],
    ["Poste planifié", v ? [v.poste, v.evenement].filter(Boolean).join(" — ") || "(poste non précisé au planning)" : "Hors planning"],
    ["Vacation", v ? `${new Date(v.date + "T12:00:00").toLocaleDateString("fr-FR", { weekday: "long", day: "numeric", month: "long" })} de ${v.debut} à ${v.fin}${v.site ? " — " + v.site : ""}` : ""]];
}

// Envoi d'un rapport à l'adresse mail du PC sécurité (avec photos en pièces jointes)
const escH = (x) => String(x ?? "").replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
async function mailPC(sujet, lignes, photos = []) { return mailVers(await load("mail_pc", MAIL_PC_DEFAUT), sujet, lignes, photos); }
async function mailVers(dest, sujet, lignes, photos = [], nomDest = "PC Sécurité") {
  if (!dest) return;
  const html = `<div style="font-family:Arial,sans-serif;max-width:620px"><h2 style="margin:0 0 8px">${escH(sujet)}</h2>
    <table style="border-collapse:collapse;width:100%">${lignes.filter(([, v]) => v).map(([k, v]) => `<tr><td style="padding:6px;border-bottom:1px solid #ddd;color:#666;width:130px;vertical-align:top">${escH(k)}</td><td style="padding:6px;border-bottom:1px solid #ddd;white-space:pre-wrap">${escH(v)}</td></tr>`).join("")}</table>
    ${photos.length ? `<p style="color:#666">${photos.length} photo(s) en pièce jointe.</p>` : ""}
    <p style="color:#888;font-size:12px">SSIAP Pro — Le PC Sécurité Parc Expo Valmont (T) / Valmont Arena (L) — 04 65 71 00 00<br>Site exploité par la VEV</p></div>`;
  const att = photos.map((d, i) => ({ name: `photo-${i + 1}.jpg`, content: String(d).replace(/^data:image\/\w+;base64,/, "") }));
  await sendMail(dest.split(/[,;\s]+/).filter(Boolean).map((email) => ({ email, nom: nomDest })), sujet, html, att).catch(() => {});
}
async function mailMdp(u, mdp, nouveau, url) {
  await sendMail([{ email: u.id, nom: u.nom }], nouveau ? "SSIAP Pro — ton accès à l'application" : "SSIAP Pro — ton nouveau mot de passe",
    `<div style="font-family:Arial,sans-serif;max-width:560px"><h2>SSIAP Pro</h2>
     <p>Bonjour ${u.nom},</p><p>${nouveau ? "Un compte a été créé pour toi sur l'application SSIAP Pro." : "Un nouveau mot de passe a été généré pour ton compte."}</p>
     <p>Identifiant : <b>${u.id}</b><br>Mot de passe : <b style="font-size:20px;letter-spacing:1px">${mdp}</b></p>
     <p><a href="${url}" style="display:inline-block;background:#d7102e;color:#fff;padding:10px 18px;border-radius:8px;text-decoration:none">Ouvrir SSIAP Pro</a></p>
     <p style="color:#666;font-size:13px">Change ce mot de passe dans « Plus ➜ Changer mon mot de passe » après ta première connexion. Ne le partage avec personne.</p>
     <p style="color:#888;font-size:12px">SSIAP Pro — Application créée par Rochdi Mecheti</p></div>`);
}

export default async (req) => {
  await seedDemo().catch(() => {});
  const url = new URL(req.url);
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean);
  const [r0, r1, r2, r3] = parts;
  const m = req.method;
  const body = m === "GET" ? {} : await req.json().catch(() => ({}));

  try {
    /* ---------- Connexion ---------- */
    if (r0 === "login" && m === "POST") {
      const id = String(body.email || body.id || "").trim().toLowerCase();
      const mdp = String(body.mdp ?? body.pin ?? "").trim();
      const locks = await load("locks", {});
      const lk = locks[id];
      if (lk && lk.n >= 5 && Date.now() - lk.t < 10 * 60e3) return json({ error: "Trop d'essais, réessaie dans 10 min" }, 429);

      let user = null;
      const adminPass = String(process.env.ADMIN_PASSWORD || process.env.ADMIN_PIN || "").trim();
      const adminIds = ["admin", (process.env.ADMIN_EMAIL || "mr.mecheti@gmail.com").toLowerCase()];
      const u = (await load("users", [])).find((x) => x.id === id && x.actif !== false);
      if (u && checkPin(mdp, u.pin)) user = u;
      else if (!u && adminIds.includes(id) && adminPass && mdp === adminPass) user = { id: "__admin", nom: "Administrateur", role: "admin" };
      if (!user && !u && adminIds.includes(id) && !adminPass)
        return json({ error: "Le serveur ne trouve pas ADMIN_PASSWORD : vérifie la variable dans Netlify puis relance un déploiement" }, 401);
      if (!user) {
        locks[id] = { n: (lk && Date.now() - lk.t < 10 * 60e3 ? lk.n : 0) + 1, t: Date.now() };
        await save("locks", locks);
        return json({ error: "E-mail ou mot de passe incorrect" }, 401);
      }
      if (lk) { delete locks[id]; await save("locks", locks); }
      if (AGENTS.includes(user.role) && (await superviseurs()).includes(user.id)) {
        const us = await load("users", []), uu = us.find((x) => x.id === user.id);
        if (uu) { uu.role = "responsable"; await save("users", us); user = uu; }
      }
      const acc = (await estAdminPC(user.id)) ? { ok: true } : await accesPlanning(user); // un administrateur se connecte à toute heure
      await journal("connexion", user.nom, !acc.ok ? "hors vacation : planning et disponibilités seulement" : user.role + (acc.vacation ? ` · vacation ${acc.vacation.debut}-${acc.vacation.fin} ${acc.vacation.site || ""}` : ""));
      const fiches = await load("fiches", {});
      return json({ token: signToken(user), message: acc.ok ? undefined : acc.message,
        user: { id: user.id, nom: user.nom, ...infosPoste(user, acc), planif: await peutPlanif(user), niveauPlanif: await niveauPlanif(user), voitPlanif: await voirPlanif(user), ...((await estAdminPC(user.id)) ? { role: "admin" } : {}), hors: !acc.ok, proprio: estProprio(user), redac: await estRedac(user), coord: await estCoord(user), ficheOk: isStaff(user) || !!fiches[user.id] } });
    }

    /* ---------- Inscription d'un agent : impossible sans le code d'accès donné par le PC ---------- */
    if (r0 === "inscription" && m === "POST") {
      const t = (v, n = 80) => String(v ?? "").trim().slice(0, n);
      const email = t(body.email, 120).toLowerCase();
      const locks = await load("locks", {}), k = "inscr:" + (req.headers.get("x-nf-client-connection-ip") || req.headers.get("x-forwarded-for") || "?").split(",")[0];
      const lk = locks[k];
      if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
      const h = await load("code_agents", null), hResp = await load("code_resp", null), mode = await load("inscription_mode", "libre");
      const codeSaisi = String(body.code || "").trim();
      const acces24 = await superviseurs();
      const estResp = acces24.includes(email) || (!!hResp && !!codeSaisi && checkPin(codeSaisi, hResp));
      if (!estResp && mode === "ferme") return json({ error: "Les inscriptions sont fermées pour le moment : contacte le PC sécurité" }, 403);
      // Inscriptions libres : un code faux ou rempli automatiquement par le téléphone est simplement ignoré
      if (!estResp && mode === "code" && h && !checkPin(codeSaisi, h)) {
        locks[k] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: Date.now() }; await save("locks", locks);
        await journal("inscription", t(body.prenom) + " " + t(body.nom), `code d'accès faux (${email})`, "attention", "#/admin");
        return json({ error: "Code d'accès incorrect : demande-le au PC sécurité" }, 403);
      }
      const nom = t(body.nom).toUpperCase(), prenom = t(body.prenom), tel = t(body.tel, 20), mdp = String(body.mdp || "");
      if (!nom || !prenom) return json({ error: "Nom et prénom obligatoires" }, 400);
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return json({ error: "Adresse e-mail invalide" }, 400);
      if (tel.replace(/\D/g, "").length < 9) return json({ error: "Numéro de téléphone invalide" }, 400);
      if (mdp.length < 6) return json({ error: "Mot de passe : 6 caractères minimum" }, 400);
      const users = await load("users", []);
      if (email === PROPRIO()) return json({ error: "Cette adresse est réservée" }, 403);
      if (users.some((u) => u.id === email)) return json({ error: "Un compte existe déjà avec cet e-mail : utilise « Mot de passe oublié » si besoin" }, 409);
      const role = estResp ? "responsable" : ["ads", "ssiap1", "ssiap2", "ssiap3"].includes(body.role) ? body.role : "ads";
      const u = { id: email, nom: `${prenom} ${nom}`, role, tel, actif: true, pin: hashPin(mdp), cree: new Date().toISOString(), inscrit: true };
      users.push(u); await save("users", users);
      if (lk) { delete locks[k]; await save("locks", locks); }
      await journal("inscription", u.nom, `nouveau compte ${estResp ? "RESPONSABLE" : "agent"} (${role}, ${email})`, estResp ? "attention" : "info", "#/admin");
      const acc = (await estAdminPC(u.id)) ? { ok: true } : await accesPlanning(u);
      return json({ token: signToken(u), message: acc.ok ? undefined : "Compte créé ✅ " + acc.message,
        user: { id: u.id, nom: u.nom, ...infosPoste(u, acc), planif: await peutPlanif(u), niveauPlanif: await niveauPlanif(u), voitPlanif: await voirPlanif(u), ...((await estAdminPC(u.id)) ? { role: "admin" } : {}), hors: !acc.ok, redac: await estRedac(u), coord: await estCoord(u), ficheOk: estResp } }, 201);
    }

    /* ---------- Mot de passe oublié : code à 6 chiffres envoyé par mail ---------- */
    if (r0 === "reset" && m === "POST") {
      const id = String(body.email || "").trim().toLowerCase();
      const users = await load("users", []), u = users.find((x) => x.id === id && x.actif !== false);
      const resets = await load("resets", {});
      if (!body.code) {
        if (u && !(resets[id] && Date.now() - resets[id].t < 60e3)) {
          const code = String(crypto.randomInt(100000, 1000000));
          resets[id] = { h: hashPin(code), t: Date.now(), n: 0 };
          await save("resets", resets);
          await sendMail([{ email: id, nom: u.nom }], "SSIAP Pro — code de réinitialisation",
            `<p>Bonjour ${u.nom},</p><p>Ton code pour choisir un nouveau mot de passe : <b style="font-size:22px;letter-spacing:3px">${code}</b></p><p>Valable 15 minutes. Si tu n'as rien demandé, ignore ce mail.</p>`);
        }
        return json({ ok: true }); // même réponse que le compte existe ou non
      }
      const r = resets[id];
      if (!u || !r || Date.now() - r.t > 15 * 60e3 || r.n >= 5) return json({ error: "Code expiré, redemande un code" }, 400);
      if (!checkPin(body.code, r.h)) { r.n++; await save("resets", resets); return json({ error: "Code incorrect" }, 400); }
      if (String(body.mdp || "").length < 6) return json({ error: "Mot de passe : 6 caractères minimum" }, 400);
      u.pin = hashPin(String(body.mdp)); delete resets[id];
      await save("users", users); await save("resets", resets);
      await journal("compte", u.nom, "mot de passe réinitialisé par mail");
      return json({ ok: true });
    }

    /* ---------- État de la configuration (ne montre jamais les valeurs secrètes) ---------- */
    if (r0 === "etat" && m === "GET") {
      const users = await load("users", []);
      return json({ demo: true, version: "3.62", ADMIN_PASSWORD: !!String(process.env.ADMIN_PASSWORD || process.env.ADMIN_PIN || "").trim(),
        ADMIN_EMAIL: process.env.ADMIN_EMAIL ? process.env.ADMIN_EMAIL.replace(/^(.).*(@.*)$/, "$1…$2") : "(défaut)",
        APP_SECRET: !!process.env.APP_SECRET, BREVO_API_KEY: !!process.env.BREVO_API_KEY, MAIL_FROM: !!process.env.MAIL_FROM,
        MF_API_KEY: !!process.env.MF_API_KEY, comptes: users.length });
    }

    /* ---------- Intitulés personnalisés (lisibles sans connexion pour l'écran d'accueil) ---------- */
    if (r0 === "textes" && m === "GET") return json(await load("textes", {}));

    const me = await currentUser(req);
    if (me && (await estAdminPC(me.id))) me.role = "admin"; // le PC sécurité est administrateur
    if (!me) return json({ error: "Session expirée, reconnecte-toi" }, 401);
    if (me.role === "responsable" && m !== "GET" && !["mdp", "deverrouiller", "notifs", "fiche", "alertes", "dossier", "push"].includes(r0) && !(r0 === "docs" && (await estRedac(me)))
      && !(((r0 === "admin" && COORD_ADMIN.includes(r1)) || r0 === "planning" || r0 === "sms" || r0 === "risques" || r0 === "dispos" || r0 === "parcours" || r0 === "cles" || r0 === "materiel" || r0 === "batiments" || r0 === "dpae" || r0 === "arena-equipe" || r0 === "plan") && (await estCoord(me)))
      && !((r0 === "planif" && (await niveauPlanif(me))) || (r0 === "planning" && (await peutPlanif(me)))))
      return json({ error: "Accès en lecture seule : tu peux tout consulter, mais pas modifier ni saisir" }, 403);
    if (AGENTS.includes(me.role)) {
      const u = (await load("users", [])).find((x) => x.id === me.id);
      const acc = await accesPlanning(u || me);
      // Hors vacation : seulement son planning, ses disponibilités, sa fiche et son mot de passe
      if (!acc.ok && !["me", "monplanning", "dispos", "fiche", "mdp", "dossier", "push"].includes(r0) && !(r0 === "dpae" && peutDPAE(u || me)) && !((r0 === "planif" || r0 === "planning") && (await peutPlanif(u || me)))) return json({ error: acc.message, hors: true }, 403);
      me.hors = !acc.ok; me.horsMessage = acc.ok ? "" : acc.message;
      const ip = infosPoste(u || me, acc);
      me.perimetre = ip.perimetre; me.profilMC = ip.profilMC; me.postePlanning = ip.postePlanning; me.coordArena = ip.coordArena;
      if (ip.role === "pc") { me.roleAgent = me.role; me.role = "pc"; } // SSIAP 2 du PC Parc : voit et gère tout, comme le PC
    }

    if (r0 === "me") return json({ ...me, planif: await peutPlanif(me), niveauPlanif: await niveauPlanif(me), voitPlanif: await voirPlanif(me), proprio: estProprio(me), redac: await estRedac(me), coord: await estCoord(me), ficheOk: isStaff(me) || !!(await load("fiches", {}))[me.id] });

    /* ---------- Changer son mot de passe ---------- */
    if (r0 === "mdp" && m === "POST") {
      const users = await load("users", []), u = users.find((x) => x.id === me.id);
      if (!u || !checkPin(String(body.ancien || ""), u.pin)) return json({ error: "Mot de passe actuel incorrect" }, 400);
      if (String(body.mdp || "").length < 6) return json({ error: "6 caractères minimum" }, 400);
      u.pin = hashPin(String(body.mdp)); await save("users", users);
      return json({ ok: true });
    }

    /* ---------- Code d'accès aux contacts (SMS + fiches agents) ---------- */
    const unlockSig = (uid, exp) => crypto.createHmac("sha256", (process.env.APP_SECRET || "change-moi-dans-netlify") + ":contacts").update(uid + "." + exp).digest("base64url");
    const unlocked = () => {
      const [exp, sig] = String(req.headers.get("x-contacts") || "").split(".");
      return exp && Number(exp) > Date.now() && sig === unlockSig(me.id, exp);
    };
    if (r0 === "deverrouiller" && m === "POST") {
      if (!isStaff(me)) return deny();
      const h = await load("code_contacts", null);
      if (!h) return json({ error: isAdmin(me) ? "Définis d'abord le code dans Administration" : "Code non défini, contacte un administrateur" }, 400);
      const locks = await load("locks", {}), k = "code:" + me.id, lk = locks[k];
      if (lk && lk.n >= 5 && Date.now() - lk.t < 15 * 60e3) return json({ error: "Trop d'essais, réessaie dans 15 min" }, 429);
      if (!checkPin(String(body.code || ""), h)) {
        locks[k] = { n: (lk && Date.now() - lk.t < 15 * 60e3 ? lk.n : 0) + 1, t: Date.now() }; await save("locks", locks);
        await journal("contacts", me.nom, "code d'accès incorrect", "attention");
        return json({ error: "Code incorrect" }, 403);
      }
      if (lk) { delete locks[k]; await save("locks", locks); }
      const exp = String(Date.now() + 4 * 3600e3); // déverrouillé 4 h
      await journal("contacts", me.nom, "accès aux contacts ouvert");
      return json({ token: exp + "." + unlockSig(me.id, exp), exp: Number(exp) });
    }
    if (["sms", "fiches", "planning", "postes"].includes(r0) && isStaff(me) && !unlocked()) return json({ error: "Code d'accès requis", verrou: true }, 423);

    /* ---------- Fiche de renseignement agent ---------- */
    if (r0 === "fiche") {
      const fiches = await load("fiches", {});
      if (m === "GET") {
        if (fiches[me.id]) return json(fiches[me.id]);
        const u = (await load("users", [])).find((x) => x.id === me.id); // pré-remplissage depuis l'inscription
        return json(u ? { tel: u.tel || "", email: /@/.test(u.id) ? u.id : "" } : null);
      }
      if (m === "PUT") {
        if (me.id === "__admin") return json({ error: "Crée d'abord ton compte personnel" }, 400);
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const f = {
          nom: t(body.nom, 60).toUpperCase(), prenom: t(body.prenom, 60), naissance: t(body.naissance, 10),
          adresse: t(body.adresse, 200), cp: t(body.cp, 10), ville: t(body.ville, 80),
          tel: t(body.tel, 20), email: t(body.email, 120).toLowerCase(),
          diplomes: Array.isArray(body.diplomes) ? body.diplomes.slice(0, 20).map((d) => ({
            code: t(d.code, 40), numero: t(d.numero, 40), echeance: t(d.echeance, 10) })) : [],
          consentement: body.consentement === true, maj: new Date().toISOString(),
        };
        if (!f.nom || !f.prenom || !/^\d{4}-\d{2}-\d{2}$/.test(f.naissance) || !f.tel || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email) || !f.adresse)
          return json({ error: "Champs obligatoires manquants ou invalides" }, 400);
        if (!f.consentement) return json({ error: "Coche l'acceptation du traitement des données" }, 400);
        fiches[me.id] = f;
        await save("fiches", fiches);
        // le numéro de la fiche alimente la liste SMS
        const users = await load("users", []); const u = users.find((x) => x.id === me.id);
        if (u) { u.tel = f.tel; await save("users", users); }
        await journal("fiche", me.nom, "fiche de renseignement mise à jour");
        return json({ ok: true });
      }
    }
    // Consultation des fiches : responsables/admin = tout ; PC = nom, téléphone, diplômes
    if (r0 === "fiches" && m === "GET") {
      if (!isStaff(me)) return deny();
      const fiches = await load("fiches", {}), users = await load("users", []);
      return json(users.map((u) => {
        const f = fiches[u.id];
        if (!f) return { id: u.id, nom: u.nom, role: u.role, fiche: null };
        const fiche = isRH(me) ? f : { nom: f.nom, prenom: f.prenom, tel: f.tel, diplomes: f.diplomes };
        return { id: u.id, nom: u.nom, role: u.role, fiche };
      }));
    }

    /* ---------- Contacts : jamais de numéro envoyé à l'affichage ---------- */
    if (r0 === "contacts" && m === "GET") {
      const c = await load("contacts", DEFAULT_CONTACTS);
      return json(c.map(({ id, nom, fonction, tel }) => ({ id, nom, fonction, dispo: !!tel })));
    }
    if (r0 === "appel" && m === "POST") {
      const c = (await load("contacts", DEFAULT_CONTACTS)).find((x) => x.id === body.id);
      if (!c || !c.tel) return json({ error: "Numéro non configuré" }, 404);
      await journal("appel", me.nom, c.nom);
      return json({ href: "tel:" + c.tel.replace(/[^\d+]/g, "") });
    }

    /* ---------- Événements (Parc Expo Valmont / Arena) ---------- */
    if (r0 === "evenements") {
      let evs = await load("evenements", []);
      if (m === "GET") return json(isStaff(me) ? evs : evs.filter((e) => e.statut !== "clos").map(({ id, nom, site }) => ({ id, nom, site })));
      if (!isStaff(me)) return deny();
      if (m === "POST" || m === "PUT") {
        let e = r1 ? evs.find((x) => x.id === r1) : null;
        if (r1 && !e) return json({ error: "Introuvable" }, 404);
        if (!e) { e = { id: uid(), cree: new Date().toISOString(), statut: "ouvert" }; evs.unshift(e); }
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        if (body.nom !== undefined) e.nom = t(body.nom);
        if (!e.nom) return json({ error: "Nom de l'événement requis" }, 400);
        for (const k of ["site", "lieux", "type", "organisateur", "debut", "fin", "responsable"]) if (body[k] !== undefined) e[k] = t(body[k], 200);
        if (body.effectif !== undefined) e.effectif = Math.max(0, parseInt(body.effectif, 10) || 0);
        if (body.statut && ["ouvert", "clos"].includes(body.statut)) {
          if (body.statut !== e.statut) await journal("événement", me.nom, `${e.nom} ${body.statut === "clos" ? "clôturé" : "rouvert"}`, "info", "#/mc");
          e.statut = body.statut;
        }
        await save("evenements", evs.slice(0, 500));
        return json(e, r1 ? 200 : 201);
      }
    }

    /* ---------- Main courante électronique ---------- */
    if (r0 === "incidents") {
      if (m === "GET" && r1 === "mois") { // mois archivés (avec le nombre de saisies)
        if (!isStaff(me) && !(await estCoord(me))) return deny();
        const idx = await mcIndex(), copies = await load("mc_copies", {});
        return json({ mois: await Promise.all(idx.map(async (mm) => ({ mois: mm, nb: (await mcMois(mm)).length, copie: copies[mm] || "" }))), conservation: await load("mc_conservation", { actif: false, ansTexte: 5, ansPhotos: 3 }) });
      }
      if (m === "POST" && r1 === "copie") { // envoyer la copie d'un mois au PC et au coordinateur
        if (!estProprio(me) && me.role !== "admin" && !(await estCoord(me))) return deny();
        const mm = /^\d{4}-\d{2}$/.test(body.mois || "") ? body.mois : undefined;
        return json(await copieMensuelleMC({ mois: mm, essai: !!body.essai }));
      }
      if (m === "PUT" && r1 === "conservation") {
        if (!estProprio(me)) return refusProprio();
        const c = { actif: !!body.actif, ansTexte: Math.max(1, Math.min(30, parseInt(body.ansTexte) || 5)), ansPhotos: Math.max(1, Math.min(30, parseInt(body.ansPhotos) || 3)) };
        if (c.ansPhotos > c.ansTexte) c.ansPhotos = c.ansTexte;
        await save("mc_conservation", c); await journal("admin", me.nom, `conservation main courante : ${c.actif ? `${c.ansTexte} ans, photos ${c.ansPhotos} ans` : "désactivée"}`, "attention"); return json(c);
      }
      if (m === "GET") {
        const ev = url.searchParams.get("evenement"), mm = url.searchParams.get("mois");
        let list;
        if (/^\d{4}-\d{2}$/.test(mm || "")) list = await mcMois(mm);
        else if (ev) { const e = (await load("evenements", [])).find((x) => x.id === ev); const d0 = [e && e.debut, e && e.cree].find((x) => /^\d{4}-\d{2}-\d{2}/.test(String(x || ""))); list = await mcEntre(d0 ? moisPrec(String(d0).slice(0, 7), 1) + "-01" : moisPrec(moisDe(), 3) + "-01", "9999"); }
        else list = await mcRecents(2);
        if (!isStaff(me)) list = list.filter((i) => dansPerimetre(me, i));
        if (ev) list = list.filter((i) => i.evenementId === ev);
        return json(list.slice(0, ev || mm ? 5000 : 400));
      }
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const evs = await load("evenements", []);
        const ev = evs.find((e) => e.id === body.evenementId && e.statut !== "clos");
        const year = new Date().getFullYear(), cpt = await load("mc_compteur", {});
        cpt[year] = (cpt[year] || 0) + 1; await save("mc_compteur", cpt);
        const inc = {
          id: uid(), numero: `MC-${year}-${String(cpt[year]).padStart(4, "0")}`,
          t: new Date().toISOString(), heure: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(body.heure || "") ? body.heure.slice(0, 16) : null,
          auteurId: me.id, auteur: me.nom, role: me.role,
          evenementId: ev ? ev.id : null, evenement: ev ? ev.nom : "",
          categorie: t(body.categorie || "Autre", 120), famille: t(body.famille, 60), poste: PROFILS_MC.includes(body.poste) ? body.poste : "", societe: t(body.societe, 80), immat: t(body.immat, 20).toUpperCase(),
          gravite: ["info", "moyenne", "urgente"].includes(body.gravite) ? body.gravite : "info",
          site: t(body.site, 60), lieu: t(body.lieu), description: t(body.description, 4000),
          intervenants: t(body.intervenants, 300), actions: t(body.actions, 2000), prestataire: t(body.prestataire, 80),
          gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null,
          statut: body.clos ? "clos" : "ouvert", suivi: [], photo: false, photos: 0,
        };
        if (!inc.description) return json({ error: "Description obligatoire" }, 400);
        const phs = (Array.isArray(body.photos) ? body.photos : body.photo ? [body.photo] : [])
          .filter((d) => typeof d === "string" && d.startsWith("data:image/") && d.length < MAX_PHOTO).slice(0, 4);
        for (let k = 0; k < phs.length; k++) await save(`photo/${inc.id}-${k}`, { d: phs[k], auteurId: me.id });
        inc.photos = phs.length; inc.photo = phs.length > 0;
        await mcAjouter(inc);
        await mailPC(`${inc.gravite === "urgente" ? "🚨 " : ""}Main courante ${inc.numero} — ${inc.categorie}`, [...(await lignesAgent(me)), ["Heure", (inc.heure ? fmtHeure(inc.heure) : fmtParis(inc.t))],
          ["Événement", inc.evenement], ["Site", ERP(inc.site)], ["Lieu", inc.lieu], ["Famille", inc.famille], ["Société", inc.societe], ["Immatriculation", inc.immat], ["Prestataire concerné", inc.prestataire], ["Gravité", inc.gravite], ["Faits", inc.description], ["Intervenants", inc.intervenants], ["Actions", inc.actions],
          ["Position", inc.gps ? `https://maps.google.com/?q=${inc.gps.lat},${inc.gps.lon}` : ""]], phs);
        await journal("main courante", me.nom, `${inc.numero} · ${inc.categorie}${inc.lieu ? " · " + inc.lieu : ""}${inc.evenement ? " · " + inc.evenement : ""}`,
          inc.gravite === "urgente" ? "urgent" : inc.gravite === "moyenne" ? "attention" : "info", "#/mc");
        if (inc.gravite === "urgente") {
          await envoyerPush({ titre: `URGENT — ${inc.categorie}`, texte: `${inc.numero} · ${inc.lieu || ""} · ${inc.description.slice(0, 140)}`, url: "/#/mc", alerte: true }, (u) => isStaff(u) || estProprio(u)).catch(() => 0);
          const dest = (await load("destinataires", DEFAULT_RECIPIENTS)).filter((d) => d.email);
          await sendMail(dest, `🚨 SSIAP Pro — ${inc.numero} urgent : ${inc.categorie}`,
            `<h2>Main courante — fait urgent</h2><p><b>${inc.numero} · ${inc.categorie}</b> — ${inc.lieu}${inc.evenement ? " — " + inc.evenement : ""}</p>
             <p>${inc.description.replace(/</g, "&lt;")}</p><p>Saisi par ${inc.auteur} le ${fmtParis(inc.t)}</p>`).catch(() => {});
        }
        return json(inc, 201);
      }
      if (m === "PATCH" && r1) {
        const { inc, mois: mInc, list } = await mcTrouver(r1);
        if (!inc || inc.id !== r1) return json({ error: "Introuvable" }, 404);
        if (!isStaff(me) && !(me.perimetre && dansPerimetre(me, inc))) return deny();
        const avant = inc.statut;
        if (body.statut && ["ouvert", "en cours", "clos"].includes(body.statut)) inc.statut = body.statut;
        if (body.note) inc.suivi.push({ t: new Date().toISOString(), qui: me.nom, note: String(body.note).slice(0, 1000) });
        if (inc.statut === "clos" && avant !== "clos") inc.clos = { t: new Date().toISOString(), qui: me.nom };
        await save("mc/" + mInc, list);
        if (avant !== inc.statut || body.note) await journal("main courante", me.nom, `${inc.numero || ""} → ${inc.statut}${body.note ? " · " + String(body.note).slice(0, 80) : ""}`, "info", "#/mc");
        return json(inc);
      }
    }
    if (r0 === "photo" && r1) {
      const p = await load("photo/" + r1, null);
      if (!p) return json({ error: "Introuvable" }, 404);
      if (!isStaff(me) && !estProprio(me) && p.auteurId !== me.id && !(p.fil && p.fil === me.id)) {
        const inc = me.perimetre ? (await mcTrouver(r1)).inc : null;
        if (!inc || !dansPerimetre(me, inc)) return deny();
      }
      return json({ d: p.d });
    }

    /* ---------- Dossier des agents (diplômes, carte pro, habilitations, recyclages, visite médicale) ---------- */
    if (r0 === "dossier") {
      const moi = me.id === "__admin" ? PROPRIO() : me.id; // le compte administrateur = le dossier du propriétaire
      const coordPC = await estCoord(me), gere = estProprio(me) || coordPC || me.role === "admin"; // ajoute / supprime pour les autres
      const vueTous = gere || me.role === "admin" || me.role === "responsable" || (me.role === "pc" && !me.roleAgent);
      const tous = await load("dossiers", {}), t = (v, n = 120) => String(v ?? "").trim().slice(0, n), types = DOC_TYPES.map((x) => x[0]);
      const users0 = await load("users", []), users = users0.some((u) => u.id === PROPRIO()) ? users0 : [...users0, { id: PROPRIO(), nom: process.env.OWNER_NOM || "Rochdi Mecheti", role: "admin" }];
      if (m === "GET" && !r1) { const p = await profilDossier(estProprio(me) ? { ...me, id: moi } : me), docs = tous[moi] || [];
        return json({ docs, ...p, types: DOC_TYPES, etat: conformite(p.q, p.pcs, docs) }); }
      if (m === "POST" && r1 === "essai-alertes") { if (!gere) return deny(); return json(await alertesDossiers({ essai: true })); }
      if (m === "GET" && r1 === "equipe") return json(await load("equipe_pcs", EQUIPE_PCS_DEFAUT));
      if (m === "PUT" && r1 === "equipe") {
        if (!estProprio(me)) return deny();
        const l = (Array.isArray(body.items) ? body.items : []).map((x) => ({ nom: t(x.nom, 60), q: ["ssiap1", "ssiap2", "ssiap3", "ads"].includes(x.q) ? x.q : "ssiap2" })).filter((x) => x.nom).slice(0, 40);
        await save("equipe_pcs", l); await journal("admin", me.nom, `équipe PCS : ${l.length} personne(s)`); return json({ ok: true, nb: l.length });
      }
      if (m === "GET" && r1 === "agents") {
        if (!vueTous) return deny();
        return json((await lectureDossiers()).map((a) => ({ ...a, docs: a.docs.map(({ id, type, libelle, numero, obtention, echeance, fichier, mime, t: tt }) => ({ id, type, libelle, numero, obtention, echeance, fichier, mime, t: tt })) })));
      }
      if (m === "GET" && r1 === "fichier" && r2) {
        const uidDoc = Object.keys(tous).find((k) => tous[k].some((d) => d.id === r2)); const d = uidDoc && tous[uidDoc].find((x) => x.id === r2);
        if (!d) return json({ error: "Introuvable" }, 404);
        if (uidDoc !== moi && !(gere || (vueTous && d.type !== "visite"))) return deny(); // la visite médicale : l'agent, le propriétaire et le coordinateur PC seulement
        const f = await load("dossierf/" + d.id, null); if (!f) return json({ error: "Fichier introuvable" }, 404);
        return json({ d: f.d, type: d.mime, nom: d.nomFichier || d.libelle });
      }
      if (m === "POST" && !r1) {
        const pour = t(body.pour, 120) && t(body.pour, 120) !== moi ? t(body.pour, 120) : moi;
        if (pour !== moi && !gere) return deny();
        if (pour !== moi && !users.some((u) => u.id === pour)) return json({ error: "Agent introuvable" }, 404);
        if (!types.includes(body.type)) return json({ error: "Type de document inconnu" }, 400);
        const dt = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || "") ? v : "");
        const d = { id: uid(), type: body.type, libelle: t(body.libelle, 80) || DOC_TYPES.find((x) => x[0] === body.type)[1], numero: t(body.numero, 40), obtention: dt(body.obtention), echeance: dt(body.echeance),
          fichier: false, mime: "", nomFichier: t(body.nomFichier, 100), t: new Date().toISOString(), par: me.nom };
        const f = String(body.fichier || "");
        if (f) { const mm = f.match(/^data:(application\/pdf|image\/jpeg|image\/png|image\/webp);base64,/); if (!mm) return json({ error: "Fichier PDF, JPG ou PNG seulement" }, 400);
          if (f.length > MAX_DOC) return json({ error: "Fichier trop lourd (4 Mo maximum)" }, 413);
          await save("dossierf/" + d.id, { d: f, userId: pour }); d.fichier = true; d.mime = mm[1]; }
        if (!d.fichier && !d.numero && !d.obtention) return json({ error: "Joins le document (photo ou PDF) ou indique au moins le numéro / la date" }, 400);
        tous[pour] = [d, ...(tous[pour] || [])].slice(0, 60); await save("dossiers", tous);
        await journal("dossier", me.nom, `${d.libelle}${pour !== moi ? " pour " + ((users.find((u) => u.id === pour) || {}).nom || pour) : ""}`, "info", "#/dossiers");
        return json(d, 201);
      }
      if (m === "DELETE" && r1) {
        const uidDoc = Object.keys(tous).find((k) => tous[k].some((d) => d.id === r1));
        if (!uidDoc) return json({ error: "Introuvable" }, 404);
        if (uidDoc !== moi && !gere) return deny();
        tous[uidDoc] = tous[uidDoc].filter((d) => d.id !== r1); await save("dossiers", tous); await save("dossierf/" + r1, null);
        return json({ ok: true });
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Équipe ADS Arena du jour, répartie par groupe (coordinateur Arena) ---------- */
    if (r0 === "arena-equipe") {
      const coordPC = await estCoord(me), voit = isStaff(me) || estProprio(me) || coordPC || !!me.coordArena;
      if (!voit) return deny();
      const peutModif = estProprio(me) || me.role === "admin" || me.role === "pc" || coordPC || !!me.coordArena;
      const t = (v, n = 80) => String(v ?? "").trim().slice(0, n);
      if (m === "GET" && r1 === "agents") { const vus = new Map();
        (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => a.nom && vus.set(a.nom.toUpperCase(), { nom: a.nom, tel: a.tel || "" }));
        return json([...vus.values()].sort((a, b) => a.nom.localeCompare(b.nom, "fr"))); }
      const date = me.coordArena && !isStaff(me) && !coordPC && !estProprio(me) ? me.coordArena : /^\d{4}-\d{2}-\d{2}$/.test(url.searchParams.get("date") || body.date || "") ? (url.searchParams.get("date") || body.date) : new Date().toISOString().slice(0, 10);
      const toutes = await load("arena_equipes", {}), eq = toutes[date] || { affect: {}, requis: {}, ajouts: [], retires: [] };
      if (m === "PUT") {
        if (!peutModif) return deny();
        const ks = GROUPES_ARENA.map((g) => g[0]).concat("aplacer");
        if (body.affect && typeof body.affect === "object") for (const [id, g] of Object.entries(body.affect).slice(0, 400)) if (ks.includes(g)) eq.affect[t(id, 120)] = g;
        if (body.requis && typeof body.requis === "object") for (const [k, n] of Object.entries(body.requis)) if (ks.includes(k)) eq.requis[k] = Math.max(0, Math.min(200, parseInt(n) || 0));
        if (body.ajout && t(body.ajout.nom)) {
          const n = t(body.ajout.nom).toUpperCase(), dejaPl = (await load("planning", PLANNING_INITIAL)).some((v) => v.date === date && /ARENA/i.test((v.site || "") + " " + (v.poste || "")) && String(v.nom || "").toUpperCase() === n);
          if (dejaPl || eq.ajouts.some((a) => a.nom.toUpperCase() === n)) return json({ error: "Cet ADS est déjà dans l'équipe du jour" }, 400);
          const a = { id: "a" + uid(), nom: t(body.ajout.nom), tel: t(body.ajout.tel, 20).replace(/[^\d+]/g, ""), debut: t(body.ajout.debut, 5), fin: t(body.ajout.fin, 5), par: me.nom };
          eq.ajouts.push(a); eq.affect[a.id] = ks.includes(body.ajout.groupe) ? body.ajout.groupe : "aplacer"; }
        if (body.retirer) { const id = t(body.retirer, 120); eq.ajouts = eq.ajouts.filter((a) => a.id !== id); if (!id.startsWith("a")) eq.retires = [...new Set([...(eq.retires || []), id])]; delete eq.affect[id]; }
        if (body.remettre) eq.retires = (eq.retires || []).filter((x) => x !== t(body.remettre, 120));
        eq.maj = new Date().toISOString(); eq.par = me.nom; toutes[date] = eq;
        for (const d of Object.keys(toutes).sort().slice(0, -60)) delete toutes[d]; // on garde 60 jours
        await save("arena_equipes", toutes);
        await journal("équipe Arena", me.nom, `répartition des ADS du ${date.split("-").reverse().join("/")}`, "info", "#/equipe");
      }
      if (m !== "GET" && m !== "PUT") return json({ error: "Méthode non gérée" }, 405);
      const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === date && /ARENA/i.test((v.site || "") + " " + (v.poste || "")) && estADS(v) && !estCoordArena(v));
      const auto = (poste) => (GROUPES_ARENA.find((g) => g[2].test(String(poste || "").toUpperCase())) || ["aplacer"])[0];
      const agents = pl.map((v) => { const id = `${v.nom}|${v.debut}`; return { id, nom: v.nom, tel: v.tel || "", debut: v.debut, fin: v.fin, poste: v.poste || "", groupe: eq.affect[id] || auto(v.poste), retire: (eq.retires || []).includes(id) }; })
        .concat(eq.ajouts.map((a) => ({ ...a, poste: "ajouté par " + a.par, groupe: eq.affect[a.id] || "aplacer", ajoute: true })));
      const evs = [...new Set(pl.map((v) => v.evenement).filter(Boolean))];
      const coords = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === date && estCoordArena(v)).map((v) => v.nom);
      return json({ date, evenement: evs.join(" · "), coordinateurs: coords, modifiable: peutModif, choixDate: !(me.coordArena && !isStaff(me) && !coordPC && !estProprio(me)),
        groupes: GROUPES_ARENA.map(([k, lb]) => ({ k, lb, requis: eq.requis[k] || 0 })), agents: agents.sort((a, b) => a.nom.localeCompare(b.nom, "fr")), maj: eq.maj || "", par: eq.par || "" });
    }

    /* ---------- Demandes de DPAE (déclaration préalable à l'embauche) ---------- */
    if (r0 === "dpae") {
      const coord = await estCoord(me), ok = peutDPAE(me);
      if (!ok && !coord && !["responsable", "admin"].includes(me.role)) return deny(); // données personnelles : pas pour les autres agents
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      if (m === "GET" && r1 === "agents") { // liste des agents (annuaire + comptes) avec leur fiche si elle existe
        if (!ok && !coord) return deny();
        const fiches = await load("fiches", {}), users = await load("users", []), vus = new Map();
        const cle = (n) => String(n || "").normalize("NFD").replace(/[\u0300-\u036f]/g, "").toUpperCase().split(/[\s()-]+/).filter(Boolean).sort().join(" ");
        for (const u of users) if (AGENTS.includes(u.role)) { const f = fiches[u.id] || {}; vus.set(cle(u.nom), { nom: u.nom, tel: f.tel || u.tel || "", email: f.email || (/@/.test(u.id) ? u.id : ""), naissance: f.naissance || "", adresse: [f.adresse, f.cp, f.ville].filter(Boolean).join(" "), qualif: u.role }); }
        for (const a of await load("sms_annuaire", ANNUAIRE_INITIAL)) if (a.nom && !vus.has(cle(a.nom))) vus.set(cle(a.nom), { nom: a.nom, tel: a.tel || "" });
        return json([...vus.values()].sort((a, b) => a.nom.localeCompare(b.nom, "fr")));
      }
      if (m === "GET" && r1 === "mail") return json({ email: await load("mail_dpae", PROPRIO()) });
      if (m === "PUT" && r1 === "mail") {
        if (!estProprio(me) && !coord) return deny();
        const e = t(body.email, 300);
        if (e && !e.split(/[,;\s]+/).filter(Boolean).every((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))) return json({ error: "Adresse e-mail invalide" }, 400);
        await save("mail_dpae", e); await journal("admin", me.nom, "adresse des demandes de DPAE modifiée"); return json({ ok: true });
      }
      const list = await load("dpae", []);
      if (m === "GET") return json(list.slice(0, 300));
      if (m === "POST") {
        if (!ok) return json({ error: "Réservé au SSIAP 3" }, 403);
        let nom = t(body.agent, 80), tel = t(body.tel, 20).replace(/[^\d+]/g, ""), nouveau = false;
        if (body.nouveau) {
          const prenom = t(body.prenom, 40), nomF = t(body.nom, 40).toUpperCase();
          if (!prenom || !nomF) return json({ error: "Nom et prénom du nouvel agent obligatoires" }, 400);
          nom = `${prenom} ${nomF}`; nouveau = true;
          const ann = await load("sms_annuaire", ANNUAIRE_INITIAL);
          if (!ann.some((a) => a.nom.toUpperCase() === nom.toUpperCase())) { ann.push({ nom, tel }); await save("sms_annuaire", ann.slice(0, 1000)); }
        }
        if (!nom) return json({ error: "Choisis un agent ou crée-le" }, 400);
        const d = {
          id: uid(), numero: "DPAE-" + new Date().getFullYear() + "-" + String(list.length + 1).padStart(4, "0"), t: new Date().toISOString(),
          demandeur: me.nom, demandeurId: me.id, agent: nom, nouveau, tel, email: t(body.email, 120).toLowerCase(),
          naissance: /^\d{4}-\d{2}-\d{2}$/.test(body.naissance || "") ? body.naissance : "", lieuNaissance: t(body.lieuNaissance, 80), nationalite: t(body.nationalite, 40), adresse: t(body.adresse, 200),
          qualif: ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3", "ADS + SSIAP 1"].includes(body.qualif) ? body.qualif : "ADS",
          contrat: ["CDD d'usage", "CDD", "CDI", "Extra / vacation"].includes(body.contrat) ? body.contrat : "CDD d'usage",
          debut: /^\d{4}-\d{2}-\d{2}$/.test(body.debut || "") ? body.debut : "", heure: /^\d{2}:\d{2}$/.test(body.heure || "") ? body.heure : "", fin: /^\d{4}-\d{2}-\d{2}$/.test(body.fin || "") ? body.fin : "",
          site: t(body.site, 60), evenement: t(body.evenement, 120), poste: t(body.poste, 80), commentaire: t(body.commentaire, 1000),
          nirFourni: !!t(body.nir, 30), statut: "demandée", suivi: [],
        };
        if (!d.debut) return json({ error: "Date d'embauche obligatoire" }, 400);
        const nir = t(body.nir, 30).replace(/\s/g, ""); // le n° de sécurité sociale part seulement dans le mail, il n'est pas conservé dans l'appli
        list.unshift(d); await save("dpae", list.slice(0, 2000));
        const fr = (x) => (x ? x.split("-").reverse().join("/") : "");
        await mailVers(await load("mail_dpae", PROPRIO()), `Demande de DPAE ${d.numero} — ${d.agent}`, [["Demandée par", `${me.nom} (SSIAP 3)`], ["Agent", d.agent + (nouveau ? " (nouvel agent)" : "")],
          ["Téléphone", d.tel], ["E-mail", d.email], ["Date de naissance", fr(d.naissance)], ["Lieu de naissance", d.lieuNaissance], ["Nationalité", d.nationalite], ["Adresse", d.adresse], ["N° de sécurité sociale", nir],
          ["Qualification", d.qualif], ["Contrat", d.contrat], ["Embauche le", `${fr(d.debut)}${d.heure ? " à " + d.heure : ""}`], ["Fin de contrat", fr(d.fin)],
          ["Site", ERP(d.site)], ["Événement", d.evenement], ["Poste", d.poste], ["Commentaire", d.commentaire]], [], "Service DPAE");
        await journal("DPAE", me.nom, `${d.numero} · ${d.agent} · ${fr(d.debut)}`, "info", "#/dpae");
        return json(d, 201);
      }
      if (m === "PATCH" && r1) {
        if (!ok && !coord) return deny();
        const d = list.find((x) => x.id === r1); if (!d) return json({ error: "Introuvable" }, 404);
        if (["demandée", "faite", "annulée"].includes(body.statut)) d.statut = body.statut;
        if (t(body.note, 300)) d.suivi.push({ t: new Date().toISOString(), qui: me.nom, note: t(body.note, 300) });
        await save("dpae", list); return json(d);
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Rondes ---------- */
    if (r0 === "rondes") {
      if (r1 === "points") return json(await load("rondes_points", DEFAULT_RONDES));
      let list = await load("rondes", []);
      if (m === "GET") {
        if (!isStaff(me)) list = list.filter((p) => p.agentId === me.id);
        return json(list.slice(0, 500));
      }
      if (m === "POST") {
        const p = { id: uid(), t: new Date().toISOString(), agentId: me.id, agent: me.nom,
          point: String(body.point || "").slice(0, 80), obs: String(body.obs || "").slice(0, 500),
          ras: body.ras !== false };
        list.unshift(p);
        await save("rondes", list.slice(0, 5000));
        if (!p.ras) await journal("ronde", me.nom, `Anomalie · ${p.point} · ${p.obs}`, "attention", "#/rondes");
        return json(p, 201);
      }
    }

    /* ---------- Gestion des clés (boîte à clés PC, clés organisateurs Parc / Arena) ---------- */
    if (r0 === "cles") {
      const liste = await load("cles", CLES_INITIAL), etat = await load("cles_etat", {});
      if (m === "GET" && !r1) return json({ liste, etat });
      if (m === "GET" && r1 === "agents") { // noms des agents de sécurité (sans numéros) pour la remise de clés
        const noms = new Map(); const add = (n) => { const k = String(n || "").trim(); if (k && !noms.has(k.toLowerCase())) noms.set(k.toLowerCase(), k); };
        (await load("users", [])).forEach((u) => add(u.nom)); (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => add(a.nom));
        return json([...noms.values()].sort((a, b) => a.localeCompare(b, "fr")));
      }
      if (m === "GET" && r1 === "historique") { const n = url.searchParams.get("n"); const h = await load("cles_mvt", []); return json((n ? h.filter((x) => x.n === n) : h).slice(0, 400)); }
      if (m === "PUT" && !r1) {
        if (!(await estCoord(me))) return json({ error: "Réservé à la coordination" }, 403);
        const t = (v, n = 160) => String(v ?? "").trim().slice(0, n), vus = new Set();
        const out = (Array.isArray(body.liste) ? body.liste : []).slice(0, 600).map((c) => ({ n: t(c.n, 12), nom: t(c.nom), boite: t(c.boite, 80) })).filter((c) => c.n && c.nom && !vus.has(c.n) && vus.add(c.n));
        await save("cles", out); await journal("clés", me.nom, `liste des clés modifiée (${out.length})`, "info", "#/cles");
        return json({ ok: true, nb: out.length });
      }
      const cle = liste.find((c) => c.n === r1); if (!cle) return json({ error: "Clé introuvable" }, 404);
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      const mvt = await load("cles_mvt", []);
      if (m === "POST" && r2 === "sortie") {
        if (etat[cle.n]) return json({ error: `Clé déjà sortie (remise à ${etat[cle.n].nom})` }, 400);
        const e = { cat: ["agent", "sploe", "prestataire", "orga"].includes(body.type) ? body.type : "", nom: t(body.nom), societe: t(body.societe), tel: t(body.tel, 20), motif: t(body.motif, 200), retour: /^\d{2}:\d{2}$/.test(body.retour || "") ? body.retour : "",
          piece: t(body.piece, 60), t: new Date().toISOString(), par: me.nom, parId: me.id };
        if (!e.nom) return json({ error: "Indique à qui la clé est remise" }, 400);
        etat[cle.n] = e; await save("cles_etat", etat);
        mvt.unshift({ id: uid(), n: cle.n, cle: cle.nom, type: "sortie", ...e }); await save("cles_mvt", mvt.slice(0, 5000));
        await journal("clés", me.nom, `🔑 ${cle.n} ${cle.nom} remise à ${e.nom}${e.societe ? " (" + e.societe + ")" : ""}`, "info", "#/cles");
        return json({ etat });
      }
      if (m === "POST" && r2 === "retour") {
        const e = etat[cle.n]; if (!e) return json({ error: "Cette clé est déjà au tableau" }, 400);
        delete etat[cle.n]; await save("cles_etat", etat);
        const duree = Math.round((Date.now() - Date.parse(e.t)) / 60000);
        mvt.unshift({ id: uid(), n: cle.n, cle: cle.nom, type: "retour", nom: e.nom, societe: e.societe, sortie: e.t, duree, obs: /^\s*ras\s*$/i.test(body.obs || "") ? "" : t(body.obs, 300), t: new Date().toISOString(), par: me.nom, parId: me.id });
        await save("cles_mvt", mvt.slice(0, 5000));
        await journal("clés", me.nom, `✅ ${cle.n} ${cle.nom} restituée par ${e.nom}${mvt[0].obs ? " · " + mvt[0].obs : ""}`, mvt[0].obs ? "attention" : "info", "#/cles");
        return json({ etat });
      }
    }

    /* ---------- Ouverture / fermeture des bâtiments et éclairage ---------- */
    if (r0 === "batiments") {
      const HALLS = ["Accueil A", "Hall A1", "Hall A2", "Hall A3", "Hall A4", "Hall A5", "Hall A6", "Accueil B", "Hall B1", "Hall B2", "Hall B3", "Hall B4", "Hall B5", "Centre de conférences", "Valmont Arena"];
      const etat = await load("batiments_etat", {});
      if (m === "GET" && !r1) return json({ halls: HALLS, etat });
      if (m === "GET" && r1 === "historique") return json((await load("batiments_mvt", [])).slice(0, 400));
      if (m === "POST" && !r1) {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const halls = (Array.isArray(body.halls) ? body.halls : []).filter((h) => HALLS.includes(h));
        const ACT = { ouverture: "Ouverture", fermeture: "Fermeture", eclairage_on: "Mise en fonction éclairage", eclairage_off: "Mise hors fonction éclairage" };
        const actions = (Array.isArray(body.actions) ? body.actions : []).filter((a) => ACT[a]);
        if (!halls.length) return json({ error: "Choisis au moins un hall" }, 400);
        if (!actions.length) return json({ error: "Choisis au moins une opération" }, 400);
        const dem = { type: ["prestataire", "organisateur", "sploe", "pc", "autre"].includes(body.demType) ? body.demType : "autre", societe: t(body.demSociete), nom: t(body.demNom) };
        const mv = { id: uid(), t: new Date().toISOString(), halls, actions, libelle: actions.map((a) => ACT[a]).join(" + "), dem, commentaire: t(body.commentaire, 500), par: me.nom };
        for (const h of halls) { const e = etat[h] || {};
          if (actions.includes("ouverture")) e.ouvert = true; if (actions.includes("fermeture")) e.ouvert = false;
          if (actions.includes("eclairage_on")) e.eclairage = true; if (actions.includes("eclairage_off")) e.eclairage = false;
          e.maj = mv.t; e.par = me.nom; etat[h] = e; }
        await save("batiments_etat", etat);
        const mvt = await load("batiments_mvt", []); mvt.unshift(mv); await save("batiments_mvt", mvt.slice(0, 5000));
        const qui = { prestataire: "Prestataire", organisateur: "Organisateur", sploe: "VEV", pc: "PC sécurité", autre: "Autre" }[dem.type];
        await journal("bâtiments", me.nom, `🏢 ${mv.libelle} · ${halls.join(", ")} · demande : ${qui}${dem.societe ? " " + dem.societe : ""}${dem.nom ? " (" + dem.nom + ")" : ""}`, "info", "#/batiments");
        return json({ etat, mv });
      }
    }

    /* ---------- Notifications push ---------- */
    if (r0 === "push") {
      if (m === "GET" && r1 === "cle") return json({ cle: (await vapid()).cle });
      if (m === "GET" && r1 === "dernier") return json((await load("push_dernier", null)) || { titre: "SSIAP Pro", texte: "Nouvelle notification", url: "/#/" });
      if (r1 === "abonner") {
        const abos = await load("push_abos", {}), moi = me.id === "__admin" ? PROPRIO() : me.id;
        const sub = body.subscription;
        if (m === "POST") { if (!sub || !/^https:\/\//.test(sub.endpoint || "")) return json({ error: "Abonnement invalide" }, 400);
          for (const k of Object.keys(abos)) abos[k] = abos[k].filter((x) => x.endpoint !== sub.endpoint); // un téléphone = un seul compte
          abos[moi] = [...(abos[moi] || []), { endpoint: sub.endpoint, t: new Date().toISOString() }].slice(-5);
          await save("push_abos", abos); return json({ ok: true }); }
        if (m === "DELETE") { abos[moi] = (abos[moi] || []).filter((x) => !sub || x.endpoint !== sub.endpoint); await save("push_abos", abos); return json({ ok: true }); }
      }
      if (m === "POST" && r1 === "test") { const moi = me.id === "__admin" ? PROPRIO() : me.id;
        const n = await envoyerPush({ titre: "SSIAP Pro — test", texte: "Les notifications sonores fonctionnent sur ce téléphone.", url: "/#/" }, (u) => u.id === moi);
        return json({ envoyes: n, abonnements: ((await load("push_abos", {}))[moi] || []).length, details: envoyerPush.details || [] }); }
      if (m === "GET" && r1 === "journal") { if (!isStaff(me) && !estProprio(me)) return deny(); return json(await load("push_log", [])); }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Planification (type Comète) ---------- */
    if (r0 === "planif") {
      const modif = await peutPlanif(me), niveau = await niveauPlanif(me), redac = niveau === "redacteur";
      const tarifOK = modif || redac || (await estAdminPC(me.id)); // tarification et devis : planificateurs, Thomas Garnier, Lucas Fontaine, PC sécurité
      if (!modif && !(await voirPlanif(me))) return deny();
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n), hm = (v) => (/^\d{2}:\d{2}$/.test(v || "") ? v : ""), dte = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(v || "") ? v : "");
      if (m === "GET" && !r1) {
        const du = dte(url.searchParams.get("du")) || new Date().toISOString().slice(0, 10), au = dte(url.searchParams.get("au")) || du;
        const avant = new Date(Date.parse(du) - 90 * 864e5).toISOString().slice(0, 10), apres = new Date(Date.parse(au) + 864e5).toISOString().slice(0, 10);
        const pl = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date >= avant && v.date <= apres);
        const ctrl = globalThis.PLANIF.controles(pl).filter((c) => !c.date || (c.date >= new Date(Date.parse(du) - 7 * 864e5).toISOString().slice(0, 10) && c.date <= au));
        const noms = new Map(); (await load("users", [])).forEach((u) => AGENTS.includes(u.role) && noms.set(u.nom.toUpperCase(), u.nom)); (await load("sms_annuaire", ANNUAIRE_INITIAL)).forEach((a) => a.nom && noms.set(a.nom.toUpperCase(), a.nom));
        // numéros de téléphone : fiches, comptes, annuaire, plannings
        const tels = {}, fiches = await load("fiches", {}), cle = globalThis.PLANIF.cleAgent;
        for (const v of pl) if (v.tel) tels[cle(v.nom)] ||= v.tel;
        for (const a of await load("sms_annuaire", ANNUAIRE_INITIAL)) if (a.nom && a.tel) tels[cle(a.nom)] = a.tel;
        for (const u of await load("users", [])) { const t = (fiches[u.id] || {}).tel || u.tel; if (t) tels[cle(u.nom)] = String(t).replace(/[^\d+]/g, ""); }
        // DPAE : faite (vert) ou non (rouge) pour chaque agent affiché
        const dpaes = await load("dpae", []), dpae = {}, tous = new Set([...noms.values(), ...pl.map((v) => v.nom)]);
        for (const n of tous) { const l = dpaes.filter((d) => d.statut !== "annulée" && memeAgent({ nom: n }, { nom: d.agent })).sort((a, b) => (a.statut === "faite" ? -1 : 1) - (b.statut === "faite" ? -1 : 1) || String(b.t).localeCompare(String(a.t)));
          if (l.length) dpae[globalThis.PLANIF.cleAgent(n)] = { statut: l[0].statut, debut: l[0].debut, numero: l[0].numero }; }
        const brouillons = (await load("planif_brouillons", [])).filter((b) => b.statut !== "validé");
        return json({ du, au, peutModif: modif || redac, niveau, peutDevis: tarifOK, tels, brouillons, controles: ctrl, dpae, agents: [...noms.values()].sort((a, b) => a.localeCompare(b, "fr")),
          lignes: pl.filter((v) => v.date >= new Date(Date.parse(du) - 864e5).toISOString().slice(0, 10) && v.date <= au).map(({ tel, telApproche, rappel, ...v }) => v) });
      }
      if (r1 === "vacation" && redac) { // rédacteur : enregistré en brouillon, publié après validation
        const br = await load("planif_brouillons", []), pl = await load("planning", PLANNING_INITIAL);
        const ref = r2 ? pl.find((x) => x.id === r2) : null;
        if (r2 && !ref) return json({ error: "Introuvable" }, 404);
        if (ref && ref.source !== "planif") return json({ error: "Vacation téléversée : elle ne peut pas être modifiée ici" }, 403);
        const action = m === "DELETE" ? "supprimer" : r2 ? "modifier" : "ajouter";
        const vac = action === "supprimer" ? { ...ref } : { date: dte(body.date), nom: t(body.nom, 80), debut: hm(body.debut), fin: hm(body.fin), poste: t(body.poste), site: t(body.site, 60), evenement: t(body.evenement), qualif: t(body.qualif, 60) };
        if (action !== "supprimer" && (!vac.date || !vac.nom || !vac.debut || !vac.fin)) return json({ error: "Date, agent, début et fin obligatoires" }, 400);
        const b = { id: "b" + uid(), action, ref: ref ? ref.id : null, vac, statut: "en attente", par: me.nom, parId: me.id, t: new Date().toISOString() };
        br.unshift(b); await save("planif_brouillons", br.slice(0, 2000));
        await journal("planification", me.nom, `en attente de validation : ${action} ${vac.nom} ${String(vac.date).split("-").reverse().join("/")} ${vac.debut}-${vac.fin}`, "attention", "#/planif");
        await envoyerPush({ titre: "Planning à valider", texte: `${me.nom} : ${action} ${vac.nom} le ${String(vac.date).split("-").reverse().join("/")}`, url: "/#/planif" }, (u) => peutPlanif(u)).catch(() => 0);
        return json({ brouillon: b, controles: [] }, 201);
      }
      if (r1 === "brouillon" && r2) {
        let br = await load("planif_brouillons", []); const b = br.find((x) => x.id === r2);
        if (!b) return json({ error: "Introuvable" }, 404);
        if (m === "DELETE") { if (!modif && b.parId !== me.id) return deny(); await save("planif_brouillons", br.filter((x) => x.id !== r2)); return json({ ok: true }); }
        if (m === "POST" && (r3 === "valider" || r3 === "refuser")) {
          if (!modif) return json({ error: "Seul un planificateur valide (Julien Moreau)" }, 403);
          if (r3 === "refuser") { b.statut = "refusé"; b.motif = t(body.motif, 300); b.par2 = me.nom; b.t2 = new Date().toISOString(); await save("planif_brouillons", br);
            await journal("planification", me.nom, `refusé : ${b.action} ${b.vac.nom} (${b.par})${b.motif ? " · " + b.motif : ""}`, "info", "#/planif"); return json(b); }
          let pl = await load("planning", PLANNING_INITIAL);
          if (b.action === "ajouter") pl.push({ ...b.vac, id: uid(), source: "planif", cree: b.t, par: b.par, validePar: me.nom, valideLe: new Date().toISOString() });
          else if (b.action === "modifier") { if (!pl.some((x) => x.id === b.ref)) return json({ error: "La vacation d'origine n'existe plus" }, 409); pl = pl.map((x) => (x.id === b.ref ? { ...x, ...b.vac, par: b.par, validePar: me.nom, valideLe: new Date().toISOString() } : x)); }
          else pl = pl.filter((x) => x.id !== b.ref);
          await save("planning", pl); br = br.filter((x) => x.id !== r2); await save("planif_brouillons", br);
          await journal("planification", me.nom, `validé et publié : ${b.action} ${b.vac.nom} ${String(b.vac.date).split("-").reverse().join("/")} (saisi par ${b.par})`, "info", "#/planif");
          return json({ ok: true });
        }
      }
      if (r1 === "vacation") {
        if (!modif) return json({ error: "Lecture seule : seuls les planificateurs (SSIAP 3) modifient le planning" }, 403);
        let pl = await load("planning", PLANNING_INITIAL);
        if (m === "POST" || (m === "PATCH" && r2)) {
          const v0 = r2 ? pl.find((x) => x.id === r2) : null;
          if (r2 && !v0) return json({ error: "Introuvable" }, 404);
          if (v0 && v0.source !== "planif") return json({ error: "Vacation téléversée : elle ne peut pas être modifiée ici" }, 403);
          const v = { ...(v0 || { id: uid(), source: "planif", cree: new Date().toISOString() }), date: dte(body.date), nom: t(body.nom, 80), debut: hm(body.debut), fin: hm(body.fin), poste: t(body.poste), site: t(body.site, 60), evenement: t(body.evenement), qualif: t(body.qualif, 60), par: me.nom, maj: new Date().toISOString() };
          if (!v.date || !v.nom || !v.debut || !v.fin) return json({ error: "Date, agent, début et fin obligatoires" }, 400);
          if (!v.tel) { const a = (await load("sms_annuaire", ANNUAIRE_INITIAL)).find((x) => memeAgent({ nom: v.nom }, { nom: x.nom })); if (a) v.tel = a.tel || ""; }
          pl = v0 ? pl.map((x) => (x.id === v.id ? v : x)) : [...pl, v]; await save("planning", pl);
          await journal("planification", me.nom, `${v0 ? "vacation modifiée" : "vacation ajoutée"} : ${v.nom} ${v.date.split("-").reverse().join("/")} ${v.debut}-${v.fin} ${v.poste}`, "info", "#/planif");
          const ctrl = globalThis.PLANIF.controles(pl.filter((x) => globalThis.PLANIF.cleAgent(x.nom) === globalThis.PLANIF.cleAgent(v.nom))).filter((c) => c.ids.includes(v.id));
          return json({ vacation: v, controles: ctrl }, v0 ? 200 : 201);
        }
        if (m === "DELETE" && r2) { const v0 = pl.find((x) => x.id === r2); if (!v0) return json({ error: "Introuvable" }, 404);
          if (v0.source !== "planif") return json({ error: "Vacation téléversée : elle ne peut pas être supprimée ici" }, 403);
          await save("planning", pl.filter((x) => x.id !== r2)); await journal("planification", me.nom, `vacation supprimée : ${v0.nom} ${v0.date} ${v0.debut}-${v0.fin}`, "info", "#/planif"); return json({ ok: true }); }
      }
      if (r1 === "tarifs") {
        if (m === "GET") return json(await load("planif_tarifs", { taux: {}, majNuit: "", majDimanche: "", majFerie: "", nuitDebut: "21:00", nuitFin: "06:00", tva: "20" }));
        if (m === "PUT") { if (!tarifOK) return deny(); const taux = {}, tauxChef = {};
          for (const [k, v] of Object.entries(body.taux || {}).slice(0, 40)) if (t(k, 60)) taux[t(k, 60)] = t(v, 12);
          for (const [k, v] of Object.entries(body.tauxChef || {}).slice(0, 40)) if (t(k, 60)) tauxChef[t(k, 60)] = t(v, 12);
          const tf = { taux, tauxChef, majNuit: t(body.majNuit, 8), majDimanche: t(body.majDimanche, 8), majFerie: t(body.majFerie, 8), nuitDebut: hm(body.nuitDebut) || "21:00", nuitFin: hm(body.nuitFin) || "06:00", maj: new Date().toISOString(), par: me.nom };
          await save("planif_tarifs", tf); await journal("planification", me.nom, "grille tarifaire modifiée", "info", "#/planif"); return json(tf); }
      }
      if (r1 === "devis") {
        let list = await load("planif_devis", []); const tarifs = await load("planif_tarifs", {});
        if (m === "GET") return json(list.map((d) => ({ ...d, calc: globalThis.PLANIF.calcDevis(d, tarifs) })));
        if (!tarifOK) return json({ error: "Lecture seule" }, 403);
        if (m === "POST") {
          const d0 = body.id ? list.find((x) => x.id === body.id) : null, an = new Date().getFullYear();
          const d = { ...(d0 || { id: uid(), numero: `DEV-${an}-${String(list.filter((x) => String(x.numero).startsWith("DEV-" + an)).length + 1).padStart(4, "0")}`, cree: new Date().toISOString(), creePar: me.nom }),
            client: t(body.client, 120), contact: t(body.contact, 160), evenement: t(body.evenement, 160), site: t(body.site, 80), objet: t(body.objet, 300), validite: t(body.validite, 20), statut: ["brouillon", "envoyé", "accepté", "refusé"].includes(body.statut) ? body.statut : "brouillon",
            remise: t(body.remise, 8), tva: t(body.tva, 6), notes: t(body.notes, 2000),
            mode: body.mode === "mois" ? "mois" : "evenement", mois: /^\d{4}-\d{2}$/.test(body.mois || "") ? body.mois : "",
            lignes: (Array.isArray(body.lignes) ? body.lignes : []).slice(0, 300).map((l) => ({ qualif: t(l.qualif, 60), libelle: t(l.libelle, 120), nb: Math.max(0, parseInt(l.nb) || 0), date: dte(l.date), au: dte(l.au), jours: (Array.isArray(l.jours) ? l.jours : []).map(Number).filter((j) => j >= 0 && j <= 6), debut: hm(l.debut), fin: hm(l.fin), taux: t(l.taux, 12), chef: l.chef === true }))
              .filter((l) => l.debut && l.fin && (l.date || body.mode === "mois")),
            frais: (Array.isArray(body.frais) ? body.frais : []).slice(0, 30).map((f) => ({ libelle: t(f.libelle, 120), montant: t(f.montant, 12) })).filter((f) => f.libelle), maj: new Date().toISOString(), majPar: me.nom };
          list = d0 ? list.map((x) => (x.id === d.id ? d : x)) : [d, ...list]; await save("planif_devis", list.slice(0, 1000));
          await journal("planification", me.nom, `devis ${d.numero} ${d0 ? "modifié" : "créé"} · ${d.client}`, "info", "#/planif");
          return json({ ...d, calc: globalThis.PLANIF.calcDevis(d, tarifs) });
        }
        if (m === "DELETE" && r2) { await save("planif_devis", list.filter((x) => x.id !== r2)); return json({ ok: true }); }
      }
      /* ----- postes à pourvoir (glisser les agents), brouillon d'équipe, publication par le planificateur ----- */
      if (r1 === "postes") {
        const equipe = modif || redac; let postes = await load("planif_postes", []);
        const nettoie = (b, p0) => ({ ...(p0 || { id: "p" + uid(), cree: new Date().toISOString(), creePar: me.nom, statut: "brouillon" }), date: dte(b.date), debut: hm(b.debut), fin: hm(b.fin), poste: t(b.poste), site: t(b.site, 60), evenement: t(b.evenement), qualif: t(b.qualif, 60),
          nb: Math.max(1, Math.min(200, parseInt(b.nb) || 1)), agents: (Array.isArray(b.agents) ? b.agents : []).slice(0, 200).map((a) => ({ nom: t(a.nom, 80), tel: String(a.tel || "").replace(/[^\d+]/g, "").slice(0, 15) })).filter((a) => a.nom),
          devisId: b.devisId ?? (p0 && p0.devisId) ?? null, ligne: b.ligne ?? (p0 && p0.ligne) ?? null, modifie: true, maj: new Date().toISOString(), majPar: me.nom });
        if (m === "GET" && !r2) {
          const du = dte(url.searchParams.get("du")) || "0000", au = dte(url.searchParams.get("au")) || "9999";
          const devis = (await load("planif_devis", [])).filter((d) => d.statut === "accepté");
          const nonPlanifiees = [];
          for (const d of devis) (d.lignes || []).forEach((l, i) => { for (const date of globalThis.PLANIF.joursLigne(l, d)) if (date >= du && date <= au && !postes.some((p) => p.devisId === d.id && p.ligne === i && p.date === date && !p.supprime)) nonPlanifiees.push({ devisId: d.id, numero: d.numero, client: d.client, evenement: d.evenement, site: d.site, ligne: i, ...l, date }); });
          return json({ postes: postes.filter((p) => p.date >= du && p.date <= au), nonPlanifiees, peutEditer: equipe, peutPublier: modif, aPublier: postes.filter((p) => p.modifie).length });
        }
        if (!equipe) return json({ error: "Réservé à l'équipe de planification" }, 403);
        if (m === "POST" && r2 === "devis" && r3) {
          const d = (await load("planif_devis", [])).find((x) => x.id === r3); if (!d) return json({ error: "Devis introuvable" }, 404);
          const idx = body.ligne != null ? [parseInt(body.ligne)] : (d.lignes || []).map((_, i) => i); let n = 0;
          for (const i of idx) { const l = (d.lignes || [])[i]; if (!l) continue;
            for (const date of globalThis.PLANIF.joursLigne(l, d)) { if ((body.date && date !== body.date) || postes.some((p) => p.devisId === d.id && p.ligne === i && p.date === date && !p.supprime)) continue;
              postes.push(nettoie({ date, debut: l.debut, fin: l.fin, poste: l.libelle || l.qualif + (l.chef ? " chef d'équipe" : ""), site: d.site, evenement: d.evenement, qualif: l.qualif, nb: l.nb, devisId: d.id, ligne: i })); n++; } }
          await save("planif_postes", postes); await journal("planification", me.nom, `${n} poste(s) créé(s) depuis le devis ${d.numero}`, "info", "#/planif"); return json({ ok: true, crees: n });
        }
        if (m === "POST" && r2 === "publier") {
          if (!modif) return json({ error: "La publication est faite par Julien Moreau (planificateur)" }, 403);
          let pl = await load("planning", PLANNING_INITIAL), nbP = 0, nbL = 0; const ann = await load("sms_annuaire", ANNUAIRE_INITIAL);
          for (const p of postes.filter((x) => x.modifie)) {
            pl = pl.filter((v) => v.posteId !== p.id); nbP++;
            if (p.supprime) continue;
            for (const a of p.agents) { const tel = a.tel || (ann.find((x) => memeAgent({ nom: a.nom }, { nom: x.nom })) || {}).tel || "";
              pl.push({ id: uid(), date: p.date, nom: a.nom, tel, debut: p.debut, fin: p.fin, poste: p.poste, site: p.site, evenement: p.evenement, qualif: p.qualif, source: "planif", posteId: p.id, par: p.majPar, validePar: me.nom, valideLe: new Date().toISOString() }); nbL++; }
            p.modifie = false; p.statut = "publié"; p.pub = { t: new Date().toISOString(), par: me.nom };
          }
          postes = postes.filter((x) => !(x.supprime && !x.modifie));
          await save("planning", pl); await save("planif_postes", postes);
          await journal("planification", me.nom, `planning publié : ${nbP} poste(s), ${nbL} vacation(s) visibles par les agents`, "info", "#/planif");
          return json({ ok: true, postes: nbP, vacations: nbL });
        }
        if (m === "POST" && !r2) {
          const p0 = body.id ? postes.find((x) => x.id === body.id) : null; if (body.id && !p0) return json({ error: "Introuvable" }, 404);
          const p = nettoie(body, p0); if (!p.date || !p.debut || !p.fin || !p.poste) return json({ error: "Date, horaires et poste obligatoires" }, 400);
          if (p.agents.length > p.nb) return json({ error: `Ce poste ne prend que ${p.nb} agent(s)` }, 400);
          postes = p0 ? postes.map((x) => (x.id === p.id ? p : x)) : [...postes, p]; await save("planif_postes", postes.slice(-5000)); return json(p, p0 ? 200 : 201);
        }
        if (m === "DELETE" && r2) { const p = postes.find((x) => x.id === r2); if (!p) return json({ error: "Introuvable" }, 404);
          if (p.statut === "publié") { p.supprime = true; p.modifie = true; } else postes = postes.filter((x) => x.id !== r2);
          await save("planif_postes", postes); return json({ ok: true }); }
      }
      if (r1 === "redacteurs") {
        if (m === "GET") return json({ emails: await load("planif_redacteurs", REDAC_PLANIF_DEFAUT) });
        if (m === "PUT") { if (!estProprio(me)) return refusProprio();
          const e = (Array.isArray(body.emails) ? body.emails : []).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)).slice(0, 10);
          await save("planif_redacteurs", e); return json({ ok: true, nb: e.length }); }
      }
      if (r1 === "planificateurs") {
        if (m === "GET") return json({ emails: await load("planificateurs", []) });
        if (m === "PUT") { if (!estProprio(me)) return refusProprio();
          const e = (Array.isArray(body.emails) ? body.emails : []).map((x) => String(x).trim().toLowerCase()).filter((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x)).slice(0, 10);
          await save("planificateurs", e); return json({ ok: true, nb: e.length }); }
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Plan du site interactif : infos par hall + état en direct ---------- */
    if (r0 === "plan") {
      const peutModif = estProprio(me) || me.role === "admin" || (await estCoord(me));
      const infos = await load("plan_infos", {});
      if (m === "GET") {
        const voitMC = isStaff(me) || !!me.perimetre;
        let mc = [];
        if (voitMC) { mc = (await mcRecents(2)).filter((i) => i.statut !== "clos" && (isStaff(me) || dansPerimetre(me, i))).slice(0, 300)
          .map(({ id, numero, categorie, lieu, site, t, heure, gravite, statut }) => ({ id, numero, categorie, lieu, site, t, heure, gravite, statut })); }
        // agents du jour d'après le planning (noms et postes, sans numéros) : PC, responsables, coordinateurs
        let postes = [], arena = null;
        if (isStaff(me) || (await estCoord(me)) || me.coordArena) {
          const auj = jourParis(), hier = jourParis(-1), now = maintenantParis();
          postes = (await load("planning", PLANNING_INITIAL)).filter((v) => v.date === auj || (v.date === hier && v.fin && v.debut && v.fin < v.debut && now <= minutesLocales(auj, v.fin)))
            .map(({ nom, poste, debut, fin, site, date }) => ({ nom, poste: poste || "", debut, fin, site: site || "", date }));
          const jA = postes.some((v) => v.date === hier && /ARENA/i.test(v.site + " " + v.poste)) && !postes.some((v) => v.date === auj && /ARENA/i.test(v.site + " " + v.poste)) ? hier : auj;
          arena = await equipeArenaJour(jA);
        }
        return json({ daePos: await load("plan_dae", {}), infos: { ...PLAN_INFOS_DEFAUT, ...infos }, etat: await load("batiments_etat", {}), mc, voitMC, peutModif, postes, arena });
      }
      if (m === "PUT" && r1 === "dae" && r2) { // placer un DAE sur le plan et / ou enregistrer sa position GPS
        if (!peutModif) return deny();
        const pos = await load("plan_dae", {}), id = String(r2).slice(0, 30), cur = pos[id] || {};
        if (body.x != null || body.y != null) { const x = Number(body.x), y = Number(body.y); if (!Number.isFinite(x) || !Number.isFinite(y)) return json({ error: "Position invalide" }, 400); cur.x = Math.round(x); cur.y = Math.round(y); }
        if (body.gps) { const la = Number(body.gps.lat), lo = Number(body.gps.lon), ac = Number(body.gps.acc);
          if (!Number.isFinite(la) || !Number.isFinite(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) return json({ error: "Position GPS invalide" }, 400);
          cur.gps = { lat: Math.round(la * 1e6) / 1e6, lon: Math.round(lo * 1e6) / 1e6, acc: Number.isFinite(ac) ? Math.round(ac) : null, t: new Date().toISOString(), par: me.nom }; }
        pos[id] = cur; await save("plan_dae", pos);
        await journal("plan du site", me.nom, `DAE ${id} : ${body.gps ? "position GPS enregistrée" : "placé sur le plan"}`, "info", "#/plan"); return json(pos);
      }
      if (m === "PUT" && r1) {
        if (!peutModif) return deny();
        const t = (v, n = 300) => String(v ?? "").trim().slice(0, n), id = t(r1, 30);
        infos[id] = { effectif: t(body.effectif, 40), ssi: t(body.ssi), dae: t(body.dae), ria: t(body.ria), coupures: t(body.coupures), issues: t(body.issues), rassemblement: t(body.rassemblement), notes: t(body.notes, 1000), maj: new Date().toISOString(), par: me.nom };
        await save("plan_infos", infos); await journal("plan du site", me.nom, `fiche ${id} mise à jour`, "info", "#/plan");
        return json(infos[id]);
      }
      return json({ error: "Méthode non gérée" }, 405);
    }

    /* ---------- Prêt de matériel aux agents (casques anti-bruit, radios, PTI, autres) ---------- */
    if (r0 === "materiel") {
      const liste = await load("materiel", MATERIEL_INITIAL), etat = await load("materiel_etat", {}), hs = await load("materiel_hs", {});
      if (m === "GET" && !r1) return json({ liste, etat, hs });
      if (m === "GET" && r1 === "historique") return json((await load("materiel_mvt", [])).slice(0, 400));
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      if (m === "PUT" && !r1) {
        if (!(await estCoord(me))) return json({ error: "Réservé à la coordination" }, 403);
        const vus = new Set();
        const out = (Array.isArray(body.liste) ? body.liste : []).slice(0, 500).map((c) => ({ n: t(c.n, 12), nom: t(c.nom, 120), type: t(c.type, 60) || "Autres" })).filter((c) => c.n && c.nom && !vus.has(c.n) && vus.add(c.n));
        await save("materiel", out); await journal("matériel", me.nom, `liste du matériel modifiée (${out.length})`, "info", "#/materiel");
        return json({ ok: true, nb: out.length });
      }
      const it = liste.find((c) => c.n === r1); if (!it) return json({ error: "Matériel introuvable" }, 404);
      const mvt = await load("materiel_mvt", []);
      if (m === "POST" && r2 === "pret") {
        if (etat[it.n]) return json({ error: `Déjà prêté à ${etat[it.n].nom}` }, 400);
        const e = { nom: t(body.nom), manif: t(body.manif), ok: body.ok === true, remarque: t(body.remarque, 200), t: new Date().toISOString(), par: me.nom };
        if (!e.nom) return json({ error: "Indique le nom de l'agent" }, 400);
        etat[it.n] = e; await save("materiel_etat", etat);
        mvt.unshift({ id: uid(), n: it.n, objet: it.nom, sens: "prêt", ...e }); await save("materiel_mvt", mvt.slice(0, 5000));
        await journal("matériel", me.nom, `📦 ${it.nom} prêté à ${e.nom}${e.ok ? "" : " · ⚠️ état de fonctionnement non confirmé"}`, e.ok ? "info" : "attention", "#/materiel");
        return json({ etat, hs });
      }
      if (m === "POST" && r2 === "retour") {
        const e = etat[it.n]; if (!e) return json({ error: "Ce matériel n'est pas prêté" }, 400);
        delete etat[it.n]; await save("materiel_etat", etat);
        const ok = body.ok === true, remarque = t(body.remarque, 200);
        if (!ok) { hs[it.n] = { t: new Date().toISOString(), par: me.nom, remarque: remarque || "Rendu hors d'état de fonctionnement", nom: e.nom }; await save("materiel_hs", hs); }
        mvt.unshift({ id: uid(), n: it.n, objet: it.nom, sens: "retour", nom: e.nom, ok, remarque, pret: e.t, t: new Date().toISOString(), par: me.nom }); await save("materiel_mvt", mvt.slice(0, 5000));
        await journal("matériel", me.nom, `✅ ${it.nom} rendu par ${e.nom}${ok ? "" : " · ⚠️ HORS SERVICE" + (remarque ? " : " + remarque : "")}`, ok ? "info" : "attention", "#/materiel");
        if (!ok) await mailPC(`⚠️ Matériel hors service — ${it.nom}`, [["Matériel", it.nom], ["Rendu par", e.nom], ["Constaté par", me.nom], ["Heure", fmtParis(new Date())], ["Remarque", remarque]]);
        return json({ etat, hs });
      }
      if (m === "POST" && r2 === "service") { // remis en service après réparation / vérification
        delete hs[it.n]; await save("materiel_hs", hs);
        mvt.unshift({ id: uid(), n: it.n, objet: it.nom, sens: "remise en service", t: new Date().toISOString(), par: me.nom }); await save("materiel_mvt", mvt.slice(0, 5000));
        await journal("matériel", me.nom, `🔧 ${it.nom} remis en service`, "info", "#/materiel");
        return json({ etat, hs });
      }
    }

    /* ---------- Parcours de ronde NFC (pointeaux) : rédaction propriétaire + coordination ---------- */
    if (r0 === "parcours") {
      if (m === "GET") return json(await load("parcours", PARCOURS_INITIAL));
      if (m === "PUT") {
        if (!(await estCoord(me))) return json({ error: "Réservé à la coordination" }, 403);
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const out = (Array.isArray(body.parcours) ? body.parcours : []).slice(0, 30).map((pc, i) => ({ id: t(pc.id, 40) || "p" + uid(), nom: t(pc.nom) || "Parcours " + (i + 1), site: t(pc.site, 60),
          dureeMax: Math.max(0, Math.min(600, parseInt(pc.dureeMax) || 0)),
          points: (Array.isArray(pc.points) ? pc.points : []).slice(0, 80).map((x) => ({ uid: normUID(x.uid), nom: t(x.nom, 160), consigne: t(x.consigne, 300) })).filter((x) => x.uid && x.nom) })).filter((pc) => pc.points.length);
        await save("parcours", out); await journal("rondes", me.nom, `parcours de ronde modifiés (${out.length})`, "info", "#/rondes");
        return json({ ok: true, nb: out.length });
      }
    }

    /* ---------- Rondes NFC : démarrage, pointages, fin + rapport au PC ---------- */
    if (r0 === "ronde") {
      let list = await load("rondes_nfc", []);
      if (m === "GET" && r1 === "actuelle") return json(list.find((x) => x.agentId === me.id && x.statut === "en cours") || null);
      if (m === "GET") return json((isStaff(me) ? list : list.filter((x) => x.agentId === me.id)).slice(0, 200));
      if (m === "POST" && !r1) {
        if (list.some((x) => x.agentId === me.id && x.statut === "en cours")) return json({ error: "Tu as déjà une ronde en cours : termine-la d'abord" }, 400);
        const pc = (await load("parcours", PARCOURS_INITIAL)).find((x) => x.id === body.parcoursId);
        if (!pc) return json({ error: "Parcours introuvable" }, 404);
        const vac = await vacationDe(me);
        const r = { id: uid(), parcoursId: pc.id, nom: pc.nom, site: pc.site, dureeMax: pc.dureeMax || 0, points: pc.points, agentId: me.id, agent: me.nom,
          poste: vac ? [vac.poste, vac.evenement].filter(Boolean).join(" — ") : "", debut: new Date().toISOString(), fin: null, statut: "en cours", passages: [] };
        list.unshift(r); await save("rondes_nfc", list.slice(0, 3000));
        await journal("rondes", me.nom, `ronde démarrée : ${pc.nom}`, "info", "#/rondes");
        return json(r, 201);
      }
      const r = list.find((x) => x.id === r1);
      if (!r) return json({ error: "Ronde introuvable" }, 404);
      if (r.agentId !== me.id && !estProprio(me)) return deny();
      if (m === "POST" && r2 === "pointage") {
        if (r.statut !== "en cours") return json({ error: "Ronde terminée" }, 400);
        const u = normUID(body.uid), i = r.points.findIndex((x) => x.uid === u);
        if (i < 0) {
          const autre = (await load("parcours", PARCOURS_INITIAL)).flatMap((pc) => pc.points).find((x) => x.uid === u);
          return json({ error: autre ? `Ce pointeau (« ${autre.nom} ») ne fait pas partie de cette ronde` : `Pointeau inconnu (${u || "vide"})` }, 400);
        }
        const photo = typeof body.photo === "string" && body.photo.startsWith("data:image/") && body.photo.length < MAX_PHOTO ? body.photo : null;
        const gps = body.gps && typeof body.gps.lat === "number" && typeof body.gps.lon === "number" ? { lat: +body.gps.lat.toFixed(6), lon: +body.gps.lon.toFixed(6), acc: Math.round(body.gps.acc || 0) } : null;
        const avant = r.passages.find((x) => x.uid === u);
        let pa;
        if (avant && body.photoSeule) pa = { ...avant }; // simple ajout de photo sur un point déjà pointé
        else {
          pa = { uid: u, nom: r.points[i].nom, ordre: i + 1, t: new Date().toISOString(), ras: body.ras !== false, obs: String(body.obs || "").trim().slice(0, 500),
            mode: ["nfc", "lien", "qr", "manuel"].includes(body.mode) ? body.mode : "nfc", photos: 0, gps };
          if (avant) { pa.t = avant.t; pa.mode = avant.mode; pa.photos = avant.photos || 0; pa.gps = avant.gps || gps; pa.tMaj = new Date().toISOString(); } // une anomalie ajoutée après coup garde l'heure de passage
        }
        if (photo) { if ((pa.photos || 0) >= 3) return json({ error: "3 photos maximum par point" }, 400); await save(`photo/${r.id}-${u}-${pa.photos || 0}`, { d: photo, auteurId: me.id }); pa.photos = (pa.photos || 0) + 1; }
        r.passages = r.passages.filter((x) => x.uid !== u); r.passages.push(pa);
        await save("rondes_nfc", list);
        if (!pa.ras && !body.photoSeule) {
          await journal("rondes", me.nom, `⚠️ Anomalie ronde · ${pa.nom} · ${pa.obs}`, "attention", "#/rondes");
          await mailPC(`⚠️ Anomalie de ronde — ${pa.nom} — ${me.nom}`, [...(await lignesAgent(me)), ["Ronde", r.nom], ["Point", pa.nom], ["Heure", fmtParis(pa.t)], ["Anomalie", pa.obs], ["Pointage", pa.mode],
            ["Position", pa.gps ? `https://maps.google.com/?q=${pa.gps.lat},${pa.gps.lon} (±${pa.gps.acc} m)` : ""]], photo ? [photo] : []);
        }
        return json(r);
      }
      if (m === "POST" && r2 === "vu") { // accusé de réception d'une alerte forcée
        const a = list.find((x) => x.id === r1); if (!a) return json({ error: "Alerte introuvable" }, 404);
        a.vus ||= []; if (!a.vus.some((v) => v.id === me.id)) { a.vus.push({ id: me.id, nom: me.nom, t: new Date().toISOString() }); await save("alertes", list); }
        return json({ ok: true, vus: a.vus.length });
      }
      if (m === "POST" && r2 === "fin") {
        if (r.statut !== "en cours") return json(r);
        r.fin = new Date().toISOString(); r.statut = "terminée"; r.obs = String(body.obs || "").trim().slice(0, 1000);
        const faits = new Set(r.passages.map((x) => x.uid)), oublies = r.points.filter((x) => !faits.has(x.uid));
        const ordres = [...r.passages].sort((a, b) => a.t.localeCompare(b.t)).map((x) => x.ordre), ordreOk = ordres.every((o, k) => k === 0 || o > ordres[k - 1]);
        const duree = Math.round((Date.parse(r.fin) - Date.parse(r.debut)) / 60000), anomalies = r.passages.filter((x) => !x.ras), manuels = r.passages.filter((x) => x.mode === "manuel");
        Object.assign(r, { oublies: oublies.length, ordreOk, duree, anomalies: anomalies.length });
        await save("rondes_nfc", list);
        await journal("rondes", me.nom, `ronde terminée : ${r.nom} · ${faits.size}/${r.points.length} points${oublies.length ? ` · ${oublies.length} oublié(s)` : ""}${anomalies.length ? ` · ${anomalies.length} anomalie(s)` : ""}`, oublies.length || anomalies.length ? "attention" : "info", "#/rondes");
        await mailPC(`${oublies.length || anomalies.length ? "⚠️" : "✅"} Rapport de ronde — ${r.nom} — ${me.nom}`, [...(await lignesAgent(me)), ["Ronde", r.nom], ["Début", fmtParis(r.debut)], ["Fin", fmtParis(r.fin)],
          ["Durée", duree + " min" + (r.dureeMax && duree > r.dureeMax ? ` (dépasse ${r.dureeMax} min)` : "")], ["Points pointés", `${faits.size} / ${r.points.length}`], ["Ordre respecté", ordreOk ? "Oui" : "Non"],
          ["Points oubliés", oublies.map((x) => "✖ " + x.nom).join("\n")], ["Anomalies", anomalies.map((x) => `⚠️ ${x.nom} : ${x.obs}`).join("\n")],
          ["Pointés à la main (sans pointeau)", manuels.map((x) => x.nom).join("\n")],
          ["Détail", [...r.passages].sort((a, b) => a.t.localeCompare(b.t)).map((x) => `${fmtParis(x.t).slice(-5)} ${x.ras ? "✔" : "⚠️"} ${x.nom}${x.mode !== "nfc" ? " (" + x.mode + ")" : ""}${x.photos ? ` · ${x.photos} photo(s)` : ""}${x.gps ? ` · https://maps.google.com/?q=${x.gps.lat},${x.gps.lon}` : ""}`).join("\n")],
          ["Observations", r.obs]], await (async () => { const ph = []; for (const x of r.passages) for (let k = 0; k < (x.photos || 0) && ph.length < 10; k++) { const f = await load(`photo/${r.id}-${x.uid}-${k}`, null); if (f) ph.push(f.d); } return ph; })());
        return json(r);
      }
    }

    /* ---------- Check-lists (ouverture, stands, spectacle, fermeture…) ---------- */
    if (r0 === "checklists") {
      let list = await load("checklists", []);
      if (m === "GET") {
        if (!isStaff(me)) list = list.filter((c) => c.agentId === me.id);
        return json(list.slice(0, 300));
      }
      if (m === "POST") {
        const items = Array.isArray(body.items) ? body.items.slice(0, 80).map((x) => ({
          label: String(x.label || "").slice(0, 200), ok: x.ok === true, nc: x.nc === true })) : [];
        const c = { id: uid(), t: new Date().toISOString(), agentId: me.id, agent: me.nom,
          modele: String(body.modele || "").slice(0, 80), evenement: String(body.evenement || "").slice(0, 120),
          lieu: String(body.lieu || "").slice(0, 120), obs: String(body.obs || "").slice(0, 2000), items,
          conforme: items.every((x) => !x.nc) };
        list.unshift(c);
        await save("checklists", list.slice(0, 3000));
        const nc = items.filter((x) => x.nc).length;
        await mailPC(`${nc ? "⚠️ " : "✅ "}Check-list — ${c.modele}${c.lieu ? " — " + c.lieu : ""} — ${me.nom}`, [...(await lignesAgent(me)), ["Envoyée le", fmtParis(c.t)],
          ["Événement", c.evenement], ["Lieu", c.lieu], ["Résultat", nc ? `${nc} non-conformité(s)` : "Conforme"],
          ["Non conforme", items.filter((x) => x.nc).map((x) => "✖ " + x.label).join("\n")], ["Conforme", items.filter((x) => x.ok).map((x) => "✔ " + x.label).join("\n")],
          ["Non vérifié", items.filter((x) => !x.ok && !x.nc).map((x) => "• " + x.label).join("\n")], ["Observations", c.obs]]);
        await journal("check-list", me.nom, `${c.modele}${c.evenement ? " · " + c.evenement : ""}${nc ? ` · ${nc} non-conformité(s)` : " · conforme"}`, nc ? "attention" : "info", "#/site");
        return json(c, 201);
      }
    }

    /* ---------- Compteur de jauge (entrées / sorties par porte) ---------- */
    if (r0 === "jauge") {
      const j = await load("jauge", { evenement: "", max: 0, portes: {}, maj: null });
      const total = () => Object.values(j.portes).reduce((a, p) => a + p.in - p.out, 0);
      if (m === "POST") {
        const porte = String(body.porte || "Porte").slice(0, 40);
        const d = Math.max(-50, Math.min(50, parseInt(body.delta, 10) || 0));
        const p = (j.portes[porte] ||= { in: 0, out: 0 });
        if (body.sens === "sortie") p.out += d; else p.in += d;
        p.in = Math.max(0, p.in); p.out = Math.max(0, p.out);
        j.maj = new Date().toISOString();
        await save("jauge", j);
      }
      if (m === "PUT") {
        if (!isStaff(me)) return deny();
        if (body.reset) j.portes = {};
        if (body.evenement !== undefined) j.evenement = String(body.evenement).slice(0, 120);
        if (body.max !== undefined) j.max = Math.max(0, parseInt(body.max, 10) || 0);
        j.maj = new Date().toISOString();
        await save("jauge", j);
      }
      const t = total();
      return json({ evenement: j.evenement, max: j.max, total: t, maj: j.maj,
        portes: isStaff(me) ? j.portes : undefined, pct: j.max ? Math.round((t / j.max) * 100) : null });
    }

    /* ---------- Sites et zones ---------- */
    if (r0 === "zones" && m === "GET") return json(await load("zones", DEFAULT_ZONES));
    if (r0 === "prestataires" && m === "GET") return json(await load("prestataires", DEFAULT_PRESTATAIRES));

    /* ---------- Rapports libres avec photos (envoyés au mail du PC) ---------- */
    if (r0 === "rapports") {
      let list = await load("rapports", []);
      if (m === "GET") return json((isStaff(me) ? list : list.filter((r) => r.auteurId === me.id)).slice(0, 300));
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const photos = (Array.isArray(body.photos) ? body.photos : []).filter((d) => typeof d === "string" && d.startsWith("data:image/") && d.length < MAX_PHOTO).slice(0, 4);
        const r = { id: uid(), t: new Date().toISOString(), auteurId: me.id, auteur: me.nom, titre: t(body.titre) || "Rapport", site: t(body.site, 60), lieu: t(body.lieu),
          texte: t(body.texte, 6000), gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null, photos: photos.length };
        if (!r.texte && !photos.length) return json({ error: "Écris un texte ou ajoute une photo" }, 400);
        for (let i = 0; i < photos.length; i++) await save(`photo/${r.id}-${i}`, { d: photos[i], auteurId: me.id });
        list.unshift(r); await save("rapports", list.slice(0, 3000));
        await mailPC(`📝 Rapport — ${r.titre}`, [...(await lignesAgent(me)), ["Heure", fmtParis(r.t)], ["Site", ERP(r.site)], ["Lieu", r.lieu], ["Rapport", r.texte],
          ["Position", r.gps ? `https://maps.google.com/?q=${r.gps.lat},${r.gps.lon}` : ""]], photos);
        await journal("rapport", me.nom, `${r.titre}${r.lieu ? " · " + r.lieu : ""}${photos.length ? ` · ${photos.length} photo(s)` : ""}`, "info", "#/rapports");
        return json(r, 201);
      }
    }

    /* ---------- Rapports terrain (DI, malaise, incident, rixe, intrusion…) : photo + mail direct au PC ---------- */
    if (r0 === "rap" || r0 === "di") {
      let list = await load("rap", null);
      if (!list) list = (await load("di", [])).map((d) => ({ ...d, kind: "di", details: { "Type de défaut": d.type }, statut: d.statut === "traitée" ? "clos" : d.statut === "à traiter" ? "ouvert" : d.statut }));
      if (m === "GET") return json((isStaff(me) ? list : list.filter((r) => r.auteurId === me.id || (me.perimetre === "arena" && /arena/i.test(r.site || "")))).slice(0, 800));
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const K = TYPES_RAPPORT[body.kind] || TYPES_RAPPORT.autre;
        const kind = TYPES_RAPPORT[body.kind] ? body.kind : "autre";
        const photos = (Array.isArray(body.photos) ? body.photos : []).filter((d) => typeof d === "string" && d.startsWith("data:image/") && d.length < MAX_PHOTO).slice(0, 4);
        const details = {};
        for (const [k, v] of Object.entries(body.details && typeof body.details === "object" ? body.details : {}).slice(0, 20)) { const x = Array.isArray(v) ? v.map((y) => t(y, 60)).join(", ") : t(v, 300); if (x) details[t(k, 60)] = x; }
        const vac = await vacationDe(me);
        const d = { id: uid(), t: new Date().toISOString(), kind, label: K.lb, auteurId: me.id, auteur: me.nom,
          poste: vac ? [vac.poste, vac.evenement].filter(Boolean).join(" — ") : "", heure: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(body.heure || "") ? body.heure.slice(0, 16) : null,
          urgence: body.urgence === "urgente" ? "urgente" : "normale", site: t(body.site, 60), lieu: t(body.lieu), prestataire: t(body.prestataire, 80),
          details, texte: t(body.texte, 4000), securise: t(body.securise, 500), intervenants: (Array.isArray(body.intervenants) ? body.intervenants : []).map((x) => t(x, 40)).slice(0, 10).join(", "),
          gps: body.gps && typeof body.gps.lat === "number" ? { lat: body.gps.lat, lon: body.gps.lon } : null, photos: photos.length, statut: "ouvert", suivi: [] };
        if (!d.lieu) return json({ error: "Indique la zone" }, 400);
        if (!d.texte) return json({ error: "Décris ce qui s'est passé" }, 400);
        const year = new Date().getFullYear(), cpt = await load("rap_compteur", {});
        cpt[K.pre + year] = (cpt[K.pre + year] || 0) + 1; await save("rap_compteur", cpt);
        d.numero = `${K.pre}-${year}-${String(cpt[K.pre + year]).padStart(4, "0")}`;
        for (let i = 0; i < photos.length; i++) await save(`photo/${d.id}-${i}`, { d: photos[i], auteurId: me.id });
        list.unshift(d); await save("rap", list.slice(0, 8000));
        // trace automatique dans la main courante
        const mc = await load("mc_compteur", {});
        mc[year] = (mc[year] || 0) + 1; await save("mc_compteur", mc);
        await mcAjouter({ id: uid(), numero: `MC-${year}-${String(mc[year]).padStart(4, "0")}`, t: d.t, heure: d.heure, auteurId: me.id, auteur: me.nom, role: me.role,
          evenementId: null, evenement: vac?.evenement || "", categorie: K.lb, gravite: d.urgence === "urgente" ? "urgente" : K.grav || "info",
          site: d.site, lieu: d.lieu, description: `Rapport ${d.numero} : ${d.texte}`, intervenants: d.intervenants, actions: d.securise, prestataire: d.prestataire,
          gps: d.gps, statut: "ouvert", suivi: [], photo: false, rapport: d.numero });
        await mailPC(`${d.urgence === "urgente" ? "🚨 URGENT — " : ""}${K.ic} ${d.numero} — ${K.lb} — ${d.lieu} — ${me.nom}`, [["Rapport", `${K.lb} · ${d.numero}`],
          ...(await lignesAgent(me)), ["Heure du fait", fmtHeure(d.heure)], ["Envoyé le", fmtParis(d.t)],
          ["Urgence", d.urgence === "urgente" ? "URGENTE" : "Normale"], ["Site", ERP(d.site)], ["Zone", d.lieu], ...Object.entries(d.details),
          ["Constat / déroulé", d.texte], ["Mesures prises", d.securise], ["Intervenants", d.intervenants], ["Prestataire concerné", d.prestataire],
          ["Position", d.gps ? `https://maps.google.com/?q=${d.gps.lat},${d.gps.lon}` : ""]], photos);
        await journal("rapport", me.nom, `${d.numero} · ${K.lb} · ${d.lieu}${photos.length ? ` · ${photos.length} photo(s)` : ""}`, d.urgence === "urgente" ? "urgent" : "attention", "#/rap");
        return json(d, 201);
      }
      if (m === "PATCH" && r1) {
        if (!isStaff(me)) return deny();
        const d = list.find((x) => x.id === r1); if (!d) return json({ error: "Rapport introuvable" }, 404);
        if (["ouvert", "en cours", "clos"].includes(body.statut)) d.statut = body.statut;
        const note = String(body.note || "").trim().slice(0, 500);
        d.suivi.push({ t: new Date().toISOString(), qui: me.nom, note: note || "statut : " + d.statut });
        await save("rap", list); await journal("rapport", me.nom, `${d.numero} → ${d.statut}`, "info", "#/rap");
        return json(d);
      }
    }

    /* ---------- Alertes en cours (enfant perdu…) : visibles par tous, disparaissent au bout d'1 h ---------- */
    if (r0 === "alertes") {
      let list = await load("alertes", []); const now = Date.now();
      const actives = () => list.filter((a) => !a.fin && Date.parse(a.exp) > now);
      if (m === "GET") return json({ actives: actives(), recentes: isStaff(me) ? list.filter((a) => Date.parse(a.t) > now - 24 * 3600e3).slice(0, 50) : [] });
      const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
      if (m === "POST" && !r1) {
        const NATURES = ["Enfant perdu", "Personne recherchée", "Personne vulnérable / malaise", "Objet suspect", "Comportement suspect", "Véhicule recherché", "Évacuation / mise à l'abri", "Alerte météo", "Autre"];
        const a = { id: uid(), t: new Date().toISOString(), exp: new Date(now + 3600e3).toISOString(), nature: NATURES.includes(body.nature) ? body.nature : "Autre",
          texte: t(body.texte, 1000), site: t(body.site, 60), lieu: t(body.lieu), auteur: me.nom, auteurId: me.id, fin: null,
          forcee: body.forcee !== false, vus: [{ id: me.id, nom: me.nom, t: new Date().toISOString() }], relances: 0, derniereRelance: new Date().toISOString() };
        if (!a.texte) return json({ error: "Ajoute une description" }, 400);
        list.unshift(a); await save("alertes", list.slice(0, 500));
        await envoyerPush({ titre: `${a.forcee ? "ALERTE FORCÉE" : "ALERTE"} — ${a.nature}`, texte: `${a.lieu ? a.lieu + " · " : ""}${a.texte.slice(0, 160)}${a.forcee ? " — confirme la réception dans l'appli" : ""}`, url: "/#/alertes", alerte: true }, enService).catch(() => 0);
        await journal("alerte", me.nom, `🚨 ${a.nature}${a.lieu ? " · " + a.lieu : ""} · ${a.texte.slice(0, 120)}`, "urgent", "#/alertes");
        await mailPC(`🚨 ALERTE — ${a.nature}${a.lieu ? " — " + a.lieu : ""}`, [...(await lignesAgent(me)), ["Nature", a.nature], ["Site", ERP(a.site)], ["Lieu", a.lieu], ["Description", a.texte], ["Heure", fmtParis(a.t)], ["Fin automatique", fmtParis(a.exp)]]);
        return json(a, 201);
      }
      if (m === "POST" && r2 === "vu") { // accusé de réception d'une alerte forcée
        const a = list.find((x) => x.id === r1); if (!a) return json({ error: "Alerte introuvable" }, 404);
        a.vus ||= []; if (!a.vus.some((v) => v.id === me.id)) { a.vus.push({ id: me.id, nom: me.nom, t: new Date().toISOString() }); await save("alertes", list); }
        return json({ ok: true, vus: a.vus.length });
      }
      if (m === "POST" && r2 === "fin") {
        const a = list.find((x) => x.id === r1); if (!a) return json({ error: "Alerte introuvable" }, 404);
        if (a.auteurId !== me.id && !isStaff(me)) return deny();
        a.fin = { t: new Date().toISOString(), par: me.nom, note: t(body.note, 300) }; await save("alertes", list);
        await journal("alerte", me.nom, `✅ Alerte levée : ${a.nature}${a.fin.note ? " · " + a.fin.note : ""}`, "info", "#/alertes");
        return json({ ok: true });
      }
    }

    /* ---------- Fil de l'eau général Parc / Arena (responsables, PC, propriétaire) ---------- */
    if (r0 === "fil" && m === "GET") {
      if (!isStaff(me)) return deny();
      const du = url.searchParams.get("du") || new Date(Date.now() - 7 * 864e5).toISOString().slice(0, 10), au = url.searchParams.get("au") || "9999";
      const dans = (t) => { const d = String(t || "").slice(0, 10); return d >= du && d <= au; };
      const siteDe = (x) => (/arena/i.test(x || "") ? "Arena" : /parc/i.test(x || "") ? "Parc" : "");
      const out = [];
      for (const i of await mcEntre(du, au)) if (dans(i.t) && !i.rapport) out.push({ t: i.t, fait: i.heure, type: i.categorie === "Prise de service" || i.categorie === "Fin de service" ? "Service" : "Main courante",
        titre: `${i.numero || ""} · ${i.categorie}`, texte: [i.famille && "[" + i.famille + "]", i.description, i.societe && "Société : " + i.societe, i.immat && "Immat. : " + i.immat, i.intervenants && "Intervenants : " + i.intervenants, i.actions && "Actions : " + i.actions].filter(Boolean).join(" — "),
        auteur: i.auteur, site: siteDe(i.site), lieu: i.lieu, niveau: i.gravite, lien: "#/mc", statut: i.statut });
      for (const r of (await load("rap", null)) || []) if (dans(r.t)) out.push({ t: r.t, fait: r.heure, type: "Rapport", titre: `${r.numero} · ${r.label}`,
        texte: [r.texte, ...Object.entries(r.details || {}).map(([k, v]) => `${k} : ${v}`), r.securise && "Mesures : " + r.securise].filter(Boolean).join(" — "),
        auteur: r.auteur + (r.poste ? " (" + r.poste + ")" : ""), site: siteDe(r.site), lieu: r.lieu, niveau: r.urgence === "urgente" ? "urgente" : "moyenne", lien: "#/rap", statut: r.statut, photos: r.photos });
      for (const r of await load("rapports", [])) if (dans(r.t)) out.push({ t: r.t, type: "Rapport", titre: "Rapport libre · " + r.titre, texte: r.texte, auteur: r.auteur, site: siteDe(r.site), lieu: r.lieu, lien: "#/rapports", photos: r.photos });
      for (const r of await load("rondes_nfc", [])) if (dans(r.debut)) { const fait = new Set(r.passages.map((x) => x.uid)).size;
        out.push({ t: r.debut, type: "Ronde", titre: `Ronde · ${r.nom}`, texte: `${fait}/${r.points.length} points${r.statut === "en cours" ? " · en cours" : ` · ${r.duree} min`}${r.oublies ? ` · oubliés : ${r.points.filter((p) => !r.passages.some((x) => x.uid === p.uid)).map((p) => p.nom).join(", ")}` : ""}${r.passages.filter((x) => !x.ras).map((x) => ` · ⚠️ ${x.nom} : ${x.obs}`).join("")}${r.obs ? " · " + r.obs : ""}`,
          auteur: r.agent, site: siteDe(r.site), niveau: r.oublies || r.anomalies ? "moyenne" : "info", lien: "#/rondes" }); }
      for (const c of await load("checklists", [])) if (dans(c.t)) { const nc = c.items.filter((x) => x.nc);
        out.push({ t: c.t, type: "Check-list", titre: "Check-list · " + c.modele, texte: (nc.length ? "Non conforme : " + nc.map((x) => x.label).join(", ") : "Conforme") + (c.obs ? " — " + c.obs : ""), auteur: c.agent, site: siteDe(c.lieu + " " + c.modele), lieu: c.lieu, niveau: nc.length ? "moyenne" : "info", lien: "#/site" }); }
      for (const x of await load("cles_mvt", [])) if (dans(x.t)) out.push({ t: x.t, type: "Clés", titre: `${x.type === "sortie" ? "Clé remise" : "Clé rendue"} · ${x.n} ${x.cle}`,
        texte: x.type === "sortie" ? `À ${x.nom}${x.societe ? " (" + x.societe + ")" : ""}${x.motif ? " · " + x.motif : ""}` : `Par ${x.nom}${x.obs ? " · " + x.obs : ""}`, auteur: x.par, site: /arena/i.test(x.cle) ? "Arena" : "", lien: "#/cles" });
      for (const x of await load("materiel_mvt", [])) if (dans(x.t)) out.push({ t: x.t, type: "Matériel", titre: `${x.sens === "prêt" ? "Prêt" : x.sens === "retour" ? "Retour" : "Remise en service"} · ${x.objet}`,
        texte: x.nom ? `${x.sens === "prêt" ? "À" : "Par"} ${x.nom}${x.ok === false ? " · ⚠️ hors service" : ""}${x.remarque ? " · " + x.remarque : ""}` : "", auteur: x.par, site: "", niveau: x.ok === false ? "moyenne" : "info", lien: "#/materiel" });
      for (const b of await load("batiments_mvt", [])) if (dans(b.t)) out.push({ t: b.t, type: "Bâtiment", titre: `🏢 ${b.libelle}`, texte: `${b.halls.join(", ")} · à la demande : ${({ prestataire: "Prestataire", organisateur: "Organisateur", sploe: "VEV", pc: "PC sécurité", autre: "Autre" })[b.dem.type]}${b.dem.societe ? " " + b.dem.societe : ""}${b.dem.nom ? " (" + b.dem.nom + ")" : ""}${b.commentaire ? " — " + b.commentaire : ""}`,
        auteur: b.par, site: b.halls.every((h) => /arena/i.test(h)) ? "Arena" : b.halls.some((h) => !/arena/i.test(h)) ? "Parc" : "", lien: "#/batiments" });
      for (const a of await load("alertes", [])) if (dans(a.t)) out.push({ t: a.t, type: "Alerte", titre: `🚨 Alerte · ${a.nature}`, texte: a.texte + (a.fin ? ` — levée par ${a.fin.par}${a.fin.note ? " : " + a.fin.note : ""}` : ""), auteur: a.auteur, site: siteDe(a.site), lieu: a.lieu, niveau: "urgente", lien: "#/alertes" });
      for (const d of await load("docs", [])) if (dans(d.t)) out.push({ t: d.t, type: "Document", titre: "Document · " + d.titre, texte: [d.categorie, d.evenement].filter(Boolean).join(" · "), auteur: d.par, site: siteDe(d.site), lien: "#/docs" });
      out.sort((a, b) => String(b.t).localeCompare(String(a.t)));
      return json(out.slice(0, 2000));
    }

    /* ---------- En direct (responsables, PC, admin) ---------- */
    if (r0 === "direct" && m === "GET") {
      if (!isStaff(me)) return deny();
      const inc = await mcRecents(2), rap = await load("rapports", []), dis = (await load("rap", null)) || [];
      const etat = {};
      for (const i of [...inc].reverse()) {
        if (i.categorie === "Prise de service") etat[i.auteurId] = { nom: i.auteur, depuis: i.t, site: i.site, lieu: i.lieu, evenement: i.evenement };
        if (i.categorie === "Fin de service") delete etat[i.auteurId];
      }
      const depuis = Date.now() - 24 * 3600e3;
      const fil = [...inc.filter((i) => Date.parse(i.t) > depuis).map((i) => ({ type: "mc", ...i })),
        ...rap.filter((r) => Date.parse(r.t) > depuis).map((r) => ({ type: "rapport", ...r })),
        ...dis.filter((r) => Date.parse(r.t) > depuis || r.statut !== "clos").map((r) => ({ ...r, type: "rap" }))].sort((a, b) => b.t.localeCompare(a.t)).slice(0, 80);
      return json({ enService: Object.values(etat).filter((e) => Date.now() - Date.parse(e.depuis) < 20 * 3600e3), fil,
        ouverts: inc.filter((i) => i.statut !== "clos" && !/service/i.test(i.categorie)).length, maj: new Date().toISOString() });
    }

    /* ---------- Planning des vacations (protégé par le code PIN) ---------- */
    /* ---------- Évaluation des risques par événement (rédaction : propriétaire + coordinateur PC ; lecture : tous) ---------- */
    if (r0 === "risques") {
      let list = await load("risques", []);
      if (m === "GET") return json(r1 ? list.find((x) => x.id === r1) || null : list.map(({ risques, ...e }) => ({ ...e, nb: risques.length,
        max: Math.max(0, ...risques.map((r) => r.p * r.g)), critiques: risques.filter((r) => r.p * r.g >= 12).length })));
      if (!(await estCoord(me))) return json({ error: "Seuls le propriétaire et le coordinateur PC rédigent les évaluations des risques" }, 403);
      if (m === "DELETE" && r1) { list = list.filter((x) => x.id !== r1); await save("risques", list); await journal("risques", me.nom, "évaluation supprimée", "info", "#/risques"); return json({ ok: true }); }
      if (m === "POST" || m === "PUT") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n), n4 = (v) => Math.min(4, Math.max(1, parseInt(v) || 1));
        const e = { id: m === "PUT" && r1 ? r1 : uid(), maj: new Date().toISOString(), auteur: me.nom, titre: t(body.titre) || "Événement", site: t(body.site, 60),
          date: /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : "", type: t(body.type, 60), effectif: t(body.effectif, 20), organisateur: t(body.organisateur),
          statut: body.statut === "validee" ? "validee" : "brouillon", obs: t(body.obs, 3000),
          risques: (Array.isArray(body.risques) ? body.risques : []).slice(0, 60).map((r) => ({ fam: t(r.fam, 40), r: t(r.r, 160), p: n4(r.p), g: n4(r.g), mesures: t(r.mesures, 800), resp: t(r.resp, 80) })).filter((r) => r.r) };
        const old = list.find((x) => x.id === e.id); e.cree = old?.cree || e.maj;
        list = [e, ...list.filter((x) => x.id !== e.id)].slice(0, 300); await save("risques", list);
        await journal("risques", me.nom, `${e.titre} · ${e.statut === "validee" ? "validée" : "brouillon"}`, "info", "#/risques");
        if (e.statut === "validee" && old?.statut !== "validee") {
          const tri = [...e.risques].sort((a, b) => b.p * b.g - a.p * a.g);
          await mailPC(`⚠️ Évaluation des risques — ${e.titre}${e.date ? " — " + e.date.split("-").reverse().join("/") : ""}`, [["Événement", e.titre], ["Site", ERP(e.site)], ["Type", e.type],
            ["Effectif attendu", e.effectif], ["Organisateur", e.organisateur], ["Validée par", me.nom],
            ["Risques", tri.map((r) => `[${r.p * r.g}] ${r.r}${r.mesures ? " → " + r.mesures : ""}${r.resp ? " (" + r.resp + ")" : ""}`).join("\n")], ["Observations", e.obs]]);
        }
        return json(e, m === "POST" ? 201 : 200);
      }
    }

    /* ---------- Disponibilités des agents (CDD…) : saisie par l'agent, traitement par la coordination ---------- */
    if (r0 === "dispos") {
      const moisOk = (x) => /^\d{4}-\d{2}$/.test(x || "");
      const mois = moisOk(url.searchParams.get("mois")) ? url.searchParams.get("mois") : moisOk(body.mois) ? body.mois : new Date().toISOString().slice(0, 7);
      const key = "dispos/" + mois, all = await load(key, {});
      const QUALIFS = ["ADS", "SSIAP 1", "SSIAP 2", "SSIAP 3"], CRENEAUX = ["jour", "nuit", "jn", "indispo"];
      if (m === "GET" && url.searchParams.get("tous")) {
        if (!isStaff(me)) return deny();
        const coordo = await estCoord(me), users = await load("users", []);
        return json(Object.entries(all).map(([id, d]) => { const u = users.find((x) => x.id === id) || {}; return { id, nom: u.nom || d.nom || id, tel: coordo ? u.tel || "" : undefined, ...d }; })
          .sort((a, b) => a.nom.localeCompare(b.nom)));
      }
      if (m === "GET") return json(all[me.id] || { qualifs: [], jours: {}, note: "", retenus: {} });
      if (m === "PUT") {
        const [y, mo] = mois.split("-").map(Number), maintenant = new Date(), lim = new Date(maintenant.getFullYear(), maintenant.getMonth() + 4, 1);
        if (new Date(y, mo - 1, 1) > lim || new Date(y, mo, 0) < new Date(maintenant.getFullYear(), maintenant.getMonth(), 1)) return json({ error: "Mois non ouvert à la saisie" }, 400);
        const jours = {};
        for (const [d, v] of Object.entries(body.jours || {})) if (d.startsWith(mois + "-") && /^\d{4}-\d{2}-\d{2}$/.test(d) && CRENEAUX.includes(v)) jours[d] = v;
        const old = all[me.id] || {};
        all[me.id] = { nom: me.nom, qualifs: (Array.isArray(body.qualifs) ? body.qualifs : []).filter((q) => QUALIFS.includes(q)), jours,
          note: String(body.note || "").trim().slice(0, 500), retenus: old.retenus || {}, maj: new Date().toISOString() };
        await save(key, all);
        const n = Object.values(jours).filter((v) => v !== "indispo").length;
        await journal("disponibilités", me.nom, `${mois} · ${n} jour(s) disponible(s) · ${all[me.id].qualifs.join(", ") || "qualification non précisée"}`, "info", "#/dispos-admin");
        return json(all[me.id]);
      }
      if (m === "PATCH") { // la coordination retient (ou non) un agent sur une date
        if (!(await estCoord(me))) return json({ error: "Réservé à la coordination" }, 403);
        const d = all[body.agentId]; if (!d) return json({ error: "Agent introuvable" }, 404);
        if (!String(body.jour || "").startsWith(mois + "-")) return json({ error: "Date invalide" }, 400);
        d.retenus = d.retenus || {};
        if (body.retenu) d.retenus[body.jour] = { par: me.nom, t: new Date().toISOString() }; else delete d.retenus[body.jour];
        await save(key, all); await journal("disponibilités", me.nom, `${d.nom} ${body.retenu ? "retenu" : "non retenu"} le ${body.jour.split("-").reverse().join("/")}`, "info", "#/dispos-admin");
        return json(d);
      }
    }

    /* ---------- Mon planning : chaque agent voit uniquement ses vacations ---------- */
    if (r0 === "monplanning" && m === "GET") {
      return json(await planningDe((await load("users", [])).find((x) => x.id === me.id) || me));
    }

    /* ---------- Planning général (responsables, PC, propriétaire) : lecture seule, sans numéros, sans code ---------- */
    if (r0 === "plangen" && m === "GET") {
      if (!isStaff(me)) return deny();
      const d1 = url.searchParams.get("du") || "", d2 = url.searchParams.get("au") || d1;
      const pl = await load("planning", PLANNING_INITIAL);
      return json(pl.filter((v) => v.date >= d1 && v.date <= d2).map(({ date, nom, debut, fin, poste, evenement, site, qualif, code }) => ({ date, nom, debut, fin, poste, evenement, site, qualif, code }))
        .sort((a, b) => (a.date + a.debut + a.nom).localeCompare(b.date + b.debut + b.nom)));
    }

    /* ---------- Documents PC sécurité (plans, consignes, brief, feuille de route…) : seuls le propriétaire et les rédacteurs téléversent ---------- */
    if (r0 === "docs") {
      let docs = await load("docs", []);
      if (m === "GET" && !r1) return json(docs);
      if (m === "GET" && r1) {
        const f = await load("doc/" + r1, null);
        return f ? json(f) : json({ error: "Document introuvable" }, 404);
      }
      if (!(await estRedac(me))) return json({ error: "Seul le responsable PC sécurité peut téléverser des documents" }, 403);
      if (m === "POST") {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const d = String(body.data || "");
        if (!/^data:(application\/pdf|image\/(jpeg|png|webp));base64,/.test(d)) return json({ error: "Format accepté : PDF, JPG ou PNG" }, 400);
        if (d.length > MAX_DOC) return json({ error: "Fichier trop lourd (4 Mo maximum). Compresse le PDF ou découpe-le." }, 413);
        const doc = { id: uid(), t: new Date().toISOString(), titre: t(body.titre) || t(body.nom) || "Document", categorie: t(body.categorie, 60) || "Autre",
          site: t(body.site, 60), evenement: t(body.evenement, 120), date: /^\d{4}-\d{2}-\d{2}$/.test(body.date || "") ? body.date : "",
          nom: t(body.nom, 120), type: d.slice(5, d.indexOf(";")), taille: Math.round((d.length * 3) / 4), par: me.nom };
        await save("doc/" + doc.id, { d, nom: doc.nom, type: doc.type });
        docs.unshift(doc); await save("docs", docs.slice(0, 500));
        await journal("document", me.nom, `${doc.categorie} · ${doc.titre}`, "info", "#/docs");
        return json(doc, 201);
      }
      if (m === "DELETE" && r1) {
        const doc = docs.find((x) => x.id === r1); if (!doc) return json({ error: "Document introuvable" }, 404);
        docs = docs.filter((x) => x.id !== r1); await save("docs", docs); await save("doc/" + r1, null);
        await journal("document", me.nom, `supprimé : ${doc.titre}`, "info", "#/docs");
        return json({ ok: true });
      }
    }

    if (r0 === "planning") {
      if (!isStaff(me) && !(await peutPlanif(me))) return deny();
      let pl = await load("planning", PLANNING_INITIAL);
      if (m === "GET") {
        const d1 = url.searchParams.get("du") || "", d2 = url.searchParams.get("au") || "9999";
        return json(pl.filter((v) => v.date >= d1 && v.date <= d2).sort((a, b) => (a.date + a.debut).localeCompare(b.date + b.debut)));
      }
      if ((m === "PUT" || m === "DELETE") && !(await estCoord(me)) && !(await peutPlanif(me))) return refusProprio();
      if (m === "PUT" && Array.isArray(body.lignes)) {
        const t = (v, n = 120) => String(v ?? "").trim().slice(0, n);
        const lignes = body.lignes.slice(0, 8000).map((l) => ({ id: uid(), date: t(l.date, 10), nom: t(l.nom, 80), tel: String(l.tel || "").replace(/[^\d+]/g, "").slice(0, 15),
          telApproche: l.telApproche === true, debut: t(l.debut, 5), fin: t(l.fin, 5), poste: t(l.poste), evenement: t(l.evenement),
          site: t(l.site, 60), qualif: t(l.qualif, 60), code: t(l.code, 10), source: "import", importePar: me.nom, importeLe: new Date().toISOString() })).filter((l) => /^\d{4}-\d{2}-\d{2}$/.test(l.date) && l.nom);
        const dates = new Set(lignes.map((l) => l.date));
        const sites = new Set(lignes.map((l) => l.site));
        if (body.mode === "remplacer") pl = pl.filter((v) => v.source === "planif" || !(dates.has(v.date) && sites.has(v.site || ""))); // remplace les jours importés, site par site
        pl = [...pl, ...lignes].sort((a, b) => a.date.localeCompare(b.date));
        const limite = new Date(Date.now() - 400 * 864e5).toISOString().slice(0, 10);
        await save("planning", pl.filter((v) => v.date >= limite));
        await journal("planning", me.nom, `${lignes.length} vacation(s) importée(s) sur ${dates.size} jour(s)`, "info", "#/planning");
        return json({ ok: true, importees: lignes.length, jours: dates.size });
      }
      if (m === "PATCH" && r1) { // rappel SMS envoyé (visible par tout le PC)
        const v = pl.find((x) => x.id === r1);
        if (!v) return json({ error: "Introuvable" }, 404);
        v.rappel = body.rappel === false ? null : { t: new Date().toISOString(), qui: me.nom };
        await save("planning", pl);
        if (v.rappel) await journal("sms", me.nom, `rappel de vacation → ${v.nom} (${v.date} ${v.debut}, ${v.site || ""})`, "info", "#/planning");
        return json(v);
      }
      if (m === "DELETE" && r1) {
        await save("planning", pl.filter((v) => v.id !== r1 && v.date !== r1));
        await journal("planning", me.nom, `suppression ${r1}`, "info", "#/planning");
        return json({ ok: true });
      }
    }
    /* ---------- Consignes par poste (ajoutées aux SMS de rappel) ---------- */
    if (r0 === "postes") {
      if (!isStaff(me)) return deny();
      if (m === "GET") return json(await load("postes_consignes", {}));
      if (m === "PUT" && !estProprio(me)) return refusProprio();
      if (m === "PUT" && body.consignes && typeof body.consignes === "object") {
        const c = {};
        for (const [k, v] of Object.entries(body.consignes).slice(0, 2000))
          if (typeof v === "string" && v.trim()) c[String(k).toUpperCase().trim().slice(0, 160)] = v.trim().slice(0, 300);
        await save("postes_consignes", c);
        await journal("planning", me.nom, `consignes par poste mises à jour (${Object.keys(c).length})`, "info", "#/planning");
        return json({ ok: true, nb: Object.keys(c).length });
      }
    }
    if (r0 === "sms" && r1 === "journal" && m === "POST") {
      if (!isStaff(me)) return deny();
      await journal("sms", me.nom, String(body.detail || "").slice(0, 200), "info", "#/sms");
      return json({ ok: true });
    }

    /* ---------- Notifications / historique (administrateurs) ---------- */
    if (r0 === "notifs") {
      if (!isRH(me)) return deny();
      const lus = await load("notifs_lu", {});
      if (m === "GET") {
        const j = await load("journal", []);
        const depuis = lus[me.id] || "";
        return json({ nonLues: j.filter((x) => x.t > depuis && x.qui !== me.nom).length, dernier: j[0]?.t || null, lu: depuis,
          items: url.searchParams.get("compte") ? [] : j.slice(0, 1000) });
      }
      if (m === "POST") { lus[me.id] = new Date().toISOString(); await save("notifs_lu", lus); return json({ ok: true }); }
    }

    /* ---------- Météo ---------- */
    if (r0 === "meteo") {
      let cache = await load("meteo_cache", null);
      if (!cache || Date.now() - cache.at > 10 * 60e3) {
        const data = await fetchPrevisions();
        const mf = await vigilanceMF().catch(() => []);
        const h = data.hourly;
        cache = { at: Date.now(), site: SITE.nom, alertes: [...mf, ...analyser(data)],
          heures: h.time.map((t, i) => ({ h: t.slice(11, 16), temp: h.temperature_2m[i], ress: h.apparent_temperature[i],
            pluie: h.precipitation[i], rafales: h.wind_gusts_10m[i], vent: h.wind_speed_10m[i], code: h.weather_code[i] })) };
        await save("meteo_cache", cache);
      }
      return json(cache);
    }

    /* ---------- Prise de poste SMS (PC / admin) ---------- */
    if (r0 === "sms" && m === "GET") {
      if (!isStaff(me)) return deny();
      const users = await load("users", []);
      return json({
        agents: users.filter((u) => u.actif !== false && u.tel).map(({ id, nom, role, tel }) => ({ id, nom, role, tel })),
        annuaire: await load("sms_annuaire", ANNUAIRE_INITIAL),
        modeleVacation: await load("sms_modele_vacation", null),
        modele: await load("sms_modele", "Bonjour {prenom}, rappel prise de poste {date} à {heure} — {lieu}. Merci de confirmer.\nLe PC Sécurité Parc Expo Valmont / Arena\n04 65 71 00 00"),
      });
    }
    if (r0 === "sms" && m === "PUT") {
      if (!(await estCoord(me))) return refusProprio();
      if (!estProprio(me)) { delete body.modele; delete body.modeleVacation; } // le coordinateur ne gère que les numéros
      if (body.modele !== undefined) await save("sms_modele", String(body.modele).slice(0, 500));
      if (body.modeleVacation !== undefined) await save("sms_modele_vacation", String(body.modeleVacation).slice(0, 500));
      if (Array.isArray(body.annuaire)) await save("sms_annuaire", body.annuaire.slice(0, 500).map((a) => ({
        nom: String(a.nom || "").slice(0, 60), tel: String(a.tel || "").replace(/[^\d+]/g, "").slice(0, 15) })).filter((a) => a.tel));
      return json({ ok: true });
    }

    /* ---------- Administration ---------- */
    /* ---------- Sauvegarde complète des données (propriétaire uniquement) ---------- */
    if (r0 === "sauvegarde" && m === "GET") {
      if (!estProprio(me)) return refusProprio();
      const EXCLUS = new Set(["vapid", "resets"]); // clé privée des notifications et codes de réinitialisation : jamais exportés
      if (!r1) { const cles = (await listeCles()).filter((k) => !EXCLUS.has(k)).sort();
        await journal("admin", me.nom, `sauvegarde complète des données téléchargée (${cles.length} éléments)`); return json({ cles, version: "3.62", t: new Date().toISOString() }); }
      if (r1 === "valeur") { const k = url.searchParams.get("k") || ""; if (!k || EXCLUS.has(k)) return json({ error: "Introuvable" }, 404); return json({ k, v: await load(k, null) }); }
    }

    /* ---------- Historique : suppression complète et exemples de présentation (propriétaire et administrateurs seulement) ---------- */
    if (r0 === "historique") {
      if (!(estProprio(me) || me.role === "admin" || (await estAdminPC(me.id)))) return json({ error: "Réservé au propriétaire et aux administrateurs" }, 403);
      const STORES_L = ["rap", "di", "rapports", "rondes_nfc", "checklists", "cles_mvt", "materiel_mvt", "batiments_mvt", "alertes", "incidents"];
      if (m === "GET") { const idx = await mcIndex(); let mc = 0, demo = 0; for (const mm of idx) { const l = await load("mc/" + mm, []); mc += l.length; demo += l.filter((x) => x.demo).length; }
        const n = {}; for (const k of STORES_L) { const l = (await load(k, [])) || []; n[k] = l.length; demo += l.filter((x) => x.demo).length; }
        return json({ mc, ...n, demo }); }
      if (m === "POST" && r1 === "purger") {
        if (body.confirmation !== "SUPPRIMER") return json({ error: "Tape SUPPRIMER pour confirmer" }, 400);
        for (const mm of await mcIndex()) await save("mc/" + mm, []);
        await save("mc_index", []); await save("mc_migre", true); await save("mc_compteur", {}); await save("rap_compteur", {});
        for (const k of STORES_L) await save(k, []);
        await save("cles_etat", {}); await save("materiel_etat", {}); await save("journal", []); await save("push_dernier", null);
        const fils = await load("msg_fils", {}); for (const id of Object.keys(fils)) await save("msg/" + id, []); await save("msg_fils", {});
        await journal("admin", me.nom, "historique entièrement supprimé (fil de l'eau, main courante, rapports, rondes, clés, alertes)", "attention");
        return json({ ok: true });
      }
      if (m === "POST" && r1 === "notifications") { await save("journal", []); await save("push_dernier", null); await save("push_log", []); return json({ ok: true }); }
      if (m === "POST" && r1 === "exemples-retirer") {
        let n = 0;
        for (const mm of await mcIndex()) { const l = await load("mc/" + mm, []), k = l.filter((x) => !x.demo); if (k.length !== l.length) { n += l.length - k.length; await save("mc/" + mm, k); } }
        for (const k of STORES_L) { const l = (await load(k, [])) || [], g = l.filter((x) => !x.demo); if (g.length !== l.length) { n += l.length - g.length; await save(k, g); } }
        await journal("admin", me.nom, `${n} exemple(s) de présentation retiré(s)`); return json({ ok: true, n });
      }
      if (m === "POST" && r1 === "exemples") { try { return json(await genererExemples(me)); } catch (e) { return json({ error: e.message }, 400); } }
      return json({ error: "Méthode non gérée" }, 405);
    }

    if (r0 === "admin") {
      if (!estProprio(me) && !(COORD_ADMIN.includes(r1) && (await estCoord(me)))) return refusProprio();
      if (r1 === "users") {
        const users = await load("users", []);
        if (m === "GET") return json(users.map(({ pin, ...u }) => u));
        if (m === "PUT") {
          const id = String(body.email || body.id || "").trim().toLowerCase();
          if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(id)) return json({ error: "Adresse e-mail valide requise" }, 400);
          if (!ROLES.includes(body.role)) return json({ error: "Rôle invalide" }, 400);
          let u = users.find((x) => x.id === id), nouveau = false, mdpGen = null;
          if (!u) { u = { id, cree: new Date().toISOString() }; users.push(u); nouveau = true; if (!body.mdp) mdpGen = genMdp(); }
          u.nom = String(body.nom || id).slice(0, 60);
          u.role = body.role;
          u.tel = String(body.tel || "").slice(0, 20);
          u.actif = body.actif !== false;
          u.horsPlanning = body.horsPlanning === true || body.horsPlanning === "on";
          if (body.mdp) {
            if (String(body.mdp).length < 6) return json({ error: "Mot de passe : 6 caractères minimum" }, 400);
            u.pin = hashPin(String(body.mdp));
          }
          if (mdpGen) u.pin = hashPin(mdpGen);
          await save("users", users);
          await journal("compte", me.nom, `compte ${id} ${nouveau ? "créé" : "modifié"} (${u.role})`, "info", "#/admin");
          if (mdpGen) {
            try { await mailMdp(u, mdpGen, true, url.origin); return json({ ok: true, envoye: true }); }
            catch (e) { return json({ ok: true, envoye: false, mdp: mdpGen, erreur: e.message }); } // mail impossible : on montre le mot de passe à l'admin
          }
          return json({ ok: true });
        }
        if (m === "POST" && r2 && parts[3] === "renvoyer") {
          const u = users.find((x) => x.id === decodeURIComponent(r2));
          if (!u) return json({ error: "Introuvable" }, 404);
          const mdp = genMdp(); u.pin = hashPin(mdp); await save("users", users);
          await journal("compte", me.nom, `nouveau mot de passe envoyé à ${u.id}`, "info", "#/admin");
          try { await mailMdp(u, mdp, false, url.origin); return json({ ok: true, envoye: true }); }
          catch (e) { return json({ ok: true, envoye: false, mdp, erreur: e.message }); }
        }
        if (m === "DELETE" && r2) {
          const rid = decodeURIComponent(r2);
          await save("users", users.filter((x) => x.id !== rid));
          const fiches = await load("fiches", {}); delete fiches[rid]; await save("fiches", fiches);
          await journal("admin", me.nom, `compte ${r2} supprimé`);
          return json({ ok: true });
        }
      }
      const simple = { contacts: DEFAULT_CONTACTS, destinataires: DEFAULT_RECIPIENTS, "rondes-points": DEFAULT_RONDES };
      if (r1 in simple) {
        const key = r1 === "rondes-points" ? "rondes_points" : r1;
        if (m === "GET") return json(await load(key, simple[r1]));
        if (m === "PUT" && Array.isArray(body.items)) {
          await save(key, body.items.slice(0, 100));
          await journal("admin", me.nom, `${r1} modifiés`);
          return json({ ok: true });
        }
      }
      if (r1 === "journal") return json(await load("journal", []));
      if (r1 === "code-resp" && m === "GET") return json({ defini: !!(await load("code_resp", null)) });
      if (r1 === "code-resp" && m === "PUT") {
        if (body.fermer) { await save("code_resp", null); await journal("admin", me.nom, "code PIN responsables supprimé"); return json({ ok: true }); }
        if (String(body.code || "").trim().length < 6) return json({ error: "Code responsable : 6 caractères minimum" }, 400);
        await save("code_resp", hashPin(String(body.code).trim()));
        await journal("admin", me.nom, "code PIN responsables modifié", "attention");
        return json({ ok: true });
      }
      if (r1 === "prestataires" && m === "PUT") {
        const z = body.prestataires;
        if (!z || typeof z !== "object" || Array.isArray(z)) return json({ error: "Format invalide" }, 400);
        const out = {};
        for (const [grp, noms] of Object.entries(z).slice(0, 20))
          out[String(grp).slice(0, 60)] = (Array.isArray(noms) ? noms : []).map((x) => String(x).trim().slice(0, 80)).filter(Boolean).slice(0, 100);
        await save("prestataires", out); await journal("admin", me.nom, "liste des prestataires modifiée");
        return json({ ok: true });
      }
      if (r1 === "zones" && m === "PUT") {
        const z = body.zones;
        if (!z || typeof z !== "object" || Array.isArray(z)) return json({ error: "Format invalide" }, 400);
        const out = {};
        for (const [site, secs] of Object.entries(z).slice(0, 10)) {
          out[String(site).slice(0, 60)] = {};
          for (const [sec, zs] of Object.entries(secs || {}).slice(0, 40))
            out[String(site).slice(0, 60)][String(sec).slice(0, 60)] = (Array.isArray(zs) ? zs : []).map((x) => String(x).trim().slice(0, 60)).filter(Boolean).slice(0, 80);
        }
        await save("zones", out); await journal("admin", me.nom, "sites et zones modifiés");
        return json({ ok: true });
      }
      if (r1 === "redacteurs" && m === "GET") return json({ emails: await load("redacteurs", REDAC_DEFAUT) });
      if (r1 === "redacteurs" && m === "PUT") {
        const emails = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((e) => String(e).trim().toLowerCase()).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)))].slice(0, 10);
        await save("redacteurs", emails); await journal("admin", me.nom, `rédacteurs documents : ${emails.length}`, "attention");
        const us = await load("users", []); let ch = false;
        us.forEach((u) => { if (emails.includes(u.id) && AGENTS.includes(u.role)) { u.role = "responsable"; ch = true; } }); if (ch) await save("users", us);
        return json({ ok: true, nb: emails.length });
      }
      if (r1 === "acces24" && m === "GET") return json({ emails: await load("acces24", ACCES24_DEFAUT) });
      if (r1 === "acces24" && m === "PUT") {
        const emails = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((e) => String(e).trim().toLowerCase()).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e !== PROPRIO()))].slice(0, 200);
        await save("acces24", emails);
        // les comptes déjà créés avec ces adresses passent en lecture 24h/24
        const us = await load("users", []); let n = 0;
        for (const u of us) if (emails.includes(u.id) && AGENTS.includes(u.role)) { u.role = "responsable"; n++; }
        if (n) await save("users", us);
        await journal("admin", me.nom, `accès 24h/24 : ${emails.length} adresse(s)`);
        return json({ ok: true, nb: emails.length });
      }
      if (r1 === "admins-pc" && m === "GET") return json({ emails: await load("admins_pc", ADMINS_DEFAUT) });
      if (r1 === "admins-pc" && m === "PUT") {
        if (!estProprio(me)) return refusProprio();
        const emails = [...new Set((Array.isArray(body.emails) ? body.emails : []).map((e) => String(e).trim().toLowerCase()).filter((e) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e) && e !== PROPRIO()))].slice(0, 20);
        await save("admins_pc", emails); await journal("admin", me.nom, `administrateurs : ${emails.join(", ") || "aucun"}`, "attention"); return json({ ok: true, nb: emails.length });
      }
      if (r1 === "mail-pc" && m === "GET") return json({ email: await load("mail_pc", MAIL_PC_DEFAUT) });
      if (r1 === "mail-pc" && m === "PUT") {
        const e = String(body.email || "").trim().slice(0, 300);
        if (e && !e.split(/[,;\s]+/).filter(Boolean).every((x) => /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(x))) return json({ error: "Adresse e-mail invalide" }, 400);
        await save("mail_pc", e); await journal("admin", me.nom, "adresse mail du PC modifiée");
        return json({ ok: true });
      }
      if (r1 === "code-agents" && m === "GET") return json({ defini: !!(await load("code_agents", null)), mode: await load("inscription_mode", "libre") });
      if (r1 === "inscription-mode" && m === "PUT") {
        const md = ["libre", "code", "ferme"].includes(body.mode) ? body.mode : "libre";
        await save("inscription_mode", md); await journal("admin", me.nom, `inscriptions : ${md}`);
        return json({ ok: true });
      }
      if (r1 === "code-agents" && m === "PUT") {
        if (body.fermer) { await save("code_agents", null); await journal("admin", me.nom, "inscriptions des agents fermées"); return json({ ok: true }); }
        if (String(body.code || "").trim().length < 4) return json({ error: "Code : 4 caractères minimum" }, 400);
        await save("code_agents", hashPin(String(body.code).trim()));
        await journal("admin", me.nom, "code d'inscription des agents modifié");
        return json({ ok: true });
      }
      if (r1 === "code-contacts" && m === "GET") return json({ defini: !!(await load("code_contacts", null)) });
      if (r1 === "code-contacts" && m === "PUT") {
        if (String(body.code || "").length < 4) return json({ error: "Code PIN : 4 caractères minimum" }, 400);
        await save("code_contacts", hashPin(String(body.code)));
        await journal("admin", me.nom, "code d'accès aux contacts modifié");
        return json({ ok: true });
      }
      if (r1 === "textes" && m === "PUT") {
        const t = {};
        for (const [k, v] of Object.entries(body.textes || {})) if (/^[a-z0-9.]{2,40}$/.test(k) && typeof v === "string" && v.trim()) t[k] = v.slice(0, 300);
        await save("textes", t);
        await journal("admin", me.nom, "intitulés modifiés");
        return json({ ok: true });
      }
      if (r1 === "test-mail" && m === "POST") {
        const dest = (await load("destinataires", DEFAULT_RECIPIENTS)).filter((d) => d.email);
        await sendMail(dest, "SSIAP Pro — test de la liste de diffusion",
          `<p>Test envoyé par ${me.nom}. Si tu reçois ce mail, les alertes météo et incidents urgents arriveront bien.</p>`);
        return json({ ok: true, envoyes: dest.length });
      }
    }
    return json({ error: "Route inconnue" }, 404);
  } catch (e) {
    return json({ error: e.message }, 500);
  }
};
